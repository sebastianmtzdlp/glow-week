# Pásalo · contenido completo del curso

## 0 · Bienvenida a Pásalo
*Empieza aquí · El curso en 5 minutos*

Este curso es para que la gente hable de lo que haces sin que tengas que rogarle a nadie. Ni a tu tía, ni a tus amigas de la prepa, ni al grupo de WhatsApp de la escuela.

### De qué se trata
Todas conocemos a alguien que publica y publica y nadie comenta. Y todas conocemos el caso contrario: un video sencillo, una frase, un producto que de pronto todo mundo trae en la boca. Parece suerte. No lo es.

Lo que hace que algo se comparta se puede aprender. Hay razones muy concretas por las que la gente le pasa una idea a otra persona, y casi ninguna tiene que ver con tener muchos seguidores o mucho presupuesto. Tiene que ver con **cómo está hecha la idea**.

En este curso vas a conocer **las seis semillas**: seis razones por las que la gente comparte. No necesitas las seis en cada publicación. Con dos o tres bien puestas, tu mensaje ya vuela solo.

> No se trata de gritar más fuerte. Se trata de darle a la gente algo que quiera pasar.

### Las seis semillas
- **Brillo.** Compartimos lo que nos hace ver bien.
- **Ancla.** Hablamos de lo que algo de todos los días nos recuerda.
- **Chispa.** Cuando algo nos mueve, lo pasamos.
- **Vitrina.** Lo que se ve, se copia.
- **Regalo.** Pasamos lo que le sirve a alguien que queremos.
- **Historia.** Las ideas viajan dentro de los cuentos.

### Cómo está armado
- **Clase 1** te explica por qué la plática entre personas vende más que cualquier anuncio.
- **Clases 2 a 8** son las seis semillas, una por una (Brillo tiene dos clases porque da para mucho).
- **Clases 9 y 10** las juntan: cómo revisar cualquier idea con las seis y cómo armar tu primer mes.
- **Herramientas:** la revisión de las seis semillas, ganchos y formatos listos para usar, y tu siembra de cuatro semanas.

### Lo que necesitas
- Algo que quieras que se platique: tu producto, tu negocio, tu equipo o una idea.
- Tu celular y 15 minutos por clase.
- Ganas de probar. Aquí nadie se vuelve viral leyendo; se aprende publicando y viendo qué pasa.

### Antes de empezar
Este curso no promete ventas, seguidores ni videos virales. Te da una forma de pensar tus mensajes para que tengan más probabilidad de compartirse. Y una regla que vale para todo el curso: **nada de exagerar ni de inventar**. Lo que se comparte rápido también se desmiente rápido.

### 🪞 Para pensar
¿Qué fue lo último que le recomendaste a alguien sin que nadie te pagara por hacerlo? ¿Por qué lo hiciste?

### ✍️ Escribe
Escribe en una frase qué quieres que la gente platique de ti. Por ejemplo: "Quiero que cuando alguien busque un buen perfume, mis clientas digan mi nombre."

## 1 · Clase 1 · Así se riega una idea
*Clase · De boca en boca*

Antes de hablar de cómo hacer que algo se comparta, vale la pena entender por qué la plática entre personas pesa tanto.

### La recomendación le gana al anuncio
Piensa en la última vez que probaste un restaurante nuevo, una crema o una serie. Lo más probable es que alguien te lo haya recomendado. Una recomendación de alguien que conoces vale más que cualquier anuncio por dos razones.

**Es más creíble.** El anuncio siempre va a decir que el producto es el mejor. Tu amiga no gana nada con decírtelo, y si algo no le gustó, te lo dice igual.

**Va directo a quien le sirve.** Nadie le recomienda una base de maquillaje a alguien que no se maquilla. Cuando una persona pasa algo, ya pensó a quién le va a servir.

> Una amiga que dice "pruébalo" vende más que cien publicaciones que dicen "cómpralo".

### La mayor parte de la plática no pasa en redes
Esto sorprende: una investigación encontró que solo como el 7 % de las recomendaciones pasan en internet. El resto pasa cara a cara, en la fila de las tortillas, en la junta de la escuela, en la comida del domingo.

Eso no quiere decir que las redes no sirvan. Quiere decir que tu meta no es solo que te vean en el celular. Es que **te mencionen cuando tú no estás**. Un buen video sirve si después alguien dice "oye, ¿viste lo que publicó Ana?".

### No depende de las influencers
Es fácil pensar que para que algo pegue necesitas que lo comparta alguien famosa. Pero los incendios grandes no se hacen con una chispa gigante: se hacen con muchos árboles que agarran fuego uno tras otro. Las ideas que se riegan las pasan cientos de personas normales, como tú y como tus clientas.

Por eso este curso no te va a pedir que busques a la cuenta con más seguidores. Te va a pedir que hagas **una idea que cualquiera quiera pasar**.

### No es suerte, es cómo está hecha la idea
Hay cosas que parecen "naturalmente" interesantes y cosas que parecen aburridas. Pero hay licuadoras, cereales y hasta elotes que se volvieron tema de conversación, y perfumes carísimos de los que nadie habla. La diferencia no está en el producto. Está en cómo se presenta.

Las seis semillas son las razones que se repiten una y otra vez en lo que se comparte. En las siguientes clases las vas a conocer una por una, con ejemplos de venta directa y de contenido.

### Ojo con el "compártelo, porfa"
Pedir que compartan no es una estrategia. A todas nos ha llegado el mensaje en cadena del grupo familiar y lo ignoramos. La gente no comparte para hacerte un favor; comparte por sus propias razones. Tu trabajo es entender esas razones y ponerlas en tu mensaje.

### 🪞 Para pensar
Piensa en tus últimas tres clientas. ¿Cómo llegaron contigo? ¿Cuántas llegaron porque alguien les habló de ti?

### ✍️ Escribe
Haz una lista de cinco cosas que tú has recomendado este año (un producto, un lugar, una serie, una cuenta). Junto a cada una, escribe por qué la recomendaste.

### ✅ Tu tarea de la semana
Pregúntales a tres clientas, de forma casual: "¿Cómo supiste de mí?" o "¿A quién le has platicado del producto?". Anota sus respuestas tal cual.

### 💬 Para compartir en el grupo
Comparte una cosa que recomendaste este año y por qué. Vas a ver que las razones se repiten.

## 2 · Clase 2 · Brillo: lo que te hace ver bien
*Clase · Lo que se cuenta para quedar bien*

La primera semilla es la más humana de todas: compartimos lo que nos hace ver bien ante los demás.

### Lo que compartes dice quién eres
Lo que cuentas en una comida, lo que publicas en tus historias y lo que reenvías dice algo de ti. Que estás enterada. Que tienes buen gusto. Que sabes de algo. Que eres divertida. Por eso a todas nos encanta contar algo que los demás no sabían.

Hablar de una misma se siente bien. Se ha estudiado que a la gente le gusta tanto compartir su opinión que hasta renuncia a un poco de dinero con tal de hacerlo. Eso es Brillo: **la gente comparte lo que la hace brillar a ella**, no lo que te hace brillar a ti.

> La pregunta no es "¿qué quiero decir?". Es "¿cómo va a quedar ella si lo cuenta?".

### Busca lo que sorprende
Lo sorprendente se comparte porque quien lo cuenta queda como alguien interesante. Y casi todo producto tiene algo sorprendente escondido. La clave es encontrarlo.

Una marca de licuadoras se hizo famosa metiendo cosas absurdas a la licuadora para ver si se licuaban. Nadie quiere ver un comercial de licuadoras, pero todo mundo quería ver si se licuaba un celular. Lo que mostraban era lo mismo de siempre (que era una licuadora muy potente), pero dicho de forma que daba ganas de contarlo.

En tu negocio puede ser:
- Un dato curioso de cómo se hace el producto o de un ingrediente.
- Una prueba extrema: el labial que aguantó una boda completa, con fotos de las 8 de la noche y de la 1 de la mañana.
- Un uso que nadie se imagina: el aceite para el pelo que también sirve para las cutículas.

### Cómo encontrar lo sorprendente
Hazte estas preguntas sobre tu producto o tu idea:
1. ¿Qué es lo que la gente no sabe y le haría decir "¿en serio?"?
2. ¿Qué es lo más extremo que aguanta o logra?
3. ¿Qué haría alguien que no se esperaba de esto?
4. ¿Qué preguntan siempre tus clientas la primera vez?

Si la respuesta no te sorprende ni a ti, sigue buscando. Lo sorprendente no se inventa, se descubre.

### Lo sorprendente tiene que ser cierto
Aquí va la regla de la casa: **sorprender no es exagerar**. Si dices que una crema "quita las arrugas en una semana", eso no es Brillo, es una promesa que no puedes cumplir. Y cuando una clienta lo cuenta y no se cumple, la que queda mal es ella. Nunca vuelve a recomendarte.

### 🪞 Para pensar
Cuando le recomiendas algo a una amiga, ¿qué sientes? ¿Qué quieres que piense de ti?

### ✍️ Escribe
Elige un producto que vendas. Responde las cuatro preguntas de "Cómo encontrar lo sorprendente". Subraya la respuesta que más te sorprenda a ti.

### ✅ Tu tarea de la semana
Graba un video corto de 15 a 30 segundos que muestre esa sorpresa. Nada de "compra aquí": solo el dato o la prueba.

### 💬 Para compartir en el grupo
Comparte el dato sorprendente de tu producto. Vamos a ver cuántas del equipo no lo sabían.

## 3 · Clase 3 · Brillo: juego y secreto
*Clase · Estatus y sentirse de adentro*

Hay dos formas más de darle Brillo a algo: convertirlo en juego y hacer que la gente se sienta de adentro.

### Haz que se pueda ganar
A todas nos gusta ir avanzando. Los niveles, las insignias, los sellos de la tarjeta del café. No solo porque nos dan algo, sino porque nos dejan **presumir** que vamos avanzando y que estamos por encima de otras.

Las aerolíneas lo saben: la gente cambia de vuelo y paga de más con tal de no perder su nivel. No por el beneficio, sino por el estatus.

En tu negocio puedes crear tus propios niveles:
- **Para clientas:** la tarjeta de sellos (a la quinta compra, una muestra de regalo), el "Club de las fieles" con un nombre bonito, la clienta del mes.
- **Para tu equipo:** reconocer en público cada logro, aunque sea chiquito. La primera venta, el primer mes completo, la primera persona que se suma.

Lo importante es que el logro **se pueda contar**. Si alguien gana algo y nadie se entera, no hay Brillo.

### Hazla sentir de adentro
Lo que no todas pueden tener se vuelve más valioso. Y quien sí lo tiene, lo cuenta. Esto funciona de dos formas.

**Escaso:** hay poquito. Una edición limitada, un lote pequeño, un tono que solo se consigue una temporada.

**Exclusivo:** hay que conocer a alguien o cumplir algo para entrar. Un grupo cerrado de clientas que se enteran primero de las novedades, una preventa solo para quienes ya te compraron, una clase privada para tu equipo.

Hay un bar escondido detrás de una cabina telefónica dentro de un puesto de hot dogs. No tiene letrero. Y precisamente por eso todo mundo lo platica: quien lo conoce se siente de adentro.

> Lo secreto se cuenta más que lo que se anuncia.

### Con honestidad
Lo escaso y lo exclusivo funcionan cuando son reales. Si cada semana es "la última oportunidad", tus clientas aprenden que no es cierto y dejan de creerte. Usa estas herramientas pocas veces y en serio.

### Cuidado con pagar para que hablen
Cuando le pagas a alguien por recomendarte, la recomendación cambia. Ya no lo hace porque quiere, sino por el pago. Y en cuanto el pago se acaba, la plática también. Si das un regalo, que sea un detalle o un reconocimiento, no un "te pago por cada amiga que traigas". Es más fuerte que alguien te recomiende porque se siente parte de algo.

### 🪞 Para pensar
¿De qué grupo, club o lista te encanta ser parte? ¿Por qué lo cuentas?

### ✍️ Escribe
Diseña un nivel para tus clientas o para tu equipo. Ponle nombre, di qué se necesita para llegar y cómo se va a enterar la gente cuando alguien lo logre.

### ✅ Tu tarea de la semana
Arma algo de adentro: una lista de "las primeras en enterarse", una preventa solo para clientas o un reconocimiento en público para alguien del equipo. Lánzalo esta semana.

### 💬 Para compartir en el grupo
Comparte el nombre de tu nivel o de tu grupo de adentro. Las mejores ideas se las vamos a copiar todas.

## 4 · Clase 4 · Ancla: que algo te recuerde
*Clase · Lo que está en la mente se platica*

La segunda semilla es la más subestimada: la gente habla de lo que tiene en la cabeza, y tiene en la cabeza lo que algo de su día le recuerda.

### Interesante no siempre es suficiente
Lo interesante se platica una vez, el día que lo conoces. Pero lo que se platica todos los días es otra cosa: es lo que el entorno te recuerda. Se ha visto que los productos "aburridos" de uso diario, como el cereal o el detergente, generan más conversación que cosas emocionantes como un viaje a un parque de diversiones. ¿Por qué? Porque el cereal lo ves todas las mañanas.

Hay dos tipos de plática:
- **La de un día:** cuando algo es nuevo y emocionante, se habla mucho y luego se olvida.
- **La de siempre:** cuando algo aparece en la vida diaria, se sigue hablando de él semanas y meses.

Para tu negocio, la que más importa es la segunda.

> Si nada le recuerda tu producto, no importa qué tan bueno sea: no va a hablar de él.

### Busca tu ancla
Un ancla es algo del entorno que hace que la gente piense en ti. Una canción que dice "viernes" se escucha más cada viernes. Una marca de chocolates se ligó al café ("un chocolate con tu café") y sus ventas subieron, porque la gente toma café todos los días.

Para encontrar tu ancla, pregúntate:
1. ¿En qué momento del día alguien usa o necesita lo que vendes?
2. ¿Qué cosa ve, escucha o hace justo en ese momento?
3. ¿Qué tan seguido pasa eso?

Ejemplos:
- **El protector solar:** el ancla es salir de la casa en la mañana. "Llaves, celular, protector."
- **El perfume:** el ancla es el último paso antes de salir. "Antes de la puerta, tu perfume."
- **Tu negocio:** el ancla puede ser el lunes ("lunes de reto"), la quincena, el regreso a clases o la hora del café.

### Que el ancla esté cerca de la decisión
Un ancla funciona mejor cuando aparece justo donde la persona puede actuar. Recordarle a alguien que tome agua cuando está frente al garrafón funciona mejor que un anuncio en la tele. Para ti: tu mensaje sobre el rímel tiene que aparecer cuando ella se está maquillando, no a las 11 de la noche.

### Ojo con las anclas en contra
A veces el entorno le recuerda a la gente algo que no te conviene. Si tu competencia ya es "la del café", tú no lo vas a ganar. Busca un momento que nadie haya tomado.

### 🪞 Para pensar
¿Qué marcas te vienen a la cabeza en automático en algún momento de tu día? ¿Qué es lo que te las recuerda?

### ✍️ Escribe
Elige tu producto estrella y escribe tres anclas posibles: un momento del día, un día de la semana y una temporada del año. Junto a cada una, escribe una frase corta que las una.

### ✅ Tu tarea de la semana
Elige un ancla y úsala tres veces esta semana (por ejemplo, tres lunes de reto o tres publicaciones a la hora del café). Fíjate si alguien te la menciona.

### 💬 Para compartir en el grupo
Comparte tu frase-ancla. Si otra del equipo vende lo mismo, pueden usar la misma y reforzarla juntas.

## 5 · Clase 5 · Chispa: lo que se siente, se comparte
*Clase · Emociones que encienden*

La tercera semilla: cuando algo nos mueve, lo pasamos. Pero no cualquier emoción funciona igual.

### No todas las emociones encienden
Se analizaron cientos de artículos para ver cuáles se compartían más. El resultado fue claro: lo que despierta emociones se comparte más. Pero hay un detalle importante: lo que importa no es si la emoción es buena o mala, sino **si te activa o te apaga**.

Emociones que activan (se comparten mucho):
- **Asombro:** "¡no puede ser!"
- **Emoción y entusiasmo:** "¡ya quiero!"
- **Risa:** "tienes que ver esto"
- **Enojo:** "esto no puede seguir así"
- **Ansiedad:** "¿y si me pasa a mí?"

Emociones que apagan (se comparten poco):
- **Tristeza:** te deja quieta.
- **Satisfacción tranquila:** te sientes bien, pero no te mueve.

> Lo que te pone el corazón a mil es lo que le mandas a alguien.

### El asombro es tu mejor amigo
El asombro es esa sensación de ver algo más grande de lo que esperabas. Una transformación de maquillaje increíble, una historia de superación de alguien del equipo, una clienta de 70 años que se arregló por primera vez en años para la boda de su nieta. Eso no se vende: se siente, y por eso se pasa.

### Encuentra la emoción detrás de los datos
A veces creemos que tenemos que hablar de las características: "dura 12 horas", "tiene vitamina E". Pero eso casi nunca se comparte. Lo que se comparte es lo que significa.

Usa los **tres porqués**: escribe por qué alguien compra tu producto y pregúntate "¿y eso por qué importa?" tres veces.
1. "Compra el labial porque dura todo el día."
2. ¿Por qué importa? "Porque no tiene tiempo de retocarse."
3. ¿Por qué importa? "Porque trabaja, tiene niños y no para."
4. ¿Por qué importa? "Porque merece verse bien aunque nadie le dé un respiro."

Ahí está la emoción. Ese es el video.

### La chispa también funciona fuera del celular
Se ha visto que la gente comparte más cuando está activada físicamente, por ejemplo, después de hacer ejercicio. Esto sirve para tus eventos: una presentación animada, con música y movimiento, hace que la gente salga hablando. Una junta sentada y aburrida, no.

### Con cuidado con el enojo y el miedo
El enojo y la ansiedad se comparten mucho, pero úsalos con respeto. No asustes a nadie para que te compre ("si no usas esto, vas a envejecer"). Eso es manipular. Y nunca hagas promesas de salud para vender.

### 🪞 Para pensar
¿Qué fue lo último que te dio tanto gusto o tanto asombro que se lo mandaste a alguien enseguida?

### ✍️ Escribe
Haz los tres porqués con tu producto estrella. Escribe la emoción que encontraste al final.

### ✅ Tu tarea de la semana
Graba un video o escribe una publicación que cuente esa emoción, no la característica. Si puedes, usa una historia real (con permiso de la clienta).

### 💬 Para compartir en el grupo
Comparte tus tres porqués. Es sorprendente ver cómo cambia el mensaje.

## 6 · Clase 6 · Vitrina: lo que se ve, se copia
*Clase · Hazlo público*

La cuarta semilla: la gente imita lo que ve. Si nadie ve que alguien usa lo que vendes, nadie lo va a copiar.

### Hacemos lo que vemos que otros hacen
Cuando no sabes qué hacer, ves qué hacen los demás. Entre dos restaurantes, eliges el que está lleno. Si toda la oficina usa la misma termo, terminas preguntando dónde la compraron. No es tonto: si mucha gente lo usa, debe ser bueno.

El problema es que mucho de lo que compramos **no se ve**. Nadie sabe qué crema usas, qué suplemento tomas o a qué red de venta perteneces, a menos que tú lo muestres.

> Lo que no se ve, no se puede imitar.

### Haz que lo privado se vea
Hay una campaña famosa de salud masculina en la que, durante un mes, los hombres se dejan crecer el bigote. Un tema privado (la salud) se volvió algo que todo mundo podía ver en la cara de otros. Y cada bigote abría la conversación: "¿y ese bigote?".

¿Cómo hacer visible lo tuyo?
- **El empaque que se queda:** una bolsa bonita, una tarjeta con mensaje escrito a mano, algo que la clienta quiera conservar o mostrar.
- **El detalle que se ve:** una pulsera, un listón o un color que identifique a tu equipo en los eventos.
- **El antes y después:** con permiso, la clienta que muestra su resultado.
- **La foto de la entrega:** que tus clientas suban la foto cuando reciben su pedido.

### Que se anuncie solo
Lo mejor es que el producto se anuncie cada vez que alguien lo usa. Un correo que al final dice "enviado desde tal servicio", unos audífonos de un color diferente que se reconocen de lejos. Piensa en qué parte de tu producto o de tu servicio podría llevar tu marca sin estorbar.

### Deja rastro
Las cosas que se quedan después de comprar siguen hablando por ti: la bolsa que tu clienta reutiliza, la tarjeta con tu número en su espejo, la pulsera del evento. A eso podemos llamarle **rastro**: lo que queda a la vista después de la compra.

### Cuidado con mostrar lo que no quieres
Si quieres que algo no se haga, no muestres que todo mundo lo hace. Decir "nadie del equipo está publicando" hace que más gente deje de publicar, porque lo que ven es que "nadie lo hace". Mejor muestra a las que sí lo hacen.

### 🪞 Para pensar
¿Qué compraste porque viste que alguien más lo tenía?

### ✍️ Escribe
Haz una lista de todo lo que tu clienta ve y toca desde que te compra hasta que usa el producto. ¿En qué momento podrías dejar algo visible?

### ✅ Tu tarea de la semana
Crea un rastro: una tarjeta, una forma de entregar, un hashtag del equipo o un detalle que se quede. Úsalo con tus próximas cinco clientas.

### 💬 Para compartir en el grupo
Sube una foto de tu rastro. Si funciona, lo hacemos de todas.

## 7 · Clase 7 · Regalo: lo que sirve, se pasa
*Clase · Valor práctico*

La quinta semilla: compartimos lo que le puede servir a alguien que queremos. Pasar un buen consejo es una forma de cuidar.

### Ayudar se siente bien
Cuando le mandas a tu hermana el truco para que el delineado le salga igual de los dos lados, no lo haces por presumir. Lo haces porque te importa. Y eso tiene más fuerza de lo que parece. Los videos de consejos prácticos (cómo saber si un aguacate ya está, cómo doblar ropa en dos segundos) se comparten muchísimo porque alguien siempre piensa: "esto le sirve a fulana".

> Un buen consejo es un regalo que se envuelve solo.

### Los consejos que más se comparten
- **Son útiles de verdad:** resuelven algo que la persona quería resolver.
- **Son fáciles de entender:** se ven una vez y se aprenden.
- **Son para alguien en particular:** curiosamente, lo que le sirve a un grupo específico se comparte más que lo que le sirve "a todas", porque te hace pensar en alguien concreto. "Tres trucos de maquillaje para mamás que se arreglan en 5 minutos" se comparte más que "tips de maquillaje".

### Cuando lo que ofreces es un precio
Las ofertas también se comparten, pero no todas igual. Lo que la gente siente como buena oferta depende de con qué lo compara. Por eso:
- **Muestra el precio de referencia:** "antes $450, hoy $350" se siente mejor que solo "$350".
- **Usa la regla del 100:** si el producto cuesta menos de $100, el descuento se ve más grande en porcentaje ("25 % menos"). Si cuesta más de $100, se ve más grande en pesos ("$200 menos"). Haz la cuenta de las dos formas y usa la que suene más grande.
- **Que no sea para siempre:** un tiempo limitado o una cantidad limitada hace que valga la pena contarlo. Pero solo si es cierto.

### Empaqueta lo que sabes
Tú sabes cosas que a ti te parecen obvias y a tus clientas no. Cómo elegir el tono de base, en qué orden se ponen los productos, cómo hacer que el perfume dure más. Ese conocimiento es tu Regalo. Empaquétalo en algo fácil de pasar: un video corto, una imagen con tres pasos, una guía de una página.

Cuando una clienta reenvía tu guía, también te está recomendando a ti.

### La verdad, siempre
Los consejos se comparten tan rápido que a veces se comparte también lo que no es cierto. No caigas en eso. **Nunca compartas "consejos" de salud o resultados que no puedas comprobar**. Ni "esto cura", ni "esto quema grasa", ni "esto quita las manchas en tres días". Tu nombre vale más que una venta.

### 🪞 Para pensar
¿Cuál es el último consejo que reenviaste? ¿A quién y por qué?

### ✍️ Escribe
Escribe diez cosas que sabes de tu producto o de tu tema que tus clientas no saben. Elige la más útil y escríbela como si se la explicaras a una amiga en un audio de 30 segundos.

### ✅ Tu tarea de la semana
Publica tu consejo como video corto o imagen con pasos. Dirígelo a alguien en particular ("para las que tienen piel grasa", "para las que trabajan de noche").

### 💬 Para compartir en el grupo
Comparte tu consejo. Vamos a armar entre todas una colección de regalos para clientas.

## 8 · Clase 8 · Historia: el caballo de Troya
*Clase · Las ideas viajan dentro de los cuentos*

La sexta semilla: las ideas viajan dentro de las historias. Pero la historia tiene que llevar tu mensaje adentro, no nada más entretener.

### Pensamos en historias
Desde chiquitas aprendemos con cuentos. Una historia se recuerda mejor que un dato, se cuenta más fácil y se cree más. Si te digo "este perfume dura mucho", lo olvidas. Si te cuento que una clienta lo usó en su boda y su esposo todavía dice que "huele a ese día", lo recuerdas y lo cuentas.

> La gente no comparte información. Comparte historias, y la información va adentro.

### El caballo de Troya
En la historia antigua, los soldados entraron a la ciudad escondidos dentro de un caballo de madera que parecía un regalo. Así funciona una buena historia: la gente la deja entrar porque es entretenida, y adentro va tu mensaje.

Una buena historia de tu negocio tiene:
- **Una persona real:** tu clienta, tú, alguien del equipo.
- **Un problema que se siente:** algo que le faltaba o le preocupaba.
- **Un cambio:** qué pasó después.
- **Tu producto dentro del cambio:** no al final como anuncio, sino como parte de la historia.

### Que la historia no se coma tu mensaje
Aquí está el truco. Hay comerciales divertidísimos que todo mundo comparte, y aun así nadie recuerda la marca. Se hizo viral, pero no sirvió. Lo que lo hace valioso es que **no se pueda contar la historia sin mencionar tu producto**.

Un ejemplo: unos comerciales en los que un panda destruía todo cuando alguien rechazaba un queso. Eran absurdos y se compartían mucho, pero no se podía contar la historia sin decir "el panda del queso". La marca estaba en el centro.

Pregúntate: si alguien cuenta tu historia a otra persona, ¿va a mencionar tu producto? Si no, la historia necesita ajuste.

### Tu historia, la de tus clientas y la de tu equipo
- **La tuya:** cómo empezaste, qué te hizo quedarte, qué ha cambiado.
- **La de tus clientas:** lo que el producto significó en un momento de su vida (siempre con permiso y sin exagerar resultados).
- **La de tu equipo:** cómo llegó cada una y qué ha aprendido. Estas historias son las que más invitan a otras a sumarse.

### 🪞 Para pensar
¿Qué historia de tu negocio cuentas una y otra vez cuando platicas en persona? Esa es probablemente tu mejor historia.

### ✍️ Escribe
Escribe una historia corta con los cuatro elementos: persona real, problema, cambio y tu producto dentro del cambio. Léela en voz alta: ¿se podría contar sin tu producto?

### ✅ Tu tarea de la semana
Cuenta esa historia en un video o en una publicación. Al final no pongas "compra aquí". Deja que la historia haga el trabajo.

### 💬 Para compartir en el grupo
Comparte tu historia. Ayúdale a otra del equipo a encontrar dónde va su producto en la suya.

## 9 · Clase 9 · Las seis juntas
*Clase · Revisa cualquier idea*

Ya conoces las seis semillas. Ahora vamos a juntarlas, porque la mayoría de las ideas que se riegan usan varias a la vez.

### Una historia de uñas
Hace casi cincuenta años, un grupo de mujeres que llegaron a otro país sin nada, sin hablar el idioma y sin poder ejercer sus profesiones, aprendieron a hacer manicure con la ayuda de una actriz que las visitaba en el campamento donde vivían. Consiguieron trabajo, después abrieron sus propios salones, y la noticia corrió entre su gente. Hoy, buena parte de los salones de uñas de ese país los atienden personas de esa misma comunidad.

¿Cómo pasó? Con las seis semillas:
- **Ancla:** el tema del trabajo salía todos los días entre las recién llegadas.
- **Vitrina:** veían a otras trabajando en los salones.
- **Brillo:** a las que les iba bien les gustaba contarlo.
- **Regalo:** ayudar a una amiga a conseguir trabajo es el mejor consejo.
- **Chispa:** las historias de las que salieron adelante emocionaban.
- **Historia:** todo viajaba en forma de "fíjate que a mi prima le va increíble".

> Ninguna de esas mujeres era famosa. Lo que se riega es la idea, no la persona.

Se parece mucho a cómo crece un equipo de venta directa, ¿verdad?

### No necesitas las seis
No hay que meter las seis semillas en cada publicación. Eso se ve forzado. Con dos o tres bien puestas es suficiente. Lo que sí vale la pena es revisar tu idea con las seis preguntas antes de publicarla. Muchas veces una pequeña vuelta la convierte en algo mucho más fácil de pasar.

### La revisión
Antes de publicar, pregúntate:
1. **Brillo:** ¿quien lo comparta va a quedar bien?
2. **Ancla:** ¿qué de su día a día le va a recordar esto?
3. **Chispa:** ¿qué va a sentir? ¿La activa o la deja quieta?
4. **Vitrina:** ¿se ve cuando alguien lo usa? ¿Queda rastro?
5. **Regalo:** ¿le sirve a alguien en particular?
6. **Historia:** ¿hay una historia? ¿Se puede contar sin mi producto?

Califica cada una del 0 al 2. Si tu idea tiene menos de 4 puntos, busca cómo subir una o dos semillas.

### Un ejemplo
Idea original: "Nuevo labial en promoción."
Revisada: "Lo probé en la boda de mi hermana de 6 de la tarde a 2 de la mañana (Historia). Así se veía a las 2 a.m. (Brillo, sorpresa). Solo esta semana con 25 % menos (Regalo, regla del 100). Para las que van a boda este mes (Regalo para alguien en particular)."

### 🪞 Para pensar
De todas las semillas, ¿cuál se te da más natural? ¿Cuál casi nunca usas?

### ✍️ Escribe
Toma tu última publicación y califícala con las seis preguntas. Después reescríbela para subir al menos dos semillas.

### ✅ Tu tarea de la semana
Publica la versión mejorada y compárala con la anterior. Fíjate en comentarios, mensajes y compartidos, no solo en los "me gusta".

### 💬 Para compartir en el grupo
Comparte el antes y el después de tu publicación con su calificación.

## 10 · Clase 10 · Siembra
*Clase · Tu primer mes*

La última clase es para que lo aprendido se vuelva costumbre. Una idea que se riega no es casualidad: es lo que pasa cuando siembras seguido.

### Siembra, no cosecha
Muchas publicamos una vez, vemos que no pasa nada y concluimos que "no funciona". Pero las semillas no salen al día siguiente. Lo que hace que la gente hable de ti es que aparezcas seguido, con ideas fáciles de pasar, durante semanas.

> No necesitas una idea viral. Necesitas muchas ideas que se puedan pasar.

### Tu mes en cuatro semanas
- **Semana 1 · Brillo y Regalo.** Lo sorprendente de tu producto y un consejo útil para alguien en particular.
- **Semana 2 · Ancla.** Elige tu ancla y úsala tres veces. Que la gente empiece a ligarte con ese momento.
- **Semana 3 · Historia y Chispa.** Una historia real con tu producto adentro y la emoción que encontraste con los tres porqués.
- **Semana 4 · Vitrina y juego.** Tu rastro, tu grupo de adentro o tu nivel. Que se vea quién ya es parte.

La herramienta "Tu siembra de 4 semanas" te lo da día por día.

### Escucha lo que la gente dice
Lo más valioso no son los "me gusta". Son las frases que tus clientas usan cuando hablan de ti. Anótalas. Si dos o tres dicen lo mismo ("es que contigo sí me explicas"), ahí está tu mejor mensaje. Úsalo.

### Para tu equipo
Si lideras un equipo, enséñales las seis semillas. Cuando todas usan la misma ancla, el mismo rastro o el mismo nivel, el efecto se multiplica. Una sola persona hace ruido; un equipo coordinado hace que se platique.

### Lo que no cambia
- Nada de exagerar ni de prometer resultados.
- Nada de mensajes en cadena a tus contactos.
- Nada de pagar para que te recomienden.
- Lo que se riega es lo que la gente quiere pasar. Tu trabajo es dárselo.

### 🪞 Para pensar
¿Qué cambió en tu forma de ver tus publicaciones desde la primera clase?

### ✍️ Escribe
Escribe tu plan de las cuatro semanas con una idea concreta para cada semana.

### ✅ Tu tarea de la semana
Arranca la semana 1 hoy. Agenda en tu celular un recordatorio para cada publicación.

### 💬 Para compartir en el grupo
Comparte tu plan del mes. Busca una compañera para revisarse los avances cada semana.

## 11 · La revisión de las seis semillas
*Herramienta · Antes de publicar*

Usa esta revisión con cualquier idea: una publicación, un evento, una promoción o una invitación al equipo.

### Califica del 0 al 2
- **0:** no la tiene.
- **1:** la tiene un poco.
- **2:** la tiene clarísima.

### Las seis preguntas
1. **Brillo.** ¿Quien lo comparta va a quedar bien? ¿Hay algo sorprendente? ¿Hay un juego, un nivel o algo de adentro?
2. **Ancla.** ¿Qué momento, lugar o cosa de su día le va a recordar esto? ¿Pasa seguido?
3. **Chispa.** ¿Qué va a sentir: asombro, risa, entusiasmo? ¿Encontré la emoción con los tres porqués?
4. **Vitrina.** ¿Se ve cuando alguien lo usa o lo compra? ¿Queda algún rastro?
5. **Regalo.** ¿Le sirve a alguien en particular? ¿Se entiende en una sola vista? Si hay oferta, ¿usé la regla del 100?
6. **Historia.** ¿Hay una persona real y un cambio? ¿Se puede contar sin mencionar mi producto?

### Cómo leer tu resultado
- **0 a 3:** la idea necesita otra vuelta. Busca la semilla más fácil de subir.
- **4 a 7:** buena idea. Con un ajuste puede volar.
- **8 a 12:** lista para salir.

### La revisión de la verdad
Antes de publicar, también contesta:
- ¿Todo lo que digo es cierto y lo puedo comprobar?
- ¿Estoy prometiendo un resultado de salud, de peso o de dinero? Si sí, quítalo.
- ¿Tengo permiso de la clienta para usar su historia o su foto?

## 12 · Ganchos y formatos listos
*Herramienta · Una idea por semilla*

Formatos para cuando no sepas por dónde empezar. Cámbialos a tus palabras y a tu producto.

### Brillo
- "Algo que casi nadie sabe de [producto]…"
- "Lo puse a prueba: [prueba extrema]. Así quedó."
- "Tres usos de [producto] que no te imaginas."
- "Las primeras en enterarse siempre son las del grupo. Hoy les toca a ustedes."

### Ancla
- "Lunes de [tu reto]: hoy toca…"
- "Antes de salir de la casa: llaves, celular y [producto]."
- "Si estás leyendo esto con tu café, esto es para ti."

### Chispa
- "No me lo esperaba: [momento de asombro]."
- La transformación completa en 15 segundos, con música que suba.
- "Esto me pasó hoy y tenía que contárselo a alguien."

### Vitrina
- Foto de la entrega con tu rastro (tarjeta, bolsa, listón).
- "Así llegó el pedido de [nombre de clienta, con permiso]."
- Foto grupal del equipo con su detalle distintivo.

### Regalo
- "Tres trucos para [grupo específico] que [problema]."
- "El orden correcto para ponerte [rutina], en 30 segundos."
- "Hoy está en $[precio] (antes $[precio]). Solo hasta el [fecha]."

### Historia
- "Hace un año, [persona] me escribió porque [problema]…"
- "Cómo llegué a este negocio (y por qué me quedé)."
- "Lo que [clienta] me dijo ayer me tiene pensando…"

### Para cerrar sin rogar
En lugar de "compártelo, porfa", prueba:
- "Mándaselo a la amiga que siempre llega tarde."
- "Guárdalo para tu próximo evento."
- "¿A quién le serviría esto?"

## 13 · Tu siembra de 4 semanas
*Herramienta · Un plan día por día*

Un plan sencillo para practicar las seis semillas durante un mes. Tres publicaciones a la semana y una acción fuera de redes.

### Semana 1 · Brillo y Regalo
- **Lunes:** publica lo sorprendente de tu producto (clase 2).
- **Miércoles:** publica un consejo útil para alguien en particular (clase 7).
- **Viernes:** publica un uso inesperado de tu producto.
- **Fuera de redes:** platícale a tres clientas el dato sorprendente en persona.

### Semana 2 · Ancla
- **Lunes:** presenta tu ancla ("cada lunes les voy a…").
- **Miércoles:** usa tu ancla otra vez.
- **Viernes:** usa tu ancla y pide que te cuenten cómo les fue.
- **Fuera de redes:** pon tu frase-ancla en la tarjeta de tus entregas.

### Semana 3 · Historia y Chispa
- **Lunes:** cuenta tu historia (cómo empezaste o por qué te quedaste).
- **Miércoles:** cuenta la historia de una clienta, con permiso.
- **Viernes:** publica algo que te dé asombro o risa de tu día.
- **Fuera de redes:** cuenta tu mejor historia en la próxima reunión en persona.

### Semana 4 · Vitrina y juego
- **Lunes:** lanza tu rastro o tu detalle visible.
- **Miércoles:** lanza tu nivel o tu grupo de adentro.
- **Viernes:** celebra en público a una clienta o a alguien del equipo.
- **Fuera de redes:** entrega tus pedidos con el rastro nuevo.

### Al final del mes
Contesta:
- ¿Qué publicación generó más mensajes o compartidos?
- ¿Qué frases repitieron tus clientas cuando hablaron de ti?
- ¿Qué semilla te sale más natural y cuál te falta practicar?
