# Despacio · contenido completo del curso

## 0 · Bienvenida a Despacio
*Empieza aquí · El curso en 5 minutos*

Este curso es para que entiendas cómo decide tu cabeza y cómo decide la cabeza de tu clienta. Con eso vendes mejor, creas mejor y te equivocas menos.

### De qué se trata
Dentro de ti hay dos formas de pensar. Una es rápida: reconoce caras, contesta "2 + 2", siente desconfianza antes de saber por qué y decide si un video le gusta en el primer segundo. La otra es lenta: hace cuentas, compara opciones, revisa un plan y se aguanta las ganas de contestar un mensaje enojada.

En este curso les vamos a decir **la Rápida** y **la Lenta**. La Rápida hace casi todo el trabajo del día y casi siempre lo hace bien. La Lenta es la que creemos que manda, pero es floja: si la Rápida ya le dio una respuesta que suena bien, la firma sin revisar.

La mayoría de nuestros errores (comprar de más, prometer fechas imposibles, juzgar mal a una prospecta, rendirnos después de un mal mes) vienen de dejar que la Rápida decida algo que le tocaba a la Lenta. Y casi todas las decisiones de compra de tus clientas también pasan primero por su Rápida.

> Piensa rápido para vivir. Decide despacio cuando importa.

### Cómo está armado
- **Tus dos mentes (clases 1 a 5).** Quién es la Rápida, por qué la Lenta se cansa, por qué lo fácil se siente verdad, por qué sacamos conclusiones con muy poca información y cómo cambiamos una pregunta difícil por una fácil sin darnos cuenta.
- **Cómo decide tu clienta (clases 6 a 9).** El primer número, el miedo a perder, el marco con el que cuentas las cosas y por qué una historia le gana a una estadística. Todo para vender con honestidad, no para manipular.
- **Tu negocio (clases 10 a 12).** Planes que siempre tardan más, rachas buenas y malas que no significan lo que crees, y lo que tu clienta (y tú) recuerdan de una experiencia.
- **Herramientas.** La Pausa (cinco preguntas antes de decidir), el Premortem, el Diccionario de tropiezos y la lista para Vender limpio.

### Lo que necesitas
- Un cuaderno, o el cuaderno de cada clase, que se guarda en tu celular.
- Unos 10 minutos por clase y un ejercicio corto para la semana.
- Ganas de cacharte a ti misma. Es más fácil ver los errores en otras que en una. Por eso el curso te da nombres para cada tropiezo: cuando algo tiene nombre, lo reconoces.

### Una aclaración honesta
Este curso se inspira en un libro de psicología que reúne décadas de investigación. Algunas de esas investigaciones se han vuelto a revisar con los años y no todas salieron igual de fuertes. Aquí nos quedamos con las ideas más sólidas y con lo que te sirve en la vida diaria.

### 🪞 Para pensar
Piensa en una decisión de los últimos meses de la que te arrepientes. ¿La tomaste rápido o despacio? ¿Qué estabas sintiendo en ese momento?

### ✍️ Escribe
Escribe en una frase qué quieres decidir mejor: tu dinero, tu contenido, tus ventas, tu equipo o tus días.

## 1 · Clase 1 · La Rápida y la Lenta
*Tus dos mentes · Las dos que viven en tu cabeza*

Contesta rápido, sin papel: una pluma y una libreta cuestan 110 pesos en total. La pluma cuesta 100 pesos más que la libreta. ¿Cuánto cuesta la libreta?

### La respuesta que salta
Seguro te saltó "10 pesos". Es la respuesta que le sale a casi todo el mundo, incluidas personas muy preparadas. Pero está mal: si la libreta costara 10, la pluma costaría 110 y el total sería 120. La libreta cuesta 5 y la pluma 105.

Lo interesante no es el error. Es que la respuesta equivocada llegó sola, rápida y segura de sí misma. Y que para encontrar la correcta tuviste que detenerte y hacer la cuenta, cosa que casi nadie hace porque "10" suena bien.

### Quién es quién
**La Rápida** trabaja todo el tiempo y sin esfuerzo. Lee la cara de una persona y sabe si está enojada. Maneja por una calle conocida mientras platicas. Completa "pan con…". Siente que un precio es caro o barato. Decide en un segundo si un video le interesa. No la puedes apagar.

**La Lenta** se activa cuando algo exige atención: una multiplicación difícil, llenar una forma, comparar dos planes de celular, morderte la lengua en una discusión. Es la que revisa, la que duda y la que se controla. Pero gastarla cuesta, y por eso prefiere no trabajar.

> La Lenta se cree la protagonista. La que escribe casi todo el guion es la Rápida.

### No es buena ni mala
La Rápida no es tu enemiga. Gracias a ella reaccionas a tiempo, tienes intuición con tu clientela de siempre y puedes grabar un video sin pensar en cada palabra. El problema es que no avisa cuando está fuera de su terreno. Su respuesta equivocada se siente igual de segura que la correcta.

El trabajo de este curso no es pensar despacio todo el día (sería agotador e imposible). Es aprender a reconocer los momentos en los que vale la pena frenar.

### Las señales para frenar
- Hay dinero de por medio, sobre todo si es mucho o es a crédito.
- Sientes urgencia, enojo, emoción o miedo.
- La respuesta llegó demasiado fácil para una pregunta difícil.
- Es una situación nueva para ti.
- Alguien te está presionando para decidir ya.

### En tu negocio
Tu clienta también tiene una Rápida, y es la que ve tus historias. Decide en un segundo si se queda o se va, si le caes bien y si tu producto "se ve bueno". Por eso importa tanto lo que se ve primero. Pero también por eso no la quieres engañar: la Lenta de tu clienta despierta después, cuando ya le llegó el producto, y ahí decide si te vuelve a comprar.

### 🪞 Mírate al espejo
¿En qué tipo de decisiones te dejas llevar por la primera respuesta, aunque después te arrepientas? ¿Compras, mensajes, promesas, precios?

### ✍️ Ejercicio
Esta semana caza tres momentos en los que tu Rápida contestó por ti. Anota qué pasó, qué contestó y si después la Lenta estuvo de acuerdo.

### ✅ Tu tarea de la semana
Escoge una decisión de dinero de esta semana (aunque sea pequeña) y antes de tomarla di en voz alta: "Esto es la Rápida hablando. Déjame hacer la cuenta."

## 2 · Clase 2 · La Lenta se cansa
*Tus dos mentes · Atención, esfuerzo y por qué decides peor cuando estás agotada*

Tu atención es como el saldo del celular: alcanza para lo que alcanza. Si lo gastas en una cosa, no te queda para otra.

### La atención tiene límite
Intenta multiplicar 23 por 47 mientras caminas rápido. Lo más probable es que te detengas sin darte cuenta. Cuando la Lenta trabaja duro, el cuerpo lo nota: las pupilas se agrandan, el corazón se acelera y todo lo demás pasa a segundo plano. Por eso no ves lo que pasa a tu alrededor cuando estás concentrada, y por eso no te conviene revisar un pedido complicado mientras manejas o mientras tus hijos te hablan.

### La ley del menor esfuerzo
Cuando hay dos caminos para llegar al mismo lugar, el cerebro escoge el que cuesta menos. Es su forma natural de ahorrar energía. El problema es que "el que cuesta menos" muchas veces es aceptar la primera idea, seguir haciendo lo de siempre o decir que sí para no pensar.

Hay estudios que sugieren que, después de muchas horas de decisiones seguidas, la gente tiende a escoger la opción por defecto: lo que ya estaba, lo más cómodo, lo que no exige pensar. Los científicos todavía discuten qué tan fuerte es este efecto, pero lo vas a reconocer en ti: en la noche, cansada, compras cosas que en la mañana no comprarías, contestas peor y te rindes más rápido.

> Las decisiones importantes no se toman a las once de la noche.

### El flujo
Hay un estado en el que la Lenta trabaja mucho sin que se sienta pesado: cuando estás tan metida en algo que se te va el tiempo. Editando un video que te encanta, armando un set de regalo, platicando con una clienta que te cae bien. Ahí rindes muchísimo. Busca que tus tareas difíciles se parezcan a eso: un solo foco, sin interrupciones, con un reto a tu medida.

### Para ti
- Pon lo que exige cabeza (cuentas, planes, guiones nuevos, decisiones de compra) en tu horario más fresco.
- Deja para la noche lo mecánico: empacar, programar historias ya hechas, contestar mensajes sencillos.
- Si estás cansada, con hambre o muy emocionada, posterga las decisiones grandes un día. Casi nunca es urgente.
- Una tarea a la vez. Saltar entre el chat, la edición y las cuentas gasta atención en cada salto.

### Para tu clienta
Tu clienta también está cansada. Te ve entre el trabajo, los niños y el tráfico. Si comprarte le exige pensar mucho (preguntar el precio por mensaje, buscar cómo pagar, adivinar qué tono le queda), su Lenta dice "luego" y luego nunca llega. Hazle fácil decir que sí: precio visible, una recomendación clara, un solo paso para pedir.

### 🪞 Mírate al espejo
¿A qué hora del día tomas tus peores decisiones? ¿Qué sueles hacer a esa hora?

### ✍️ Ejercicio
Revisa tu proceso de venta desde los ojos de una clienta cansada. Cuenta cuántos pasos y cuántas preguntas tiene que hacer antes de poder pagarte. Escribe cuáles puedes quitar.

### ✅ Tu tarea de la semana
Elige tu "hora fresca" y protégela tres días esta semana para una sola tarea importante, con el celular en otro cuarto.

## 3 · Clase 3 · Lo fácil se siente verdad
*Tus dos mentes · Por qué creemos lo que nos resulta cómodo*

Tu cabeza tiene un medidor que va de "fácil" a "me cuesta". Y todo lo que marca "fácil" se siente más verdadero, más bonito y más confiable.

### La comodidad mental
Cuando algo se lee fácil, se entiende rápido o ya lo habías visto antes, la Rápida se relaja. Esa sensación de comodidad se mezcla con otras: "esto es cierto", "esto me gusta", "esto es seguro". Cuando algo cuesta trabajo (una letra difícil de leer, una explicación enredada, una idea nueva), la Rápida se pone alerta y la Lenta entra a revisar con más desconfianza.

### Lo que hace que algo se sienta fácil
- **Lo repetido.** Una frase que has escuchado muchas veces se siente verdadera, aunque nadie la haya comprobado. Es la razón por la que los rumores funcionan.
- **Lo conocido.** Mientras más veces ves algo, más te gusta, aunque no te des cuenta de que lo viste. Se llama efecto de mera exposición.
- **Lo claro.** Letra legible, buen contraste, palabras sencillas. Una idea dicha con palabras rebuscadas se siente menos confiable, no más inteligente.
- **Lo que suena bien.** Las frases con ritmo o con rima se recuerdan más y hasta parecen más ciertas.
- **El buen humor.** Cuando estás contenta, la Rápida manda más y la Lenta revisa menos.

> Repetirlo no lo hace verdad. Pero sí lo hace sentir verdad.

### Para tu contenido
Aquí está, en ciencia, la razón de la constancia: que te vean seguido te vuelve conocida, y lo conocido se siente confiable. No necesitas un video viral. Necesitas aparecer seguido con la misma cara, los mismos colores y el mismo tono.

- Escribe como hablas. Frases cortas. Nada de palabras para impresionar.
- Letras grandes y legibles en tus historias, con buen contraste.
- Repite tus ideas clave muchas veces y de muchas formas. A ti te aburre; a tu audiencia apenas le está llegando.
- Ponle a tu oferta un nombre fácil de decir.

### Para ti, como compradora
Esa misma comodidad es la que te hace creer una promesa que has visto mil veces en anuncios, o un "dato" que circula en grupos de WhatsApp. Cuando algo te suena muy cierto, pregúntate: ¿lo sé, o nada más lo he escuchado mucho?

### Con honestidad
Hacer las cosas fáciles de entender es respeto. Repetir algo falso hasta que suene cierto es engaño. Usa la claridad para decir la verdad mejor, nunca para colar una mentira.

### 🪞 Mírate al espejo
¿Qué cosa crees sobre tu negocio, tus productos o las redes que nada más has escuchado repetida, sin haberla comprobado?

### ✍️ Ejercicio
Toma el texto de tu última publicación de venta. Reescríbelo con frases de máximo 12 palabras, sin una sola palabra que no usarías platicando. Compara los dos.

### ✅ Tu tarea de la semana
Escoge tu idea principal (lo que quieres que piensen cuando te ven) y repítela de cinco formas distintas esta semana: un video, una historia, un texto, una foto con frase y una respuesta a una clienta.

## 4 · Clase 4 · Lo que ves es todo lo que hay
*Tus dos mentes · Conclusiones rápidas, primeras impresiones y el efecto halo*

La Rápida es experta en armar una historia con lo poco que tiene enfrente. Y no le preocupa lo que no sabe.

### Lo que ves es todo lo que hay
Si te cuentan que una líder "es inteligente y fuerte", ya te formaste una idea de si sería buena para guiar a un equipo. No preguntaste si es honesta, si es constante o si escucha. La Rápida tomó lo que había, armó una historia coherente y te la entregó con total seguridad.

Esto es clave: **la seguridad que sientes no depende de cuánta información tienes, sino de qué tan bien encaja la historia.** Con poquitos datos que no se contradicen, la historia encaja perfecto. Por eso a veces estamos más seguras cuando sabemos menos.

### El efecto halo
Cuando algo de una persona te gusta, tiendes a que todo lo demás también te guste. Una creadora guapa y bien vestida parece también más confiable, más lista y más honesta. Una prospecta que te contestó seco el primer mensaje parece "difícil" para siempre. El orden también importa: lo primero que ves de alguien pinta todo lo que viene después.

> La primera impresión no es la más cierta. Es la que más pesa.

### Para tu contenido
Tu clienta te juzga con lo que ve. Tu foto de perfil, tu primera línea, los primeros dos segundos del video y tu descripción son su "todo lo que hay". Cuídalos como si fueran lo único que va a ver, porque muchas veces lo son.

### Para tus decisiones
- Antes de decidir sobre una persona (una prospecta, una nueva integrante, una proveedora), pregúntate: ¿qué no sé? ¿Qué necesitaría saber para cambiar de opinión?
- Ten cuidado con los "me late". Si conociste a alguien en un evento y te encantó cómo habla en público, eso no te dice si va a ser constante.
- Si decides en grupo, pídele a cada quien su opinión por escrito antes de platicar. Si hablan primero, todas terminan pensando como la que habló primero.
- Escucha las dos versiones de una historia antes de tomar partido.

### 🪞 Mírate al espejo
Piensa en alguien de tu equipo o de tu clientela de quien te formaste una idea muy rápido. ¿En qué te basaste? ¿Qué no sabías?

### ✍️ Ejercicio
Mira tu perfil como si fueras una desconocida que llega por primera vez. Escribe en tres líneas qué historia arma la Rápida de esa desconocida sobre ti con lo que ve en cinco segundos. ¿Es la que quieres?

### ✅ Tu tarea de la semana
Cambia una sola cosa de tu perfil (foto, primera línea o publicación fijada) para que su "todo lo que hay" diga lo que de verdad quieres decir.

## 5 · Clase 5 · La pregunta fácil
*Tus dos mentes · Cómo cambiamos lo difícil por lo fácil sin darnos cuenta*

Cuando la pregunta es difícil, la Rápida no se queda callada. Contesta otra más fácil y te la entrega como si fuera la respuesta.

### El cambio de pregunta
"¿Este producto me conviene?" es difícil: implica comparar precio, ingredientes, alternativas y cuánto lo vas a usar. "¿Me gusta cómo se ve en el video?" es fácil. Sin darte cuenta, contestas la fácil y sientes que contestaste la difícil.

Pasa todo el tiempo:
- "¿Esta persona va a ser buena socia?" se vuelve "¿me cayó bien en la llamada?".
- "¿Esta estrategia va a funcionar?" se vuelve "¿me emociona?".
- "¿Qué tan feliz estoy con mi vida?" se vuelve "¿cómo me siento hoy?".
- "¿Este negocio es bueno?" se vuelve "¿me cae bien la persona que me lo ofrece?".

### Lo que te gusta te parece bueno
Hay un atajo muy poderoso: cuando algo te gusta, sientes que sus beneficios son grandes y sus riesgos pequeños. Cuando algo no te gusta, todo lo ves al revés. No es que lo analizaste: es que la emoción contestó por ti. Por eso es tan difícil ver los defectos de un plan que te ilusiona.

> Antes de responder, pregúntate: ¿estoy contestando la pregunta que me hicieron o una más fácil?

### Cómo cacharlo
1. Escribe la pregunta real, completa.
2. Escribe lo que de verdad te hizo decidir.
3. Si no son lo mismo, ya encontraste el cambio.
4. Busca un dato que conteste la pregunta real (números, opiniones de otras, experiencia de casos parecidos).

### Para tu clienta
Tu clienta también cambia preguntas. "¿Esta crema le va a servir a mi piel?" es difícil; "¿la que me la vende se ve confiable y su piel se ve bien?" es fácil. Eso explica por qué tu forma de presentarte importa tanto. Pero también es una responsabilidad: ayúdale a contestar la pregunta real. Dile para qué tipo de piel sí y para cuál no, cuánto dura, cómo se usa. Una clienta que contestó la pregunta real regresa.

### 🪞 Mírate al espejo
¿Qué decisión reciente tomaste porque "te emocionó" o "te cayó bien" y no porque contestaste la pregunta real?

### ✍️ Ejercicio
Elige una decisión que tengas pendiente. Escribe arriba la pregunta real y abajo la pregunta fácil que tu Rápida quiere contestar. Luego anota tres datos que te ayudarían con la real.

### ✅ Tu tarea de la semana
En tus próximas tres recomendaciones de producto, ayuda a la clienta con la pregunta difícil: dile para quién es, para quién no y qué resultado puede esperar de verdad.

## 6 · Clase 6 · El primer número
*Cómo decide tu clienta · Anclas: por qué el primer precio cambia todo lo que sigue*

Si alguien te pregunta "¿cuánto crees que cueste?" justo después de mencionar el número 900, vas a decir un número más alto que si antes hubiera dicho 90. Aunque sepas que el 900 no tenía nada que ver.

### Qué es un ancla
El primer número que escuchas se queda como punto de partida. Luego lo ajustas, pero casi siempre te quedas corta: terminas más cerca del ancla de lo que crees. Pasa con precios, con sueldos, con descuentos, con metas y hasta con números totalmente al azar. Y le pasa también a la gente experta.

Funciona de dos formas. La Lenta empieza en el ancla y se mueve poco, porque ajustar cuesta trabajo. Y la Rápida, sin que te des cuenta, empieza a buscar razones por las que el ancla podría ser cierta.

> El primer número no informa. Ancla.

### Para presentar tus precios con honestidad
- **El orden importa.** Si muestras primero el set completo y luego el producto suelto, el suelto se siente accesible. Al revés, el set se siente caro. Muestra primero lo que de verdad le recomendarías a tu clienta.
- **El precio de referencia real.** Si hay un precio regular y uno de promoción, enseña los dos. Pero solo si el regular es real. Inventar un "antes" para que el "ahora" parezca descuento es engaño, y en muchos lugares también es ilegal.
- **El valor antes del precio.** Si lo primero que tu clienta escucha es el número, ese número es el ancla. Si primero escucha qué incluye y cuánto le dura, el número llega con contexto.

### Para defenderte
Las anclas también te las ponen a ti: el proveedor que te dice "normalmente esto cuesta el doble", la meta absurda de alguien más, el "todas venden mil al mes".
- Antes de ver un precio o una oferta, decide tu número: lo que estás dispuesta a pagar o lo que esperas lograr.
- Si te lanzan un ancla absurda, no la discutas punto por punto: di que esa no es una base para negociar y propón la tuya.
- Piensa en argumentos contra el ancla: ¿por qué podría ser mucho menos?

### Metas y anclas
Las metas también anclan. Si te pones como referencia lo que vende la líder más grande de tu país, todo lo tuyo se va a sentir poco. Si tu referencia es tu propio mes pasado, puedes ver tu avance.

### 🪞 Mírate al espejo
¿Qué número tienes en la cabeza como "lo normal" en tu negocio? ¿De dónde salió?

### ✍️ Ejercicio
Revisa cómo presentas tu producto estrella. Escribe en qué orden aparecen el valor y el precio, y reescríbelo para que tu clienta escuche primero para qué le sirve.

### ✅ Tu tarea de la semana
Antes de tu próxima compra o negociación grande, escribe tu número antes de ver el de la otra persona. Al final compara.

## 7 · Clase 7 · Perder duele el doble
*Cómo decide tu clienta · Aversión a la pérdida, lo que ya es tuyo y el punto de referencia*

Imagina que te ofrecen una apuesta con una moneda: si sale águila ganas 1,000 pesos y si sale sol pierdes 1,000. La mayoría dice que no. Para aceptar, casi todos piden poder ganar el doble de lo que pueden perder.

### Las pérdidas pesan más
Perder algo duele bastante más de lo que alegra ganar lo mismo. En los experimentos, para sentir que una apuesta "vale la pena", la gente pide ganar entre una vez y media y dos veces y media lo que arriesga. Es una herencia de cuando perder algo podía costarte la vida.

Esto explica muchas cosas:
- Te cuesta más dejar algo que ya tienes que no conseguirlo nunca.
- Una mala reseña te pega más que diez buenas.
- Un mes malo te pesa más de lo que te alegró el mes bueno.
- Las personas defienden lo que tienen con más fuerza que la que ponen en conseguir algo nuevo.

### Todo depende del punto de referencia
No sentimos las cosas por cómo estamos, sino por cómo cambiamos respecto a algo. Ganar 8,000 en un mes se siente increíble si esperabas 5,000, y se siente como fracaso si esperabas 12,000. Tu punto de referencia (lo que esperabas, lo que tenías, lo que tiene otra) decide si algo se siente como ganancia o como pérdida.

### Lo que ya es tuyo vale más
Cuando algo ya es tuyo, de pronto vale más para ti. Una taza que te regalaron te parece valer más que la misma taza en la tienda. Por eso las muestras y las pruebas funcionan: una vez que tu clienta probó la crema y la siente suya, dejar de usarla se siente como una pérdida.

> No es que tu clienta no quiera ganar. Es que no quiere perder.

### Para vender con honestidad
- **Las muestras son tu mejor amiga.** Deja que la clienta pruebe, use y sienta el producto como suyo.
- **Habla de lo que se pierde, sin miedo falso.** "Si tu piel se reseca en invierno, esto evita que llegues a marzo con la cara irritada" es honesto. "Última oportunidad en tu vida" cuando no lo es, es manipulación.
- **Ojo con subir precios.** La gente siente injusto que le quites algo que ya considera suyo. Si tienes que subir, explica por qué: a tu clienta le parece justo que protejas tu ganancia cuando a ti también te subieron los costos.
- **Garantías y devoluciones.** Bajan el miedo a perder y hacen que decir que sí cueste menos.

### Para ti
Tu miedo a perder también te frena: no lanzas el producto nuevo por miedo a que no se venda, no dejas el proveedor que ya no te conviene, no subes tu precio. Pregúntate: si no tuviera esto, ¿lo escogería hoy?

### 🪞 Mírate al espejo
¿Qué estás conservando (un producto, un método, una relación de trabajo) solo porque soltarlo se siente como perder?

### ✍️ Ejercicio
Escribe tres cosas que tu clienta pierde por no usar tu producto. Que sean ciertas y concretas, sin exagerar.

### ✅ Tu tarea de la semana
Arma un plan de muestras: a quiénes vas a dar a probar esta semana, qué producto y cuándo les vas a preguntar cómo les fue.

## 8 · Clase 8 · El marco
*Cómo decide tu clienta · La misma verdad contada de dos formas*

"Este tratamiento tiene 90% de éxito" y "este tratamiento falla en 10% de los casos" dicen exactamente lo mismo. Pero la gente, incluidos los médicos, escoge muy distinto según cuál escuche.

### Qué es el marco
El marco es la forma en que presentas una información: como ganancia o como pérdida, como parte de algo más grande o por separado, con un número o con otro. La Rápida no traduce de un marco a otro; reacciona al que le diste. Así que dos frases que significan lo mismo pueden producir decisiones opuestas.

### Ejemplos que vas a reconocer
- "Ahorras 200 pesos" se siente distinto de "pagas 200 pesos menos".
- "Menos de 10 pesos al día" se siente distinto de "290 al mes".
- "Usado por 9 de cada 10" suena mucho mejor que "1 de cada 10 no lo recomienda".
- Un cargo extra por pagar con tarjeta molesta más que un descuento por pagar en efectivo, aunque la diferencia sea igual.

### Lo que viene marcado por defecto
Uno de los marcos más poderosos es lo que pasa si no haces nada. Si para dejar de recibir algo hay que palomear una casilla, casi nadie la palomea. Si para recibirlo hay que palomearla, casi nadie la palomea tampoco. La gente se queda con la opción que ya venía puesta.

En tu negocio: si invitas a tu clienta a "avísame si quieres que te mande la novedad del mes", pocas te avisan. Si le preguntas "¿te la aparto como siempre, o este mes no?", muchas dicen que sí. Usa este poder con cuidado: que la opción por defecto sea la que de verdad le conviene, y que decir que no sea igual de fácil.

> Tú no cambias los hechos. Escoges desde dónde se miran.

### Ampliar el marco
Cuando miras una decisión sola, se siente enorme. Cuando la miras junto con todas las parecidas, se ve en su tamaño real. Una publicación que no funcionó se siente como un desastre; vista entre las cien que vas a hacer este año, es un dato más. Ampliar el marco te ayuda a arriesgarte con calma.

### La regla de oro
Un marco honesto ayuda a entender. Un marco tramposo esconde algo que la clienta querría saber. Antes de publicar, pregúntate: si mi clienta viera la información completa, ¿se sentiría engañada? Si la respuesta es sí, cambia el marco.

### 🪞 Mírate al espejo
¿Cómo te cuentas a ti misma tus resultados? ¿En marco de lo que lograste o de lo que te faltó?

### ✍️ Ejercicio
Escribe la misma oferta de tres formas: como ganancia, como pérdida que evitas y como costo por día. Elige la que sea más clara y honesta para tu clienta.

### ✅ Tu tarea de la semana
Revisa tu mensaje de reorden o de seguimiento. Cámbialo para que la opción por defecto sea la que le conviene a tu clienta y que decir que no sea igual de fácil.

## 9 · Clase 9 · Una historia le gana a un número
*Cómo decide tu clienta · Disponibilidad, casos concretos y muestras demasiado chicas*

Si te pregunto si es más común que la gente se enferme por una cosa o por otra, vas a contestar según qué tan fácil te vienen ejemplos a la mente. No según los datos.

### Lo que viene a la mente
La Rápida calcula qué tan común es algo por lo fácil que recuerda ejemplos. Si viste en las noticias dos casos de algo, te parece frecuente. Si una amiga te contó su mala experiencia con un producto, te parece que "a todas les pasa". Lo reciente, lo dramático y lo personal pesan muchísimo más de lo que deberían.

### Las historias mueven, los números no tanto
A la gente le cuesta cambiar de opinión con estadísticas. Pero un solo caso concreto, con cara y nombre, la mueve. No porque sea más cierto, sino porque la Rápida piensa en historias.

Para tu contenido, esto es oro: **un testimonio real y específico le gana a cualquier porcentaje.** "Mi clienta Ana tenía la piel tan reseca que se le pelaba la nariz, y en dos semanas dejó de pasarle" se queda en la cabeza. "92% de satisfacción" no.

> La gente no recuerda tus datos. Recuerda a la persona de tu historia.

### Con honestidad
- Usa historias reales, con permiso de quien las vivió.
- Que sean casos típicos, no el único milagro entre cien. Si escoges solo el caso extraordinario, la clienta espera eso y luego se decepciona.
- No prometas lo que le pasó a una como si le fuera a pasar a todas.

### La trampa de los números chicos
Al revés también te engaña. Con pocos datos, los resultados se ven extremos por pura casualidad. Tres videos que funcionaron no son una fórmula. Dos prospectas que dijeron que no no significan que tu mensaje está mal. Una semana buena no significa que ya encontraste el camino.

- Antes de concluir algo, junta suficientes casos: al menos 10 o 20 publicaciones de un tipo antes de decidir si funciona.
- Cuando alguien te dice "a mí me funcionó", pregunta a cuántas les funcionó y a cuántas no.

### El regreso al promedio
Después de algo extraordinario, lo normal es que venga algo más normal. Tu video que explotó probablemente fue en parte talento y en parte suerte; el siguiente va a funcionar menos, y no es porque "ya no le gustas al algoritmo". Igual al revés: después de un mes muy malo, lo más probable es que el siguiente sea mejor, aunque no cambies nada.

Esto importa para liderar. Si regañas a alguien después de un mes malo y al siguiente mejora, vas a creer que el regaño funcionó. Si felicitas a alguien después de un mes buenísimo y luego baja, vas a creer que la felicitación la relajó. Las dos cosas pueden ser puro regreso al promedio.

### 🪞 Mírate al espejo
¿Qué conclusión sacaste de tu negocio con muy pocos casos? ¿Qué historia de otra persona te hizo creer algo que no has comprobado?

### ✍️ Ejercicio
Escribe el testimonio de una clienta real como historia: cómo estaba antes, qué probó, qué notó y en cuánto tiempo. Concreto, sin exagerar. Pídele permiso para compartirlo.

### ✅ Tu tarea de la semana
Elige un tipo de contenido que quieras probar y comprométete a hacer 10 antes de juzgarlo. Anota los resultados de cada uno.

## 10 · Clase 10 · El plan que siempre tarda más
*Tu negocio · Optimismo, la mirada de afuera y el premortem*

Cuando planeas algo, te imaginas cómo va a salir si todo sale bien. Por eso casi todos los planes tardan más y cuestan más de lo que pensabas.

### La falacia de la planeación
Un equipo de expertos calculó que terminaría un proyecto en dos años. Cuando le preguntaron a uno de ellos cuánto habían tardado otros equipos en proyectos parecidos, la respuesta fue: entre siete y diez años, y casi la mitad nunca terminó. Aun sabiendo eso, siguieron con su plan. Tardaron ocho años.

Así funcionamos. Desde adentro vemos nuestro caso, nuestras ganas y nuestro talento. No vemos todo lo que puede salir mal, porque son mil cosas distintas y no se pueden imaginar una por una.

### La mirada de afuera
La solución es dejar de mirar solo tu caso y preguntar cómo les fue a otras en casos parecidos:
1. ¿Qué tipo de proyecto es? (lanzar una línea, abrir un canal nuevo, llegar a un rango, organizar un evento)
2. ¿Cuánto les tardó y les costó a otras que lo hicieron?
3. ¿Mi caso tiene razones reales para ser mejor o peor que ese promedio?
4. Ajusta tu plan desde ese promedio, no desde tu ilusión.

### El optimismo, bendición y riesgo
El optimismo te hace empezar cosas, aguantar los golpes y levantarte. Sin él no existiría ningún negocio. Pero también te hace creer que controlas más de lo que controlas, que tu competencia no existe y que sabes más de lo que sabes. Quédate con su energía para actuar y usa la Lenta para planear.

> Optimista para empezar. Realista para planear.

### El premortem
Antes de lanzar algo importante, junta a dos o tres personas (o siéntate sola) y di: "Imagina que pasó un año. Lo hicimos tal como está planeado y fue un desastre. Escribe en cinco minutos la historia de ese desastre." Sale todo lo que nadie se atrevía a decir. Luego decides qué cambiar.

Funciona porque vuelve normal dudar. En un equipo emocionado, nadie quiere ser la aguafiestas; el premortem hace que buscar fallas sea parte del trabajo.

### Lo que ya invertiste
Seguir en algo que no funciona solo porque ya le metiste mucho tiempo o dinero es otra trampa. Lo que ya gastaste no regresa, decidas lo que decidas. La pregunta útil es: si empezara hoy desde cero, ¿escogería esto?

### 🪞 Mírate al espejo
¿Qué plan de los últimos meses tardó mucho más de lo que pensabas? ¿Qué no viste venir?

### ✍️ Ejercicio
Toma tu próximo proyecto y haz el premortem: escribe la historia de cómo salió mal dentro de seis meses. Luego subraya las tres causas más probables.

### ✅ Tu tarea de la semana
Pregúntale a dos personas que ya hicieron algo parecido a tu proyecto cuánto tiempo les tomó de verdad. Ajusta tu fecha.

## 11 · Clase 11 · Suerte, rachas e historias de éxito
*Tu negocio · Por qué el pasado parece obvio y cuándo confiar en tu intuición*

Después de que algo pasa, parece que era obvio. "Se veía venir." Pero antes no se veía tan claro.

### La historia perfecta
Nos encantan las historias de éxito: la líder que empezó desde cero y llegó a la cima, la creadora que se hizo viral con un solo video. Las contamos simples, con mucho talento, buenas decisiones y casi nada de suerte. Pero en la vida real, la suerte pesa muchísimo, y las historias de quienes hicieron exactamente lo mismo y no llegaron nunca se cuentan.

Cuando copias la receta de alguien exitosa, recuerda: estás viendo una sola historia, contada al final, con lo que salió bien. Aprende de ella, pero no la tomes como garantía.

### Juzgar por el resultado
Si una decisión sale bien, decimos que fue buena; si sale mal, que fue tonta. Pero una buena decisión puede salir mal por mala suerte, y una tonta puede salir bien por pura suerte. Juzga tus decisiones (y las de tu equipo) por cómo se tomaron con la información que había, no solo por cómo salieron.

> Una decisión buena no siempre sale bien. Pero a la larga, decidir bien gana.

### Cuándo sí confiar en tu intuición
La intuición de una experta es real. Una líder con años de experiencia puede "sentir" en una llamada que una prospecta no está lista. Pero solo es confiable cuando se cumplen dos condiciones:
1. **El ambiente tiene reglas que se repiten.** Lo que funcionó muchas veces vuelve a funcionar.
2. **Tuviste mucha práctica con retroalimentación rápida y clara.** Hiciste algo, viste rápido si funcionó y lo hiciste muchas veces.

Tu intuición para saber qué tono le queda a una clienta que atiendes desde hace años puede ser muy buena. Tu intuición para adivinar qué video se va a hacer viral o cómo va a estar la economía el próximo año, no tanto: ahí las reglas cambian y la suerte manda. Y ojo: sentirte muy segura no es prueba de que tengas razón.

### Las fórmulas sencillas
Para muchas decisiones que se repiten (a quién darle seguimiento primero, a quién invitar a tu equipo), una lista sencilla de criterios le gana al "me late". Escoge 4 o 5 cosas que de verdad importan, califícalas del 1 al 5 y súmalas. Después, si quieres, usa tu intuición, pero no antes.

### 🪞 Mírate al espejo
¿Qué historia de éxito estás tratando de copiar? ¿Cuánta de esa historia fue suerte que no se cuenta?

### ✍️ Ejercicio
Piensa en una decisión que salió mal. Escribe qué sabías cuando la tomaste. Con esa información, ¿fue una mala decisión o una buena decisión con mala suerte?

### ✅ Tu tarea de la semana
Arma tu lista de criterios para decidir algo que repites mucho (por ejemplo, a qué prospectas darles seguimiento primero). Úsala toda la semana antes de tu "me late".

## 12 · Clase 12 · Lo que se recuerda
*Tu negocio · El final, el mejor momento y lo que de verdad te hace feliz*

Hay dos "tú": la que vive cada momento y la que después recuerda. Y la que recuerda es la que decide si vuelves.

### La que vive y la que recuerda
En un estudio, la gente metió la mano en agua helada dos veces. Una vez fueron 60 segundos de agua muy fría. Otra vez fueron esos mismos 60 segundos y luego 30 segundos más en agua un poquito menos fría. La segunda vez sufrieron más tiempo en total. Y aun así, cuando les preguntaron cuál repetirían, la mayoría escogió la segunda. ¿Por qué? Porque terminó mejor.

### La regla del pico y el final
Cuando recordamos una experiencia, no sumamos todos los momentos. Nos quedamos con dos cosas: **el momento más intenso** y **cómo terminó**. Lo que duró casi no importa. Un viaje maravilloso con un pleito el último día se recuerda peor de lo que fue. Una consulta incómoda que termina con alguien amable se recuerda mejor.

> Tu clienta no recuerda todo. Recuerda el mejor momento y el final.

### Para la experiencia de tu clienta
- **Diseña un momento alto.** El empaque que se abre bonito, la nota escrita a mano, la muestra sorpresa, el video personalizado.
- **Cuida el final.** El seguimiento después de la entrega, la pregunta de cómo le fue, la forma de resolver un problema. Un problema bien resuelto al final puede dejar mejor recuerdo que una compra sin problemas.
- **En tus eventos y lives,** cierra arriba: lo mejor al final, no un "bueno, ya me voy" desinflado.

### Para tu vida
La que recuerda es la que hace los planes, y a veces escoge cosas que a la que vive no la hacen feliz. Compramos lo que creemos que nos va a cambiar la vida, y en unos meses nos acostumbramos.

Hay una idea del libro que vale oro: **nada importa tanto como parece mientras lo estás pensando.** El carro nuevo, la casa más grande, el rango que persigues: mientras piensas en eso, parece que lo cambia todo. Después, te acostumbras y vuelves a tu día normal.

Lo que sí cambia tu día a día es cómo usas tu tiempo: con quién lo pasas, cuánto tiempo pasas haciendo lo que te gusta y cuánto haciendo lo que odias. Si quieres ser más feliz, empieza por tu agenda.

### 🪞 Mírate al espejo
¿Qué meta estás persiguiendo pensando que te va a cambiar todo? ¿Cómo cambiaría de verdad tu martes normal si la logras?

### ✍️ Ejercicio
Dibuja el camino de tu clienta desde que te escribe hasta una semana después de recibir su pedido. Marca dónde está su mejor momento y cómo termina. Escribe una mejora para cada uno.

### ✅ Tu tarea de la semana
Revisa tu semana pasada: anota cuántas horas pasaste haciendo lo que disfrutas y cuántas en lo que te drena. Mueve una hora de la segunda lista a la primera.

## 13 · La Pausa
*Herramienta · Cinco preguntas antes de una decisión importante*

Úsala antes de comprar algo grande, prometer una fecha, invitar a alguien a tu equipo, subir un precio o contestar un mensaje que te enojó. Toma cinco minutos.

### Primero, ¿vale la pena frenar?
Frena si hay mucho dinero o tiempo de por medio, si sientes urgencia o emoción fuerte, si es algo nuevo para ti o si alguien te presiona para decidir ya. Si no, deja que la Rápida haga su trabajo.

### Las cinco preguntas
1. **¿Cuál es la pregunta real?** Escríbela completa. ¿Estoy contestando esa o una más fácil, como "¿me emociona?" o "¿me cae bien?"?
2. **¿Qué no sé?** ¿Qué información me falta? ¿Qué me haría cambiar de opinión?
3. **¿Cuál es el primer número que me dieron?** ¿Me está anclando? ¿Cuál sería mi número si no lo hubiera escuchado?
4. **¿Cómo les fue a otras?** Si no supiera nada de mi caso, ¿qué resultado esperaría según lo que les pasó a otras en casos parecidos?
5. **¿Cómo me estoy sintiendo?** ¿Cansada, emocionada, con miedo de perder algo? ¿Cambiaría la decisión si la tomo mañana en la mañana?

### Y al final
Si después de las cinco preguntas tu respuesta es la misma, adelante: ahora sí es una decisión tuya, no solo de la Rápida.

### ✍️ Escribe
Usa La Pausa con una decisión que tengas pendiente esta semana y escribe tus respuestas aquí.

## 14 · El Premortem
*Herramienta · Encuentra las fallas de tu plan antes de que pasen*

Para lanzamientos, eventos, retos con tu equipo, nuevas líneas de producto o metas grandes. Toma 20 minutos.

### Cómo se hace
1. **Junta a quienes saben del plan** (o hazlo sola, por escrito). Que todavía no esté todo decidido.
2. **Di la frase:** "Pasaron seis meses. Hicimos el plan tal como está y fue un desastre. ¿Qué pasó?"
3. **Cada quien escribe sola, cinco minutos,** la historia del desastre. Sin platicar antes, para que nadie influya a nadie.
4. **Lean todas las historias.** Anoten cada causa en una lista.
5. **Escojan las tres más probables** y las tres que harían más daño.
6. **Cambien el plan** para prevenir esas causas, o preparen qué harían si pasan.

### Preguntas que ayudan
- ¿Qué pasa si tarda el doble?
- ¿Qué pasa si cuesta el doble?
- ¿Qué hace la competencia mientras tanto?
- ¿De quién depende que esto salga, y qué pasa si esa persona no puede?
- ¿Qué estamos suponiendo que es cierto y no lo hemos comprobado?

### La regla
En el premortem nadie es aguafiestas. Buscar fallas es la tarea. Agradece cada idea, sobre todo las incómodas.

### ✍️ Escribe
Escribe aquí la historia del desastre de tu próximo proyecto y las tres causas que vas a prevenir.

## 15 · El Diccionario de tropiezos
*Herramienta · Nombres para cachar errores, tuyos y de tu equipo*

Cuando un error tiene nombre, lo reconoces más rápido. Úsalos con cariño en tu equipo: "Ojo, creo que eso es un ancla."

### Los nombres
- **La Rápida y la Lenta.** La mente automática y la mente que revisa. "Eso fue la Rápida, déjame pensarlo."
- **Lo fácil se siente verdad.** Creer algo porque se repite mucho o se entiende fácil. "Lo he oído mil veces, pero ¿es cierto?"
- **Lo que ves es todo lo que hay.** Decidir con poca información sin notar lo que falta. "¿Qué no sabemos?"
- **El halo.** Que una cualidad pinte todo lo demás. "Habla increíble en público, pero eso no dice si es constante."
- **La pregunta fácil.** Contestar algo más sencillo que lo que se preguntó. "¿Estamos contestando la pregunta real?"
- **El ancla.** El primer número que se queda pegado. "No partamos de ese número."
- **Perder duele el doble.** Darle más peso a perder que a ganar. "¿Lo mantengo porque sirve o porque me duele soltarlo?"
- **El punto de referencia.** Sentir algo como ganancia o pérdida según lo que esperabas. "Comparado con el año pasado, crecí."
- **El marco.** La misma verdad contada de otra forma. "¿Cómo se vería si lo contamos al revés?"
- **La historia contra el número.** Dejarse llevar por un caso concreto más que por los datos. "Es un caso. ¿Qué dicen los demás?"
- **Los números chicos.** Concluir con muy pocos casos. "Tres videos no son una tendencia."
- **El regreso al promedio.** Después de algo extremo viene algo más normal. "No es que dejó de funcionar; es que aquel fue excepcional."
- **El plan optimista.** Planear como si todo fuera a salir bien. "¿Cuánto les tardó a otras?"
- **Lo que ya invertí.** Seguir por lo que ya gastaste. "Si empezara hoy, ¿lo escogería?"
- **Juzgar por el resultado.** Calificar una decisión solo por cómo salió. "Fue buena decisión con mala suerte."
- **El pico y el final.** Recordar una experiencia por su mejor momento y su cierre. "¿Cómo termina la experiencia de mi clienta?"
- **La lupa.** Sentir que algo es enorme mientras piensas en ello. "¿De verdad me cambiaría el martes?"

### ✍️ Escribe
Anota cuál de estos tropiezos es el que más te pasa a ti y una frase para recordártelo.

## 16 · Vender limpio
*Herramienta · Lista para usar lo que aprendiste sin manipular*

Todo lo de este curso sirve para comunicar mejor o para engañar. Tú eliges. Revisa esta lista antes de publicar una oferta.

### Antes de publicar
- **¿El precio de referencia es real?** Si dices "antes costaba", que de verdad haya costado eso.
- **¿La urgencia es real?** Si dices "últimas piezas" o "termina hoy", que sea cierto.
- **¿El testimonio es típico?** Que no sea el único caso extraordinario presentado como lo normal.
- **¿El marco esconde algo?** Si tu clienta viera la información completa, ¿se sentiría engañada?
- **¿La opción por defecto le conviene a ella?** Y decir que no, ¿es igual de fácil?
- **¿Le ayudo con la pregunta real?** Para quién es, para quién no y qué puede esperar.
- **¿Prometo resultados de salud o de dinero?** Si sí, quítalo. Nadie puede garantizar eso.

### La prueba final
Imagina que tu clienta descubre exactamente cómo armaste tu mensaje y por qué. ¿Se sentiría respetada o usada? Vende solo lo que podrías explicarle en voz alta.

### ✍️ Escribe
Pasa tu próxima oferta por esta lista y anota qué cambiaste.
