# A la vista · contenido completo del curso

## 0 · Bienvenida a A la vista
*Empieza aquí · Cómo usar el curso*

Este curso es para las que hacen buen trabajo todos los días y casi nadie se entera. Aquí aprendes a dejarlo a la vista sin sentir que te estás vendiendo a gritos.

### La idea en una frase
No se trata de promocionarte. Se trata de **dejar que te encuentren**. La gente no llega a ti por un anuncio; llega porque un día vio cómo haces lo que haces, le gustó y se quedó. Para eso, lo que haces tiene que estar donde se pueda ver.

Mucha gente piensa que primero hay que ser muy buena y después, con calma, mostrarse. Este curso propone lo contrario: mostrarte **mientras** te vuelves buena. Ir dejando migajas de tu trabajo, de lo que aprendes y de lo que te inspira, todos los días, para que las personas a las que les interesa lo mismo te encuentren.

> No tienes que gritar. Tienes que estar a la vista.

### Si ya tomaste Botín
Este curso es su hermano. Botín era sobre aprender de lo que otras hacen: mirar, juntar, mezclar. A la vista es la otra mitad: **ahora te toca a ti ser la que inspira**. Si no lo tomaste, no pasa nada; este curso se entiende solo.

### Cómo está armado
- **Diez clases cortas.** Cada una tiene una idea, ejemplos de contenido y de venta directa, y un bloque de "Tu turno" con preguntas, un ejercicio, una tarea de la semana y algo para compartir en el grupo.
- **Tres herramientas.** El envío del día, tu historia y tu bio, y un plan de 30 días para practicar todo junto.
- **Un cuaderno por clase.** Lo que escribes se guarda en tu celular.

La primera vez, ve en orden. Después regresa a la clase que necesites.

### Lo que necesitas
- Tu celular, que ya es un estudio completo.
- Cinco a quince minutos al día.
- Ganas de enseñar el "cómo", no solo el resultado.

### 🪞 Para pensar
¿Qué haces bien en tu negocio que casi nadie ha visto? Piensa en lo que pasa antes de la foto bonita.

### ✍️ Escribe
Termina esta frase en tu cuaderno: "Me da pena mostrarme porque…". No la corrijas. Al final del curso la vas a volver a leer.

### 💬 Para compartir en el grupo
Cuenta en una línea qué te gustaría que la gente supiera de tu trabajo y todavía no sabe.

## 1 · No tienes que ser genio
*Clase 1 · Tu escena y tu espíritu de aficionada*

Hay un mito que nos paraliza: que lo creativo es cosa de unas cuantas personas brillantes que trabajan solas y un día sorprenden al mundo.

### El mito de la genia solitaria
Nos contaron que las grandes ideas le caen del cielo a gente especial, que se encierra a trabajar y sale con una obra perfecta. Si crees eso, lo lógico es quedarte calladita mirando a las demás.

La realidad casi siempre es otra. Detrás de las personas que admiramos hubo **una escena**: un grupo de gente que se veía el trabajo, se copiaba, se pasaba ideas, se echaba porras y se corregía. Nadie crea en el vacío.

### Tu escena
Una escena no depende de qué tan talentosa seas, sino de **lo que aportas**: las ideas que compartes, las conversaciones que empiezas, las conexiones que haces entre personas. Eso cambia la pregunta. Ya no es "¿qué pueden hacer por mí?", sino "¿qué puedo aportar yo?".

Hoy tu escena está en tu celular: el grupo de tu equipo, las cuentas de maquillaje que sigues, los comentarios donde se ayudan entre todas. No hay que pedir permiso para entrar.

### Aficionada con orgullo
"Aficionada" viene de afición, de amor por algo. La aficionada hace las cosas por gusto, sin la presión de ser experta, y por eso se atreve a probar, a equivocarse en público y a compartir lo que va aprendiendo.

Esa es tu ventaja. Una clienta que apenas está aprendiendo a maquillarse entiende mejor a otra que apenas está aprendiendo que a una maquillista con veinte años de oficio. **Tú recuerdas lo que cuesta empezar.** La experta ya lo olvidó.

> Hacer algo, aunque sea chiquito y no perfecto, siempre le gana a no hacer nada.

### Tu voz aparece cuando la usas
"Encuentra tu voz" suena a algo que se busca. En realidad la voz se encuentra hablando. Habla de lo que te gusta, todos los días, y tu voz va a ir saliendo sola.

Y si te da miedo, recuerda que el tiempo no es infinito. No se trata de ponerse trágicas, sino de no guardar para "algún día" lo que podrías compartir hoy.

### 🪞 Para pensar
¿Qué estás aprendiendo ahorita? ¿Qué te emociona aunque todavía no lo domines?

### ✍️ Ejercicio
1. Escribe tres cosas que estás aprendiendo (un producto, una técnica, una forma de grabar, de vender o de organizarte).
2. Elige una y escribe qué has descubierto en las últimas dos semanas.
3. Escribe a quién de tu escena le serviría saberlo.

### ✅ Tu tarea de la semana
Publica algo que estás aprendiendo **mientras lo aprendes**. Empieza con "Estoy aprendiendo a…" y cuenta lo que llevas.

### 💬 Para compartir en el grupo
Comparte qué estás aprendiendo y pregunta quién más lo está aprendiendo contigo.

## 2 · Piensa en proceso, no en producto
*Clase 2 · Vuélvete documentalista de lo que haces*

Tu trabajo tiene dos partes: lo que entregas y todo lo que haces para llegar ahí. La segunda es la que más acerca a la gente.

### El sustantivo y el verbo
Hay "trabajo" el resultado (el maquillaje terminado, el pedido entregado, el video publicado) y hay "trabajar", el verbo: elegir tonos, probar, equivocarte, armar la caja, aprender a usar una app. Nos enseñaron a enseñar solo el resultado y esconder el resto.

Pero a la gente le interesa la gente. Quiere ver cómo se hacen las cosas, quién está detrás, cómo es un día normal. Cuando muestras tu proceso, la clienta deja de ver un producto y empieza a ver a una persona en la que puede confiar.

> A nadie le interesa tu currículum. Les interesa ver lo que haces con tus propias manos.

### Lo cotidiano también se ve bien
Piensa en alguien con un trabajo que parece lejano, como una astronauta: lo que más engancha a la gente no son los grandes momentos, sino verla lavarse los dientes, dormir o arreglar algo en la nave. Lo cotidiano de un trabajo ajeno es fascinante.

Tu día también lo es para alguien. Cómo organizas el inventario, cómo eliges qué producto recomendar, cómo te arreglas en diez minutos antes de una junta. **Lo que a ti te parece aburrido, a otra le parece interesante.**

### Vuélvete documentalista
Antes de compartir, junta material. No para hacer arte, solo para llevar registro:
- Toma fotos de tu trabajo en distintas etapas: el antes, el durante y el después.
- Graba pedacitos de ti trabajando, aunque no sepas si los vas a usar.
- Lleva una libreta o una nota de voz con lo que piensas, lo que pruebas y lo que aprendes.
- Guarda capturas de lo que dicen tus clientas (con su permiso si lo vas a mostrar).

Documentar tiene premio aunque no publiques nada: vas a ver tu avance con claridad. Y cuando quieras compartir, vas a tener de dónde escoger.

### 🪞 Para pensar
¿Qué parte de tu trabajo nunca enseñas porque te parece "poco interesante"?

### ✍️ Ejercicio
1. Elige una tarea que repites cada semana (armar pedidos, probar un tono, grabar un video, preparar tu día).
2. Escribe sus pasos, del primero al último.
3. Marca en qué paso podrías tomar una foto o grabar diez segundos.

### ✅ Tu tarea de la semana
Documenta esa tarea completa una vez: fotos o videos de cada paso. No tienes que publicarlo todavía; guárdalo en un álbum que se llame "proceso".

### 💬 Para compartir en el grupo
Comparte una foto del "durante", no del resultado, y cuenta qué estabas haciendo.

## 3 · Comparte algo pequeño cada día
*Clase 3 · El envío del día y la prueba del ¿y qué?*

El éxito de la noche a la mañana casi nunca existe. Lo que sí existe es poquito, todos los días, durante mucho tiempo.

### Piensa en días
Construir algo grande toma años, pero no tienes que vivir los años de golpe. Olvídate del año y del mes. **Piensa en hoy.** El día es una unidad que sí se puede manejar: sale el sol, trabajas, se mete el sol.

### El envío del día
Una vez al día, después de trabajar, regresa a lo que documentaste y escoge **un pedacito** para compartir. Qué compartir depende de en qué parte del proceso vas:
- **Al empezar algo:** lo que te inspira, de dónde salió la idea.
- **A la mitad:** cómo lo estás haciendo, lo que salió mal, lo que vas probando.
- **Al terminar:** el resultado, lo que quedó fuera y lo que aprendiste.
- **Después:** cómo le fue, qué dijeron tus clientas, cómo lo usan.

Tu envío del día puede ser una historia, un post, un video corto o un mensaje a tu lista. La forma no importa. Elige uno o dos lugares donde esté tu gente y no te preocupes por estar en todos.

### La mejor pregunta para publicar
Muchas apps te preguntan "¿qué estás pensando?" o "¿cómo te sientes?". Cámbiala por esta: **"¿en qué estás trabajando?"**. Con esa pregunta en mente, vas a enseñar tu trabajo y no tu desayuno.

Y no tiene que salir perfecto. La mayor parte de lo que hacemos no es genial, y no siempre sabemos qué es bueno hasta que otras personas lo ven y reaccionan.

### "No tengo tiempo"
El tiempo se encuentra como el cambio suelto: en los rincones. En la fila del súper, mientras se calienta la comida, cuando las niñas ya se durmieron. Y si compartir empieza a comerse tu trabajo, pon un temporizador de 20 o 30 minutos y, cuando suene, regresa a lo tuyo.

### La prueba del ¿y qué?
Compartir no es contarlo todo. Lo que subes es público y puede llegar a cualquiera, así que publica como si lo fuera a ver tu jefa, tu suegra o tu mejor clienta. Antes de subir algo, pregúntate:
- ¿Le sirve a alguien?
- ¿Entretiene o enseña algo?
- ¿Me sentiría cómoda si lo viera cualquier persona?

Si dudas, déjalo un día en borradores y míralo mañana con ojos frescos. Guardar algo para después no tiene nada de malo.

### El río y la repisa
Hay dos tipos de contenido. **El río** son tus historias y posts del día: lo que le recuerda a la gente que existes. **La repisa** es lo que dura: una guía, un video tutorial, un post fijado que sigue sirviendo en dos años.

La repisa se construye con el río. Si compartes todos los días, empiezas a ver temas que se repiten. Junta esos pedacitos y conviértelos en algo más grande: diez historias sobre cómo elegir tono de base se vuelven una guía fijada.

> Poquito todos los días se vuelve algo enorme.

### Tu casa propia
Las redes vienen y van. Ten algo que sea tuyo y no dependa de una app: tu tienda en línea, una página sencilla, tus historias destacadas bien ordenadas o tu propia lista de contactos. No tiene que ser bonito; tiene que existir y ser fácil de encontrar.

### 🪞 Para pensar
¿Qué te detiene más a la hora de publicar: el tiempo, la pena o no saber qué decir?

### ✍️ Ejercicio
1. Escribe en qué parte del proceso vas con lo que estás haciendo ahorita (empezando, a la mitad, terminando o después).
2. Haz una lista de cinco envíos del día posibles para esa etapa.
3. Pásalos por la prueba del ¿y qué? y quédate con los tres mejores.

### ✅ Tu tarea de la semana
Siete envíos del día en siete días. Uno por día, aunque sea una historia de diez segundos. Usa la herramienta "El envío del día".

### 💬 Para compartir en el grupo
Comparte tu mejor envío de la semana y cuenta qué reacción tuvo.

## 4 · Abre tu vitrina
*Clase 4 · Comparte lo que te inspira, con crédito*

Antes de atreverte a enseñar lo tuyo, puedes enseñar lo que te gusta. Tu gusto también habla de ti.

### Todas tenemos una vitrina
Antes había gente que llenaba un cuarto entero con cosas raras y bonitas: conchas, libros, piedras, objetos de otros países. Era su forma de enseñar qué le asombraba del mundo.

Tú también tienes una vitrina, aunque sea invisible: los productos que amas, las cuentas que sigues, la música con la que te arreglas, las frases que tienes en el refri, las mujeres que admiras. Todo eso forma tu gusto, y tu gusto se nota en tu trabajo.

### Tu gusto llega antes que tu talento
Al principio casi todas pasamos por lo mismo: sabemos reconocer lo bueno, pero lo que hacemos todavía no está a esa altura. Esa distancia es normal y se cierra con práctica. Mientras tanto, compartir lo que te inspira es una forma de mostrarte sin tener todo resuelto.

Pregúntate:
- ¿A quién sigues y por qué?
- ¿Qué productos usas aunque nadie te pague por hablar de ellos?
- ¿Qué te inspira fuera del maquillaje: la cocina, la moda, tu abuela, una película?
- ¿Quién hace un trabajo que admiras en tu negocio?

### Sin placeres culposos
Te van a gustar cosas que otras consideran cursis, básicas o raras. Quiérelas igual. Lo que te hace única es justamente esa mezcla de cosas "finas" y "corrientes" que nadie más juntaría. No intentes verte cool. Ser honesta con lo que te gusta es la manera más rápida de conectar con quien siente lo mismo.

### Da crédito siempre
Si compartes el trabajo de otra persona, dile a todo el mundo de quién es. Cuando no das crédito, no solo le quitas algo a quien lo hizo, también le quitas a tu gente la posibilidad de encontrar más de su trabajo.

Un buen crédito es como **la etiqueta de un museo**: quién lo hizo, qué es, por qué lo compartes y dónde ver más. Etiqueta la cuenta, pon el enlace y, si alguien te lo enseñó a ti, menciónala también.

> Si no sabes de quién es, no lo compartas. Busca el crédito o déjalo pasar.

### 🪞 Para pensar
¿Qué te gusta que te da pena admitir? ¿Qué pasaría si lo compartieras?

### ✍️ Ejercicio
1. Haz la lista de tu vitrina: tres cuentas, tres productos, tres cosas de fuera de tu negocio que te inspiran.
2. Al lado de cada una, escribe en una línea por qué te gusta.
3. Elige una y escríbele su etiqueta de museo.

### ✅ Tu tarea de la semana
Comparte una cosa de tu vitrina con su etiqueta completa: de quién es, qué es, por qué te gusta y dónde ver más.

### 💬 Para compartir en el grupo
Recomienda una cuenta que te inspire, con su etiqueta, para que las demás la conozcan.

## 5 · Cuenta buenas historias
*Clase 5 · Tu trabajo no habla solo*

Dos cosas idénticas valen distinto según la historia que traen. Lo que cuentas de tu trabajo cambia cómo lo ven.

### La misma cosa, otro valor
Imagina dos cuadros iguales. Te dicen que uno lo pintó una maestra de hace siglos y el otro es una copia de la semana pasada. Aunque no veas ninguna diferencia, ya no los miras igual.

Pasa con todo. Hubo un experimento en el que compraron objetos baratos de segunda mano, les inventaron una historia y los revendieron. Los objetos eran los mismos; con la historia, se vendieron por muchísimo más. **Las palabras cambian el valor.**

Por eso "mi trabajo habla por sí solo" no funciona. La gente quiere saber de dónde viene algo, cómo se hizo y quién lo hizo.

### Ya estás contando una historia
Cada historia que subes, cada mensaje a una clienta, cada foto es un pedacito de un relato sobre ti. Lo estás contando aunque no lo planees. La pregunta es si lo cuentas bien.

### La estructura que casi siempre funciona
Toda buena historia tiene una forma clara. La más sencilla: **alguien quiere algo, enfrenta un obstáculo y termina ganando, perdiendo o empatando**. Es también la forma del trabajo creativo: tienes una idea, la sacas adelante con esfuerzo y la mandas al mundo, a ver qué pasa.

Puedes usar este molde para cualquier contenido:
- **Había una vez…** (quién eres o cómo eran las cosas)
- **Todos los días…** (la rutina, el problema)
- **Hasta que un día…** (lo que cambió)
- **Por eso…** (lo que pasó después)
- **Y por eso…** (la consecuencia)
- **Hasta que al fin…** (cómo terminó)

### Historias sin final: la invitación
Casi siempre estamos a la mitad de nuestra historia. Para eso sirve el formato de tres actos con el final abierto: **el pasado** (de dónde vienes y qué has hecho), **el presente** (dónde estás ahorita) y **el futuro** (a dónde vas y cómo te puede ayudar la otra persona). Así funciona una buena invitación al negocio: no le vendes un final, le ofreces escribirlo contigo.

### "¿Y tú a qué te dedicas?"
Practica tu respuesta. Debe entenderla una niña de seis años y tu abuela. No inventes: di la verdad con dignidad. Si trabajas de día en otra cosa, dilo. Si estás empezando, dilo.

Y para tu bio, quita los adjetivos. No eres "una apasionada emprendedora increíble"; eres alguien que hace algo concreto. "Enseño a mamás ocupadas a arreglarse en diez minutos" dice más que cualquier adjetivo.

> No necesitas una historia más impresionante. Necesitas contarla con más claridad.

### 🪞 Para pensar
¿Qué historia te cuentas de tu trabajo? ¿Es la misma que le cuentas a los demás?

### ✍️ Ejercicio
1. Llena el molde de "Había una vez…" con la historia de cómo empezaste tu negocio.
2. Escribe tu respuesta a "¿y tú a qué te dedicas?" en dos frases, sin adjetivos.
3. Léela en voz alta. Si suena a anuncio, simplifícala.

### ✅ Tu tarea de la semana
Publica tu historia de inicio usando el molde. Puede ser un video de un minuto o un carrusel. Usa la herramienta "Tu historia y tu bio".

### 💬 Para compartir en el grupo
Comparte tu respuesta a "¿y tú a qué te dedicas?" y ayuda a otra compañera a quitarle adjetivos a la suya.

## 6 · Enseña lo que sabes
*Clase 6 · Tu propia clase de cocina*

Da miedo enseñar tus trucos porque parece que te quedas sin nada. Pasa justo lo contrario.

### La receta no es el platillo
Piensa en una taquería famosa cuya dueña explica en video exactamente cómo prepara su salsa. ¿Le quita clientes? No. La técnica es sencilla, pero dominarla toma años de práctica. Ver la receta no te hace cocinera; te hace valorar más a quien sí sabe. Y te da más ganas de ir a comer ahí.

Lo mismo con tu trabajo. Puedes enseñar cómo eliges el tono de base o cómo aplicas un delineado, y tu clienta va a seguir prefiriendo que se lo recomiendes tú. **Enseñar no resta, suma.**

### ¿Cuál es tu programa de cocina?
Pregúntate qué podrías enseñar:
- ¿Qué técnica dominas?
- ¿Qué herramientas o productos sabes usar bien?
- ¿Qué sabes de tu trabajo que tu clienta no sabe?
- ¿Qué aprendiste hace poco y todavía recuerdas cómo te costó?

En cuanto aprendas algo, voltéate y enséñaselo a alguien. Comparte lo que lees, recomienda tus fuentes, haz tutoriales paso a paso. Haz que tu gente sea mejor en algo que quiere aprender.

### Enseñar te enseña
Cuando enseñas, la gente responde: te hace preguntas, te corrige, te recomienda cosas que no conocías. Compartir lo que sabes te regala una escuela gratuita para toda la vida.

> Cuando enseñas tu receta, no regalas tu cocina. Invitas a la gente a la mesa.

### 🪞 Para pensar
¿Qué sabes hacer que a ti te parece obvio, pero a una clienta nueva le costaría muchísimo?

### ✍️ Ejercicio
1. Escribe diez cosas que sabes hacer en tu negocio, por chiquitas que parezcan.
2. Marca las tres que más le servirían a una clienta.
3. Convierte una en un tutorial de tres pasos: qué necesitas, cómo se hace y el error más común.

### ✅ Tu tarea de la semana
Publica tu tutorial de tres pasos. Termina con una pregunta para que te cuenten cómo les fue.

### 💬 Para compartir en el grupo
Comparte tu tutorial y deja un comentario en el de otra compañera con algo que aprendiste.

## 7 · No te vuelvas spam
*Clase 7 · Para tener fans, sé fan*

Todas conocemos a alguien que solo aparece para vender. No seas esa persona.

### Spam con patas
Es la que no lee lo que publican las demás, pero te manda su catálogo por inbox. La que no va a los eventos de nadie, pero exige que vayas al suyo. La que no escucha, solo habla. Y ojo: no hace falta empezar para caer ahí. También pasa cuando te va bien y empiezas a creer que todo gira alrededor de ti.

### Sé fan primero
Si quieres que la gente apoye lo tuyo, apoya primero lo de los demás. Comenta de verdad, recomienda a otras, haz preguntas, pide sugerencias, platica con tu gente sobre lo que les gusta. Sé **una puerta abierta**: alguien por donde pasan ideas, contactos y recomendaciones.

Una conversación sincera en los comentarios puede terminar en una colaboración, una clienta o una amiga. Pasa cuando tratas a tu gente como cómplice y no como público.

### Calidad, no cantidad
Deja de contar seguidores y empieza a fijarte en quiénes son. No sigas a gente solo porque crees que te conviene. Para ser interesante, interésate: pon atención, haz preguntas, aprende de otras.

Y nunca, nunca pidas "sígueme y te sigo". Haz cosas que te gustan, habla de lo que te gusta y vas a atraer a la gente a la que le gusta lo mismo.

### La prueba de la pila
Después de pasar tiempo con alguien, ¿tienes la pila cargada o vacía? Si te deja agotada cada vez, aléjate con cariño. Funciona también con trabajos, grupos, apps y hasta horarios.

### Tus cómplices
Mientras te muestras, vas a encontrar a unas cuantas personas obsesionadas con lo mismo que tú. No son muchas, pero valen oro. Cuídalas: enséñales tu trabajo antes que a nadie, celébralas en público, invítalas a hacer cosas juntas.

Y cuando se pueda, conviértelas en amigas de verdad: un café, una comida, una sesión de fotos juntas. Conocer en persona a alguien con quien ya platicabas en línea es de lo mejor que te da compartir.

> Si quieres que te noten, nota a los demás.

### 🪞 Para pensar
¿Cuándo fue la última vez que apoyaste el trabajo de otra sin esperar nada?

### ✍️ Ejercicio
1. Escribe los nombres de tres personas con las que compartes una obsesión (tus cómplices o candidatas).
2. Al lado, escribe algo concreto que puedes hacer por cada una esta semana.
3. Revisa a quién sigues y aplica la prueba de la pila.

### ✅ Tu tarea de la semana
Deja diez comentarios sinceros (no emojis sueltos) en publicaciones de otras personas. Y recomienda públicamente a una compañera o creadora que admires.

### 💬 Para compartir en el grupo
Celebra a una compañera del grupo con algo específico que te gustó de su trabajo.

## 8 · Aprende a recibir un golpe
*Clase 8 · Críticas, trolls y la voz de tu cabeza*

Mientras más gente vea tu trabajo, más opiniones vas a recibir. Unas te van a ayudar, otras no. Aquí aprendes a distinguirlas.

### Cinco formas de aguantar un golpe
1. **Respira.** Las personas creativas tenemos mucha imaginación y la usamos para imaginar lo peor. Una mala crítica no es el fin del mundo; nadie se ha muerto por un comentario feo.
2. **Hazte fuerte a fuerza de práctica.** Mientras más publicas, más críticas recibes, y mientras más críticas recibes, menos te duelen. Saca mucho trabajo.
3. **Muévete con el golpe.** No controlas lo que te dicen, pero sí cómo respondes. Una crítica puede darte la idea para tu siguiente contenido. A veces, lo que a alguien le choca es justo lo que te hace distinta.
4. **Protege lo más sensible.** Si algo te queda demasiado cerca del corazón, guárdalo. Pero si te escondes siempre por miedo a la pena, nunca vas a conectar de verdad con nadie.
5. **Recuerda que tu trabajo no eres tú.** Es algo que haces, no quien eres. Rodéate de la gente que te quiere por ti, no por tus resultados.

### ¿De quién viene?
Lo primero es ver quién te lo dice. Escucha a la gente que te quiere y que entiende lo que haces. Desconfía de las opiniones que vienen de fuera de ese círculo.

Un **troll** es alguien que no quiere que mejores, solo quiere provocarte. No le contestes. Sin atención, casi siempre se va. Bloquea, borra comentarios ofensivos y, si hace falta, desactiva los comentarios. Si alguien ensucia la sala de tu casa, no lo dejas ahí.

### El troll más difícil
El peor troll es el que vive en tu cabeza: la voz que dice que no eres suficiente, que ya se rieron de ti, que nadie te va a comprar. Es una cosa tenerla dentro y otra que un comentario de una desconocida le preste un megáfono.

Cuando pase, regresa al número 5: tu trabajo no eres tú. Y busca a tus cómplices.

> No te importa lo que piensen todos. Te importa lo que piensen las personas correctas.

### 🪞 Para pensar
¿Qué crítica te ha dolido más? ¿Vino de alguien que te quiere y entiende lo que haces?

### ✍️ Ejercicio
1. Escribe la crítica que más miedo te da recibir.
2. Escribe qué le contestaría tu mejor amiga.
3. Escribe una idea de contenido que podrías sacar de esa misma crítica.

### ✅ Tu tarea de la semana
Publica algo que te dé un poquito de miedo. Y arma tu carpeta de porras: capturas de mensajes bonitos para leer en los días malos.

### 💬 Para compartir en el grupo
Cuenta una crítica que te ayudó a mejorar y cómo la usaste.

## 9 · Véndete sin pena
*Clase 9 · Cobrar, tu lista y decir que sí*

Hay que comer y pagar la renta. Ganar dinero con lo que haces no te hace menos auténtica.

### Basta de la artista muerta de hambre
Mucha de la obra más querida del mundo se hizo por encargo y por dinero. Querer que te vaya bien no corrompe tu trabajo. Y cuando a una compañera le va bien, no es "vendida": celébrala como si fuera tu triunfo.

### Cuando hay gente, se puede pedir
Cuando ya hay personas que disfrutan lo que compartes gratis, puedes invitarlas a apoyarte: comprar, recomendarte, contratarte. Funciona mucho mejor cuando ya llevas tiempo mostrando tu proceso y cuidando a tu gente. Primero das, luego pides.

Ojo con algo: cuando le pones precio a lo que amas, descubres cuánto lo valora la gente de verdad. Habrá quien te diga "me cambiaste la vida" y no compre. Está bien. **Pide dinero cuando estés segura de que lo que ofreces vale, y ponle un precio justo.**

### Tu lista
Aunque hoy no tengas nada que vender, junta los contactos de la gente a la que le gusta lo que haces y quiere saber de ti: una lista de difusión, un grupo, un correo. Lo más sencillo es lo que más dura. Un mensaje directo llega; un post se puede perder.

Las reglas: nunca agregues a nadie sin su permiso, di qué tan seguido vas a escribir y no abuses. Quien se suma a tu lista te está dando su confianza.

### Di que sí (y luego, que no)
Sé ambiciosa. Prueba cosas nuevas. Si una oportunidad te deja hacer más del trabajo que amas, di que sí. Si te da más dinero, pero menos del trabajo que amas, piénsalo dos veces.

Y cuando te vaya bien, comparte: recomienda a tus maestras, a tus compañeras y a tu gente. Con el tiempo vas a tener que decir que no más seguido para cuidar tu tiempo. Sé tan generosa como puedas, pero lo bastante egoísta para hacer tu trabajo.

> No hacemos contenido para vender. Vendemos para poder seguir haciendo lo que amamos.

### 🪞 Para pensar
¿Qué te da pena de cobrar o de invitar a comprar? ¿De dónde viene esa pena?

### ✍️ Ejercicio
1. Escribe en una frase qué ofreces y por qué vale lo que cuesta.
2. Escribe un mensaje para invitar a la gente a tu lista: qué van a recibir y cada cuánto.
3. Escribe una oportunidad a la que te gustaría decir que sí este mes y una a la que deberías decir que no.

### ✅ Tu tarea de la semana
Abre tu lista y comparte la invitación. Después manda tu primer mensaje con algo útil, no solo con una venta.

### 💬 Para compartir en el grupo
Comparte tu invitación a la lista y pide a las demás que te ayuden a mejorarla.

## 10 · Quédate
*Clase 10 · No renuncies antes de tiempo*

Las que llegan casi siempre son las que se quedaron el tiempo suficiente.

### No sabes en qué capítulo vas
En medio de tu historia no sabes si vas arriba o abajo. Que hoy no funcione no significa que no vaya a funcionar. Hay segundos, terceros y hasta quintos actos. **No renuncies antes de tiempo.**

No puedes controlar el éxito. Solo puedes hacer tu trabajo todos los días, sin ilusionarte de más ni desesperarte, y estar lista para cuando llegue la oportunidad.

### La mecha
Ni el éxito ni el fracaso te garantizan nada. Después de cada lanzamiento, te vas a preguntar: "¿y ahora qué?". Para no quedarte parada, usa el final de un proyecto para prender el siguiente:
- Al terminar algo, pregúntate qué te faltó, qué harías mejor y qué no alcanzaste a hacer.
- Esa respuesta es tu siguiente proyecto.
- Deja siempre algo empezado para saber por dónde arrancar mañana.

### Pausas para recargar
A veces te vas a quemar y necesitarás parar. No hace falta un año sabático; bastan pausas pequeñas: un rato en el camino sin celular, moverte, salir a la naturaleza. Separa tu trabajo del resto de tu vida. Si nunca te vas del trabajo, tampoco descansas de él.

### Vuelve a empezar
Cuando sientas que ya aprendiste todo lo que había que aprender de algo, toca buscar algo nuevo. Si no te da un poco de pena quién eras hace un año, quizá no estás aprendiendo lo suficiente.

No es empezar de cero: lo que aprendiste se queda contigo y se mete en todo lo que hagas. Es **volver a ser aficionada**. Regresa a la clase 1, busca algo nuevo que aprender y apréndelo a la vista. Documenta, comparte y, cuando lleguen las personas correctas, ponles atención.

> Muéstralo, enséñalo, quédate. Y cuando aprendas, vuelve a empezar.

### 🪞 Para pensar
¿Qué proyecto dejaste a medias porque no funcionó luego luego? ¿Qué pasaría si le dieras otra temporada?

### ✍️ Ejercicio
1. Elige tu último proyecto o lanzamiento.
2. Escribe qué te faltó, qué harías mejor y qué no alcanzaste a hacer.
3. Convierte una de esas respuestas en tu siguiente proyecto.
4. Lee la frase que escribiste en la bienvenida ("Me da pena mostrarme porque…") y escribe qué cambió.

### ✅ Tu tarea de la semana
Empieza el plan de 30 días a la vista. Y elige una pausa semanal que vas a cuidar como cita.

### 💬 Para compartir en el grupo
Cuenta qué vas a aprender a la vista en los próximos 30 días e invita a una compañera a hacerlo contigo.

## 11 · El envío del día
*Herramientas · Qué compartir hoy, en cinco minutos*

Para cuando abres la cámara y no sabes qué subir. Úsala todos los días, al terminar de trabajar.

### Paso 1 · ¿En qué parte vas?
- **Empezando:** comparte lo que te inspira, una referencia (con crédito) o la idea que traes.
- **A la mitad:** un "durante", algo que salió mal, una decisión que tomaste.
- **Terminando:** el resultado, lo que quedó fuera, lo que aprendiste.
- **Después:** cómo le fue, qué dijo una clienta, cómo se usa.

### Paso 2 · Elige un formato
- Una foto del durante con una línea de texto.
- Un video de diez segundos con tus manos trabajando.
- Una nota en historias: "Hoy aprendí…".
- Un antes y después.
- Una pregunta a tu gente.

### Paso 3 · La prueba del ¿y qué?
- ¿Le sirve o entretiene a alguien?
- ¿Se entiende sin explicación extra?
- ¿Me daría gusto que lo viera cualquier persona?
- Si comparto algo ajeno, ¿lleva su crédito?

Si pasa, publícalo. Si dudas, a borradores y mañana lo ves.

### Paso 4 · Cierra
- Anota en tu cuaderno qué compartiste.
- Contesta los comentarios del día.
- Apaga la app. Ya cumpliste.

### Treinta ideas para cuando no se te ocurre nada
1. Tu mesa de trabajo antes de empezar.
2. Lo que hay en tu bolsa hoy.
3. Un producto que usas todos los días y por qué.
4. Un error que cometiste esta semana.
5. Cómo armas un pedido.
6. Un tono que no te funcionó y por qué.
7. La pregunta que más te hacen.
8. Tu rutina de diez minutos.
9. Algo que aprendiste de una compañera (con crédito).
10. Una cuenta que te inspira (con crédito).
11. Tu primera foto de producto contra la de hoy.
12. Un mensaje bonito de una clienta (con su permiso).
13. Qué haces cuando no tienes ganas.
14. Tu lugar favorito para grabar.
15. Cómo organizas tu semana.
16. Algo que estás aprendiendo.
17. Un mito que quieres desmentir (sin promesas de salud).
18. Tu herramienta favorita y cómo la limpias.
19. Una decisión difícil de tu negocio.
20. Lo que hay detrás de una foto bonita.
21. Un tip para principiantes.
22. Algo que te dio pena publicar.
23. Una meta de este mes.
24. El resultado de una meta del mes pasado.
25. Una recomendación que no es de tu negocio.
26. Cómo elegiste tu negocio.
27. Lo mejor de tu día.
28. Una pregunta para tu gente.
29. Algo que se quedó fuera de un video.
30. Lo que harás mañana.

## 12 · Tu historia y tu bio
*Herramientas · Tres moldes para contar lo que haces*

Tres plantillas para llenar en tu cuaderno. Escríbelas a mano primero; después pásalas a tu perfil.

### Molde 1 · Había una vez
- Había una vez… (quién eras)
- Todos los días… (cómo era tu vida o tu problema)
- Hasta que un día… (lo que cambió)
- Por eso… (lo que hiciste)
- Y por eso… (lo que pasó después)
- Hasta que al fin… (dónde estás hoy)

Úsalo para tu historia de inicio, para la historia de un producto o para la de una clienta (con su permiso).

### Molde 2 · La invitación en tres actos
- **Pasado:** qué querías, por qué y qué has hecho para lograrlo.
- **Presente:** dónde estás ahorita y qué te ha costado.
- **Futuro:** a dónde vas y cómo puede ayudarte, o sumarse, la persona que te escucha.

Sirve para invitar a alguien a tu equipo, presentarte en un evento o pedir una colaboración. Deja el final abierto: que la otra persona decida cómo sigue.

### Molde 3 · "¿Y tú a qué te dedicas?"
Dos frases, sin adjetivos:
- **Qué haces:** "Vendo maquillaje y enseño a usarlo".
- **Para quién o cómo:** "Sobre todo a mamás que tienen diez minutos para arreglarse".

Prueba: ¿lo entendería una niña de seis años? ¿Y tu abuela? Si no, simplifícalo.

### Tu bio
- Quita adjetivos como "apasionada", "increíble" o "experta".
- Nada de "gurú", "ninja" ni "reina", a menos que lo seas de verdad.
- Di lo que haces, para quién y dónde encontrarte.
- Si trabajas en otra cosa de día, puedes decirlo. La verdad conecta.

> Una bio corta y verdadera vale más que una larga e impresionante.

## 13 · 30 días a la vista
*Herramientas · Un plan para practicar todo el curso*

Un mes para convertir el curso en hábito. Haz un envío del día diario y suma la acción de cada semana.

### Semana 1 · Documenta
- Todos los días: toma al menos tres fotos o videos de tu proceso.
- Día 1: crea tu álbum "proceso" en el celular.
- Día 3: publica "Estoy aprendiendo a…".
- Día 5: publica un "durante".
- Día 7: revisa tu álbum y elige tus tres favoritas.

### Semana 2 · Abre la vitrina
- Día 8: comparte una cuenta que te inspira, con su etiqueta.
- Día 10: comparte un producto que amas y por qué.
- Día 12: comparte algo que te gusta fuera de tu negocio.
- Día 14: deja diez comentarios sinceros a otras.

### Semana 3 · Cuenta y enseña
- Día 15: escribe tu respuesta a "¿y tú a qué te dedicas?".
- Día 16: actualiza tu bio, sin adjetivos.
- Día 18: publica tu historia de inicio con el molde "Había una vez".
- Día 20: publica un tutorial de tres pasos.
- Día 21: celebra en público a una cómplice.

### Semana 4 · Invita y sigue
- Día 22: abre tu lista e invita a tu gente.
- Día 24: manda tu primer mensaje útil a la lista.
- Día 26: publica algo que te dé un poquito de miedo.
- Día 28: junta tus mejores envíos del mes y conviértelos en algo de la repisa (una guía o un destacado).
- Día 30: escribe qué te faltó, qué harías mejor y elige qué vas a aprender a la vista el mes que sigue.

### Reglas del plan
- Si un día no publicas, no pasa nada. Al día siguiente sigues donde ibas.
- Lo que cuenta es la constancia, no el número de seguidores.
- Comparte tus avances en el grupo cada domingo.

> Treinta pedacitos pequeños se ven como un trabajo grande.
