# Átomo · contenido completo del curso

Ideas inspiradas en el libro Hábitos atómicos, de James Clear.

## 0 · Bienvenida a Átomo
*Empieza aquí · El curso en 5 minutos*

Este curso es para cuando ya sabes lo que te conviene hacer, pero no lo haces. O lo haces tres días y luego se te olvida. Aquí no vas a necesitar más fuerza de voluntad: vas a aprender a armar hábitos que se sostengan solos.

### De qué se trata
Un átomo es lo más pequeño que existe, y también es una fuente enorme de energía. Así son los hábitos: cosas chiquitas que, repetidas todos los días, cambian tu vida entera. Para bien o para mal.

La idea central del curso es esta: **no subes al nivel de tus metas, bajas al nivel de tus sistemas**. Tus metas dicen a dónde quieres llegar. Tus hábitos deciden si llegas.

> Pequeños cambios, todos los días. Eso es todo el secreto, y también todo el trabajo.

### Cómo está armado
- **Los cimientos (clases 1 a 3).** Por qué lo pequeño importa tanto, por qué tus hábitos dicen quién eres y cómo funciona un hábito por dentro.
- **Las cuatro reglas (clases 4 a 10).** Un método sencillo para crear cualquier hábito bueno: que se vea, que se antoje, que cueste poquito y que se sienta bien. Y su versión al revés, para dejar los malos.
- **Para ir más lejos (clases 11 y 12).** Cómo elegir los hábitos que van contigo, qué hacer cuando te aburres y cómo revisar tu avance sin castigarte.
- **Herramientas.** Las cuatro reglas en una hoja, el inventario de tu día, fórmulas para copiar y un tracker de 30 días.

### Lo que necesitas
- Un cuaderno (o el cuaderno de cada clase, que se guarda en tu celular).
- Un hábito que quieras crear y uno que quieras dejar. Si todavía no sabes cuáles, la clase 4 te ayuda a encontrarlos.
- Diez minutos al día para leer y hacer el ejercicio. Una clase por día o dos por semana, como te acomode.

### Cómo sacarle provecho
No leas todo de corrido. Cada clase termina con un ejercicio chiquito: hazlo antes de pasar a la siguiente. El curso funciona igual que los hábitos: poquito, pero seguido.

### 🪞 Para pensar
¿Qué cosa has intentado empezar más de tres veces? ¿Qué pasó la última vez que la dejaste?

### ✍️ Escribe
Escribe un hábito que quieras crear y uno que quieras dejar. Por ejemplo: "Quiero publicar una historia al día" y "Quiero dejar de revisar el celular en la cama".

## 1 · Clase 1 · El poder del 1%
*Los cimientos · Por qué lo pequeño cambia todo*

Casi siempre creemos que para cambiar algo hace falta un cambio enorme. Un plan nuevo, un lunes perfecto, una gran decisión. Pero los cambios que se quedan casi nunca se ven así.

### La cuenta del 1%
Imagina que mejoras 1% cada día. Un poquito. Algo que nadie notaría. Si lo sostienes un año, matemáticamente terminas casi 37 veces mejor que como empezaste. Y si empeoras 1% cada día, terminas casi en cero.

Eso es lo que hacen los hábitos: **funcionan como el interés compuesto**. Lo que repites se suma y se multiplica con el tiempo. Una historia al día no cambia tu negocio esta semana. Trescientas sesenta y cinco historias, sí.

> Tus hábitos son el interés compuesto de tu vida. Lo que repites todos los días, crece.

### Funciona para los dos lados
El mismo efecto que te ayuda también te puede hundir. Un gasto chiquito de café, un "nomás un ratito" de redes, una noche más sin dormir bien. Ninguno se nota hoy. Juntos, en un año, sí.

Por eso vale la pena poner atención a lo pequeño: no porque una sola vez importe mucho, sino porque casi nunca es una sola vez.

### La meseta escondida
Aquí está la parte que hace que casi todas se rindan. Al principio trabajas y no ves nada. Publicas, das seguimiento, haces ejercicio, y todo se ve igual. Parece que no está sirviendo.

Pero sí está sirviendo. Es como un hielo en un cuarto frío que se va calentando grado por grado: a 29, a 30, a 31 grados bajo cero sigue igual de hielo... y de repente, en un grado más, se empieza a derretir. El grado que lo derritió no fue más importante que los anteriores. Solo fue el que hizo visible todo lo que ya se había acumulado.

> Cuando sientas que no avanzas, no estás estancada. Estás acumulando.

### Olvídate un poco de las metas
Las metas sirven para saber a dónde vas. Pero todas las que compiten quieren ganar, y no todas ganan. Lo que hace la diferencia es el sistema: lo que haces todos los días.

Las metas también tienen trampa: te hacen pensar "cuando llegue, voy a estar contenta". Y si llegas, muchas veces dejas de hacer lo que te llevó ahí. Si te enamoras del sistema, ya ganaste cada día que lo cumples.

- **Meta:** vender 20 productos este mes.
- **Sistema:** mandar tres mensajes de seguimiento cada mañana y publicar una historia de producto cada tarde.

### 🪞 Para pensar
¿En qué parte de tu vida sientes que estás "en la meseta", trabajando sin ver resultados todavía?

### ✍️ Escribe
Toma una meta que tengas y conviértela en sistema. Completa: "Mi meta es… Mi sistema diario es…".

### ✅ Hoy
Haz hoy la versión más chiquita de tu sistema. Solo una vez.

## 2 · Clase 2 · Quién quieres ser
*Los cimientos · Tus hábitos y tu identidad*

La razón más común por la que un hábito no se queda no es la flojera. Es que estás tratando de cambiar lo que haces sin cambiar quién crees que eres.

### Tres capas
Todo cambio puede pasar en tres niveles:
- **Lo que logras:** bajar de peso, vender más, ahorrar.
- **Lo que haces:** tu rutina, tu forma de trabajar.
- **Quién eres:** lo que crees de ti misma.

Casi todas empezamos por la primera capa: "quiero vender más". El cambio que dura empieza al revés, por la tercera: "soy una mujer que le da seguimiento a sus clientas".

### Dos personas, un mismo cigarro
Imagina a dos mujeres que quieren dejar de fumar. Les ofrecen uno. La primera dice: "No, gracias, estoy tratando de dejarlo". La segunda dice: "No, gracias, no fumo".

La primera todavía se ve como fumadora que se está aguantando. La segunda ya cambió quién es. ¿Cuál crees que lo va a lograr?

> La meta no es correr un maratón. La meta es volverte corredora.

### Cada acción es un voto
Aquí viene lo bonito: tu identidad no la decides de golpe, la vas construyendo. **Cada vez que haces algo, es un voto por el tipo de persona que quieres ser.**

Publicas una historia aunque te dé pena: un voto por "soy creadora". Le contestas a una clienta a tiempo: un voto por "soy profesional". No necesitas ganar por unanimidad. Solo necesitas más votos a favor que en contra.

Por eso los hábitos chiquitos importan tanto: no solo te dan resultados, te dan pruebas de quién eres.

### Cómo usarlo
Son dos pasos:
1. Decide qué tipo de persona quieres ser.
2. Demuéstratelo con pequeñas victorias.

Si no sabes por dónde empezar, pregúntate frente a cada decisión: "¿Qué haría aquí una mujer que ya es como yo quiero ser?". ¿Qué haría una emprendedora organizada? ¿Una mamá paciente? ¿Una mujer sana?

### Cuidado con lo que te repites
También funciona al revés. "Soy malísima para los números", "yo no soy de levantarme temprano", "a mí no se me da vender". Cada vez que lo dices y actúas así, le das otro voto. Muchas de esas frases no son verdad: son hábitos que llevan años votando.

### 🪞 Para pensar
¿Qué frase sobre ti misma repites mucho y te está estorbando?

### ✍️ Escribe
Completa: "Soy el tipo de mujer que…". Después escribe tres acciones chiquitas que serían un voto por esa mujer.

### ✅ Hoy
Haz una de esas tres acciones y, cuando la termines, dite en voz baja: "Un voto".

## 3 · Clase 3 · Cómo funciona un hábito
*Los cimientos · El ciclo de cuatro pasos y las cuatro reglas*

Un hábito es algo que repetiste tantas veces que ya sale solo. Tu cerebro los crea para ahorrar energía: lo que ya resolvió una vez, no lo quiere volver a pensar.

### El ciclo
Todo hábito, bueno o malo, sigue el mismo ciclo de cuatro pasos:
1. **La señal.** Algo que tu cerebro nota y le avisa que puede haber una recompensa. Ves el celular sobre la mesa.
2. **El antojo.** Las ganas de cambiar cómo te sientes. Quieres saber si alguien te escribió.
3. **La acción.** Lo que haces. Desbloqueas el celular.
4. **La recompensa.** Lo que obtienes. Te enteras, te distraes, te sientes conectada.

La recompensa le enseña a tu cerebro que vale la pena repetirlo. La próxima vez que veas la señal, el antojo llega más rápido. Y así, hasta que ya ni lo piensas.

> No quieres el celular. Quieres cómo te hace sentir.

### Las cuatro reglas
Si un hábito tiene cuatro pasos, tienes cuatro lugares para intervenir. Para crear un hábito bueno:
- **Que se vea:** haz la señal obvia.
- **Que se antoje:** haz que te den ganas.
- **Que cueste poquito:** haz la acción fácil.
- **Que se sienta bien:** haz que la recompensa llegue rápido.

Y para dejar uno malo, se invierten:
- **Que no se vea:** esconde la señal.
- **Que no se antoje:** quítale el encanto.
- **Que cueste mucho:** ponle obstáculos.
- **Que se sienta mal:** que tenga un costo inmediato.

Cuando un hábito no te sale, casi siempre es porque falla una de las cuatro. El resto del curso es aprender a moverlas.

### Un ejemplo completo
Quieres tomar más agua.
- **Que se vea:** una botella llena sobre tu escritorio desde la mañana.
- **Que se antoje:** una botella que te encante, con limón y hielo.
- **Que cueste poquito:** que ya esté llena y a la mano, no en la cocina.
- **Que se sienta bien:** una marca en tu tracker cada vez que la terminas.

### 🪞 Para pensar
Piensa en un hábito que ya tienes sin querer. ¿Cuál es la señal que lo dispara? ¿Qué recompensa te da en realidad?

### ✍️ Escribe
Toma el hábito que quieres crear y escribe una idea para cada regla: que se vea, que se antoje, que cueste poquito y que se sienta bien.

## 4 · Clase 4 · Date cuenta
*Regla 1 · Que se vea · Lo que haces sin darte cuenta*

Antes de cambiar un hábito, tienes que verlo. Y lo difícil es que los hábitos más fuertes son justamente los que ya no ves.

### El piloto automático
Cuando algo se vuelve hábito, tu cerebro deja de ponerle atención. Por eso puedes llegar a tu casa manejando sin acordarte del camino, o encontrarte con el celular en la mano sin saber cuándo lo agarraste.

Eso es útil para lo bueno y peligroso para lo malo. No puedes cambiar lo que no notas.

### Señala y dilo
En algunos sistemas de trenes, los conductores tienen una costumbre que parece rara: antes de cada acción señalan con el dedo y dicen en voz alta lo que van a hacer. "Señal en verde." "Velocidad correcta." Parece exagerado, pero reduce mucho los errores, porque convierte algo automático en algo consciente.

Tú puedes hacer lo mismo. Antes de comprar algo por impulso, dilo: "Voy a gastar 400 pesos en algo que no planeé". Antes de abrir redes: "Voy a abrir Instagram y probablemente me quede media hora". Decirlo en voz alta te devuelve el volante.

> Darte cuenta no es castigarte. Es encender la luz.

### El inventario del día
Este es el primer ejercicio del método. Haz una lista de todo lo que haces en un día normal, desde que despiertas: apagas la alarma, revisas el celular, vas al baño, te lavas la cara, haces el café…

Al lado de cada cosa pon un signo:
- **+** si te acerca a la mujer que quieres ser.
- **−** si te aleja.
- **=** si es neutral.

La pregunta no es "¿esto es bueno o malo?" sino "¿esto me ayuda a ser quien quiero ser?". Revisar el celular al despertar puede ser + para alguien que atiende pedidos temprano y − para alguien que quiere empezar el día en calma.

No cambies nada todavía. Solo observa.

### 🪞 Para pensar
¿Cuál de tus hábitos te sorprendió más cuando lo pusiste en la lista?

### ✍️ Escribe
Haz tu inventario del día con sus signos. La herramienta "El inventario del día" tiene una lista de ejemplo.

### ✅ Hoy
Elige un hábito − y, cada vez que lo vayas a hacer hoy, dilo en voz alta antes.

## 5 · Clase 5 · Cuándo, dónde y con qué
*Regla 1 · Que se vea · Dale a tu hábito una cita y un lugar*

"Voy a hacer más ejercicio." "Voy a publicar más." Así como está, eso no es un plan, es un deseo. A los hábitos les falta casi siempre lo mismo: cuándo y dónde.

### Ponle una cita
La forma más sencilla de empezar un hábito es decir exactamente cuándo y dónde lo vas a hacer:

> Voy a [hábito] a las [hora] en [lugar].

- "Voy a grabar un video de producto a las 9 de la mañana en la mesa del comedor."
- "Voy a leer 10 páginas a las 10 de la noche en el sillón."
- "Voy a revisar mis pedidos el lunes a las 8 en mi escritorio."

Cuando ya está decidido, no tienes que esperar a tener ganas. Llega la hora y ya sabes qué toca.

### Engánchalo a otro hábito
Hay una forma todavía más fácil: pegar tu hábito nuevo a uno que ya haces sin pensar.

> Después de [lo que ya hago], voy a [hábito nuevo].

- "Después de servirme el café, voy a mandar tres mensajes de seguimiento."
- "Después de lavarme los dientes en la noche, voy a ponerme mi crema."
- "Después de dejar a los niños en la escuela, voy a grabar una historia en el coche."

Puedes hacer una cadena entera: café → mensajes → historia → revisar pedidos. Cada hábito es la señal del siguiente. La clave es que el disparador sea muy concreto y que pase siempre.

### Tu entorno decide más que tu motivación
Muchas veces no elegimos algo por lo que es, sino por dónde está. Si la fruta está a la vista, comes fruta. Si las galletas están a la vista, comes galletas.

Así que acomoda tu casa para que lo bueno se vea:
- Tu kit de grabación armado y listo en un rincón.
- Los productos que quieres mostrar en un lugar donde los veas al pasar.
- Tu libro sobre la almohada, no en el librero.

Y si puedes, dale a cada actividad su lugar: esta silla es para leer, esta mesa es para trabajar, la cama es para dormir. Mezclar todo en un solo lugar (sobre todo en el celular) hace que todo compita.

### 🪞 Para pensar
¿Qué cosas buenas tienes escondidas en cajones y qué distracciones tienes siempre a la vista?

### ✍️ Escribe
Escribe tu hábito con las dos fórmulas: "Voy a… a las… en…" y "Después de…, voy a…".

### ✅ Hoy
Mueve una sola cosa de tu casa para que tu hábito bueno se vea.

## 6 · Clase 6 · Que se te antoje
*Regla 2 · Que se antoje · Ganas, premios y tu tribu*

Mientras más atractivo es algo, más fácil es que se vuelva hábito. Y lo atractivo no se encuentra: se diseña.

### Las ganas vienen antes
Tu cerebro no se mueve por el premio, se mueve por la anticipación del premio. Por eso la emoción de comprar algo en línea a veces es más fuerte que abrir el paquete. Las ganas de hacer algo son la que te levanta del sillón.

Entonces la pregunta es: ¿cómo hago que mi hábito bueno se me antoje?

### Pega lo que tienes que hacer con lo que quieres hacer
Junta un hábito que necesitas con algo que disfrutas, y solo te permites lo que disfrutas mientras haces lo que necesitas.

- "Solo escucho mi podcast favorito mientras camino."
- "Solo veo mi serie mientras doblo ropa o empaco pedidos."
- "Me tomo mi café rico mientras preparo las publicaciones de la semana."

Y lo puedes combinar con la cadena de la clase 5: "Después de [lo que ya hago], voy a [lo que necesito]. Después de [lo que necesito], voy a [lo que me gusta]".

### Tu tribu te jala
Copiamos los hábitos de tres grupos: las personas cercanas (familia, amigas), la mayoría (lo que "todas hacen") y las que admiramos. Queremos pertenecer, y eso pesa más que casi cualquier fuerza de voluntad.

Por eso uno de los movimientos más poderosos es **rodearte de gente para quien tu hábito ya es lo normal**. Si en tu equipo todas publican diario, publicar diario deja de ser un esfuerzo y se vuelve "lo que hacemos aquí". Si tus amigas hacen ejercicio, tú también.

> Elige un grupo donde lo que quieres hacer sea lo normal. Ahí el hábito se contagia.

### Cambia el "tengo que" por "puedo"
Tus hábitos se sienten como se los nombras. "Tengo que hacer ejercicio" se siente como carga. "Puedo hacer ejercicio, mi cuerpo puede moverse" se siente como regalo.

- "Tengo que dar seguimiento" → "Le puedo ayudar a una clienta a encontrar lo que busca."
- "Tengo que grabar" → "Puedo practicar hablar a cámara y cada vez me sale mejor."

No es engañarte. Es elegir el ángulo verdadero que te da ganas.

### Al revés: que no se antoje
Para dejar un hábito malo, haz visible lo que te cuesta. Escribe qué ganarías al dejarlo: más horas de sueño, más dinero, más paz. Mientras más claro tengas el costo, menos encanto tiene.

### 🪞 Para pensar
¿Quiénes son las personas que más influyen en tus hábitos? ¿Te jalan hacia la mujer que quieres ser o hacia la de siempre?

### ✍️ Escribe
Escribe tu fórmula: "Solo voy a [lo que me gusta] mientras [lo que necesito hacer]".

### ✅ Hoy
Cambia una frase de "tengo que" por "puedo" y dila en voz alta antes de hacerlo.

## 7 · Clase 7 · Empieza en dos minutos
*Regla 3 · Que cueste poquito · Practicar le gana a planear*

Esta es la regla que más cambia las cosas, porque ataca el problema más común: el hábito se siente demasiado grande para empezar hoy.

### Moverte no es avanzar
Hay dos formas de estar ocupada. Una es **moverte**: investigar, planear, ver tutoriales, armar el calendario perfecto de contenido. La otra es **avanzar**: publicar el video.

Moverse se siente productivo y es más cómodo, porque no te expone a fallar. Pero no da resultados. Planear está bien, siempre y cuando no se vuelva tu forma elegante de no empezar.

> No necesitas el plan perfecto. Necesitas la repetición número uno.

### Cuenta veces, no días
No existe un número mágico de días para que algo se vuelva hábito. Lo que importa es cuántas veces lo has hecho. Por eso la meta al principio no es hacerlo perfecto, es hacerlo muchas veces.

### La ley del menor esfuerzo
Siempre vamos a elegir lo que cueste menos. Por eso gana el celular sobre el libro y el sillón sobre la caminata. En lugar de pelear contra eso, úsalo:
- **Quítale fricción a lo bueno:** deja la ropa de ejercicio lista la noche anterior, ten plantillas de mensajes guardadas, deja el aro de luz conectado.
- **Prepara tu espacio para la siguiente vez:** al terminar de grabar, deja todo listo para mañana.

### La regla de los dos minutos
Cuando empiezas un hábito nuevo, la versión de inicio tiene que tomar menos de dos minutos.
- "Leer antes de dormir" → "Leer una página."
- "Hacer ejercicio" → "Ponerme los tenis."
- "Publicar diario" → "Grabar una historia de 15 segundos."
- "Ordenar la casa" → "Doblar una prenda."

Suena ridículamente chiquito, y esa es la idea. Primero tienes que volverte la persona que aparece todos los días. Un hábito que no existe no se puede mejorar. **Primero haz que exista, luego lo haces crecer.**

Si quieres, ponte la regla de parar a los dos minutos durante unos días. Te sorprende las ganas que te quedan.

### Los momentos que deciden el día
Hay momentos chiquitos que deciden lo que sigue: llegar a casa y sentarte en el sillón o cambiarte; abrir la laptop y entrar al correo o a TikTok. Esos momentos duran segundos, pero marcan horas. Concéntrate en ganar esos momentos.

### 🪞 Para pensar
¿Qué hábito llevas semanas "planeando" sin empezar?

### ✍️ Escribe
Escribe la versión de dos minutos de tu hábito. Si te toma más de dos minutos, hazla más chiquita.

### ✅ Hoy
Haz la versión de dos minutos. Ahorita, si puedes.

## 8 · Clase 8 · Ponle candado
*Regla 3 · Que cueste poquito · Decide una vez y que tu yo del futuro no tenga que pelear*

Hay decisiones que tomas una vez y te ayudan todos los días después. Esta clase es para aprovecharlas y para hacer que lo malo cueste más.

### Pon obstáculos a lo que quieres dejar
Así como quitas fricción a lo bueno, ponle fricción a lo malo. Mientras más pasos haya entre tú y el mal hábito, menos lo haces.
- Saca las redes sociales de la pantalla de inicio, o del celular unas semanas.
- Deja el celular cargando fuera de la recámara.
- Borra la tarjeta guardada en las apps de compras.
- No compres lo que no quieres comer. Si no está en casa, no te lo comes.

> Es más fácil evitar la tentación que resistirla.

### Decide hoy por tu yo de mañana
Un candado es una decisión que tomas ahora para que tu yo del futuro no tenga que pelear. Algunos ejemplos:
- Pagar la clase por adelantado para no faltar.
- Agendar con tu amiga la caminata del sábado.
- Usar platos más chicos.
- Poner un temporizador al wifi o un límite de tiempo en las apps.

Tu yo de hoy está tranquila y piensa claro. Tu yo de las 11 de la noche, cansada, no. Deja que la primera le ayude a la segunda.

### Decisiones de una sola vez
Hay cambios que haces una vez y siguen dando frutos solos:
- Programar que una parte de cada ingreso se vaya directo a tu ahorro.
- Comprar un buen colchón o cortinas que oscurezcan.
- Darte de baja de correos y cuentas que solo te dan ganas de comprar.
- Silenciar notificaciones que no son urgentes.
- Programar tus publicaciones de la semana en un solo bloque.

Busca la tecnología que trabaje por ti: recordatorios, pagos automáticos, publicaciones programadas, plantillas. Lo que se automatiza, ya no depende de tu fuerza de voluntad.

### 🪞 Para pensar
¿Cuál es el hábito malo que más te cuesta? ¿Cuántos pasos hay hoy entre tú y ese hábito?

### ✍️ Escribe
Escribe tres obstáculos que puedes ponerle a tu hábito malo y una decisión de una sola vez que puedes tomar esta semana.

### ✅ Hoy
Toma esa decisión de una sola vez. Hoy, antes de dormir.

## 9 · Clase 9 · Que se sienta bien
*Regla 4 · Que se sienta bien · Premios inmediatos y tu tracker*

Repetimos lo que se siente bien. Y aquí está el problema: casi todos los hábitos buenos se sienten bien hasta después, y casi todos los malos se sienten bien ahorita.

### El cerebro quiere todo ya
Tu cerebro le da mucho más peso a lo que pasa hoy que a lo que pasará en meses. El postre se siente bien ahorita, la salud llega en años. Comprar se siente bien ahorita, el ahorro llega después. Publicar da pena ahorita, las ventas llegan después.

Por eso hay una regla de oro: **lo que se premia de inmediato se repite, y lo que se castiga de inmediato se evita.** Si quieres que un hábito se quede, necesitas sentir una pequeña victoria en el momento, aunque el resultado grande tarde.

### Ponle un premio de inmediato
Busca algo chiquito que puedas darte justo al terminar, que no vaya en contra del hábito:
- Cada vez que no compras algo por impulso, pasa esa cantidad a una cuenta que diga "mi viaje". Ver crecer esa cuenta se siente bien hoy.
- Al terminar tus mensajes de seguimiento, te tomas tu café en la terraza.
- Al publicar, te mandas un emoji a ti misma o se lo cuentas a tu compañera.

### El tracker
Una de las cosas que más satisfacción da es ver tu avance. Por eso funciona tanto algo tan simple como **tachar un cuadrito en un calendario** cada día que cumples tu hábito.

El tracker te recuerda que te toca, te da gusto al marcarlo y te muestra la prueba de quién te estás volviendo. Hazlo así:
- Marca justo después de hacer el hábito.
- Lleva el registro de lo que puedas controlar: "publiqué", no "vendí".
- Usa el tracker de la sección de herramientas.

> No rompas la cadena. Y si se rompe, nunca falles dos veces.

### Nunca dos veces
Vas a fallar. A todas nos pasa: se enferma un hijo, viajas, se te va el día. Fallar una vez es un accidente. Fallar dos veces seguidas es el principio de otro hábito.

Así que la regla no es "nunca fallar", es "**nunca fallar dos veces**". Y en los días malos, haz la versión de dos minutos. Un día malo con dos minutos vale muchísimo más que un día en cero, porque mantiene viva tu identidad.

### Cuidado con lo que mides
Medir ayuda, pero no todo lo importante se puede medir. Si solo ves números (seguidores, ventas, kilos), puedes olvidar para qué lo haces. El número es una pista, no todo el camino.

### 🪞 Para pensar
¿Qué recompensa inmediata te está dando tu hábito malo? ¿Qué podría darte algo parecido sin el costo?

### ✍️ Escribe
Escribe tu premio inmediato: "Cada vez que [hábito], voy a [premio chiquito]".

### ✅ Hoy
Empieza tu tracker de 30 días y marca hoy.

## 10 · Clase 10 · Alguien que te vea
*Regla 4 · Que se sienta bien · Compañera de hábitos y acuerdos*

Nos importa mucho lo que piensan las personas que respetamos. Esa fuerza, bien usada, sostiene un hábito como pocas cosas.

### Que lo malo tenga un costo
Así como lo bueno necesita un premio inmediato, lo malo necesita un costo inmediato. Si faltar a tu hábito no te cuesta nada hoy, es muy fácil dejarlo para mañana.

El costo más poderoso casi nunca es dinero: es saber que alguien se va a enterar.

### Tu compañera de hábitos
Elige a una persona (tu amiga, tu hermana, alguien de tu equipo) y hagan un acuerdo:
- Cada una dice qué hábito va a sostener.
- Se reportan todos los días o cada semana. Un mensaje con una foto basta.
- Si alguna falla, la otra se entera. Sin regaños, pero se entera.

Saber que alguien te está esperando hace que sea mucho más difícil no aparecer.

> Cuando alguien te está viendo, cumplir se vuelve más fácil que dar explicaciones.

### El acuerdo por escrito
Si quieres ir más lejos, escríbanlo. Un acuerdo sencillo que diga:
- Qué hábito voy a sostener.
- Cómo lo voy a reportar y a quién.
- Qué pasa si no cumplo (algo pequeño y real: invito el café, dono una cantidad, hago 20 sentadillas en videollamada).
- Las firmas de las dos.

Parece exagerado, pero es justo lo que lo hace funcionar: convierte una promesa privada, que es fácil de romper, en una pública.

### Las cuatro reglas al revés
Con esta clase ya tienes el método completo para dejar un hábito malo:
- **Que no se vea:** saca la señal de tu vista.
- **Que no se antoje:** recuerda lo que te cuesta.
- **Que cueste mucho:** ponle obstáculos y candados.
- **Que se sienta mal:** que alguien se entere y que tenga un costo.

### 🪞 Para pensar
¿Quién en tu vida sería una buena compañera de hábitos? Alguien que te quiera, pero que no te deje pasar todo.

### ✍️ Escribe
Escribe tu acuerdo con los cuatro puntos. Si todavía no sabes con quién, escribe a quién se lo podrías proponer.

### 💬 Comparte
Mándale un mensaje a esa persona hoy y propónle ser compañeras de hábitos por 30 días.

## 11 · Clase 11 · Tu cancha
*Para ir más lejos · Elige hábitos que van contigo y sigue aunque te aburras*

No todas estamos hechas para lo mismo. Y no tiene nada de malo. La clave es elegir la cancha donde tienes ventaja.

### Juega donde ganas
Cada persona tiene facilidades distintas: hay quien es buenísima frente a la cámara, quien escribe muy bonito, quien organiza todo con gusto y quien conecta con la gente uno a uno. Los hábitos son más fáciles cuando van con lo que ya eres.

Si odias bailar en video, no tienes que construir tu negocio bailando. Puedes hacer reseñas honestas, tutoriales con las manos, fotos bonitas o mensajes personales. Busca la forma de hacer lo que hay que hacer **a tu manera**.

Algunas preguntas que ayudan:
- ¿Qué se me hace divertido y a otras les parece trabajo?
- ¿En qué pierdo la noción del tiempo?
- ¿Qué me sale más natural que a la mayoría?
- ¿Dónde puedo ser distinta en lugar de competir por ser la mejor?

> Si no encuentras un juego que te favorezca, invéntalo.

### La zona justa
La motivación está más alta cuando lo que haces está justo al borde de lo que puedes: ni tan fácil que aburra, ni tan difícil que frustre. Cuando ya dominas tu hábito, súbele un poquito. Si te está costando muchísimo, bájale.

### El enemigo de verdad es el aburrimiento
Al principio todo es emoción. Después, el hábito se vuelve rutina y deja de ser interesante. Ahí es donde casi todas se salen: no porque fracasaron, sino porque se aburrieron.

Lo que separa a quien llega lejos de quien no, casi nunca es el talento. Es poder seguir haciéndolo cuando ya no emociona. Las profesionales se apegan al plan aunque no tengan ganas. Las aficionadas dejan que la vida se interponga.

Hay días en que no vas a tener ganas de publicar, de dar seguimiento o de hacer ejercicio. La diferencia es aparecer de todas formas, aunque sea en la versión de dos minutos.

### 🪞 Para pensar
¿Qué parte de tu trabajo te sale más natural? ¿Estás construyendo tus hábitos sobre eso o en contra de eso?

### ✍️ Escribe
Escribe tu hábito "a tu manera": cómo lo harías aprovechando lo que se te da fácil.

### ✅ Hoy
Haz tu hábito aunque no tengas ganas. Cuando termines, anota cómo te sentiste.

## 12 · Clase 12 · Revisa y crece
*Para ir más lejos · Que tus hábitos no te encierren*

Los hábitos te dejan hacer cosas sin pensar. Esa es su ventaja y también su trampa: cuando algo va en automático, dejas de notar en qué podrías mejorar.

### Hábito más práctica
Cuando un hábito ya sale solo, no lo dejes ahí. Escoge un detalle pequeño y mejóralo a propósito. Ya publicas diario: ahora fíjate en tus primeros tres segundos. Ya das seguimiento: ahora mejora tu primera pregunta.

Hábito para que salga solo, práctica con intención para que siga creciendo. Así se pasa de buena a excelente.

### Revisa sin castigarte
Ponte una cita contigo para revisar cómo vas. Puede ser cada domingo, cada mes y una vez al año. Tres preguntas bastan:
- ¿Qué funcionó?
- ¿Qué no funcionó?
- ¿Qué aprendí?

Y una vez al año, una pregunta más grande: ¿mis hábitos de hoy me están llevando a la vida que quiero? La revisión no es para regañarte, es para ajustar el rumbo con datos y no con culpa.

### Suelta un poco tu identidad
Mientras más te aferras a una sola forma de verte, más te duele cuando cambia la vida. "Soy la que más vende", "soy la mamá que todo lo puede". Si un día no vendes o no puedes, sientes que pierdes quién eres.

Una forma más sana es definirte por lo que valoras, no por un título:
- En vez de "soy la número uno", "soy alguien que se esfuerza y que ayuda a otras a crecer".
- En vez de "soy atleta", "soy alguien a quien le gusta retarse".

Así tu identidad puede crecer contigo en lugar de encerrarte.

### El secreto que dura
Un hábito chiquito no cambia nada por sí solo. Pero cuando lo repites, y le sumas otro, y otro, se vuelve un sistema. Y un sistema bueno, sostenido el tiempo suficiente, cambia una vida.

> No es un cambio de 1000%. Son mil cambios de 1%.

### 🪞 Para pensar
Si sigues con los hábitos que tienes hoy durante cinco años más, ¿a dónde te llevan?

### ✍️ Escribe
Haz tu primera revisión: qué funcionó, qué no y qué aprendiste desde que empezaste el curso.

### ✅ Hoy
Agenda en tu calendario tu revisión semanal: día, hora y lugar.

## 13 · Las cuatro reglas en una hoja
*Herramienta · Para crear un hábito y para dejarlo*

Tómale captura y tenla a la mano.

### Para crear un hábito bueno
#### 1. Que se vea
- Haz tu inventario del día para darte cuenta de lo que haces.
- Ponle una cita: "Voy a [hábito] a las [hora] en [lugar]".
- Engánchalo: "Después de [lo que ya hago], voy a [hábito nuevo]".
- Acomoda tu entorno para que la señal esté a la vista.

#### 2. Que se antoje
- Pega lo que necesitas con lo que te gusta.
- Rodéate de gente para quien tu hábito es lo normal.
- Cambia "tengo que" por "puedo".
- Haz algo que disfrutes justo antes del hábito difícil.

#### 3. Que cueste poquito
- Quítale pasos al hábito bueno.
- Prepara tu espacio para la siguiente vez.
- Hazlo en dos minutos.
- Automatiza lo que se pueda.

#### 4. Que se sienta bien
- Date un premio inmediato y chiquito.
- Tacha tu tracker.
- Nunca falles dos veces.

### Para dejar un hábito malo
#### 1. Que no se vea
- Saca la señal de tu vista y de tu celular.

#### 2. Que no se antoje
- Escribe lo que ganas al dejarlo y lo que te cuesta seguir.

#### 3. Que cueste mucho
- Ponle obstáculos y candados. Decide hoy por tu yo de mañana.

#### 4. Que se sienta mal
- Busca una compañera de hábitos y escriban un acuerdo.

## 14 · El inventario del día
*Herramienta · La lista para darte cuenta de lo que haces*

Escribe todo lo que haces en un día normal, en orden, y ponle un signo a cada cosa.

### Los signos
- **+** me acerca a la mujer que quiero ser.
- **−** me aleja.
- **=** es neutral.

### Un ejemplo
- Me despierto con la alarma del celular. =
- Reviso redes en la cama 20 minutos. −
- Me lavo la cara y me pongo mi rutina de skincare. +
- Preparo desayuno para los niños. +
- Me sirvo café. =
- Contesto mensajes de clientas. +
- Veo videos mientras como. −
- Grabo una historia de producto. +
- Me como algo dulce al llegar a casa. −
- Ceno con mi familia sin celular. +
- Me duermo después de la medianoche. −

### Después del inventario
1. Encierra en un círculo los **+** que quieres proteger.
2. Elige **un** solo **−** para trabajar este mes.
3. Busca en tu lista un hábito que ya hagas siempre para engancharle uno nuevo.

### 🪞 Para pensar
¿Hay algún **=** que en realidad es **−** y no lo habías querido ver?

### ✍️ Escribe
Haz tu inventario completo aquí, con sus signos.

## 15 · Fórmulas para copiar
*Herramienta · Las frases que convierten un deseo en plan*

Copia, llena los espacios y pégalas donde las veas.

### La cita
> Voy a [hábito] a las [hora] en [lugar].

Ejemplo: "Voy a mandar tres mensajes de seguimiento a las 9 en mi escritorio."

### El enganche
> Después de [lo que ya hago], voy a [hábito nuevo].

Ejemplo: "Después de dejar a los niños en la escuela, voy a grabar una historia en el coche."

### El antojo
> Solo voy a [lo que me gusta] mientras [lo que necesito hacer].

Ejemplo: "Solo veo mi serie mientras empaco pedidos."

### La versión de dos minutos
> Mi hábito empieza con [acción de menos de dos minutos].

Ejemplo: "Mi hábito de leer empieza con abrir el libro y leer una página."

### El premio
> Cada vez que [hábito], voy a [premio chiquito].

Ejemplo: "Cada vez que no compro algo por impulso, paso esa cantidad a mi cuenta del viaje."

### La identidad
> Soy el tipo de mujer que [acción].

Ejemplo: "Soy el tipo de mujer que le da seguimiento a sus clientas."

### El acuerdo
> Yo, [nombre], me comprometo a [hábito] durante [tiempo]. Se lo reporto a [persona] cada [frecuencia]. Si no cumplo, [costo].

### ✍️ Escribe
Llena aquí las fórmulas de tu hábito.

## 16 · Tu tracker de 30 días
*Herramienta · Tacha, revisa y nunca falles dos veces*

Un tracker sencillo para tu hábito más importante. Cópialo en tu cuaderno o úsalo en el cuaderno de esta página.

### Cómo usarlo
1. Escribe arriba tu hábito en su versión de dos minutos.
2. Escribe tu cita o tu enganche: cuándo y dónde.
3. Cada día que lo hagas, tacha el cuadro **justo después**.
4. Si un día fallas, marca un punto y al día siguiente hazlo sí o sí. Nunca dos veces.

### Tu mes
- Días 1 a 7: solo aparecer. Versión de dos minutos.
- Días 8 a 14: si ya sale fácil, súbele un poquito.
- Días 15 a 21: busca tu compañera de hábitos si no la tienes.
- Días 22 a 30: fíjate en un detalle y mejóralo a propósito.

### La revisión del domingo
- ¿Cuántos días lo hice esta semana?
- ¿Qué día me costó más y por qué?
- ¿Cuál de las cuatro reglas falló ese día?
- ¿Qué ajusto para la próxima semana?

### ✍️ Escribe
Escribe tu hábito, tu cita y, cada día, un número del 1 al 30 con una ✓ o un punto.
