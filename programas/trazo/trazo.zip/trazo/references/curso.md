# Trazo · contenido completo del curso

Cada bloque empieza con: @@ número | sección | título | subtítulo

@@ 0 | Empieza aquí | Bienvenida a Trazo | Un mes para que tus redes trabajen para ti
Trazo es un mes intensivo para convertir tu perfil en un lugar donde la gente te encuentra, confía en ti y te escribe. Aquí trazas tu ruta paso a paso: un perfil claro, una clienta ideal, una mezcla de contenido, herramientas para producirlo y conversaciones que venden sin rogar.

## Tú eres la marca
La empresa es tu socia comercial; tú eres tu propia marca personal. Integras los productos a tu vida diaria como mamá, profesionista, abuela o lo que seas. Si mañana cambiara todo, tu marca personal seguiría siendo tuya.

## Los tres acuerdos del mes
- **Constancia:** publicar a diario. Si fallas un día, retomas al siguiente, sin esperar al lunes.
- **Simplicidad:** editar un reel no debería tomarte dos horas. Al principio te tomará una; en dos semanas, media.
- **Acción antes que perfección:** no vas a romper Instagram por equivocarte.

## Tus apps
- **Instagram** (obligatoria) y **TikTok** (opcional).
- **CapCut** o **Edits** para editar video.
- **Canva** para diseño.
- **ChatGPT** u otro asistente de IA.
- **Un calendario digital.** Lo que no se agenda no se cumple.

## Empieza tu banco de videos
Graba todos los días clips cortos de 5 a 10 segundos de tu vida: caminar, cocinar, el súper, hacer ejercicio, leer, tu rutina con los productos. Así no dependes del ánimo de cada día para publicar. No necesitas casa "estética", tripié ni micrófono para empezar. Organiza tu banco en: vida diaria, beneficios, testimonios, educación y ventas.

## Cómo usar el curso
Son 19 clases y 5 herramientas. Puedes ir a cualquier clase desde el menú. Si es tu primera vez, ve en orden: cada bloque se apoya en el anterior.

> No buscamos perfección, buscamos acción.

## 🪞 Mírate al espejo
¿Qué te ha detenido hasta hoy para publicar con constancia?

## ✍️ Ejercicio
1. Escribe **qué quieres lograr en este mes** con tus redes, en una frase.
2. Instala las apps que te falten.
3. Graba **3 clips** para tu banco de videos hoy.

## ✅ Tu tarea
Bloquea en tu calendario un horario diario para crear y publicar.

## 💬 Para compartir en el grupo
Comparte tu frase del mes y tu horario de creación.

@@ 1 | Clase 1 | Tu perfil en cuatro puntos | La auditoría del primer día
Antes de pensar en contenido, tu perfil tiene que decir "soy una persona real y te puedo ayudar". Hoy lo revisas punto por punto.

## 1. Foto de perfil
Tú, con la cara bien visible y sonriendo. Sin lentes de sol, sin gorra, sin hijos, pareja ni mascota, sin paisajes ni logos. Nunca una foto hecha con IA. Prueba rápida: ¿le comprarías un champú a alguien cuya foto es un atardecer? No tiene que ser foto ejecutiva; tiene que ser tuya.

## 2. Usuario (@)
Tu nombre, o el apodo por el que ya te conocen. Nunca el nombre de la marca: la gente huye de las cuentas que parecen catálogo. El link de tu tienda sí puede ir en el perfil.

## 3. Campo de nombre
Nombre y un apellido, para dar credibilidad. Puedes sumar tu tema o proyecto: "Ana López · piel después de los 40".

## 4. Descripción
Quién eres o tu filosofía, a quién ayudas y en qué. Corta y concreta. Ejemplos de estructura:
- "Mamá presente y emprendedora. Te enseño a cuidarte sin culpa."
- "Más de 40 y sin manual. Acompáñame en esta etapa."
- "Ayudo a mamás a emprender desde casa, a su ritmo."

Puedes cambiarla las veces que haga falta durante el mes: tu tema se va a afinar en las siguientes clases.

## ¿Cuenta personal o nueva?
Usa tu cuenta personal: esa cuenta eres tú y ya tiene gente que te conoce. No compres seguidores.

## Instagram y TikTok
Instagram premia un mensaje claro: a qué te dedicas y cómo ayudas. TikTok es más natural, como un diario. Al inicio puedes subir lo mismo a las dos y observar qué funciona en cada una. Vincular Instagram con Facebook también lleva tus reels a más gente.

## 🪞 Mírate al espejo
Si alguien que no te conoce entra hoy a tu perfil, ¿sabría en 3 segundos quién eres y en qué le ayudas?

## ✍️ Ejercicio
Usa la **Auditoría de perfil** (en Herramientas) y corrige los cuatro puntos.

## ✅ Tu tarea
Cambia hoy tu foto, usuario, nombre y descripción.

## 💬 Para compartir en el grupo
Comparte tu perfil antes y después.

@@ 2 | Clase 2 | Calma, constancia y cabeza fría | La vacuna contra el agobio
Lo que más hace que la gente abandone no es la falta de estrategia: es la cabeza. Esta clase te prepara para el agobio, la comparación y la postergación que van a aparecer durante el mes.

## El embudo
Arriba hay mucha gente que no te conoce y te encuentra por contenido que se comparte. Unas cuantas te siguen. Menos te compran o se unen a tu equipo. Es normal: así funciona.

## Parte del resultado no depende de ti
La plataforma decide a quién mostrarte y cuándo. Hay quien despega en una semana y quien tarda ocho meses. Compararte es exigirle a tu proceso un ritmo que no controlas.

## Qué pasa cuando te agobias
Exageras problemas pequeños, te comparas con otras y con tu propio contenido anterior, dudas de ti, imaginas lo peor y quieres abandonar. Cuando lo notes, divide lo que te agobia en partes pequeñas: 15 minutos solo para leer, 15 para grabar.

## El viaje en coche
Si en un viaje a un lugar nuevo te bajas cada cinco minutos a revisar las llantas o pides aprobación a todos, no llegas. Ya hay letreros: sigue la ruta.

## La postergación disfrazada
"No publico porque no tengo claridad" y "no tengo claridad porque no publico" son la misma excusa. Pasar horas editando o investigando también puede ser postergar con buena cara. Ser honesta contigo es el primer paso.

## La constancia es neutral
No se siente como fuego. Es rutina. Las que avanzan no son las más emocionadas, sino las más estables. El orden es: **acción → claridad → seguridad → resultados**. No necesitas sentirte cómoda con cómo te ves para grabarte.

## Constancia con estrategia
Publicar a diario sin estrategia tampoco funciona. Por eso el curso te da las dos cosas.

## Aprende a buscar
Google, YouTube y tu asistente de IA son tus mejores amigos para resolver dudas técnicas. Si no entiendes algo, mándale una captura. Nada te hace más independiente que saber resolver.

## 🪞 Mírate al espejo
¿Cuál es tu forma favorita de postergar con buena excusa?

## ✍️ Ejercicio
1. Escribe qué te agobia de este mes y divídelo en 3 partes pequeñas.
2. Responde: ¿qué pierdes si haces lo que te toca durante seis meses, aunque dudes y no veas resultados rápidos?

## ✅ Tu tarea
Arma un pacto con 2 o 3 compañeras: publicar al menos 4 veces esta semana y avisarse cuando lo hagan.

## 💬 Para compartir en el grupo
Comparte tu pacto y con quién lo hiciste.

@@ 3 | Clase 3 | Hablarle a todas es no venderle a nadie | Tu clienta ideal
Si le hablas a todo el mundo, nadie te escucha. La clienta ideal no se encuentra: se elige. Y desde ahí se construye todo lo demás.

## El partido de fútbol
- **La empresa es el deporte:** todas juegan con los mismos productos y el mismo plan.
- **Tu tema es la cancha:** bienestar, belleza o emprendimiento.
- **Tu clienta ideal es tu posición:** portera, defensa o delantera. Cada posición entrena distinto.

Así te diferencias de otras vendedoras de la misma marca.

## Puedes vender todo sin promover todo
En persona puedes ofrecer a cualquiera. En redes, para atraer, le hablas a una sola persona. Después ella te puede comprar cualquier producto.

## Cómo aprende la plataforma
Observa qué ve completo la gente, qué guarda y qué comparte, y le muestra más de eso. Si tu contenido le habla a cinco perfiles distintos, no entiende a quién mostrarte. Tu trabajo no es gustarle a todas, sino ser claramente útil para alguien durante el tiempo suficiente.

## Qué es una clienta ideal
La persona con la que tu oferta encaja mejor: menos resistencia, más probabilidad de actuar, mejor resultado. La señal de que lo lograste es que te escriban "¿me estás espiando?".

## Dos formas fáciles de elegirla
1. **Tú antes de empezar:** tus miedos y frustraciones de entonces, con tus propias palabras.
2. **A quién quieres en tu equipo:** haz tu lista de personas destacadas en lo que hacen. Quien es buena en su profesión suele serlo también aquí.

## Ánclala a un grupo de productos
Ofrécele una solución completa, no un producto suelto: rutina de piel, bienestar, maquillaje o emprendimiento.

## El ejercicio del diario
Pídele a tu asistente de IA: "Escribe el diario de una mujer que es [tu clienta ideal], en primera persona: cómo fue su día, qué le frustró, qué pensó frente al espejo, qué le preocupa, qué quiere cambiar y qué le da miedo admitir. Lenguaje cotidiano, sin soluciones ni motivación."

> Al mundo no le importamos nosotras. Las redes se tratan del reflejo que la gente ve de sí misma en ti.

## 🪞 Mírate al espejo
Si tuvieras que elegir hoy una sola persona a quien hablarle, ¿quién sería?

## ✍️ Ejercicio
Llena la **Matriz de clienta ideal** (en Herramientas). Primero con tu cabeza; después, si quieres, pide ayuda a la IA. Si dudas entre dos perfiles, elige uno: lo puedes cambiar después.

## ✅ Tu tarea
Corre el ejercicio del diario y subraya 5 frases que usarías en tu contenido.

## 💬 Para compartir en el grupo
Comparte tu frase final: "Ayudo a ___ que están en ___, que batallan con ___, a lograr ___ con ___."

@@ 4 | Clase 4 | Ser extraordinaria | Una decisión diaria e incómoda
Ser extraordinaria no es suerte ni talento. Es hacer lo ordinario con intención, disciplina y propósito: presentarte cuando nadie te ve y seguir cuando ya no es cómodo.

## El miedo no protege, limita
Quedarte quieta parece seguro, pero te encierra. Si te da miedo, muchas veces vas en la dirección correcta.

## Tu energía vende antes que tu producto
Hay personas que suben la energía de un lugar y otras que la apagan. Si tú estás apagada, tu equipo se apaga: la gente hace lo que ve, no lo que dices.

## La cadena
**Pensamiento → emoción → acción → resultado.** Lo que piensas de ti y de tu negocio termina en tus resultados. Si quieres cambiar el final, empieza por el principio.

## La IA son los brazos, no el cerebro
Amplifica lo que ya eres. La estrategia, el mensaje y la intención siguen siendo tuyos. Si todas publicaran lo mismo que escribe el chat, las redes serían aburridísimas.

## Mentalidad de líder
- No eres víctima, eres responsable. Al asumirlo recuperas el poder.
- A veces no estás cansada, estás desconectada de tu para qué.
- Nadie va a venir a rescatarte, y eso es buena noticia: el poder está en tus manos.
- Tu primer equipo eres tú: tu disciplina, tu palabra, tu coherencia.

## La ejecución le gana a la motivación
La motivación es una emoción y va y viene. La disciplina es identidad y se queda. Actúa sobre todo cuando no hay ganas.

## Visibilidad
Si no te ven, no existes. El mundo no premia al mejor, sino al más visible y constante. Tu historia, lo que viviste y superaste, es lo que conecta.

## Con los pies en la tierra
Comprometerte al cien no significa arriesgar tu estabilidad. Crece tu negocio con decisiones responsables para ti y tu familia.

> El éxito sin paz no es éxito.

## 🪞 Mírate al espejo
¿Hoy subes o bajas la energía de tu equipo?

## ✍️ Ejercicio
1. Escribe un pensamiento que te limita y la cadena que produce (emoción, acción, resultado).
2. Reescribe el pensamiento y la nueva cadena.
3. Escribe tu **para qué** en una frase.

## ✅ Tu tarea
Publica hoy, aunque no tengas ganas.

## 💬 Para compartir en el grupo
Comparte tu para qué.

@@ 5 | Clase 5 | Tu marca personal | Que te elijan sin rogar
Tu marca personal es la huella que dejas en quien te ve: tus valores, tu experiencia, tu personalidad. Bien hecha, funciona como imán y como filtro: llega gente lista y con confianza.

## Sin marca y con marca
- **Sin marca:** historias que son puras promociones, posts de precios, mensajes copiados. Se siente invasivo.
- **Con marca:** tu proceso real, educación sencilla, tu opinión, un estilo de vida coherente. La gente quiere lo que tú usas porque te ve usarlo.

## No se trata de estar lista
Sentirte lista no es una emoción, es una decisión. Consumir sin publicar, ver historias sin responder o esperar a "tener seguidores" son formas de comodidad. Pregunta clave: ¿tu razón para moverte ya es más fuerte que tus excusas?

## Los cinco pilares
1. **Autenticidad:** habla como hablas en la vida real. Tu historia más incómoda suele ser tu diferencia.
2. **Coherencia:** lo que haces y dices, en línea y fuera, va alineado. Tu propuesta no cambia cada semana.
3. **Propuesta de valor:** a quién ayudas, con qué y para qué.
4. **Diferenciador:** no inventas nada nuevo; dices lo mismo desde tu vida.
5. **Percepción:** no publicar también comunica.

## La fórmula de tu bio
> Ayudo a **[quién]** a **[resultado]** **[cómo o sin qué sacrificio]**.

Escríbela muchas veces hasta que suene a ti. Cuida que el resultado sea algo que puedes sostener: nada de promesas de dinero o de salud.

## La prueba de los tres segundos
Al entrar a tu perfil, ¿saben quién eres, qué haces y si eres para ellas?

## Tus componentes
Valores y habilidades · propuesta de valor · **tono** (cercano, educativo, inspirador o directo, pero sostenido) · **identidad visual** (tus colores y tus dos tipografías) · visibilidad (responder todos los comentarios).

## El error número uno
Creer que vendes productos. Vendes tu criterio, tu estilo de vida, tu energía y tu visión. Tu marca no depende de ser guapa, alta o delgada: depende de tu trabajo y tu historia.

## Si ya le rogaste a alguien
Suéltala. La presión aleja; la marca atrae.

## 🪞 Mírate al espejo
¿Comunicas desde quien eres o desde lo que crees que deberías ser?

## ✍️ Ejercicio
1. Escribe tus fortalezas, tu historia en 3 líneas y el tema que podrías sostener.
2. Escribe 3 versiones de tu bio con la fórmula.
3. Haz la prueba de los tres segundos con alguien que no te conozca bien.

## ✅ Tu tarea
Actualiza tu bio y archiva (no borres) las publicaciones que ya no encajan.

## 💬 Para compartir en el grupo
Comparte tus 3 versiones de bio.

@@ 6 | Clase 6 | Alcance, conexión y venta | La mezcla 7-2-1
Una cuenta que vende hace tres cosas a la vez: atrae gente nueva, genera confianza y pide la venta. Si te falta una, terminas famosa sin negocio, o vendiéndole a nadie.

## La mezcla de cada 10 publicaciones
- **7 de alcance:** contenido sencillo que la gente guarda o le manda a su comadre. Humor, tips, recetas, "sí, soy yo".
- **2 de conexión:** tu historia, tus errores, antes y después, educación, testimonios reales, recursos gratis.
- **1 de venta:** clara y directa: el producto, la invitación al negocio, el llamado a la acción.

## Los tres errores
- Solo conectar: te quedas con 50 seguidores para siempre.
- Solo vender: te quemas con las mismas 100 personas.
- Solo alcance: muchas vistas y nadie que compre.

## El cine
No todo el que entra al cine compra palomitas, y eso no significa que el cine no sirva. El contenido de conexión tendrá menos vistas que el de alcance. No dejes de hacerlo: ahí está la confianza que vende.

## Que la carnada y el pescado coincidan
Atrae con el mismo tema que luego vendes. Si atraes con recetas de crianza, te van a pedir soluciones de crianza, no maquillaje. Máximo dos temas y que se complementen (piel y maquillaje; bienestar y cuidado del cabello).

## La conexión que abre conversaciones
"Comenta GUÍA y te mando mi checklist de…" Cuando te escriban, no mandes el link en automático:
1. Agradece.
2. Pregunta su situación: "Antes de mandártela, cuéntame qué quieres lograr".
3. Comparte el recurso o un consejo.
4. Si encaja, ofrece el producto o la reunión de negocio.

El gancho tiene que ser específico y deseable. "Comenta YO si quieres cambiar tu vida" no funciona.

## La venta
"Si no pides la venta, nunca te compran." Sé clara, muestra el producto y dile cómo comprar. La urgencia y los descuentos solo si son reales.

## Calcula tu semana
| Publicaciones por semana | Alcance | Conexión | Venta |
|---|---|---|---|
| 7 (una al día) | 5 | 1 | 1 |
| 10 | 7 | 2 | 1 |
| 14 (dos al día) | 10 | 3 | 1 |

Las historias van aparte: ahí conectas y vendes todos los días.

> La complicación es enemiga de la ejecución.

## 🪞 Mírate al espejo
De tus últimas 10 publicaciones, ¿cuántas fueron de cada tipo?

## ✍️ Ejercicio
Usa el **Planificador 7-2-1** (en Herramientas) para armar tu semana.

## ✅ Tu tarea
Crea tu primer recurso con palabra clave y publícalo.

## 💬 Para compartir en el grupo
Comparte tu planificador de la semana.

@@ 7 | Clase 7 | Encuentra lo que ya funciona | Formatos probados para tu clienta
El contenido de alcance no se inventa desde cero: se investiga. Hay formatos que ya demostraron que tu clienta los ve, los guarda y los comparte. Tu trabajo es encontrarlos y hacer tu propia versión.

## Tu cuenta de investigación
Abre una segunda cuenta solo para investigar, como si fueras tu clienta ideal. Ahí buscas, ves y guardas sin que eso confunda a tu cuenta principal. En tu cuenta principal, interactúa con tu comunidad y evita usarla para entretenerte con cualquier cosa.

## Por qué no "sígueme y te sigo"
Si sigues a cientos de compañeras de la misma marca, la plataforma aprende a mostrarte a vendedoras, no a tu clienta.

## Cómo buscar
1. En la lupa escribe una palabra del mundo de tu clienta ("menopausia", "rutina de piel", "mamá primeriza"). Una palabra suele funcionar mejor que dos.
2. Busca piezas con **muchas vistas en cuentas pequeñas**. Así sabes que funcionó la idea, no la fama de la persona.
3. Fíjate en los **compartidos y guardados**: valen más que los likes.
4. Elige las que puedas hacer fácil en tu casa.
5. Si no encuentras, prueba sinónimos, otro idioma o pide ideas de palabras a tu asistente de IA.

## Haz tu versión, no una copia
Toma el formato: la duración, el tipo de escena, la estructura del texto, el ritmo. Grábalo tú, con tus palabras, tu casa, tu producto y un audio disponible en la app. No descargues ni resubas videos ajenos, ni copies textos palabra por palabra. Tu marca está en cuáles formatos eliges y cómo los cuentas.

## Sal tú
Los memes sin tu cara sirven de emergencia, pero no construyen tu marca. Si no estás lista para que te vean, este es el momento de empezar.

## Señales que importan
1. Compartidos. 2. Guardados. 3. Comentarios. Los likes son lo que menos dice. Menos de un minuto suele funcionar mejor. Sube a cada plataforma por separado, sin marca de agua de la otra app.

## Los tres gatillos
- **Identificación:** "sí, soy yo".
- **Entretenimiento:** humor, sorpresa.
- **Utilidad:** una guía completa que la gente guarda.

## 🪞 Mírate al espejo
¿Estás eligiendo contenido por lo que te gusta a ti o por lo que necesita tu clienta?

## ✍️ Ejercicio
1. Crea tu cuenta de investigación.
2. Guarda **10 formatos** que cumplan los criterios.
3. Elige los 3 más fáciles de hacer.

## ✅ Tu tarea
Graba y publica tu versión de 3 formatos esta semana.

## 💬 Para compartir en el grupo
Comparte el formato original (link) y tu versión.

@@ 8 | Clase 8 | Historias limpias y atractivas | Que se entiendan en dos segundos
Una historia que funciona no es la más estética: es la que se entiende en dos segundos y dice qué hacer después.

## Las reglas base
1. **Se entiende en 2 segundos**, con o sin sonido. Si hablas a cámara, pon la idea principal en texto.
2. **Una idea por historia.** Desayuno, ejercicio y rímel en la misma historia confunden.
3. **Tus colores y tus 2 tipografías**, siempre las mismas.
4. **No satures:** pocos gifs, pocos textos, espacios vacíos.
5. **Lo grande atrae:** una foto o frase principal; lo demás complementa.

## La historia de venta
**Frase principal** ("Sí se puede vender sin perseguir") + **frase secundaria** corta ("usando tus historias") + **llamado suave** ("¿Quieres saber cómo? Te explico") con flecha, encuesta o sticker. Mientras más suave el llamado, más respuestas.

## La serie de 4
1. **Conecta** con un dolor: "Tomé café tarde y no dormí".
2. **Identificación:** que se vean reflejadas.
3. **Lo que a ti te funcionó**, contado como experiencia, sin prometer resultados.
4. **Llamado a la acción.**

Error común: subir directo la foto del producto con todos sus beneficios. Mucho texto sin contexto se brinca.

## El sticker no es adorno, es dirección
Cada sticker dice qué hacer: votar, responder, reaccionar, ir al link. La encuesta con opciones positivas ("¡Me urge!" / "Cuéntame más") y el deslizador de emoji generan respuesta.

## Trucos de Instagram
- **Cuentagotas** para tomar un color de la foto y que todo combine.
- **Marcador** manteniendo el dedo para un velo translúcido detrás del texto.
- **Menciones limpias:** etiqueta y esconde la etiqueta fuera de la pantalla.
- **Compartir historias de otras** que lo permitan, con tu contexto (por ejemplo, testimonios reales de tu equipo).
- **Fondos:** tu espacio limpio o una foto tuya.

## El "chisme" con propósito
"Vamos a chismear" con encuesta funciona, pero siempre lleva a algo.

## 🪞 Mírate al espejo
Revisa tus historias de ayer: ¿cuántas se entendían en 2 segundos?

## ✍️ Ejercicio
Arma una historia de venta con frase principal, secundaria y llamado suave. Revísala con el **Checklist de historias** (en Herramientas).

## ✅ Tu tarea
Sube tu primera serie de 4 historias.

## 💬 Para compartir en el grupo
Comparte capturas de tu serie.

@@ 9 | Clase 9 | Comparte con naturalidad | Sé la primera prueba de lo que recomiendas
La conexión en redes viene de mostrarte tal cual eres y usar los productos en tu vida real. La IA nunca le va a ganar a una emoción auténtica.

## Clienta y comunidad
La meta es que te sigan como a una amiga que te deja entrar a su día. Habla como tú a gente como tú.

## Producto del producto
Si recomiendas maquillaje o cuidado personal, úsalo y muéstralo. Que te pregunten "¿qué te hiciste?". Lo que muestras es tu experiencia; no prometas resultados que no puedes garantizar a otras.

## Las historias también son para vender
El miedo a "fastidiar" es más grande que la realidad. Comparte desde "esto me ayudó y te lo quiero contar", no desde "cómprame". Muestra lo que de verdad usas: el kit que llevas de viaje, tu rutina de la mañana.

## Recomienda más que productos
Recetas, libros, lugares, lo que te gusta. Eso te da credibilidad para cuando recomiendas lo que vendes.

## Tu set
- Luz de ventana o una pared blanca.
- Un tripié o soporte para celular.
- Si puedes, una lámpara o aro de luz.

No necesitas más para empezar.

## Graba en lote
Un día ya arreglada, cambia de blusa o peinado y graba varias piezas para varios días o antes de un viaje.

## Ganchos naturales
Contar una anécdota y meter el producto en medio conecta mucho más que un gancho obvio. La gente quiere distraerse, reír y sentirse acompañada.

## Aceptarte en cámara
Verte a diario ayuda a aceptarte. Lo que llamas defectos te hace única. Si alguien ataca algo que ya aceptaste, no te mueve. A los comentarios negativos: lee, no te enganches, sigue.

## Tu primer video va a estar feo
Todas tienen uno. Ponle tu toque a todo y sigue.

## 🪞 Mírate al espejo
¿Qué usas todos los días y nunca has mostrado?

## ✍️ Ejercicio
1. Arma tu set en casa y toma una foto.
2. Escribe 5 momentos reales de tu día donde usas los productos.

## ✅ Tu tarea
Graba en lote 4 piezas en una sola sesión.

## 💬 Para compartir en el grupo
Comparte la foto de tu set.

@@ 10 | Clase 10 | CapCut: lo básico | Cortes, subtítulos y textos con ritmo
CapCut es tu herramienta para editar reels dinámicos. Hoy aprendes lo que vas a usar en todos tus videos. Las funciones con diamante son de paga.

## Antes de editar
- **Deja aire** al grabar para poner textos.
- **Zona segura:** no pongas texto en la franja de abajo ni en el lado derecho, donde la app pone comentarios y botones.
- **Graba de corrido:** si te equivocas, haz una pausa, repite la frase y lo arreglas al editar.

## 1. Cortar
Toca el clip → **Dividir** en cada error o silencio. Arrastra los bordes para ajustar. Haz zoom en la línea de tiempo con dos dedos para cortar con precisión.

## 2. Ritmo
Algo visual debe cambiar seguido: un corte, un texto o una imagen cada medio segundo aproximadamente. Eso retiene.

## 3. Volumen
Sube tu voz y baja la música para que siempre se entienda lo que dices.

## 4. Subtítulos automáticos
**Subtítulos → Generar.** Revisa que estén bien escritos. Desmarca "Aplicar a todos" si quieres darle estilo distinto a una parte; márcalo si quieres el mismo estilo en todo. **Eliminar muletillas** quita los "eh" y "este".

## 5. Tipografía y estilo
Usa **dos fuentes**: una base y otra para resaltar. Para que se lean: un delineado fino y una sombra negra suave (opacidad baja, un poco de desenfoque). Evita las plantillas de subtítulo muy recargadas.

## 6. Animaciones de texto
De entrada, salida o en bucle. Guarda tus favoritas manteniendo el dedo → **Favoritos**, igual con fuentes y audios, para no perder tiempo buscando.

## 7. Texto palabra por palabra
Duplica el subtítulo tantas veces como palabras, deja una palabra por copia y escalona la entrada de cada una.

## 8. Texto detrás de ti
Duplica tu clip → **Superposición** → alinéalo con el original → **Eliminar fondo** → en **Capas** manda el texto detrás del recorte.

## 9. Imágenes de apoyo
**Superposición → Agregar** una foto tuya o una imagen oficial del producto → **Eliminar fondo** → animación de entrada.

## 10. Exportar
Elige resolución y cuadros por segundo. 1080p a 30 fps es suficiente para redes. Usa la versión de la app que te corresponda y no trucos para quitar la marca de agua.

> No tiene que quedar profesional. Tiene que salir.

## ✍️ Ejercicio
Edita un video de 15 a 30 segundos con: cortes sin silencios, subtítulos con tus dos fuentes, una animación guardada en favoritos y un texto detrás de ti.

## ✅ Tu tarea
Publícalo.

## 💬 Para compartir en el grupo
Comparte tu video y qué fue lo más difícil.

@@ 11 | Clase 11 | CapCut: el siguiente nivel | Filtros, sonido, retoque y teleprompter
Con lo básico ya puedes publicar. Esta clase suma lo que hace que tu video se vea y se escuche mejor.

## Filtros y énfasis
- Los filtros son de luz y color. Uno oscurecido hace que resalte el texto.
- **Énfasis:** selecciona un fragmento → filtro blanco y negro + un filtro de voz. Cambia la imagen y el sonido a la vez.
- **Zoom por cortes (gratis):** divide el clip en cada palabra clave y agranda un poco cada fragmento.
- **Desenfoque de fondo** si tu casa no está arreglada.

## Ajustes
Brillo, contraste, saturación, sombras. Con paga: reducir ruido, estabilizar y mejorar calidad.

## Stickers
Pocos y con intención: una flecha, una notificación, una manita. Se pueden animar y duplicar.

## Retoque con medida
Rostro y piel con intensidad baja. Importante: **Aplicar a todo** para que no cambie a media toma. No abuses: el exceso se ve falso y en contenido de belleza o bienestar engaña.

## Formato vertical
Si grabaste en horizontal, la ampliación con IA puede llevarlo a 9:16.

## Sonido
- **Música:** usa la biblioteca de la app o guarda audios en tendencia desde Instagram o TikTok y úsalos dentro de esa misma app.
- **Efectos de sonido:** pop, clic, teclado. Ponle uno a cada texto que aparece; mejora mucho la retención.
- **Mejorar voz** al 100 para quitar ruido de fondo.
- **Ritmos:** marca los golpes de la canción y cambia de imagen en cada uno.

## Teleprompter
**Grabar** → pega tu guion → ajusta velocidad y tamaño → graba mirando a la cámara.

## El orden que ahorra tiempo
Primero pon subtítulos y después corta: los subtítulos te enseñan dónde están los silencios.

## Poco a poco
Primer video: solo cortes y subtítulos. Segundo: suma efectos de sonido. Tercero: un énfasis. Querer un video perfecto a la primera es la manera más rápida de no publicar.

## ✍️ Ejercicio
Edita un video con: zoom por cortes, un énfasis en blanco y negro, efectos de sonido en cada texto y voz mejorada.

## ✅ Tu tarea
Graba un video usando el teleprompter y publícalo.

## 💬 Para compartir en el grupo
Comparte tu efecto de sonido favorito.

@@ 12 | Clase 12 | Canva: diseña desde cero | Capas, fondos y tu tipografía sagrada
Canva sirve para posts, carruseles, portadas y más. Hoy diseñas desde cero, en la computadora, con tu propio estilo.

## Principios
- **Evita las plantillas genéricas** tal cual: todas las usan y se nota. Si usas una, cambia fondo, fuentes y colores.
- **Edita en la computadora:** en el celular no ves bien las capas. El celular sirve para descargar.
- **Tipografía sagrada:** una fuente principal para lo que quieres resaltar, siempre la misma. Una segunda para lo demás.
- Canva Pro vale la pena si creas mucho, pero puedes empezar con la versión gratis.

## Pasos para un carrusel
1. **Crear diseño** → busca "post de Instagram". El formato 3:4 da más espacio que el cuadrado.
2. **Fondo:** selecciona el lienzo → color de tu paleta.
3. **Sube tu foto** → **Quitar fondo** (Pro) si lo necesitas.
4. **Texto:** divide la frase en 2 o 3 cajas para combinar fuentes y resaltar una palabra.
5. **Capas** (Posición → Capas): para texto detrás de ti, el orden es fondo → texto → foto sin fondo.
6. **Formas** detrás del texto para resaltarlo, con esquinas redondeadas.
7. **Contorno tipo sticker:** foto → Editar → Sombras → Contorno blanco.
8. **Segunda diapositiva:** título con tu fuente principal y una lista corta.
9. **Texto curvo:** Efectos → Curvar.
10. **Marcos:** Elementos → Marcos para meter tu foto en un celular o círculo.
11. **Foto oscurecida con texto:** fondo negro y tu foto encima con transparencia baja; el texto resalta encima.

## Imágenes
Usa tus fotos o las oficiales de la marca. Pinterest sirve para inspirarte, no para descargar imágenes ajenas.

> Si algo no te gusta, lo quitas. Aquí no hay error que no se arregle.

## ✍️ Ejercicio
Diseña un carrusel de 2 diapositivas: portada con tu foto, texto detrás de ti y tu fuente principal; segunda diapositiva con una lista de 3 puntos.

## ✅ Tu tarea
Publícalo como tu contenido de conexión de la semana.

## 💬 Para compartir en el grupo
Comparte tu portada.

@@ 13 | Clase 13 | Canva: kit de marca y animación | Historias y reels animados en minutos
Con un kit de marca, todo lo que diseñas sale con tus colores y tus fuentes. Y con plantillas propias, un reel animado te toma minutos.

## Tu kit de marca
**Marca → Agregar kit de marca.**
- **Colores:** tu paleta con sus códigos. La versión gratis guarda pocos; Pro, los que quieras.
- **Logo o firma:** en blanco, negro y color.
- **Fuentes:** principal y secundaria.
- Puedes guardar fotos e íconos que usas siempre.

Para aplicarlo a cualquier plantilla: abre la plantilla → **Marca** → tu kit.

## Historia o reel animado
1. **Crear diseño → Reel de Instagram.**
2. Fondo con un color de tu paleta.
3. Agrega elementos (flechas, flores, líneas) y tu foto o producto.
4. Todo dentro del marco para que no se corte.
5. Título con tu fuente principal y un llamado: "Consíguelo aquí".
6. **Animar** cada elemento por separado: máquina de escribir, ascender, aparecer.
7. En la línea de tiempo, **escalona** las entradas para que aparezcan en cascada.
8. Que dure **10 segundos o menos**.
9. Descarga en **MP4** para conservar la animación.

## Tus plantillas
Tres puntitos → **Crear una copia**, cambia el producto o la temporada y listo. Así tienes plantillas propias para cada semana.

## Videos con material de la app
Busca videos del banco de Canva, únelos y agrega transiciones con clic derecho. Pon la música al final en Instagram o TikTok.

## ✍️ Ejercicio
1. Crea tu kit de marca.
2. Haz una historia animada de un producto con 3 elementos que entren en cascada.

## ✅ Tu tarea
Guárdala como plantilla y haz una segunda versión con otro producto.

## 💬 Para compartir en el grupo
Comparte tu historia animada.

@@ 14 | Clase 14 | Color para tu marca | Lo que tu paleta comunica
Los colores comunican antes que las palabras. Elegirlos con intención, y no solo por gusto, ayuda a que tu marca se vea coherente y te reconozcan sin ver tu nombre.

## Tómalo como guía, no como ley
Estas asociaciones vienen de la publicidad y cambian según la cultura y la persona. Úsalas para decidir, no como reglas científicas.

## Lo que suele comunicar cada color
| Color | Suele transmitir | Úsalo para |
|---|---|---|
| Rojo | Pasión, energía, alerta | Acentos y llamados puntuales, no como color principal |
| Azul | Confianza, calma, responsabilidad | Color principal en temas de organización, finanzas o metas |
| Verde | Naturaleza, calma, frescura | Bienestar y mensajes que no deben asustar |
| Amarillo o dorado | Calidez, alegría, valor | Acentos que iluminan; dorado para un toque especial |
| Naranja | Juventud, diversión | Campañas cortas o público muy joven |
| Morado | Exclusividad, elegancia, espiritualidad | Marcas que buscan verse sofisticadas |
| Café | Tierra, tradición, experiencia | Marcas naturales y cercanas |
| Rosa | Dulzura, feminidad, cercanía | Público principalmente femenino |
| Negro | Elegancia, lujo, fuerza | Fondos y portadas; con dorado se ve premium |
| Blanco | Limpieza, calma, minimalismo | Espacio para respirar; bienestar y calma |
| Varios colores | Diversidad, alegría, innovación | Un color base y los demás de acento |

## Cómo elegir tu paleta
1. Piensa en cómo quieres que se sienta tu clienta cuando te ve.
2. Elige un color principal, uno secundario y uno de acento.
3. Si odias un color, busca otro que transmita lo mismo.
4. Pruébala en 3 piezas antes de decidir.

## Una paleta, toda tu comunicación
Posts, reels, historias, PDF y presentaciones salen de la misma paleta. Si un día cambias de colores, hazlo como un relanzamiento, no a medias.

## Sobre la urgencia
El rojo llama la atención, pero úsalo para avisos reales: "se acabó", "último día". Nunca para fingir que quedan pocos lugares o que el precio sube.

## ✍️ Ejercicio
Elige tus 3 colores y tus 2 fuentes. Guárdalos en tu kit de marca.

## ✅ Tu tarea
Rediseña tu próxima portada con tu paleta nueva.

## 💬 Para compartir en el grupo
Comparte tu paleta y qué quieres que transmita.

@@ 15 | Clase 15 | Tu asistente de IA | Piensa contigo, no por ti
ChatGPT y otros asistentes son como una asistente disponible a cualquier hora. Te ayudan a escribir, organizar y destrabarte, si les das buenas instrucciones y siempre lees lo que te devuelven.

## Tú eres la jefa
Se equivoca. Lee todo, cuestiona y adapta a tu forma de hablar. Si copias y pegas, suena a robot y la gente lo nota.

## La fórmula del prompt
1. **Rol:** "Actúa como experta en…"
2. **Contexto:** quién eres y qué haces.
3. **Objetivo:** qué pieza exactamente (post, historia, mensaje).
4. **A quién le hablas:** tu clienta ideal.
5. **Canal:** Instagram, WhatsApp, correo.
6. **Tono:** cercano, directo, cálido… y "sin promesas exageradas".

## Ejemplo
> Actúa como estratega de contenido para emprendedoras de venta directa. Vendo productos de belleza y bienestar a mamás que trabajan. Ayúdame con 7 ideas de contenido para Instagram esta semana: 5 de alcance, 1 de conexión y 1 de venta. Tono cálido y realista, sin promesas de ingresos ni de salud.

## Técnicas que hacen la diferencia
- **Itera:** "más corto", "más cálido", "para mamás de adolescentes". La primera respuesta casi nunca es la buena.
- **Pide 3 versiones:** emocional, educativa y directa. Combina lo mejor.
- **Dicta por voz** tus ideas y pídele que las ordene.
- **Dale tu contexto:** cómo hablas, qué te gusta, qué no dices nunca.
- **Destrábate:** "Ayúdame a entender por qué estoy evitando publicar sobre…"
- **Planea:** "Tengo 30 minutos al día. Ayúdame a planear mi semana de contenido."

## Organízalo en proyectos
Crea un proyecto por área (contenido, ventas, productos, mi clienta ideal) y conversaciones dentro de cada uno. Si cambias de tema o de clienta, actualiza la información que le diste.

## Para mensajes uno a uno
Úsalo para ordenar qué decir, pero manda el mensaje con tus palabras, o mejor en nota de voz. El texto generado suele sonar a anuncio.

## Imágenes con IA
Úsalas con medida. Que tu contenido principal seas tú, real. No uses IA para tu foto de perfil ni para fingir resultados.

## ✍️ Ejercicio
Escribe tu prompt base con los 6 elementos y guárdalo. Pruébalo pidiendo tus ideas de la semana.

## ✅ Tu tarea
Crea tus proyectos y corre 3 prompts de la herramienta **Prompts para tu negocio**.

## 💬 Para compartir en el grupo
Comparte el prompt que mejor te funcionó.

@@ 16 | Clase 16 | Vender sin vender | Conectar en lugar de perseguir
A muchas les da pena vender. Pero vender bien no es perseguir ni presionar: es atraer, escuchar y compartir experiencias reales.

## Lo que creemos y lo que sí es
| Lo que creemos que es vender | Lo que sí es |
|---|---|
| Insistir | Persistir, buscando otra forma |
| Incomodar | Generar confianza con honestidad |
| Perseguir | Atraer |
| Recitar fichas técnicas | Contar soluciones desde tu experiencia |
| Hablar mucho | Escuchar y observar |
| Convencer | Inspirar |
| Presionar | Despertar el deseo |

## Como una doctora
Antes de recomendar, pregunta: ¿qué busca?, ¿qué ha probado?, ¿qué le importa? Escucha antes de proponer y personaliza la solución. Nada de guiones genéricos.

## Empieza por la experiencia
En lugar de "Hola, tengo un programa", prueba "¿A ti también te pasó que…?". Primero el resultado emocional que viviste; los detalles técnicos, si preguntan.

## Un producto gancho
Como la tienda ancla de un centro comercial: conectas con uno que amas y desde ahí la persona conoce los demás.

## Las objeciones con curiosidad
"¿Por qué no te funcionó?", "¿Cómo lo usaste?". Los "no" son información, no un fracaso.

## El trabajo invisible
- **Cuida a tus clientas actuales:** conseguir una nueva cuesta varias veces más que venderle a quien ya confía.
- **Actúa como dueña desde hoy.**
- **Mide:** una hoja simple con quién compra, cada cuánto y qué.
- **Piensa a largo plazo**, no solo en el cierre del mes.
- **Cumple:** puntualidad y palabra construyen reputación.

## Hábitos que sostienen
- **Pega un hábito nuevo a uno que ya tienes:** "después de lavarme los dientes, escribo a 3 clientas".
- **Deja todo listo el domingo.**
- **Mejora 1% al día.**

## 🪞 Mírate al espejo
¿Cuál es tu objeción interna para vender?

## ✍️ Ejercicio
1. Escribe tu objeción interna y una frase para contestarle.
2. Arma tu hoja de seguimiento de clientas.
3. Elige el hábito que vas a pegar a tu rutina.

## ✅ Tu tarea
Escríbele a 3 clientas actuales para preguntarles cómo les ha ido, sin venderles.

## 💬 Para compartir en el grupo
Comparte tu hábito pegado.

@@ 17 | Clase 17 | Tu ecosistema digital | Cada canal tiene su trabajo
Las grandes marcas usan varios canales y cada uno tiene una función. Tú puedes hacer lo mismo a tu escala.

## Los canales
- **La tienda en línea:** la marca ya la tiene. Tu trabajo es llevar gente a ella. Recomienda productos juntos ("completa tu rutina").
- **Tu "blog":** un canal de difusión, historias destacadas o un videoblog donde le hablas a tu comunidad más fiel sin vender. Una vez al mes basta.
- **Mensajes directos y listas:** canal de difusión de Instagram, WhatsApp Business o correo. Llegan a quien no está viendo redes y son más directos para comprar. Escribe solo a quien aceptó recibirlos.
- **Publicidad pagada:** funciona mejor cuando el anuncio parece contenido normal. Si tu contenido orgánico todavía no conecta, espera. Empieza con poco y mide.

## Cada red, su papel
- **Instagram:** interacción y llevar gente a tu WhatsApp o tienda.
- **Facebook:** conversación en grupos y Messenger; ahí también funcionan los reels.
- **TikTok:** que te descubra gente nueva.
- **Pinterest:** inspiración y búsqueda de productos.

Puedes reciclar el mismo contenido en varias redes y reservar piezas especiales para cada canal.

## Grande, mediana y diaria
- **Pieza grande:** una al mes, más trabajada (un video largo, un lanzamiento). De ella salen muchas pequeñas.
- **Piezas medianas:** algunas por semana: promociones, tutoriales.
- **Piezas diarias:** el día a día que te mantiene presente.

## Mide
Deja crecer cada publicación 3 o 4 días y revisa: cuántas personas la vieron, cuántas interactuaron y cuántas dieron clic. Pregúntate por qué funcionó o no.

> Lo que no se mide no se puede repetir.

## ✍️ Ejercicio
Dibuja tu ecosistema: qué canales usas, para qué sirve cada uno y cuál te falta.

## ✅ Tu tarea
Planea tu pieza grande del mes y escribe 5 piezas pequeñas que saldrán de ella.

## 💬 Para compartir en el grupo
Comparte tu pieza grande.

@@ 18 | Clase 18 | De 0 a 100 | Sostener tu tema y tu visibilidad
Las que crecen no son las que nunca tuvieron miedo, sino las que eligieron un tema y lo sostuvieron todos los días, con ganas y sin ganas.

## El tema se decide, no se encuentra
No cae como iluminación. Aparece mientras publicas, te equivocas y conectas. El error común es cambiar de tema cada semana. Un tema imperfecto que sostienes funciona mejor que uno perfecto que abandonas.

## La repetición
Las cuentas que dominan un tema dicen lo mismo de muchas maneras. Repetir no aburre: te posiciona.

## El viaje de tu clienta
1. Te observa en silencio.
2. Guarda o comparte.
3. Interactúa con un emoji o una encuesta.
4. Se anima a escribirte.

Nadie escribe de la nada: es siembra.

## Cuando te escriba
**Escucha → conecta → acompaña → la venta llega sola.** Pregunta qué la movió a escribirte y en qué etapa está, antes de hablar de productos.

## Visibilidad para valientes
Ser visible no es gritar ni ser perfecta ni extrovertida: es mostrarte aunque te tiemble la voz. El primer video da pena; no lo borres, para que se note tu avance. Como aprender a nadar: primero los pies, luego chapotear, luego nadar.

## Rodéate de gente que suma
Busca a quienes te dicen "sí puedes". El brillo de una incomoda a algunas; no es tu problema.

## Hábitos que hacen crecer
- Usar los productos y mostrarlos.
- Preparar tu imagen y tu contenido con anticipación.
- Abrir tu "tienda" todos los días, en línea y en persona.
- Aceptar oportunidades de mostrarte aunque den miedo.
- Metas escalonadas: un mes bajo no es fracaso, se remonta.
- Planear: crear y programar un día, revisar y ajustar a media semana.

## Comentarios negativos
Lee, no contestes con enojo, sigue. Perder seguidores que no son tu clienta está bien.

> La claridad sostenida le gana a la viralidad de un día.

## 🪞 Mírate al espejo
¿Cuántas veces has cambiado de tema en los últimos meses?

## ✍️ Ejercicio
Responde: ¿a quién le hablo?, ¿qué siente hoy?, ¿qué voy a subir esta semana para que diga "esa soy yo"?

## ✅ Tu tarea
Define tu día de crear y tu día de revisar, y agéndalos.

## 💬 Para compartir en el grupo
Comparte tu tema en una frase.

@@ 19 | Clase 19 | Graduación | Hazlo sola y enséñalo
El curso termina; tu etapa de hacerlo sola empieza. Ya tienes el paso a paso. Ahora toca sostenerlo, pulirlo y enseñarlo.

## Constancia con estrategia
Publicar a diario sin estrategia no da resultados. Con un tema claro, una mezcla 7-2-1 y formatos probados, sí. Si no ves resultados, revisa: ¿definiste tu tema?, ¿publicaste a diario?, ¿seguiste la mezcla?

## Duplica, no solo compartas
Vuelve a ver las clases, aplícalas y enséñalas a tu equipo. Cuando explicas algo, lo aprendes dos veces y tu equipo te reconoce como líder.

## Ya influyes
Si influyes en una persona, ya eres influencer. Celebra en público tus avances pequeños.

## Dimensiona tu alcance
Si 300 personas vieron tu video, piensa en un salón lleno. Si fueron 3,000, un teatro. Compáralo con lo que tardarías puerta por puerta.

## No te compares
Detrás de cada éxito visible hay meses de constancia que no ves. El presente de otra puede ser tu futuro si haces el trabajo.

## Lidera con el ejemplo
No pidas a tu equipo lo que tú no haces. Tu marca personal te acompaña siempre.

## Lo que ya tienes
- Tu perfil auditado.
- Tu clienta ideal.
- Tu bio y tu marca personal.
- Tu mezcla 7-2-1 y tu cuenta de investigación.
- Historias limpias y tu set.
- CapCut, Canva, tu paleta y tu asistente de IA.
- Tu forma de vender sin perseguir.

## 🪞 Mírate al espejo
¿Qué hiciste este mes que antes te daba miedo?

## ✍️ Ejercicio
1. Escribe 3 cambios que lograste.
2. Escribe 3 cosas que vas a seguir haciendo cada semana.
3. Elige qué clase vas a enseñar primero a tu equipo.

## ✅ Tu tarea
Comparte tu antes y después de perfil en tus historias.

## 💬 Para compartir en el grupo
Comparte tu clase favorita y por qué.

@@ 20 | Herramientas | Auditoría de perfil | Revisa los cuatro puntos
Marca cada punto cuando lo cumplas.

## Foto
- Se ve mi cara clara y sonriendo.
- Sin lentes de sol, gorra, hijos, pareja, mascotas, paisajes ni logos.
- No es una foto hecha con IA.

## Usuario (@)
- Es mi nombre o el apodo por el que me conocen.
- No incluye el nombre de la marca.

## Nombre
- Nombre y un apellido.
- Opcional: mi tema ("· piel después de los 40").

## Descripción
- Dice quién soy o mi filosofía.
- Dice a quién ayudo y en qué.
- Es corta y concreta.
- No promete dinero ni resultados de salud.

## Extra
- Link a mi tienda o WhatsApp.
- Prueba de los 3 segundos aprobada.

@@ 21 | Herramientas | Matriz de clienta ideal | Para hablarle a una sola
Llena solo lo que sabes. Deja en blanco lo demás y complétalo con el tiempo.

## La matriz
1. ¿Qué me gusta más de la marca? (bienestar, maquillaje, cuidado de la piel, emprendimiento)
2. ¿A quién quiero atraer? (clienta de producto, clienta recurrente, socia para el equipo)
3. ¿Quién es hoy y cómo se siente? ¿Qué le frustra y qué ya no quiere vivir?
4. **Lo que dice** que le duele y **lo que siente pero no dice**.
5. **Frases textuales** que usa.
6. **Objeciones prácticas** (tiempo, dinero, tecnología) y **emocionales** (miedo a fallar, a exponerse).
7. **Lo que admite que quiere** y **lo que desea en el fondo**.
8. **En una frase:** "Ayudo a ___ que están en ___, que batallan con ___, a lograr ___ con ___."

## Prompts para profundizar
- El diario de un día de su vida, en primera persona.
- Una conversación de ella con una amiga sobre su problema.
- Qué buscaría en Google o YouTube.
- Cómo se ve antes y después de encontrar la solución.

@@ 22 | Herramientas | Planificador 7-2-1 | Tu semana de contenido
Copia esta tabla cada semana.

## Mi semana
| Día | Tipo | Formato | Idea | Listo |
|---|---|---|---|---|
| Lunes | Alcance | | | |
| Martes | Alcance | | | |
| Miércoles | Conexión | | | |
| Jueves | Alcance | | | |
| Viernes | Alcance | | | |
| Sábado | Venta | | | |
| Domingo | Alcance | | | |

## Historias de cada día
- Algo de tu día.
- Uso real de un producto.
- Una pregunta o encuesta.
- Una vez por semana: una serie de 4 de venta.

## Al final de la semana
- ¿Qué pieza tuvo más compartidos y guardados?
- ¿Qué conversación se abrió?
- ¿Qué repito la próxima semana?

@@ 23 | Herramientas | Checklist de historias | Antes de publicar
- Se entiende en 2 segundos.
- Tiene una sola idea.
- Usa mis colores.
- Usa mis 2 tipografías.
- Tiene espacio libre, no está saturada.
- El elemento principal es grande.
- Tiene un sticker o llamado con dirección.
- Si es de venta, es parte de una serie de 4.
- No promete resultados de salud ni de dinero.

@@ 24 | Herramientas | Prompts para tu negocio | Para tu asistente de IA
Copia, cambia lo que está entre corchetes y adapta siempre la respuesta a tu voz.

## Mi prompt base
> Actúa como [rol]. Soy [quién eres] y vendo [qué] a [tu clienta ideal]. Ayúdame con [pieza] para [canal]. Tono [tono], realista, sin promesas de ingresos ni de salud. Dame 3 versiones: emocional, educativa y directa.

## Contenido
> Dame 10 ideas de contenido de alcance para [clienta ideal] que la hagan pensar "sí, soy yo".

> Convierte esta idea en un guion de reel de 20 segundos con un gancho en los primeros 2 segundos: [idea].

## Historias
> Escribe una serie de 4 historias para [producto]: conectar con un dolor, identificación, mi experiencia y llamado suave. Sin prometer resultados.

## Conversaciones
> Una clienta me escribió "[mensaje]". Ayúdame a responder con preguntas para entender qué busca, sin venderle todavía.

## Organización
> Tengo [30] minutos al día. Ayúdame a planear mi semana de contenido con la mezcla 7-2-1.

## Bloqueos
> Ayúdame a entender por qué estoy evitando [publicar / invitar / grabarme] y dame un primer paso pequeño para hoy.


# Preguntas frecuentes

## Empezar | 0

### ¿Tengo que tomar las clases en orden?
La primera vez te lo recomendamos, porque cada bloque usa lo del anterior. Pero puedes ir a cualquier clase desde el menú.

### ¿Cuánto tiempo me toma?
Está pensado para un mes: una clase casi diaria y publicar todos los días. Si vas más lento, no pasa nada; lo importante es no soltarlo.

### ¿Dónde guardo mis ejercicios?
En el cuaderno al final de cada clase. Se guarda solo en este dispositivo y navegador. Copia lo importante a tu libreta.

### ¿Tengo que pagar CapCut, Canva o ChatGPT?
No para empezar. Las versiones gratis alcanzan para todo lo básico. Si vas a crear mucho, la versión de paga te ahorra tiempo.

## Perfil y marca | 1

### ¿Uso mi cuenta personal o abro una nueva?
Tu cuenta personal: esa cuenta eres tú y ya tiene gente que te conoce. Para investigar formatos, abre una segunda cuenta aparte.

### ¿Puedo poner el nombre de la marca en mi usuario?
Mejor no. Usa tu nombre. El link de tu tienda sí puede ir en el perfil.

### No sé qué tema elegir.
Empieza por ti antes de resolver lo que hoy ya resolviste (Clase 3). Elige uno y sostenlo; lo puedes afinar después (Clase 18).

## Contenido | 6

### ¿Cuántas veces publico?
Al menos una vez al día. Con 7 publicaciones a la semana: 5 de alcance, 1 de conexión y 1 de venta. Las historias van aparte, todos los días.

### ¿Está bien copiar videos que se hicieron virales?
Copia el formato, no el video. Haz tu versión con tus palabras, tu espacio y un audio de la app. No descargues ni resubas contenido ajeno.

### Mis amigas y familia no me comentan.
Está bien: probablemente no son tu clienta ideal. Fíjate en los compartidos y guardados de gente que no conoces.

### ¿Sirven los hashtags?
Pesan poco. Importa más que tu tema sea claro y que tu contenido se comparta y se guarde.

### Me da pena salir a cuadro.
Es muy normal. Tu primer video va a estar feo y está bien. Empieza con historias cortas y no lo borres, para que se note tu avance.

## Ventas | 16

### ¿Puedo poner "quedan pocos lugares" para que se decidan?
Solo si es verdad. Nunca inventes escasez, descuentos ni garantías.

### ¿Puedo decir que un producto me quitó un problema de salud?
No. Cuenta tu experiencia de uso sin prometer resultados de salud, y no hables de enfermedades. Si alguien tiene un tema de salud, que lo vea con su médico.

### ¿Puedo decir cuánto gano para invitar a mi equipo?
No prometas ingresos ni uses tus cifras como promesa. Comparte tu experiencia, lo que te gusta del negocio y deja que cada quien decida.

### Alguien me escribió por mi palabra clave, ¿qué le digo?
Agradece, pregunta qué quiere lograr, comparte el recurso o un consejo y, si encaja, ofrece el producto o la reunión. Está en la Clase 6.

## El mentor | 0

### ¿Qué es "Tu mentora"?
Es la mentora de Trazo dentro de Claude. Te da las clases una por una, audita tu perfil, te ayuda con tu clienta ideal, tus ideas 7-2-1, tus historias y tus mensajes.

### ¿Tengo que pagar Claude?
No. Funciona con la cuenta gratis de claude.ai. La cuenta gratis tiene un límite de mensajes por día.

### ¿Cómo la instalo?
Descarga la mentora (.zip) en la pestaña Tu mentora. En Claude entra a Customize → Skills, toca "+", luego "Create skill" → "Upload a skill" y sube el zip sin descomprimir.
