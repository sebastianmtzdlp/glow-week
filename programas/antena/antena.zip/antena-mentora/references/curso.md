# Antena · contenido completo del curso

## 0 · Bienvenida a Antena
*Empieza aquí · El curso en 5 minutos*

Este curso no te va a enseñar a hacer videos ni a escribir textos. Te va a enseñar algo que va antes: a vivir con la antena prendida, para que las ideas te encuentren y sepas qué hacer con ellas.

### De qué se trata
Casi todas pensamos que la creatividad es para unas cuantas: las artistas, las que "nacieron con eso". No es cierto. Cada vez que arreglas tu mesa para una foto, que inventas cómo explicarle un producto a una clienta o que le cambias el final a un cuento para tus hijas, estás creando.

La idea central del curso es esta: **crear no es algo que haces un rato, es una forma de estar en el mundo**. Poner atención, notar lo que te mueve, juntar lo que te llama, jugar con eso y atreverte a soltarlo. Eso se practica, como se practica caminar o cocinar.

> Ser creativa no es un talento que tienes o no tienes. Es una forma de mirar.

### Cómo está armado
- **Sintoniza (clases 1 a 5).** Cómo prender tu antena: notar más, alimentar bien lo que entra, encontrar pistas y bajarle el volumen a la duda y a las reglas que ni sabías que seguías.
- **Crea (clases 6 a 10).** El camino de cualquier proyecto, en cuatro movimientos: **Junta, Juega, Construye y Suelta**. Sirve igual para un video, un live, una presentación para tu equipo o una idea de negocio.
- **Sostén (clases 11 y 12).** Cómo seguir creando a largo plazo: qué es el éxito para ti, por qué compararte no sirve y cómo crear con otras sin pelearte.
- **Herramientas.** Tu libreta de semillas, doce experimentos para cuando te atores, la guía de las cuatro fases y una guía para dar y recibir retroalimentación.

### Lo que necesitas
- Una libreta chiquita o las notas de tu celular. Va a ser tu libreta de semillas.
- Diez minutos al día para notar. No para producir: para notar.
- Algo que quieras crear, aunque sea pequeño: un video, una foto, un texto, una idea para tu negocio.

### Cómo leer este curso
Algunas ideas te van a hacer clic y otras no. Está bien. Toma lo que te sirva y deja lo demás. Cada clase termina con un ejercicio y una tarea; hazlos en el cuaderno de la clase, que se guarda en tu dispositivo.

### 🪞 Para pensar
¿Cuándo fue la última vez que creaste algo solo porque te dio gusto, sin pensar en si iba a gustar?

### ✍️ Escribe
Escribe en una frase qué te gustaría crear en las próximas semanas. Por ejemplo: "Quiero animarme a hacer videos donde hable yo, no solo el producto."

## 1 · Clase 1 · Todas creamos
*Sintoniza · La creatividad es una forma de estar*

Crear es traer al mundo algo que antes no estaba. Una conversación, una solución, una nota para una amiga, una nueva forma de acomodar tu mesa. Lo haces todos los días.

### No es solo para artistas
La palabra "artista" asusta. Suena a museo, a talento raro, a gente distinta. Por eso muchas mujeres dicen "yo no soy creativa" mientras arman un aparador precioso, inventan un juego para que sus hijas coman verdura o escriben el mensaje perfecto para una clienta que está dudando.

Lo que haces no tiene que estar en una galería ni venderse para contar como creación. **Tu vida entera ya es una obra**: cada decisión que tomas con atención dice cómo ves el mundo.

> No necesitas permiso para llamarte creadora. Ya lo eres.

### Las ideas tienen su tiempo
Piensa en la naturaleza: los árboles saben cuándo florecer y las nubes cuándo llover. Las ideas funcionan parecido. Hay ideas que andan "en el aire" y llegan a quien está lista para recibirlas.

¿Te ha pasado que tuviste una idea, no la hiciste y meses después la viste hecha por alguien más? No te la robaron. Simplemente era su momento y alguien la tomó. Por eso, cuando una idea te emociona, dale vida.

### Ver como niña
Las niñas reciben todo con asombro. No comparan, no se preocupan por lo que van a pensar, pasan de la risa al llanto sin quedarse atoradas en una historia. Esa forma de mirar es justo la que hace falta para crear.

Las creadoras que siguen haciendo cosas buenas toda la vida suelen conservar algo de eso: curiosidad, juego y cero miedo a verse raras.

### Qué cambia con esto
Si crear es una forma de estar, ya no tienes que esperar a sentirte inspirada para empezar. Empiezas cuando pones atención. Y eso lo puedes hacer hoy, en la fila del súper, mientras preparas el café o mientras ves a tus clientas probar un producto.

### 🪞 Para pensar
¿En qué parte de tu día ya eres creativa sin darte cuenta? Piensa en tu casa, tu negocio, tu familia.

### ✍️ Ejercicio
Haz una lista de cinco cosas que creaste esta semana y que nunca llamaste "creación". Una comida, un mensaje, una foto, una solución, un acomodo.

### ✅ Tu tarea de la semana
Cada noche, antes de dormir, escribe una línea: "Hoy creé…". Aunque sea algo chiquito.

### 💬 Para compartir en el grupo
Comparte una de tus cinco creaciones escondidas. Te va a sorprender lo que hacen las demás.

## 2 · Clase 2 · Prende tu antena
*Sintoniza · Notar es el primer paso de crear*

Todas somos antenas. Las ideas, las señales y las pistas pasan todo el tiempo. La diferencia está en qué tan sintonizada estás para recibirlas.

### La nube
Imagina que todas las ideas posibles viven en una nube enorme: todo lo que has visto, vivido, soñado, olvidado y lo que todavía no conoces. Las nubes nunca desaparecen, solo cambian de forma: llueven, se vuelven mar, se evaporan y regresan.

Las ideas son iguales. **Nada sale de la nada**; lo nuevo es una mezcla distinta de lo que ya circula. Por eso no tienes que "inventar" desde cero. Tienes que aprender a recibir.

### Tu vasija y tu colador
Dentro de ti hay una vasija donde se guarda todo lo que vives: pensamientos, emociones, recuerdos, lo que ves en redes, lo que escuchas en la calle. Pero antes de entrar, todo pasa por un colador: tus creencias, tus prisas, lo que te enseñaron a ignorar.

El colador es necesario, porque si no te volverías loca con tanta información. El problema es cuando está tan cerrado que ya no deja pasar nada nuevo. Ahí todo te parece igual y sientes que no tienes ideas.

> La herramienta más importante para crear no es tu celular ni tu ring light. Eres tú.

### Notar sin juzgar
Poner atención no es analizar. Cuando ves algo bonito, primero vívelo. Ya después, si quieres, piensas por qué te gustó. Si de inmediato le pones etiqueta ("esto es un buen hook", "esto se vende"), dejas de verlo de verdad.

Puedes jugar con tu atención: acercarte tanto a algo que se vuelva otra cosa, o alejarte hasta verlo completo. Callar lo de afuera para escuchar lo de adentro, o al revés.

### Nada se repite
Puedes sentarte en el mismo lugar cinco días seguidos y cada día será distinto: otra luz, otros ruidos, otra tú. Tampoco eres la misma persona todo el día. Eso significa que nunca se te van a acabar las cosas que notar.

### Una práctica pequeña
No necesitas retiros. Necesitas rituales chiquitos que repitas:
- Tres respiraciones lentas al despertar, antes de ver el celular.
- Comer un bocado al día con toda tu atención.
- Una caminata corta mirando todo como si fuera la primera vez.

El chiste no es el ritual. Es que poco a poco empiezas a mirar así todo el día.

### 🪞 Para pensar
¿Qué tan abierto está tu colador? ¿Hay cosas que ya ni ves porque "siempre están ahí"?

### ✍️ Ejercicio
Siéntate cinco minutos en un lugar de tu casa o tu calle. Cierra los ojos y anota todo lo que escuchas, hueles y sientes, en orden. Luego ábrelos y anota diez cosas que ves y que nunca habías notado.

### ✅ Tu tarea de la semana
Elige un ritual chiquito de la lista y hazlo todos los días.

### 💬 Para compartir en el grupo
Comparte la cosa más sorprendente que notaste en tu ejercicio de cinco minutos.

## 3 · Clase 3 · Busca pistas
*Sintoniza · Lo que entra, sale*

Las ideas para tu siguiente video, tu siguiente post o tu siguiente presentación ya están a tu alrededor. Solo hay que aprender a verlas.

### Las pistas pasan como en una banda
Imagina que el mundo es una banda de aeropuerto con paquetitos pasando todo el tiempo: una frase que escuchas en la fila, un color en la calle, una canción, una pregunta que te hace una clienta. El primer paso es darte cuenta de que la banda existe. El segundo es agarrar un paquete y abrirlo.

Cuando algo raro o bonito te llama la atención, pregúntate: ¿por qué me llamó? ¿Qué me quiere decir?

### Cuida lo que entra
Todo lo que consumes llena tu vasija. Si todo el día ves contenido apurado y del montón, eso es lo que va a salir. Si te rodeas de cosas hermosas, bien hechas, que te mueven, tu ojo se afina.

No tiene que ser arte de museo. Puede ser una película buena, un libro, una cuenta que cuida cada detalle, una cocinera que hace todo con amor. Se trata de **subir el nivel de tu gusto** para que, cuando te toque decidir, sepas distinguir lo bueno de lo muy bueno.

> No se trata de copiar lo que admiras. Se trata de afinar tu ojo.

### La naturaleza enseña
La naturaleza es la obra más grande que tenemos gratis. La luz cambia cada hora. Ninguna piedra tiene un solo color. Si escoges colores de un catálogo, tienes opciones limitadas; si sales al jardín, la paleta es infinita. Mirar la naturaleza con calma te regresa a tu propia naturaleza.

### Mira hacia adentro
No necesitas una vida extraordinaria para tener qué compartir. Tu mundo de adentro (lo que sientes, lo que recuerdas, lo que sueñas) es tan interesante como cualquier viaje. Algunas formas de entrar:
- **Escribir sin pensar.** Pon un temporizador de cinco minutos y escribe lo que salga, sin corregir.
- **La libreta junto a la cama.** Al despertar, antes de moverte, apunta lo que soñaste. Con los días vas a recordar más.
- **El momento antes de dormir.** Nota qué ideas te llegan justo ahí.

### Tu lugar
Hay quien crea con música y ruido, y hay quien necesita silencio total. No hay una forma correcta. Prueba y nota dónde te sientes más abierta: tu rincón de la casa, una cafetería, el coche estacionado, el parque.

### 🪞 Para pensar
Si lo que entra es lo que sale, ¿qué está entrando a tu vasija todos los días? ¿Cuánto de eso te hace mejor creadora?

### ✍️ Ejercicio
Abre un libro en una página al azar y lee la primera frase que veas. Escribe cómo podría tener que ver con algo que estás viviendo o creando. Luego haz una lista de cinco cosas hermosas o muy bien hechas que podrías dejar entrar esta semana.

### ✅ Tu tarea de la semana
Cambia una hora de scroll por una de esas cinco cosas. Y apunta en tu libreta tres pistas que encuentres en el día.

### 💬 Para compartir en el grupo
Comparte una pista que encontraste y en qué idea se convirtió.

## 4 · Clase 4 · La duda viene contigo
*Sintoniza · Cómo crear aunque tengas miedo*

La duda vive en todas. Hasta en las que admiras. La meta no es que desaparezca, sino que no maneje.

### La duda también sirve
Lo que hace que el arte nos mueva es que es humano, con todo y sus imperfecciones. Si fuéramos máquinas, lo que hacemos no tendría alma. Tu inseguridad también es parte de ti, y eso le da verdad a lo que creas.

Nadie más tiene tu voz. Si tú no haces lo que te toca hacer, nadie lo puede hacer por ti.

### Bájale a lo que está en juego
Nos atoramos en tres momentos: al empezar, al terminar y al compartir. Casi siempre es porque pensamos que lo que estamos haciendo nos va a definir para siempre.

Mejor piénsalo como lo que es: **un experimento**. Un video más, un paso más. El objetivo es terminarlo para pasar al siguiente. Si empiezas desde "aquí no hay bien ni mal, estoy jugando", es mucho más fácil entrarle con gusto.

> No estás jugando para ganar. Estás jugando para jugar.

### Ponle nombre al ruidero
Cuando la cabeza se llena de pensamientos ("no me va a salir", "qué van a decir", "ya lo hizo alguien"), ponle un nombre a ese ruido. Llámalo **el ruidero**. Cuando aparezca, dilo: "Ah, es el ruidero", y sigue. Ponerle nombre le quita fuerza.

### Duda de la obra, no de ti
No es lo mismo decir "no sé si este video quedó bien" que "yo no sirvo para esto". La primera duda te ayuda a mejorar. La segunda te paraliza. Si vas a dudar, que sea del trabajo, nunca de ti.

### Lo roto puede ser lo más bonito
Hay una técnica japonesa para reparar cerámica que rellena las grietas con oro. En lugar de esconder la rotura, la vuelve el centro de la pieza. A veces lo que quieres "arreglar" es justo lo que hace especial lo que hiciste: tu acento, tu risa, tu cocina real, tus manos sin manicure.

### Las voces que no son tuyas
Muchas de las voces que te dicen "no eres suficiente" las aprendiste de chiquita: de una maestra, de un familiar, de alguien que te criticaba. No son tuyas. Las puedes escuchar como escuchas el ruido de la calle: ahí están, pero no les haces caso.

Y recuerda que puedes elegir. Si un día no quieres crear, no pasa nada. A veces darte permiso de dejarlo es lo que te hace darte cuenta de que sí quieres.

### 🪞 Para pensar
¿En cuál de los tres momentos te atoras más: al empezar, al terminar o al compartir? ¿Qué te dice el ruidero en ese momento?

### ✍️ Ejercicio
Escribe las tres frases que más te dice tu ruidero. Al lado de cada una, escribe de quién la aprendiste (si lo sabes) y una versión que dude de la obra, no de ti.

### ✅ Tu tarea de la semana
Publica o comparte algo que tengas guardado "porque no está perfecto". Ponle de título mental: experimento.

### 💬 Para compartir en el grupo
Comparte una "grieta de oro": algo de ti que antes escondías y que ahora te gusta mostrar.

## 5 · Clase 5 · Ojos de principiante
*Sintoniza · Las reglas que sigues sin saber*

Lo que ya sabes te ayuda, pero también te encierra. A veces la mejor idea llega cuando miras como si nunca hubieras hecho esto antes.

### Saber menos puede ayudar
Hace unos años, una computadora aprendió sola un juego de mesa milenario, sin maestros ni tradiciones. En una partida contra el campeón del mundo hizo una jugada que ningún humano había hecho en miles de años. Todos pensaron que era un error. Esa jugada le dio la victoria.

No ganó por saber más. Ganó porque no cargaba con todo lo que "así se hace". Eso es mirar con ojos de principiante: **entrarle a algo sin la historia de cómo debería ser**.

### Las reglas son suposiciones
Una regla de creación no es como la ley de gravedad. Es una suposición: "los videos deben durar menos de 30 segundos", "hay que salir siempre maquillada", "los lives son en la noche", "la foto del producto va con fondo blanco". Algunas sirven. Muchas solo te ponen a hacer lo mismo que todas.

Las reglas te llevan al promedio. Y el promedio no es lo que quieres. Lo interesante es lo que te hace distinta.

> Que siempre lo hayas hecho así no significa que sea la mejor forma.

### Las reglas escondidas
Las reglas más fuertes son las que no ves: las que aprendiste de niña, las que absorbiste viendo a otras, las que "todo mundo sabe". Esas te mandan sin que te des cuenta. Cuando las descubres, puedes decidir si te quedas con ellas o las sueltas.

### Prueba lo contrario
Por cada regla que sigues, prueba lo opuesto. Si siempre hablas rápido, haz un video lento. Si siempre sales tú, haz uno donde solo se vean tus manos. Si siempre usas música, prueba con puro sonido real. No tiene que salir mejor. Solo vas a aprender algo.

Otra opción es irte al extremo de lo que ya haces: si eres dulce, sé muy dulce. Si eres directa, sé directísima.

### Quítate las etiquetas
"Soy vendedora", "soy mamá", "no soy de cámara". Cualquier etiqueta que te pongas antes de crear te limita. Quítatelas un rato y pregúntate: ¿cómo veo el mundo sin ellas?

### 🪞 Para pensar
¿Qué "así se hace" sigues en tu contenido o en tu negocio sin haberlo cuestionado nunca?

### ✍️ Ejercicio
Haz una lista de cinco reglas que sigues al crear. Al lado de cada una, escribe su opuesto. Elige una y haz algo siguiendo el opuesto.

### ✅ Tu tarea de la semana
Comparte esa pieza "al revés" y anota qué aprendiste, aunque no te haya gustado.

### 💬 Para compartir en el grupo
Comparte la regla que rompiste y qué pasó.

## 6 · Clase 6 · Junta
*Crea · La fase de las semillas*

Todo proyecto empieza con una semilla: una frase, una imagen, una pregunta, una molestia, un "¿y si…?". En esta fase no eliges ni juzgas. Solo juntas.

### Qué es una semilla
Una semilla es cualquier punto de partida con vida. Para un video puede ser una frase que dijo una clienta, un sonido, un lugar con buena luz o una pregunta que te hacen seguido. Para tu negocio puede ser algo que les molesta a tus clientas, una necesidad que nadie atiende o algo que te encanta.

Juntar semillas no cuesta mucho. Es más recibir que buscar. Como cuando vas a pescar: llegas al agua, pones la carnada, lanzas y esperas. No controlas al pez; solo controlas que tu caña esté en el agua.

> Tu trabajo en esta fase es estar ahí cuando llegue la idea. Nada más.

### No elijas todavía
La trampa es querer decidir de inmediato si una idea es buena. Es muy pronto para saberlo. Una semilla que parece chiquita puede volverse lo mejor que hagas, y la que más te emocionó puede no dar nada.

Por eso conviene juntar muchas antes de escoger. Si tienes cien, vas a notar que la número cincuenta y cuatro te habla de un modo especial. Si solo tienes una, no tienes con qué compararla.

### Las ideas chiquitas también cuentan
No esperes una señal enorme para empezar. Las mejores ideas suelen llegar bajito, como un susurro: un recuerdo, un detalle, una frase que oíste en el estacionamiento. El tamaño de la semilla no dice nada del tamaño del árbol.

Para oír los susurros, la cabeza tiene que estar un poco callada. Por eso funcionan tanto el baño, el coche, la caminata o lavar trastes: ocupas el cuerpo y la mente se abre.

### Siempre de guardia
Crear no es solo el rato en que grabas. Es una forma de estar todo el día. Ten siempre a la mano tu libreta de semillas. Si no lo apuntas, se va. Y la mejor idea a lo mejor es la que se te ocurre hoy en la noche.

### 🪞 Para pensar
¿Cuántas ideas se te han ido por no apuntarlas? ¿Dónde te llegan las mejores?

### ✍️ Ejercicio
Abre tu libreta de semillas (está en Herramientas) y apunta veinte semillas en diez minutos, sin juzgar. Frases, imágenes, preguntas, molestias, recuerdos.

### ✅ Tu tarea de la semana
Junta al menos tres semillas diarias durante siete días. No hagas nada con ellas todavía.

### 💬 Para compartir en el grupo
Comparte la semilla más rara que juntaste.

## 7 · Clase 7 · Juega
*Crea · La fase de experimentar*

Ya tienes semillas. Ahora toca jugar con ellas para ver cuál quiere crecer. En esta fase no hay nada en juego, y por eso es de las más divertidas.

### Buscar señales de vida
Experimentar es probar una semilla en distintas direcciones: otro formato, otro lugar, otro tono, otra historia. Si tu semilla es "las mamás no tienen tiempo para arreglarse", puedes probarla como tutorial de tres minutos, como comedia, como carta a ti misma, como reto de una semana.

Aquí no buscas la versión más rápida ni la más fácil. Buscas **la que tiene más vida**. Y no recortas todavía: generas opciones en lugar de eliminarlas.

### No discutas las ideas, pruébalas
Una idea puede sonar increíble en tu cabeza y no funcionar, y otra que suena aburrida puede ser justo lo que hacía falta. La única forma de saber es probarla.

Esto sirve muchísimo en equipo. En lugar de discutir qué idea es mejor, háganlas las dos y véanlas. Las descripciones nunca les hacen justicia a las ideas. Y el que convence mejor no siempre tiene la mejor idea.

> Si buscas la mejor idea, pruébalas todas.

### Pregúntate "¿y si…?"
- ¿Y si este fuera el primer video que alguien ve en su vida?
- ¿Y si quito todas las palabras?
- ¿Y si lo que siempre digo fuerte lo digo en voz bajita?
- ¿Y si lo grabo en un lugar donde nadie lo esperaría?

### Sigue lo que te emociona
¿Cómo sabes qué semilla está floreciendo? Casi nunca lo dice la cabeza; lo dice el cuerpo. Cuando algo empieza a juntarse, sientes ganas de más, como que te inclinas hacia adelante. **Esa emoción es tu brújula.** Síguela, aunque no sepas explicar por qué.

Si una idea parece más segura y otra más interesante, dale chance a la interesante.

### Equivocarte es información
Muchos inventos famosos salieron por accidente: buscaban otra cosa y encontraron algo mejor. Cuando algo "sale mal", no lo tires de inmediato. Pregúntate qué te está enseñando. Una vuelta equivocada te deja ver paisajes que no habrías visto.

Y si una semilla no responde, no la tires: guárdala. Hay ideas a las que todavía no les toca.

### 🪞 Para pensar
¿Sueles quedarte con tu primera idea o te das permiso de probar varias?

### ✍️ Ejercicio
Elige una semilla de tu libreta y hazle cinco versiones distintas, aunque sean borradores de diez segundos o notas en papel. Cambia formato, tono, lugar o punto de vista.

### ✅ Tu tarea de la semana
Graba o haz dos de esas versiones y nota cuál te emociona más. No la que creas que "va a funcionar": la que te emocione.

### 💬 Para compartir en el grupo
Comparte tus cinco versiones y pregunta cuál le dio más curiosidad a tus compañeras.

## 8 · Clase 8 · Construye
*Crea · La fase del oficio*

Cuando una semilla ya mostró qué quiere ser, cambia el trabajo. Ya no estás explorando: estás construyendo. Es la parte menos glamorosa y la más necesaria.

### De la chispa al ladrillo
En las primeras fases todo es descubrimiento. Aquí ya hay dirección, y toca el trabajo de pegar ladrillos: escribir el guion, grabar las tomas, editar, ajustar. Es el momento en que muchas abandonan, porque extrañan la emoción del principio.

Pero las ideas que no se terminan no existen. **Solo creces terminando.**

### Construir también es quitar
Construir no es solo agregar. También es podar: quitar lo que distrae para que lo importante tenga más fuerza.

Pregúntate cuál es la esencia de lo que estás haciendo. Si un niño dibuja una casa y le quitas la ventana, sigue siendo casa. Si le quitas la puerta, también. Pero si le quitas el techo y las paredes, ya no se sabe. Busca eso que no se puede quitar y protégelo. Si dudas de si algo sirve, probablemente sobra. Siempre lo puedes regresar.

> Lo simple bien hecho le gana a lo complicado.

### Los detalles importan
Hay un entrenador legendario de basquetbol que el primer día les enseñaba a sus jugadores a ponerse bien los calcetines, sin una sola arruga, para que no les salieran ampollas. Parece ridículo, pero esos detalles sumados hacían la diferencia.

En lo tuyo pasa igual: la luz, el audio, la primera frase, cómo acomodas el producto. **La forma en que haces una cosa es la forma en que haces todo.**

### Mantén el impulso
- **Ponte fechas para ti**, no para presumirlas. Te ayudan a no quedarte puliendo para siempre.
- **Si te atoras en una parte, sáltatela.** Termina lo demás y regresa. Un puente es más fácil de construir cuando ya ves las dos orillas.
- **Haz un borrador completo** aunque esté imperfecto. Un borrador entero sirve más que un pedacito perfecto.
- **No te enamores del borrador.** Si lo ves y lo ves mil veces, se te queda grabado como "la versión" y luego no te atreves a mejorarlo. Trabaja, y luego aléjate.

### Hábitos que te liberan
La disciplina y la libertad parecen opuestas, pero son compañeras. Si tu día práctico está ordenado, te queda espacio para jugar en lo creativo. Decide de antemano cuándo vas a crear, para que la energía se vaya en el trabajo y no en decidir cuándo hacerlo. Empieza con poco: media hora al día que sí puedas sostener.

### 🪞 Para pensar
¿Qué proyectos tienes empezados y abandonados en la fase de construir? ¿Qué te hizo soltarlos?

### ✍️ Ejercicio
Toma la versión que más te emocionó en la clase anterior. Escribe en una línea su esencia. Luego haz una lista de lo que sobra y quítalo.

### ✅ Tu tarea de la semana
Termina un borrador completo de esa pieza, saltándote las partes donde te atores. Ponte una fecha de entrega para ti.

### 💬 Para compartir en el grupo
Comparte tu fecha y cuéntale al grupo qué vas a terminar. Que te pregunten cómo vas.

## 9 · Clase 9 · Rompe la rutina
*Crea · Experimentos para cuando te atoras*

A veces todo se ve igual y nada mejora. No es que se te acabó la creatividad. Es que necesitas mover algo para volver a verlo con ojos nuevos.

### Mueve una pieza
Cuando estás atorada, cambia una sola cosa y ve qué pasa. No esperes un resultado; la idea es despertar la emoción. Algunas formas de hacerlo:
- **Pasitos chiquitos.** Escribe una sola línea al día, buena o mala. Lo grande se destraba de a poquito.
- **Cambia el lugar.** Graba en otro cuarto, en otra hora, con la luz apagada, sosteniendo tú el celular.
- **Cambia lo que está en juego.** Imagina que es la última vez que vas a contar esa historia. O al revés: que es solo un ensayo.
- **Invita a alguien.** Que una persona te vea grabar. Casi todas nos enfocamos más con público.
- **Cambia a quién le hablas.** El mismo mensaje dicho a tu mejor amiga, a tu abuela o a tu yo de hace cinco años suena distinto.
- **Crea para otra.** ¿Cómo haría este video tu creadora favorita? Hazlo como si te lo hubiera encargado.
- **Pinta una escena.** En lugar de pensar en técnica, imagina una imagen o una historia y graba "como si fuera eso".

En Herramientas tienes doce experimentos para tener a la mano.

### Reglas temporales
Una cosa es romper reglas viejas y otra es ponerte reglas nuevas a propósito, solo para un proyecto. Cuando todo es posible, cuesta decidir. Cuando te pones límites, te obligas a encontrar soluciones distintas.

Ha habido libros escritos sin usar una letra, pintores que trabajaron con un solo color y películas hechas con reglas estrictísimas. Tú puedes probar: "esta semana, solo luz natural", "solo con el celular, sin editar", "un solo producto en todos los videos", "menos de diez palabras".

> Un límite no te quita libertad. Te enseña a mirar distinto.

### Cambia el contexto
Una flor en un jardín, en la mano de una novia o sobre una tumba no se siente igual. El contexto cambia el mensaje. Si algo no te está funcionando, cambia lo que tiene alrededor: el fondo, la música, el orden, lo que va antes y después. Juega con pares: fuerte o suave, rápido o lento, cerca o lejos, claro u oscuro.

### Cómo elegir entre dos
Es difícil saber si algo está bien cuando lo ves solo. Pon dos opciones lado a lado y compáralas. Casi siempre una te jala más. Si no sabes cuál, echa un volado: mientras la moneda está en el aire, vas a notar cuál quieres que salga. Esa es.

### 🪞 Para pensar
¿Qué haces normalmente cuando te atoras? ¿Te funciona?

### ✍️ Ejercicio
Elige tres experimentos de esta clase y aplícalos a la pieza que estás construyendo. Luego compara dos versiones lado a lado.

### ✅ Tu tarea de la semana
Ponte una regla temporal para toda la semana y crea al menos tres piezas con ella.

### 💬 Para compartir en el grupo
Comparte tu regla de la semana y la pieza que más te sorprendió.

## 10 · Clase 10 · Suéltalo
*Crea · La fase de terminar y compartir*

Llega un momento en que ya no hay nada que agregar ni quitar. Ahí toca lo más difícil para muchas: dejarlo ir.

### Termina para empezar otra
Mientras algo no está terminado, todavía puedes cambiarlo todo. Por eso da miedo soltarlo. Y entonces aparecen las excusas: le encuentras defectos que no existen, haces cambios que nadie va a notar o te convences de que mejor lo tiras.

Recuerda esto: **lo que haces nunca es todo lo que eres, solo quién eres hoy**. Si esperas demasiado, ya no es tu reflejo. Cada pieza es una hoja de tu diario, no tu biografía completa.

> ¿Cuántas páginas se van a quedar vacías por darle vueltas a esta?

### Enséñaselo a alguien, pero escucha bien
Cuando ya casi está, muéstraselo a alguien de confianza. No tanto para que te dé su opinión, sino para verlo con otros ojos. Te vas a dar cuenta de cosas solo por tenerla enfrente.

Si te dan retroalimentación, escucha para entender a la persona, no para defender tu trabajo. Y si te sugieren una solución que no te convence, pregúntate qué problema real están señalando. "Quítale el principio" puede significar "el principio está lento".

### No todos lo van a amar
Si haces algo con tu voz de verdad, a unas les va a encantar y a otras no. Eso es buena señal. Si le gusta a todo el mundo, quizá te quedaste muy en lo seguro. Al final, la que lo tiene que amar eres tú.

### ¿Cuándo está listo?
No hay fórmula. Está listo cuando sientes que está listo. Una fecha de entrega ayuda mucho en esta fase: el arte no se hace con reloj, pero sí se termina con reloj. Si ya te gusta y te dan ganas de enseñárselo a una amiga, probablemente ya es hora de enseñárselo a todas.

### El río
Las ideas son como un río. Cuando compartes, el agua corre y llegan nuevas. Si guardas todo "para cuando valga la pena", el río se estanca. No guardes tu mejor idea para un momento especial: úsala, y va a llegar otra.

### La Soñadora y La Terminadora
Hay creadoras que aman soñar y probar, pero les cuesta terminar: son **Soñadoras**. Y hay otras que terminan rapidísimo, pero casi no exploran: son **Terminadoras**. A la Soñadora le sirve terminar algo pequeño, aunque sea una parte. A la Terminadora le sirve darse más tiempo para jugar antes de cerrar.

### 🪞 Para pensar
¿Eres más Soñadora o más Terminadora? ¿Qué tienes guardado que ya debería estar afuera?

### ✍️ Ejercicio
Haz una lista de todo lo que tienes "casi listo". Elige una pieza y escribe qué es lo único que le falta. Solo lo único.

### ✅ Tu tarea de la semana
Termina y comparte la pieza que construiste en las clases anteriores. Y apunta en tu libreta una semilla nueva para tu siguiente proyecto.

### 💬 Para compartir en el grupo
Comparte tu pieza terminada y celebra la de otra.

## 11 · Clase 11 · Tu éxito es tuyo
*Sostén · Medir lo que sí depende de ti*

Si mides lo que haces solo por los likes o las ventas de esa semana, vas a vivir subiendo y bajando. Hay otra forma de medir.

### Qué es el éxito
El éxito no es la popularidad ni el número de vistas. Pasa en privado: en el momento en que terminas algo, sabes que diste lo mejor que tenías y decides soltarlo, antes de que nadie opine.

Lo que pasa después depende de mil cosas que no controlas: la hora, el algoritmo, lo que está pasando en el mundo, lo que publicaron otras ese día. Lo único que sí controlas es hacer tu mejor trabajo, compartirlo, empezar el siguiente y no quedarte mirando para atrás.

> Haz lo que tú amarías ver. Tu emoción es lo que conecta.

### Haz lo que tú amarías ver
Cuando creas pensando "a mí no me gusta, pero seguro a ellas sí", casi siempre sale algo plano. No hay mejor forma de adivinar qué le va a gustar a alguien que el que te guste a ti primero.

Esto también sirve para vender: tus clientas no se enganchan con un formato, se enganchan con tu emoción por lo que muestras. Si un día cambias de estilo porque te late otra cosa, síguelo.

### Compararte te roba la alegría
Lo que tú haces representa quién eres tú. Lo que hace otra representa quién es ella. No se pueden medir una contra otra. Competir para "ganarle" a alguien casi nunca te lleva a algo bueno.

Pero hay otra energía: cuando ves algo tan bonito que te dan ganas de subir tu nivel. Eso no es competencia, es inspiración. Hay bandas famosas que se fueron inspirando unas a otras con discos cada vez mejores, por admiración, no por envidia. Así sí.

La única competencia sana es contigo: no para ganarle a lo que hiciste antes, sino para seguir creciendo.

### Mírala como película
Cuando algo sale mal (un video que no funcionó, una clienta que se fue, un mes flojo), intenta verlo como si fuera una escena de película. Eres tú, pero también eres la protagonista de una historia. "No me esperaba este giro. A ver qué sigue."

Si te acercas mucho, todo parece catástrofe. Si te alejas, cada momento se vuelve más pequeño dentro de una vida grande. Tú eliges desde dónde mirar.

### 🪞 Para pensar
¿Cómo mides hoy si lo que hiciste salió bien? ¿Cuánto de eso depende de ti?

### ✍️ Ejercicio
Escribe tu propia definición de éxito para lo que creas, con cosas que sí dependan de ti. Por ejemplo: "Terminé, me gusta y lo compartí."

### ✅ Tu tarea de la semana
Cuando publiques algo, no revises los números en 24 horas. Escribe en tu libreta cómo te sentiste al terminarlo.

### 💬 Para compartir en el grupo
Comparte tu definición de éxito.

## 12 · Clase 12 · Crear en equipo
*Sostén · Tu círculo, la opción C y cuidar la chispa*

Crear sola está bien. Crear acompañada puede llevarte a lugares a los que no llegarías nunca sola.

### Tu círculo
Rodéate de gente creativa. No tienen que hacer lo mismo que tú; basta con que les emocione crear. La creatividad se contagia: cuando pasas tiempo con personas que miran el mundo con curiosidad, empiezas a mirar igual. Un grupo así, para compartir ideas, platicar y darse retro, es de las cosas más bonitas que te pueden pasar.

### Cooperar, no competir
En un buen equipo, gana la mejor idea, sea de quien sea. Creer que tu idea es la mejor solo porque es tuya es un error de principiante.

Cuando una quiere la opción A y otra la opción B, no se trata de que una ceda. Se trata de **seguir trabajando hasta encontrar una opción C** que a las dos les encante. Puede tener algo de A, algo de B o nada de ninguna. Cuando alguien cede solo para avanzar, pierden todas.

> Si siempre están de acuerdo en todo, a lo mejor una de las dos sobra.

Un poco de fricción es buena: de dos miradas distintas sale algo que ninguna haría sola.

### Cómo dar retro
- Habla del trabajo, nunca de la persona.
- Sé específica: "el audio se oye bajito en la segunda parte" ayuda más que "no me gustó".
- Si tienes una solución, aguántate un momento. A lo mejor ella encuentra una mejor.

### Cómo recibirla
- Deja el ego en la puerta. Que te señalen un detalle no significa que todo esté mal.
- Repite lo que entendiste. Muchas veces lo que oíste no es lo que te dijeron.
- Pregunta hasta entender qué vio la otra persona.

### Primero, no estorbes
Cuando una compañera te enseña algo que está empezando, cuídalo. Las ideas recién nacidas tienen una magia que se rompe fácil. A veces la mejor ayuda es decir "así está precioso, no le muevas".

### No le pidas todo a tu creación
Si esperas que tu contenido te mantenga desde el primer día, le pones una presión enorme. Está bien tener un ingreso que te sostenga mientras creas. Así lo que haces se queda libre.

### Al terminar el curso
Ya tienes tu antena prendida, tu libreta de semillas y un camino para cualquier proyecto: junta, juega, construye y suelta. Ahora toca repetirlo una y otra vez. Cada pieza que termines es una estación, no el final del viaje.

### 🪞 Para pensar
¿Con quién creas mejor? ¿Quién te hace mirar distinto?

### ✍️ Ejercicio
Elige a una compañera y hagan una pieza juntas. Cuando no estén de acuerdo, busquen la opción C. Usa la guía de retro de Herramientas.

### ✅ Tu tarea de la semana
Arma tu círculo: tres personas con las que vas a compartir semillas y avances cada semana.

### 💬 Para compartir en el grupo
Comparte la pieza que hicieron juntas y cuál fue su opción C.

## 13 · Tu libreta de semillas
*Herramienta · Cómo apuntar y dónde buscar*

Tu libreta de semillas es el lugar donde guardas todo lo que te llama la atención. Puede ser una libreta chiquita, una nota en el celular o un álbum de capturas.

### Cómo apuntar una semilla
Para cada semilla, apunta tres cosas en una línea:
- **Qué es.** "Mi hija dijo que el maquillaje es pintura para la cara."
- **Dónde la encontraste.** En la mesa, en el súper, en un video, en un sueño.
- **Qué te movió.** "Me dio risa y ternura. Podría ser un video de cómo ven ellas lo que hago."

No la juzgues. No decidas si sirve. Solo apúntala.

### Diez lugares para buscar semillas
1. Las preguntas que te hacen tus clientas.
2. Lo que dicen las niñas y los niños.
3. Algo que te molesta y que nadie resuelve.
4. Una canción que te pone la piel chinita.
5. La luz de tu casa a distintas horas.
6. Tus sueños, apuntados al despertar.
7. Una frase de un libro abierto al azar.
8. Algo que hacías de niña y ya no haces.
9. Una conversación que oíste sin querer.
10. Un recuerdo que te regresa sin razón.

### Cada domingo
Lee las semillas de la semana. No elijas la mejor; marca las que todavía te emocionan. Esas son las que vas a llevar a la fase de jugar. Las demás se quedan guardadas, que a lo mejor todavía no es su momento.

## 14 · Doce experimentos
*Herramienta · Para cuando todo se ve igual*

Cuando te atores, elige uno, pruébalo sin esperar nada y ve qué pasa.

### Los doce
1. **Una línea al día.** Escribe solo una línea diaria, buena o mala.
2. **Otro lugar.** Graba en un cuarto, una hora o una luz que nunca usas.
3. **La última vez.** Haz como si fuera la última vez que vas a contar esto.
4. **Solo un ensayo.** Haz como si nadie lo fuera a ver nunca.
5. **Con público.** Pide a alguien que te vea crear.
6. **Otra destinataria.** Dile lo mismo a otra persona: tu abuela, tu yo de antes, una desconocida.
7. **Encargo de tu favorita.** Hazlo como lo haría la creadora que más admiras.
8. **Una escena.** Imagina una imagen o una historia y crea "como si fuera eso".
9. **Poca información.** Cuéntale a alguien solo la idea básica y deja que ella la haga a su modo.
10. **Al revés.** Haz lo contrario de lo que haces siempre.
11. **Al extremo.** Lleva lo que ya haces al máximo.
12. **Una regla temporal.** Ponte un límite solo por esta semana.

### Pares para cambiar el contexto
Prueba tu pieza moviéndola de un lado al otro de estos pares:
- fuerte o suave
- rápido o lento
- cerca o lejos
- claro u oscuro
- grande o pequeño
- adentro o afuera
- antes o después
- igual o distinto

### Para elegir
Pon dos versiones lado a lado. Si no sabes, echa un volado y nota por cuál le vas mientras la moneda está en el aire.

## 15 · Las cuatro fases
*Herramienta · Junta, juega, construye y suelta*

Un mapa para cualquier proyecto. No es una línea recta: puedes regresar a una fase anterior cuando lo necesites.

### 1 · Junta
- ¿Estoy apuntando todo lo que me llama, sin juzgar?
- ¿Tengo suficientes semillas para comparar?
- ¿Estoy dejando entrar cosas buenas a mi vasija?

### 2 · Juega
- ¿Probé la semilla en varias direcciones?
- ¿Estoy probando las ideas en lugar de discutirlas?
- ¿Qué versión me hace inclinarme hacia adelante?
- ¿Guardé las semillas que no respondieron, en vez de tirarlas?

### 3 · Construye
- ¿Cuál es la esencia, en una línea?
- ¿Qué sobra?
- ¿Tengo una fecha para mí?
- ¿Me salté la parte donde me atoré para terminar lo demás?
- ¿Estoy cuidando los detalles?

### 4 · Suelta
- ¿Ya no hay nada que agregar ni quitar?
- ¿Se lo enseñé a alguien para verlo con otros ojos?
- ¿Escuché la retro buscando el problema real?
- ¿Lo estoy deteniendo por miedo o porque de verdad le falta algo?
- ¿Ya apunté la semilla de lo que sigue?

## 16 · Dar y recibir retro
*Herramienta · Una guía para tu círculo*

Para que la retroalimentación ayude y no lastime.

### Antes de opinar
- Pregunta qué tipo de retro quiere: ¿una primera impresión, algo técnico, o solo ánimo?
- Si es una idea recién nacida, cuídala. A veces basta con decir qué te gustó.

### Al dar retro
- Empieza por lo que sí funciona, con detalle.
- Habla del trabajo, no de la persona.
- Sé específica: qué parte, qué momento, qué sentiste.
- Guárdate tu solución un ratito y deja que ella encuentre la suya.

### Al recibir retro
- Respira. Un detalle no significa que todo esté mal.
- Repite lo que entendiste: "¿Me dices que el inicio se siente lento?"
- Pregunta qué vio exactamente.
- Busca el problema detrás de la sugerencia.
- Al final decides tú. Es tu obra.

### Cuando no se ponen de acuerdo
No elijan entre A y B. Sigan probando hasta encontrar una opción C que a las dos les encante.
