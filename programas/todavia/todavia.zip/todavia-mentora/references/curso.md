# Todavía · contenido completo del curso

## 0 · Bienvenida a Todavía
*Empieza aquí · El curso en 5 minutos*

Hay una palabra que cambia todo lo que dices de ti. Se pone al final de la frase y la abre: no me sale… todavía.

### De qué se trata
Este curso es sobre una sola idea, pero es de esas que, una vez que la ves, la ves en todos lados: **lo que crees de tus capacidades decide lo que te atreves a intentar**.

Si crees que tu talento, tu inteligencia o tu forma de ser vienen de fábrica y ya, cada reto se vuelve un examen. Cada venta, cada en vivo, cada junta con tu equipo te dice si "sirves" o "no sirves". Y para no reprobar, mejor ni lo intentas.

Si crees que esas cosas se pueden desarrollar, el mismo reto se vuelve una clase. No te dice quién eres; te dice qué te falta aprender. Y eso tiene arreglo.

> No te pregunto si eres buena para esto. Te pregunto si quieres aprenderlo.

### De dónde sale
Las ideas de este curso vienen de décadas de investigación en psicología sobre cómo las personas enfrentan los retos y los fracasos. Aquí las contamos con palabras sencillas y las aterrizamos a lo que vivimos en el equipo: vender, crear contenido, liderar, criar y querer.

### Cómo está armado
- **Entiende (clases 1 a 4).** Las dos formas de verte, qué cambia cuando buscas aprender en lugar de demostrar, qué significa fallar y para qué sirve el esfuerzo.
- **En tu vida (clases 5 a 8).** Las etiquetas que te pusieron (y las que te pones), tu negocio y tu liderazgo, tus relaciones y lo que les enseñas a tus hijas y a tu equipo sin decirlo.
- **Cambia (clases 9 y 10).** Cómo conocer a tu voz de "no puedes", ponerle nombre y llevártela de viaje, y cómo convertir todo esto en un plan con día, hora y lugar.
- **Herramientas.** Un test para saber dónde estás, la tabla de las dos mentalidades, frases de cambio y tu plan de la semana.

### Antes de empezar
Nadie tiene una sola mentalidad. Todas somos una mezcla, y cambia según el tema: puedes ser muy abierta para aprender a maquillar y muy cerrada para los números. Este curso no es para que te califiques. Es para que te cachen las veces que tú misma te cierras la puerta.

Y una aclaración honesta: creer que puedes crecer no garantiza resultados. Las personas tienen distintos recursos, tiempos y apoyos. Lo que sí cambia es que dejas de rendirte antes de intentarlo.

### 🪞 Para pensar
¿Qué frase de "yo no soy buena para…" repites tanto que ya ni la escuchas?

### ✍️ Escribe
Escribe tres frases que digas de ti que empiecen con "No soy buena para…" o "No sé…". Guárdalas. Al final del curso vas a regresar a ellas.

## 1 · Clase 1 · Dos formas de verte
*Entiende · ¿Piedra o semilla?*

Hay dos maneras de ver tus capacidades, y cada una te lleva por un camino distinto aunque empieces en el mismo lugar.

### Grabado en piedra
La primera dice que tus cualidades están grabadas en piedra. Naciste con cierta inteligencia, cierto carisma, cierto "don" para vender, y eso es lo que hay. A esta forma de ver la vamos a llamar **mentalidad fija**.

Suena inofensivo, pero tiene una consecuencia enorme: si solo tienes una cantidad de talento, más te vale demostrar que tienes mucho. Entonces cada situación se vuelve una prueba. ¿Voy a quedar como lista o como tonta? ¿Me van a aceptar o rechazar? ¿Soy ganadora o perdedora?

### Una semilla
La segunda dice que lo que tienes hoy es tu punto de partida. Tus cualidades se pueden cultivar con esfuerzo, con buenas estrategias y con ayuda de otras. A esta la llamamos **mentalidad de crecimiento**.

Ojo: no dice que cualquiera puede ser cualquier cosa. Dice algo más humilde y más poderoso: **nadie sabe de qué eres capaz** hasta que le dedicas años de ganas, práctica y aprendizaje. Muchas personas que hoy admiramos fueron niñas torpes, alumnas del montón o principiantes a las que les dijeron "esto no es lo tuyo".

> Las cartas que te tocaron no son tu destino. Son tu punto de partida.

### Un mal día, dos lecturas
Imagina este día. En la mañana te cancelan un pedido grande que ya dabas por hecho. A mediodía ves que tu video de ayer casi no tuvo vistas. En la tarde le escribes a tu mejor amiga para desahogarte y te contesta seco, con un "ah, qué mal".

Desde la mentalidad fija, el día se lee así: "No sirvo para esto. A todas les va mejor que a mí. Ni mi amiga me quiere." Y lo que sigue es encerrarse: no publicar nada, no volver a ofrecer, comerse un pan entero y dormirse temprano.

Desde la mentalidad de crecimiento, el mismo día duele igual, pero se lee distinto: "¿Qué pasó con ese pedido? Le escribo mañana para entender. Ese video tenía un inicio lento; pruebo otro gancho. Mi amiga seguro tuvo un mal día; la busco el fin de semana."

Fíjate: no pasó nada grave. Un pedido, un video y un mensaje seco. Pero la mentalidad fija convirtió eso en una sentencia sobre quién eres.

### Lo que más sorprende
Las personas con mentalidad de crecimiento se conocen mejor. Cuando quieres aprender, necesitas saber con honestidad qué te sale bien y qué no. En cambio, cuando cada resultado es una calificación de tu valor, empiezas a maquillar la verdad: lo bueno lo haces enorme, lo malo lo explicas con pretextos. Y al final ya no sabes dónde estás parada.

### 🪞 Para pensar
Piensa en una persona que conozcas que siempre necesita tener la razón y se ofende con cualquier comentario. Ahora piensa en alguien que siempre está aprendiendo algo nuevo. ¿A cuál te pareces más cuando las cosas salen mal?

### ✍️ Escribe
Recuerda tu último mal día de negocio. Escribe cómo lo leíste en ese momento. Luego reescríbelo como lo leería alguien con mentalidad de crecimiento: qué pasó, qué puedes aprender y qué harías mañana.

### ✅ Esta semana
Haz el test de la herramienta "¿Qué mentalidad tienes?" y fíjate en qué temas eres más fija.

### 💬 En el grupo
Comparte una cosa que hoy haces bien y que antes "no era lo tuyo".

## 2 · Clase 2 · Demostrar o aprender
*Entiende · Qué buscas cuando buscas el éxito*

Las dos mentalidades no solo ven distinto. Quieren cosas distintas.

### Dos metas muy diferentes
Cuando a unas niñas les dieron a elegir entre repetir un rompecabezas fácil o intentar uno más difícil, pasó algo muy revelador. Las de mentalidad fija eligieron el fácil: así no se arriesgaban a parecer menos listas. Las de mentalidad de crecimiento no entendían la pregunta: ¿para qué harías el mismo otra vez si no aprendes nada?

De grandes hacemos lo mismo, solo que con otros rompecabezas. Ofrecemos solo a las clientas de siempre. Grabamos solo el tipo de video que ya nos sale. No levantamos la mano para dar la capacitación porque "¿y si me trabo?".

> En la mentalidad fija, el éxito es demostrar que eres lista. En la de crecimiento, el éxito es volverte más lista.

### ¿Cuándo te sientes capaz?
Pregúntate esto: ¿te sientes capaz cuando todo te sale perfecto y rápido, o cuando por fin entiendes algo que te costó?

Si es lo primero, cuidado. Esa sensación te va a alejar de todo lo nuevo, porque lo nuevo nunca sale perfecto ni rápido. Las de mentalidad de crecimiento disfrutan justo el momento en que algo cuesta, porque saben que ahí es donde están creciendo.

### La enfermedad de la jefa
Hay líderes que se rodean solo de gente que les dice que todo está increíble. No quieren malas noticias, no quieren críticas, no quieren a nadie que brille más que ellas. Se sienten seguras por un rato, pero dejan de aprender, y su negocio se estanca con ellas.

Esto también nos pasa en chiquito. Cuando solo escuchas a quien te aplaude y te alejas de quien te dice "esto se puede mejorar", te estás haciendo un mundo donde eres perfecta… y donde nunca vas a crecer.

### Una calificación no es para siempre
En la mentalidad fija, un resultado te marca. Un mes malo dice que no sirves para esto. Una prueba reprobada dice que no eres inteligente. En la mentalidad de crecimiento, un resultado dice dónde estás hoy, no hasta dónde puedes llegar.

### 🪞 Para pensar
¿Hay algo que dejaste de intentar porque al principio no te salió bien y te dio pena que te vieran aprendiendo?

### ✍️ Escribe
Haz dos columnas. En una, escribe las cosas que haces en tu negocio "porque ya me salen". En la otra, las que evitas "porque no me salen". Elige una de la segunda columna para practicar este mes.

### ✅ Esta semana
Pídele a alguien de confianza que te diga una cosa que podrías mejorar en tus videos o en tu forma de vender. Solo escucha y da las gracias.

### 💬 En el grupo
Cuenta algo que estés aprendiendo ahorita, aunque todavía no te salga.

## 3 · Clase 3 · Fallar no es ser un fracaso
*Entiende · Lo que significa equivocarte*

Hay una diferencia enorme entre "fallé" y "soy un fracaso". La primera es algo que pasó. La segunda es algo que crees que eres.

### Cuando el error se vuelve identidad
En la mentalidad fija, un fracaso no se queda en el hecho. Se mete hasta adentro y se vuelve tu nombre. No es "esa presentación me salió mal"; es "soy malísima para hablar en público". No es "esa clienta no me compró"; es "no sirvo para vender".

Y como duele tanto, la mente busca salidas. Algunas son conocidas:
- **Echarle la culpa a algo o a alguien.** "Es que la plataforma no me mueve los videos." "Es que la gente no tiene dinero."
- **Compararte hacia abajo.** Buscar a alguien a quien le fue peor para sentirte mejor.
- **Hacer trampa o atajos.** Inflar números, aparentar que vendes más de lo que vendes.
- **Ya no intentarlo.** Si no lo intento, no puedo fallar.

### El fracaso como información
En la mentalidad de crecimiento, fallar también duele. Nadie está brincando de gusto. Pero el fracaso se vuelve información: me dice qué no funcionó, qué no sé todavía y qué puedo probar después.

> Fallar es un evento. Rendirte es una decisión.

### Cuando te sientes mal
Algo que mostró la investigación: cuando estaban tristes o deprimidas, las personas con mentalidad fija soltaban todo. Dejaban de hacer la tarea, de ir a clase, de cuidar sus cosas. Las de mentalidad de crecimiento, aunque se sintieran igual de mal, hacían lo contrario: mientras peor se sentían, más se aferraban a lo que tenían que hacer, porque era lo que las iba a sacar.

No se trata de sentirte bien a fuerza. Se trata de que el bajón no decida por ti.

### Un momento que te marcó
Casi todas tenemos un momento que sentimos que nos midió: un examen, un despido, una ruptura, una venta grande que se cayó, un comentario que nos dejó marcadas. La pregunta no es si duele. La pregunta es si lo dejas como sentencia o lo conviertes en escalón.

### 🪞 Para pensar
¿Qué fracaso de tu pasado todavía sientes que dice quién eres?

### ✍️ Escribe
Escribe ese momento. Luego responde: ¿qué parte fue responsabilidad mía?, ¿qué aprendí o puedo aprender?, ¿cómo puedo usarlo para crecer? Termina con una frase que empiece con "Eso pasó, pero no dice que yo…".

### ✅ Esta semana
La próxima vez que algo te salga mal, antes de explicarlo con un pretexto, escribe una cosa que harías distinto.

### 💬 En el grupo
Comparte un error de tu negocio que te haya enseñado algo útil.

## 4 · Clase 4 · El mito de la natural
*Entiende · Esfuerzo, estrategia y ayuda*

"Es que ella nació para vender." Esa frase nos quita más de lo que creemos.

### El esfuerzo, visto desde las dos mentalidades
En la mentalidad fija, el esfuerzo es mala señal. Si de verdad tuvieras talento, no tendrías que esforzarte tanto. Entonces, cuando algo cuesta, en lugar de pensar "estoy aprendiendo", piensas "esto no es lo mío".

En la mentalidad de crecimiento, el esfuerzo es lo que hace que el talento crezca. Nadie que admiras llegó sin él. Detrás de la que "nació para vender" hay cientos de conversaciones incómodas, mensajes sin respuesta y videos que nadie vio.

> Lo que ves en otras es el resultado. Lo que no ves son las horas.

### El riesgo de no esforzarte
Hay una trampa muy común: no echarle todas las ganas para tener un pretexto. Si no me sale, "es que ni le dediqué tiempo". Así proteges tu imagen, pero pagas un precio alto: nunca vas a saber de qué eras capaz. Muchas personas prefieren guardarse esa duda antes que arriesgarse a descubrir que no les salió. Esa protección sale carísima.

### No es solo echarle ganas
Cuidado con el otro extremo. Esforzarte más con la misma estrategia que no funciona solo te cansa. Crecer es tres cosas juntas:
- **Esfuerzo:** dedicarle tiempo y práctica de verdad.
- **Estrategia:** cambiar la forma cuando algo no da resultado. Otro horario, otro gancho, otra manera de ofrecer.
- **Ayuda:** preguntarle a quien ya sabe. Pedir que te revisen un video, acompañar a tu líder a una cita, ver cómo lo hace otra.

### Carácter de campeona
En los deportes se habla mucho del carácter: esa capacidad de sacar lo mejor cuando el partido se pone difícil. El carácter no viene de nacimiento; se construye cada vez que eliges seguir cuando lo fácil sería rendirte.

Y algo más: para las campeonas con mentalidad de crecimiento, el éxito no es solo ganar. Es haber dado todo y haber aprendido algo. Por eso siguen disfrutando lo que hacen aunque un mes no sea el mejor.

### 🪞 Para pensar
¿A quién admiras y le atribuyes un "don"? ¿Sabes cuánto trabajo hay detrás de lo que hace?

### ✍️ Escribe
Elige a esa persona y escríbele (o pregúntale, si la conoces): ¿qué te costó más al principio?, ¿qué hiciste para mejorar? Anota tres cosas de su proceso que podrías copiar.

### ✅ Esta semana
Elige una habilidad de tu negocio y para cada una de las tres partes escribe una acción: un rato de práctica, una estrategia nueva y una persona a quien pedirle ayuda.

### 💬 En el grupo
Pregúntale a una compañera del equipo qué hace para que le salga algo que a ti te cuesta.

## 5 · Clase 5 · Las etiquetas
*En tu vida · Elogios, prejuicios y lo que te dices*

Algunas etiquetas duelen. Otras suenan bonito. Las dos te pueden encerrar.

### El elogio que encierra
En un estudio, a un grupo de niños les pusieron unos problemas y luego los felicitaron. A unos les dijeron "qué inteligente eres". A otros, "qué bien le echaste ganas".

Lo que pasó después fue impresionante. Los que oyeron "qué inteligente" empezaron a evitar los retos para no perder esa etiqueta. Cuando les tocaron problemas difíciles, se desanimaron y su desempeño cayó. Hasta exageraban sus calificaciones al contarlas. Los que oyeron "le echaste ganas" querían problemas más difíciles, disfrutaban más y mejoraban.

Decirle a alguien que es lista o talentosa parece que le da seguridad. En realidad le enseña que su valor depende de no equivocarse nunca.

> Elogia lo que hizo, no lo que es: su estrategia, su práctica, sus decisiones.

### Las etiquetas negativas
Luego están las etiquetas que pesan: "las mujeres no son buenas para los números", "en tu familia nadie ha tenido negocio", "tú eres la tímida". Cuando una persona carga una etiqueta así y se pone en una situación donde se podría confirmar, rinde menos solo por la presión de pensar en ella.

La mentalidad de crecimiento no borra los prejuicios, pero les quita fuerza. Si sabes que las habilidades se aprenden, la etiqueta deja de ser una sentencia y se vuelve una opinión que puedes contradecir.

### ¿Pertenezco aquí?
Muchas mujeres entran a un mundo nuevo (un negocio, una carrera, un equipo de líderes) y en cuanto algo sale mal piensan "yo no pertenezco aquí". Esa duda aparece más en quien ya carga una etiqueta. Si te pasa, recuerda: todas las que están ahí también tuvieron que aprender.

### Las que te pones tú
Las etiquetas más difíciles de quitar son las que te pones tú: "es que yo soy desorganizada", "yo no soy de redes", "yo soy mala para los números". Cada una te da permiso de no intentarlo. Agrégale un "todavía" y mira qué pasa.

### 🪞 Para pensar
¿Qué etiqueta te pusieron de niña que todavía cargas? ¿Te ayuda o te detiene?

### ✍️ Escribe
Escribe tres etiquetas que te pones. A cada una agrégale "todavía" y una cosa que podrías hacer para empezar a cambiarla.

### ✅ Esta semana
Cada vez que quieras elogiar a tus hijas o a alguien del equipo, cambia "qué lista" o "qué talentosa" por algo sobre lo que hizo: "me encantó cómo preparaste esa presentación".

### 💬 En el grupo
Felicita a una compañera por algo concreto que hizo esta semana, no por cómo es.

## 6 · Clase 6 · Tu negocio y tu liderazgo
*En tu vida · Liderar para que otras crezcan*

Una empresa, o un equipo de venta directa, también tiene mentalidad. Y casi siempre la contagia quien la lidera.

### El culto al talento
Hay empresas que creen tanto en el "talento nato" que contratan solo a estrellas, las ponen en un pedestal y les exigen que demuestren todo el tiempo lo brillantes que son. El resultado suele ser desastroso: nadie admite errores, nadie pide ayuda, todos esconden los problemas hasta que explotan.

### Las líderes que crecen
Las organizaciones que crecen tienen líderes que hacen algo menos vistoso: preguntan, escuchan, admiten lo que no saben y se rodean de gente capaz, aunque sea más capaz que ellas. Dan crédito, no lo acaparan. Y creen que su gente puede mejorar, entonces le enseñan.

Hay un dato que lo dice todo: las jefas que creen que las personas pueden crecer dan más retroalimentación útil, notan antes cuando alguien mejora y se toman el tiempo de acompañar. Las que creen que "una sirve o no sirve" deciden en la primera impresión y ya no cambian de opinión.

> Una líder con mentalidad fija necesita brillar. Una con mentalidad de crecimiento necesita que su equipo brille.

### El pensamiento de grupo
Cuando todas piensan igual y nadie se atreve a decir "esto no me late", se toman malas decisiones. Una buena líder abre la puerta a las ideas distintas y a las críticas constructivas: pide opiniones antes de dar la suya, pregunta "¿qué se nos está escapando?" y agradece a quien no está de acuerdo.

### ¿Las líderes nacen o se hacen?
Se hacen. Y lo mismo pasa con vender, negociar y presentar. En los estudios, quienes creían que negociar se aprende negociaban mejor, sobre todo cuando la cosa se ponía difícil. Si tú crees que tu equipo puede aprender, lo vas a capacitar distinto. Y ellas lo van a notar.

### 🪞 Para pensar
Cuando alguien de tu equipo no da resultados, ¿piensas "no es para esto" o "¿qué le falta aprender?"?

### ✍️ Escribe
Piensa en una persona de tu equipo (o en ti misma, si apenas empiezas). Escribe tres cosas que podría aprender y cómo podrías ayudarle con cada una: acompañarla, enseñarle un guion, revisar sus videos.

### ✅ Esta semana
En tu próxima junta o llamada de equipo, pregunta primero "¿qué está funcionando y qué no?" antes de dar tus ideas. Escucha sin defenderte.

### 💬 En el grupo
Comparte una cosa que aprendiste de alguien de tu equipo, aunque tenga menos tiempo que tú.

## 7 · Clase 7 · Amor, amistad y pena
*En tu vida · Tus relaciones también aprenden*

La mentalidad no solo vive en el trabajo. También se mete en la pareja, en las amistades y en la forma en que entras a una fiesta.

### "Si cuesta, no era"
La mentalidad fija tiene una idea muy romántica y muy dañina del amor: si es el bueno, todo debe fluir. Él debería saber lo que pienso sin decírselo. No deberíamos tener que platicar las cosas. Si hay que trabajarle, es que no era.

La realidad es que en todas las relaciones hay problemas. Lo que cambia es qué crees que significan.

### Los problemas no son defectos
Desde la mentalidad fija, un problema se vuelve un defecto de carácter: "es que él es un egoísta", "es que yo soy insoportable". Y si es un defecto, no hay nada que hacer, solo culpar.

Desde la mentalidad de crecimiento, un problema es algo que se puede platicar y resolver. Las parejas que crecen escuchan las diferencias, hablan con paciencia y se ayudan a ser mejores. Muchas veces los problemas resueltos acercan más que los días sin problemas.

> Una relación sana no es la que no tiene problemas. Es la que aprende a resolverlos.

### Competir con quien quieres
Cuidado con convertir a tu pareja, a tu hermana o a tu amiga en tu competencia: quién gana más, quién tiene más seguidoras, quién es mejor mamá. Querer a alguien también es alegrarte cuando crece.

### La pena
La timidez es, muchas veces, miedo a ser juzgada. Desde la mentalidad fija, cada conversación es una evaluación: ¿les caigo bien o no? Desde la de crecimiento, cada conversación es una oportunidad de conocer a alguien y de practicar. La pena no siempre se quita, pero deja de mandar.

Esto le sirve mucho a tu negocio: hablarle a alguien nuevo en un evento o hacer tu primer en vivo es una habilidad social, y las habilidades se practican.

### Después del rechazo
Cuando alguien te rechaza (una pareja, una amiga, una clienta), puedes quedarte con la herida y el coraje, o puedes preguntarte qué aprendiste de lo que quieres y no quieres, perdonar y seguir. Lo segundo no significa que no te dolió. Significa que no te quedas a vivir ahí.

### 🪞 Para pensar
¿Hay alguien en tu vida a quien le pusiste la etiqueta de "es así y no va a cambiar"? ¿Y alguien que te la puso a ti?

### ✍️ Escribe
Piensa en un problema que se repite en una relación importante. Escríbelo sin culpar a nadie: qué pasa, qué necesita cada quien y qué podrían intentar distinto.

### ✅ Esta semana
Antes de un evento o de un en vivo, repite: "vengo a conocer gente y a practicar, no a que me califiquen".

### 💬 En el grupo
Cuenta una habilidad social que antes te daba pena y hoy ya practicas.

## 8 · Clase 8 · Lo que enseñas sin decirlo
*En tu vida · Para tus hijas y tu equipo*

Las niñas no aprenden lo que les dices. Aprenden lo que ven que haces cuando las cosas salen mal. Y tu equipo, igual.

### Cada palabra manda un mensaje
"Aprendiste rapidísimo, eres un genio." "Qué bonito dibujas, eres una artista." Lo decimos con todo el amor, pero el mensaje que llega es: "te quiero porque eres lista y talentosa". Y entonces el miedo es: "si me equivoco, ¿ya no?".

El mensaje que sí ayuda es otro: "eres una persona que está creciendo, y me interesa cómo creces".

### Cómo reaccionas a los errores
Esto es lo que más pesa. Cuando tu hija trae una mala calificación, o alguien del equipo tiene un mes flojo, ¿qué haces? Si reaccionas con angustia, con regaño o tratando de que "no se note", les enseñas que el error es algo terrible.

Si reaccionas con interés ("a ver, ¿qué pasó?, ¿qué podemos probar?"), les enseñas que el error es por donde se aprende.

> Tus hijas no ven la mentalidad que tienes en la cabeza. Ven cómo reaccionas cuando se equivocan.

### Crítica que ayuda
La crítica constructiva no es etiquetar ("eres una desordenada") ni excusar ("no pasa nada, no es tu culpa"). Es ayudar a entender cómo arreglarlo: "esta parte del video está muy larga; ¿qué tal si la cortas a la mitad?".

### Exigencia con cariño
Las mejores maestras y líderes ponen la barra alta y, al mismo tiempo, dan el apoyo para llegar a ella. Bajar la exigencia no sube la autoestima. Subirla sin enseñar cómo, tampoco. Las dos cosas juntas sí.

### La mentalidad de crecimiento de mentiras
Ojo con tres confusiones muy comunes:
- **Creer que es ser buena onda o abierta.** Ser flexible está padre, pero crecer es trabajar en desarrollar habilidades.
- **Creer que es solo felicitar el esfuerzo.** Si alguien se esforzó y no avanzó, no basta con decirle "le echaste ganas". Hay que buscar otra estrategia y otros recursos. Y sí puedes celebrar los logros, uniéndolos a lo que hizo para lograrlos.
- **Creer que es decir "tú puedes con todo".** Sin enseñar el cómo, esa frase deja toda la carga en la otra persona.

### 🪞 Para pensar
¿Qué le dices a tus hijas o a tu equipo cuando les va mal? ¿Qué crees que entienden?

### ✍️ Escribe
Escribe tres frases que dices mucho cuando alguien hace algo bien o se equivoca. Reescribe cada una para que hable del proceso: lo que hizo, lo que eligió o lo que puede probar.

### ✅ Esta semana
Cada noche, anota un elogio sobre el proceso y una crítica útil que hayas dado ese día.

### 💬 En el grupo
Comparte una frase nueva que vas a usar con tus hijas o con tu equipo.

## 9 · Clase 9 · Tu voz de "no puedes"
*Cambia · Acéptala, cáchala, nómbrala y llévatela*

Todas tenemos una voz que aparece justo cuando estamos por crecer y nos dice "mejor no". Esta clase es para conocerla.

### No es una o la otra
Nadie tiene una mentalidad de crecimiento pura. Quien diga que sí, probablemente no se ha observado bien. El cambio no es un anuncio ("ya tengo mentalidad de crecimiento"); es un camino. Y empieza con cuatro pasos.

### Paso 1 · Acéptala
Tienes una parte con mentalidad fija. Todas la tenemos. No es para darte vergüenza; es parte de ser humana. Lo que sí puedes cambiar es cuántas veces la dejas manejar.

### Paso 2 · Cáchala
Descubre qué la despierta. A algunas les aparece cuando están por intentar algo grande: "¿y si no tienes lo que se necesita y todas se dan cuenta?". A otras, cuando algo no avanza: "ya déjalo, haz algo más fácil". A otras, cuando ven a alguien que es mejor en lo que ellas presumían: "nunca vas a ser como ella". Y a otras, cuando tienen presión y se vuelven jefas imposibles con su equipo.

No la juzgues. Solo obsérvala: cuándo llega, qué te dice, cómo te hace sentir y qué haces después.

### Paso 3 · Nómbrala
Sí, ponle nombre. Puede ser el de un personaje, el de una tía muy criticona o uno que te dé risa. "Ahí viene Doña Perfecta." "Ya llegó la Juez." Ponerle nombre te ayuda a ver que es una parte de ti, no toda tú.

Y si lo platicas con tu equipo, es oro: "cuando tenemos cierre de mes, me sale la Juez y me pongo insoportable; si la ven, díganme". Entender las voces de las demás te da paciencia con ellas.

### Paso 4 · Llévatela
No la vas a correr. Esa voz nació para protegerte de pasar vergüenzas. Lo que sí puedes hacer es educarla. Cuando aparezca, dale las gracias y dile por qué quieres intentarlo de todos modos: "sé que puede no salir, pero quiero probar. ¿Me acompañas?".

Cuando algo salga mal, déjala hacer su drama un ratito. Luego, cuando se calme, platícale tu plan: "sí, puede que esto no me salga… todavía. Pero ya sé qué voy a intentar".

> Tu voz de "no puedes" no se va. Pero puede aprender a viajar contigo.

### 🪞 Para pensar
¿Cuándo fue la última vez que apareció esa voz? ¿Qué te dijo y qué hiciste?

### ✍️ Escribe
Escribe la ficha de tu voz: su nombre, qué la despierta, qué te dice, cómo te hace sentir, qué te hace hacer y cómo afecta a los demás. Al final, escribe lo que le vas a contestar la próxima vez.

### ✅ Esta semana
Cada vez que aparezca, llámala por su nombre en voz baja y contéstale con tu frase.

### 💬 En el grupo
Presenta a tu voz: cómo se llama y cuándo aparece. Te vas a dar cuenta de que no eres la única.

## 10 · Clase 10 · Cuándo, dónde y cómo
*Cambia · Un plan que sí cumplas*

Saber todo esto no cambia nada si no se vuelve algo que haces un martes cualquiera.

### Prometer no sirve
Todas hemos prometido "mañana sí empiezo". Y mañana llega y se va. La investigación es clara: prometer, aunque sea con mucha intención, sirve de muy poco. Lo que sí funciona es un plan concreto que puedas imaginar: **cuándo, dónde y cómo** lo vas a hacer.

No es "esta semana hago un en vivo". Es "el jueves, cuando deje a las niñas en la escuela, me siento en la mesa del comedor con la luz de la ventana y prendo el en vivo a las 9:15 para enseñar tres productos".

### Sentirte mal y hacerlo igual
A veces, aunque te convenzas de que todo está bien, te sigues sintiendo mal. Está bien. No necesitas sentirte bien para dar el paso. El plan es el plan. Puedes estar triste y aun así mandar ese mensaje, pedir esa retroalimentación o grabar ese video.

### Pedir información, no permiso
Cuando algo no se da (una clienta que dijo que no, una promoción que no lograste), la mentalidad de crecimiento no se queda en consolarse. Da el siguiente paso: pregunta qué faltó, busca cómo prepararte y vuelve a intentarlo. Una pregunta honesta y humilde casi siempre abre puertas.

### Mantener el cambio
Lo curioso es que, cuando algo mejora, muchas personas dejan de hacer lo que lo mejoró. Como cuando te sientes mejor y dejas la medicina. El cambio de mentalidad necesita cuidado constante. No son un par de trucos; es una forma distinta de ver: de "juzgar y que me juzguen" a "aprender y ayudar a aprender".

### Tus preguntas de cada mañana
Pégalas en tu espejo:
1. ¿Qué oportunidades tengo hoy para aprender y crecer? ¿Y la gente a mi alrededor?
2. ¿Cuándo, dónde y cómo lo voy a hacer?
3. Si algo se atora: ¿cuál es mi nuevo plan y cuándo, dónde y cómo?
4. Si me sale: ¿qué tengo que hacer para seguir creciendo?

> No esperes a sentirte lista. Ponle fecha, hora y lugar.

### 🪞 Para pensar
¿Qué tienes pendiente desde hace semanas porque "todavía no es el momento"?

### ✍️ Escribe
Regresa a las tres frases que escribiste en la bienvenida. Elige una y escribe su plan: qué vas a hacer, cuándo, dónde y cómo. Agrega qué harás si tu voz de "no puedes" aparece.

### ✅ Esta semana
Cumple tu plan. Usa la herramienta "Tu plan de la semana" para escribirlo y revisarlo.

### 💬 En el grupo
Comparte tu plan con día, hora y lugar. Y la próxima semana, cuéntanos cómo te fue.

## 11 · ¿Qué mentalidad tienes?
*Herramienta · Un test rápido para saber dónde estás*

Responde con honestidad. No hay respuestas buenas ni malas: es para saber desde dónde empiezas.

### Sobre tu inteligencia
Lee cada frase y decide si estás más de acuerdo o más en desacuerdo:
1. Tu inteligencia es algo muy tuyo que no puedes cambiar mucho.
2. Puedes aprender cosas nuevas, pero no puedes cambiar qué tan inteligente eres.
3. No importa cuánta inteligencia tengas, siempre puedes aumentarla bastante.
4. Siempre puedes cambiar de manera importante qué tan inteligente eres.

Si estás más de acuerdo con la 1 y la 2, tiendes a la mentalidad fija en este tema. Si estás más de acuerdo con la 3 y la 4, tiendes a la de crecimiento.

### Sobre tu forma de ser
1. Eres de cierta manera y no hay mucho que hacer para cambiarlo.
2. No importa cómo seas, siempre puedes cambiar bastante.
3. Puedes hacer las cosas distinto, pero lo importante de quién eres no cambia.
4. Siempre puedes cambiar cosas básicas de la persona que eres.

Aquí, la 1 y la 3 son de mentalidad fija; la 2 y la 4, de crecimiento.

### Ahora con tu negocio
Cambia "inteligencia" por cada una de estas palabras y vuelve a contestar: **vender**, **hablar a cámara**, **liderar**, **los números**, **organizarte**. Es muy normal tener mentalidad de crecimiento en unas y fija en otras.

### ✍️ Escribe
Anota en qué temas saliste más fija. Esos son tus temas para este curso.

## 12 · Las dos mentalidades
*Herramienta · La tabla para pegar en tu espejo*

Tenla a la mano. Cuando no sepas desde dónde estás pensando, revisa en qué columna estás.

### Lo que crees
- **Fija:** tus capacidades vienen de fábrica.
- **Crecimiento:** tus capacidades se desarrollan.

### Lo que buscas
- **Fija:** verte capaz. Demostrar.
- **Crecimiento:** volverte más capaz. Aprender.

### Ante un reto
- **Fija:** lo evitas, por si no te sale.
- **Crecimiento:** lo tomas, porque ahí creces.

### Ante un obstáculo
- **Fija:** te rindes rápido.
- **Crecimiento:** insistes y cambias de estrategia.

### El esfuerzo
- **Fija:** es señal de que no tienes talento.
- **Crecimiento:** es el camino para dominar algo.

### La crítica
- **Fija:** la ignoras o te ofendes.
- **Crecimiento:** aprendes de ella.

### El éxito de otras
- **Fija:** te amenaza.
- **Crecimiento:** te enseña y te inspira.

### El resultado
- **Fija:** te estancas antes de tiempo y no llegas a lo que podías.
- **Crecimiento:** llegas cada vez más lejos.

## 13 · Frases de cambio
*Herramienta · Para ti, tus hijas y tu equipo*

Las palabras que repites se vuelven lo que crees. Aquí tienes cambios fáciles.

### Lo que te dices
- "No soy buena para esto." → "No me sale todavía. ¿Qué me falta aprender?"
- "Esto es muy difícil." → "Esto va a tomar tiempo y práctica."
- "Ya lo intenté y no funcionó." → "¿Qué estrategia no he probado?"
- "Ella es mejor que yo." → "¿Qué hace ella que yo podría aprender?"
- "Me equivoqué, qué tonta." → "Me equivoqué. ¿Qué me enseña esto?"
- "Ya está bien así." → "¿Esto es lo mejor que puedo hacer hoy?"
- "Me dio pena preguntar." → "Preguntar es la forma más rápida de aprender."

### Lo que les dices a tus hijas
- "Qué inteligente eres." → "Qué bien te organizaste para estudiar."
- "Eres una artista." → "Me encanta cómo mezclaste esos colores. ¿Cómo se te ocurrió?"
- "No importa, no eres buena para eso." → "Todavía no te sale. ¿Qué podemos probar?"
- "No pasa nada, no es tu culpa." → "A ver, ¿qué pasó? ¿Qué harías distinto?"

### Lo que le dices a tu equipo
- "Tú naciste para esto." → "Se nota cuánto has practicado tus mensajes."
- "Ella no sirve para vender." → "¿Qué le falta aprender y cómo la acompaño?"
- "Échale ganas." → "Probemos esta otra forma. Te enseño."
- "Tú puedes con todo." → "Este es el siguiente paso, y aquí estoy para ayudarte."

## 14 · Tu plan de la semana
*Herramienta · Preguntas para el espejo y plan con fecha*

Usa esta hoja cada lunes. Cópiala en tu cuaderno o escríbela aquí abajo.

### Las preguntas de la mañana
1. ¿Qué oportunidad tengo hoy para aprender o crecer?
2. ¿A quién puedo ayudar a crecer hoy?
3. ¿Cuándo, dónde y cómo lo voy a hacer?

### Tu plan
- **Lo que quiero aprender o intentar:**
- **Cuándo (día y hora):**
- **Dónde:**
- **Cómo (los pasos):**
- **A quién le voy a pedir ayuda:**
- **Qué le voy a contestar a mi voz de "no puedes":**

### Si se atora
- ¿Qué pasó?
- ¿Qué nueva estrategia voy a probar?
- ¿Cuándo, dónde y cómo?

### Si me salió
- ¿Qué hice que funcionó?
- ¿Qué tengo que hacer para seguir creciendo?

### ✍️ Escribe
Escribe aquí tu plan de esta semana.
