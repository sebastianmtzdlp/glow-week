# Otra tú · contenido completo del curso

## 0 · Bienvenida a Otra tú
*Empieza aquí · El curso en 5 minutos*

Este curso es para cuando sientes que siempre terminas en el mismo lugar: la misma preocupación, la misma reacción, el mismo pleito contigo. Aquí aprendes a dejar de ser la de siempre, un hábito a la vez.

### De qué se trata
La idea central es sencilla y un poco incómoda: **tu personalidad es un hábito**. La forma en que piensas, lo que sientes y cómo actúas se repite tanto que ya corre sola. Y como tu vida es el reflejo de esa personalidad, mientras sigas siendo la misma persona vas a seguir viviendo la misma vida.

La buena noticia es que un hábito se puede desaprender. No a fuerza de voluntad un lunes cualquiera, sino con un método: entender qué te tiene atorada y practicar todos los días un rato a solas para quitarle fuerza a la versión vieja y ensayar la nueva.

> No vienes a convertirte en otra persona. Vienes a dejar de cargar lo que no eres.

### Cómo está armado
- **Entiende (clases 1 a 6).** Seis clases cortas para entender por qué cuesta tanto cambiar: el ciclo pensar y sentir, las tres cosas que te jalan al pasado, por qué el cuerpo se engancha a ciertas emociones, la brecha entre cómo te ven y cómo te sientes, y qué es meditar en realidad.
- **Practica (clases 7 a 12).** Cuatro semanas de práctica diaria. Cada semana repites lo que ya aprendiste y le sumas uno o dos pasos. Son siete pasos en total. Al final, una clase para vivirlo fuera de la meditación.
- **Herramientas.** El guion completo de la sesión, las listas para elegir tu emoción, la revisión de la noche y un calendario de cuatro semanas.

### Lo que necesitas
- Un cuaderno (o el cuaderno de cada clase, que se guarda en tu celular).
- Un lugar tranquilo que no sea tu cama.
- Entre 20 y 50 minutos al día, de preferencia al despertar.
- Paciencia contigo. Los primeros días tu cuerpo va a querer pararse, revisar el celular o dormirse. Es normal.

### Antes de empezar
El libro en el que se basa este curso explica el cambio con ideas de neurociencia y de física cuántica. Algunas de esas explicaciones son la interpretación del autor y no ciencia comprobada. Aquí nos quedamos con lo práctico: poner atención, repetir y ensayar a la persona que quieres ser.

Este curso acompaña, pero **no sustituye terapia ni tratamiento médico**. Si estás pasando por depresión, ansiedad fuerte, un duelo o un trauma, busca también a una profesional.

### 🪞 Para pensar
¿Qué es lo que más se repite en tu vida y ya te cansó? No lo que te pasa, sino cómo reaccionas tú.

### ✍️ Escribe
Escribe en una frase por qué empiezas este curso. Por ejemplo: "Estoy cansada de preocuparme por todo antes de que pase."

## 1 · Clase 1 · Tu personalidad crea tu realidad
*Entiende · El ciclo de pensar y sentir*

Si quieres una vida distinta, tienes que pensar, sentir y actuar distinto. Suena obvio, pero casi nadie lo hace.

### Eres un ciclo
Cada pensamiento produce una sensación en el cuerpo. Esa sensación te hace pensar igual a como te sientes. Y ese pensamiento vuelve a producir la misma sensación. Pensar y sentir, sentir y pensar, una y otra vez.

Por ejemplo: piensas "no me va a alcanzar el dinero". El cuerpo se tensa y sientes angustia. Con la angustia encima, buscas más pruebas de que no te va a alcanzar. Y la angustia crece. Al final del día no pasó nada nuevo, pero tú ya repasaste el mismo miedo cien veces.

> Lo que piensas y sientes todos los días se convierte en quién eres.

### La mayor parte va en automático
Para cuando somos adultas, la mayor parte de lo que hacemos corre sola: las mismas rutinas, las mismas reacciones, las mismas conversaciones en la cabeza. Se calcula que la gran mayoría de los pensamientos de hoy son los mismos de ayer.

Eso no es malo. El piloto automático te deja manejar sin pensar en cada pedal. El problema es cuando el piloto automático también decide cómo te sientes contigo, con tu pareja o con tu negocio.

### Personalidad y realidad
Tu personalidad es la mezcla de cómo piensas, cómo actúas y cómo te sientes. Y tu realidad personal (tus relaciones, tu dinero, tu salud, tu día a día) sale de esa personalidad.

Por eso cambiar de ciudad, de trabajo o de pareja casi nunca alcanza. Si te llevas a la misma tú, al poco tiempo recreas la misma vida en otro lugar.

> No puedes crear una vida nueva siendo la misma persona.

### Qué cambia en este curso
No vamos a pelear con las circunstancias. Vamos a trabajar en lo único que sí controlas: la persona que eres cuando nadie te está viendo. Primero entendiendo el ciclo y después practicando todos los días para salir de él.

### 🪞 Para pensar
¿Cuál es el pensamiento que más repites en un día normal? ¿Cómo te hace sentir? ¿Y qué haces cuando te sientes así?

### ✍️ Escribe
Dibuja tu ciclo en tres líneas: "Pienso…", "Siento…", "Entonces hago…". Usa algo real de esta semana.

### ✅ Hoy
Pon una alarma a mediodía que diga "¿Qué estoy pensando?". Cuando suene, anota la respuesta sin juzgarla.

## 2 · Clase 2 · Los tres jalones
*Entiende · Tu entorno, tu cuerpo y el tiempo*

Hay tres cosas que todo el día te regresan a la versión vieja de ti. Si las conoces, puedes ganarles.

### Por qué siempre regresas
Tomas una decisión: "a partir de hoy ya no me voy a enganchar". Dura hasta que ves el mensaje de tu mamá, entras a la cocina o abres el celular. ¿Qué pasó? Que tu mente vive amarrada a tres cosas que te recuerdan quién has sido.

### Jalón 1: tu entorno
Las personas, los lugares, las cosas y las rutinas de tu vida están conectadas con recuerdos y emociones. Ver a cierta persona, pasar por cierto lugar o escuchar cierta canción enciende el mismo programa de siempre. Tu entorno te recuerda cada día quién se supone que eres.

### Jalón 2: tu cuerpo
Después de años de sentir lo mismo, el cuerpo se acostumbra a esa emoción y la pide. Cuando intentas cambiar, el cuerpo protesta: "esto no se siente normal". Esa incomodidad no significa que vas mal; significa que estás saliendo de lo conocido. Lo vemos a fondo en la clase 3.

### Jalón 3: el tiempo
Casi siempre estás en el pasado (recordando lo que te dolió) o en el futuro (anticipando lo que te da miedo). Las dos cosas te tienen viviendo con las mismas emociones de siempre. El presente es el único lugar donde puedes hacer algo distinto.

> Para cambiar tienes que ser más grande que tu entorno, más grande que tu cuerpo y más grande que el tiempo.

### Los momentos en que ya lo lograste
Seguro te ha pasado: estabas tan metida en algo (pintar, bailar, una plática buenísima) que se te olvidó el celular, no sentiste hambre y no supiste qué hora era. En ese momento te olvidaste de tu entorno, de tu cuerpo y del tiempo. Eso es exactamente lo que vamos a entrenar en la meditación.

### 🪞 Para pensar
¿Qué persona, lugar o cosa te regresa más rápido a la versión que quieres dejar? ¿En qué parte del día pasas más tiempo en el pasado o en el futuro?

### ✍️ Escribe
Haz tres listas cortas: "Lo que me jala de mi entorno", "Lo que me pide mi cuerpo" y "A dónde se va mi mente en el tiempo".

### ✅ Hoy
Elige un momento del día para estar diez minutos sin celular y sin hacer nada más que lo que estás haciendo. Nota qué tan rápido quieres escapar.

## 3 · Clase 3 · Adicta a sentirte así
*Entiende · Cómo el cuerpo se engancha a una emoción*

Te puedes volver adicta a la culpa, al enojo o a la preocupación igual que a cualquier otra cosa. Y no por débil: por química.

### El cuerpo también aprende
Una emoción es la huella química que deja una experiencia. Cuando algo te pasa, el cerebro manda señales y el cuerpo se llena de sustancias que te hacen sentir de cierta forma. Si esa emoción se repite muchas veces, el cuerpo se acostumbra a ella y la empieza a necesitar.

Llega un punto en que **el cuerpo se vuelve la mente**: ya no piensas y luego sientes, sino que el cuerpo siente primero y te empuja a pensar lo que confirma esa emoción. Por eso a veces te despiertas preocupada sin saber de qué. El cuerpo ya estaba en modo preocupación y la mente sale a buscarle motivo.

### De un momento a tu personalidad
Así se forma una personalidad, paso a paso:
- Te pasa algo y reaccionas con una emoción.
- Si te quedas en esa emoción horas o días, se vuelve un estado de ánimo.
- Si ese estado de ánimo dura semanas o meses, se vuelve tu temperamento.
- Si dura años, se vuelve tu personalidad. "Es que yo así soy."

> Lo que llamas "mi forma de ser" muchas veces es una emoción vieja que se quedó a vivir.

### Modo supervivencia y modo creación
Cuando sientes miedo, enojo o urgencia, el cuerpo se pone en modo emergencia. Eso sirve para huir de un peligro real, pero si vives así todo el día gastas tu energía en defenderte. Pones toda tu atención afuera: en el problema, en la gente, en el reloj.

En modo creación pasa lo contrario. Estás tranquila, abierta y con energía para imaginar algo nuevo. No puedes crear una vida distinta mientras tu cuerpo cree que está en peligro.

### Por qué buscas lo mismo
Si tu cuerpo está acostumbrado a la culpa, inconscientemente vas a buscar situaciones que te hagan sentir culpable. Si está acostumbrado al drama, vas a encontrar drama. No es mala suerte: el cuerpo quiere su dosis de siempre.

### 🪞 Para pensar
¿Qué emoción sientes casi todos los días, aunque no pase nada especial? ¿Desde cuándo la traes?

### ✍️ Escribe
Escribe tu emoción de cajón y completa: "Cuando la siento, en el cuerpo noto…" y "Para sentirla otra vez, sin querer yo…".

### ✅ Hoy
Cada vez que notes esa emoción, solo dite su nombre en voz baja: "esto es preocupación". Nombrarla ya te pone un paso afuera de ella.

## 4 · Clase 4 · La brecha
*Entiende · Cómo te ven y cómo te sientes*

Hay una distancia entre la mujer que todos ven y la que se queda sola en la noche. A esa distancia le llamamos la brecha.

### Dos versiones de ti
Imagina dos manos, una arriba de la otra. La de arriba es **cómo te ven**: la imagen que cuidas, la que dice "todo bien, todo bajo control". La de abajo es **cómo te sientes** cuando no hay nadie, ni ruido, ni pendientes: cansada, insegura, sola, con miedo.

Entre las dos hay un espacio, y lo llenan las emociones que fuiste guardando con los años: la culpa, la vergüenza, el miedo a no ser suficiente, el enojo que nunca dijiste.

### Mantener la imagen cuesta
Sostener esa imagen gasta muchísima energía. Necesitas que el entorno te la recuerde todo el tiempo: el trabajo, los logros, la gente, las cosas. Por eso cuando se apaga todo y te quedas quieta aparece un vacío. Y para no sentirlo, vuelves a llenarte de cosas de afuera: compras, comida, redes, trabajo, pleitos.

> Lo que sientes cuando te quedas quieta un buen rato es lo que de verdad traes adentro.

### Cuando la vida rompe la imagen
A veces la brecha se cierra a la fuerza: una crisis, una enfermedad, una pérdida. De pronto ya no puedes sostener la imagen y te toca ver lo que había abajo. Este curso propone hacerlo antes y por gusto, no por dolor.

### Cerrar la brecha
Cerrar la brecha es lograr que como te ven sea como eres. No a base de fingir mejor, sino soltando las emociones que la llenan. Cuando ya no tienes que esconder nada, recuperas toda esa energía y la puedes usar para crear.

### 🪞 Para pensar
Si alguien te viera solo en redes o en el trabajo, ¿cómo te describiría? ¿Y cómo te describirías tú a las once de la noche?

### ✍️ Escribe
Divide una hoja en dos. Arriba: "Así me ven". Abajo: "Así me siento cuando nadie me ve". Escribe tres cosas en cada lado.

### ✅ Hoy
Siéntate diez minutos sin hacer nada y sin celular. No intentes sentirte bien. Solo nota qué aparece.

## 5 · Clase 5 · Pensar, hacer, ser
*Entiende · Cómo algo nuevo se vuelve parte de ti*

Así aprende tu cerebro cualquier cosa: primero lo piensas, luego lo haces y al final ya lo eres.

### Tres niveles
- **Pensar.** Aprendes algo nuevo: lees, escuchas, entiendes. Es conocimiento, y se queda en la cabeza.
- **Hacer.** Lo pones en práctica. Ahora tienes una experiencia, y la experiencia trae una emoción. Esa emoción le enseña al cuerpo lo que la mente entendió.
- **Ser.** Lo repites tantas veces que ya no lo piensas. Lo haces natural, como manejar o amarrarte las agujetas. Ya es parte de quién eres.

Cambiar tu personalidad funciona igual. Saber que te enganchas no basta. Tienes que practicar a la nueva tú hasta que te salga sin pensar.

### Se puede ensayar en la mente
Hay estudios en los que un grupo practicó ejercicios de piano en el teclado y otro solo los imaginó, sin tocar una tecla. Después de unos días, el cerebro de los dos grupos cambió de forma muy parecida. Ensayar con la mente, con atención y repetición, deja huella.

Eso es lo que harás en la semana 4: ensayar en tu mente cómo piensa, cómo actúa y cómo se siente la nueva tú, antes de que la vida te lo pida.

> Tu cerebro no distingue tan bien entre lo que vives y lo que ensayas con todo tu ser.

### Los ingredientes
Para que algo nuevo se grabe necesitas cuatro cosas: aprender (este curso), instrucciones claras (los siete pasos), atención (estar presente mientras lo haces) y repetición (todos los días). Si falta una, no se queda.

### 🪞 Para pensar
Piensa en algo que antes te costaba y ahora haces sin pensar. ¿Cuántas veces lo repetiste antes de que saliera solo?

### ✍️ Escribe
Escribe una cualidad que quieres que sea parte de ti (por ejemplo, calma). Luego responde: ¿cómo la pienso?, ¿cómo la practico?, ¿cómo sabré que ya la soy?

## 6 · Clase 6 · Meditar es volverte conocida
*Entiende · Qué es meditar y cómo prepararte*

Meditar no es dejar la mente en blanco. Es conocerte tan bien que ya no te agarres desprevenida.

### Qué es meditar aquí
En este curso, meditar es sentarte a solas para **observarte y volverte familiar contigo**: tus pensamientos de siempre, tus emociones de siempre, tus reacciones de siempre. Lo que conoces bien deja de manejarte.

También es la forma de salir un rato de los tres jalones: cierras los ojos (adiós entorno), dejas el cuerpo quieto (adiós cuerpo) y te quedas en el presente (adiós tiempo).

### El ritmo de tu mente
El cerebro trabaja a distintas velocidades:
- **Beta:** despierta, pensando, resolviendo. Si es muy alta, es estrés: mil pestañas abiertas.
- **Alfa:** relajada pero atenta, como cuando sueñas despierta. Aquí la mente se calma y es más fácil entrar a tus programas automáticos.
- **Theta:** el estado entre dormida y despierta. Muy profundo.

La meta de cada sesión es bajar de beta a alfa sin dormirte. Por eso la primera parte de cada sesión (semana 1) es solo para eso.

> Primero bajas el volumen. Después cambias la canción.

### Prepara tu lugar
- **No en tu cama.** Tu cuerpo asocia la cama con dormir y te va a ganar el sueño. Busca otro rincón y que siempre sea el mismo.
- **Sin distracciones.** Celular en modo avión y en otro cuarto. Avisa en casa que no te interrumpan.
- **Música opcional.** Si te ayuda, que sea suave y sin letra.

### Prepara tu cuerpo
- Siéntate derecha, en una silla, con los pies en el piso y las manos sobre las piernas. Evita el sillón reclinable.
- Ve al baño, toma agua, ponte ropa cómoda. Que nada te saque.
- Si cabeceas, es buena señal: estás bajando. Con la práctica tu cuerpo aprende a estar relajado sin dormirse.

### Prepara tu horario
- Lo ideal es al despertar o antes de dormir, cuando la mente ya está más lenta.
- La primera semana son unos 20 minutos. Cada semana se suma un poco. Al final, una sesión completa dura entre 40 y 50 minutos.
- Si tienes hora de salida, pon una alarma diez minutos antes para cerrar con calma. Si en la sesión estás pensando en la hora, el tiempo te ganó.

### Prepara tu actitud
Habrá días en que la mente no se calla y el cuerpo quiere pararse. Ese es el yo viejo peleando por el control. No lo regañes. Regrésalo con cariño al presente, una y otra vez. Cada vez que lo haces, lo estás entrenando.

### ✅ Antes de la clase 7
- Elige tu lugar y pruébalo una vez.
- Elige tu hora y ponla en el calendario por cuatro semanas.
- Ten listo tu cuaderno.

### ✍️ Escribe
¿Dónde vas a meditar, a qué hora y qué vas a hacer con el celular? Escríbelo como compromiso.

## 7 · Clase 7 · Abre la puerta
*Semana 1 · Paso 1: bajar el ritmo*

Toda la semana practicas solo una cosa: entrar en calma. Este paso abre todas tus sesiones de aquí en adelante.

### Por qué empezar con el cuerpo
Suena raro: queremos dejar de estar pendientes del cuerpo y empezamos poniéndole atención. La razón es que, cuando sientes el cuerpo en lugar de pensarlo, la mente analítica se calla. Pasas de pensar a sentir, y ahí la mente baja de beta a alfa.

El truco no es sentir el cuerpo en sí, sino **el espacio que ocupa**. Cuando pones atención al espacio, tu foco se abre, deja de estar apretado en un problema y se vuelve amplio. Esa atención amplia es la que calma.

### Opción 1: recorrido por el espacio del cuerpo
1. Siéntate derecha y cierra los ojos. Respira lento por la nariz y suelta por la boca unas cuantas veces.
2. Pon atención al espacio que ocupa tu cabeza, empezando por arriba. ¿Puedes sentir su volumen, su peso?
3. Baja despacio: la frente, los ojos, la nariz, los labios, la quijada, las orejas. Quédate unos 20 o 30 segundos en cada parte.
4. Sigue con el cuello, el pecho, los hombros, los brazos, las manos, el abdomen, la espalda, la cadera, las piernas, los pies.
5. Ahora siente todo tu cuerpo a la vez, como un solo volumen en el espacio.
6. Luego siente el espacio que rodea tu cuerpo, como una burbuja alrededor de ti.
7. Al final, siente el espacio de todo el cuarto.

### Opción 2: el agua que sube
Imagina que agua tibia empieza a llenar el cuarto. Primero cubre tus pies, luego tus tobillos, tus rodillas, tus piernas, tu cadera. Sube por tu abdomen, tu pecho, tus brazos, tu cuello. Pasa por tu boca, tu nariz, tus ojos y cubre tu cabeza hasta llenar todo el cuarto. Siente tu cuerpo flotando en ese espacio.

Si no te gusta la idea del agua, usa la opción 1. Puedes alternarlas.

> Tu única tarea esta semana es quedarte presente.

### Cuánto tiempo
Unos 20 minutos. Ve despacio. Es mejor quedarte más tiempo en cada parte que llegar rápido a los pies.

### Cómo saber que va bien
- Se te olvida un rato dónde estás o qué hora es.
- La respiración se hace lenta sola.
- Cabeceas un poco.
- Te cuesta un poco "regresar" cuando abres los ojos.

Si nada de eso pasa la primera semana, no importa. Estás construyendo el camino.

### 🪞 Para pensar
¿Qué tan seguido se fue tu mente a otro lado? ¿A dónde se iba: al pasado, al futuro o al cuerpo?

### ✅ Esta semana
- Practica el paso 1 todos los días, unos 20 minutos.
- Si quieres, graba tú misma el guion de la herramienta "La sesión completa" y escúchalo.
- Repite esta semana si todavía te cuesta. No hay prisa.

### ✍️ Escribe
Al terminar cada sesión, anota en una línea cómo te fue y cuánto tiempo sentiste que pasó.

## 8 · Clase 8 · Reconoce y dilo
*Semana 2 · Pasos 2 y 3: nombrar, admitir y declarar*

Esta semana empiezas a podar. Primero ves con claridad qué parte de ti quieres soltar y luego la dices con todas sus letras.

### Paso 2: reconocer
Para cambiar algo, primero tienes que verlo y ponerle nombre. Imagina que pudieras ver tu vida como una película, con todo lo que piensas, dices y haces. Este paso es hacer esa revisión todos los días, mientras todavía puedes cambiar el final.

Cuando te observas, ya no eres solo la emoción: eres también la que la está viendo. Ese pequeño paso hacia afuera es el inicio del cambio.

### Tu revisión
Antes de meditar, responde en tu cuaderno:
- ¿Qué tipo de persona he sido?
- ¿Qué muestro al mundo y qué siento por dentro?
- ¿Qué emoción siento una y otra vez, casi todos los días?
- ¿Cómo me describirían las personas más cercanas?
- ¿Qué escondo de los demás?
- ¿Qué es lo único que más quiero cambiar de mí?

### Elige una sola emoción
De todo lo que salió, elige **una** emoción para desaprender. Solo una. Las emociones están conectadas: cuando una baja, las demás bajan con ella. Si eliges el enojo, también vas a sentir menos frustración, juicio y envidia. Abre la herramienta "Listas para elegir" si necesitas ideas.

### Siéntela en el cuerpo
Cierra los ojos y recuerda esa emoción. ¿Dónde la sientes? ¿Calor, nudo, pecho apretado, cansancio? No huyas. Casi todo lo que haces en la vida es para no sentir esto. Esta vez quédate con ella y obsérvala como energía en tu cuerpo.

### Mira cómo piensas cuando la sientes
Pregúntate: "¿Cómo pienso cuando me siento así?". Con miedo, quizá te vuelves controladora o te abrumas. Con culpa, quizá te vuelves complaciente. Escribe uno o dos de esos estados de mente. Los vas a usar en los siguientes pasos.

### Paso 3: admitir y declarar
### Admitir, hacia adentro
Ahora le cuentas a algo más grande que tú quién has sido. Llámalo como te haga sentido: Dios, el universo, la vida, tu sabiduría interna. Lo importante es que es una inteligencia que **no te juzga, no te castiga y no te deja de querer**. Puedes decirle la verdad sin miedo.

Ejemplos de lo que podrías admitir:
- "Finjo que estoy bien, pero me siento muy sola."
- "Digo que sí a todo para que me quieran, porque siento que no valgo."
- "Llevo años sintiéndome fracasada, por eso me exijo tanto."

### Declarar, en voz alta
Luego dices en voz alta, bajito, la emoción que vas a soltar. Por ejemplo: "He sido una persona enojada toda mi vida", o simplemente "enojo". Es el paso que más cuesta, porque nadie quiere que se sepa lo que esconde. El cuerpo se va a resistir. Hazlo de todos modos.

Al decirlo dejas de gastar energía en esconderlo, y esa energía queda libre para lo que viene.

> Lo que nombras deja de manejarte en secreto.

### ✍️ Escribe
- La emoción que elegiste.
- Dónde la sientes en el cuerpo.
- Uno o dos estados de mente que trae.
- Lo que quieres admitir, en dos o tres frases.

### ✅ Esta semana
Todavía no medites con esto. Termina de leer la clase 9 y empieza la semana 2 con los cuatro pasos juntos.

## 9 · Clase 9 · Suéltalo
*Semana 2 · Paso 4: entregar lo que ya no quieres cargar*

Ya viste qué te pesa y lo dijiste en voz alta. Ahora lo sueltas, sin negociar y sin decir cómo se tiene que resolver.

### Por qué soltar
Llevas años intentando arreglar esto con la misma mente que lo creó, y no ha funcionado. Este paso es pedir ayuda a algo más grande que tu forma de pensar de siempre. Desde ahí se ven salidas que tú todavía no imaginas.

### Lo que no necesitas hacer
Cuando sueltas de verdad, no tienes que:
- Negociar ni prometer.
- Rogar ni pedir perdón una y otra vez.
- Sentir culpa o vergüenza.
- Explicar cómo debería pasar.

No puedes soltar y al mismo tiempo querer controlar el resultado. Soltar es confiar en que se va a resolver de una forma que todavía no se te ocurre.

### Cómo hacerlo
1. Repasa lo que escribiste en la clase 8.
2. Con los ojos cerrados, pide que esa parte de ti se transforme en algo mejor.
3. Imagina que la entregas. Hay quien abre una puerta y la deja pasar, quien la escribe en una carta o quien la pone en una caja y la ve desaparecer. Lo que imagines está bien. Lo importante es la intención.
4. **Da gracias** como si ya estuviera resuelto.

Un ejemplo de lo que puedes decir: "Te entrego mi preocupación y mi necesidad de controlar todo. Confío en que tú lo puedes acomodar mejor que yo. Abre los caminos que me toquen."

> Agradecer antes de que pase es la señal de que ya lo diste por hecho.

### Cómo se siente
Cuando sueltas bien, suele aparecer ligereza, alivio, alegría o gratitud. Si aparece la duda ("¿y si no funciona?"), es la mente vieja regresando. Vuelve al agradecimiento.

### La sesión de la semana 2
Cada día:
1. **Abre la puerta** (paso 1), unos 20 minutos.
2. **Reconoce** la emoción y el estado de mente que trae.
3. **Admite** por dentro quién has sido y **declara** en voz alta lo que sueltas.
4. **Suelta** y da gracias.

Repite hasta que los cuatro pasos se sientan como uno solo. Si necesitas más de una semana, tómala.

### ✍️ Escribe
Escribe tu propia frase para soltar, con tus palabras y para tu emoción.

### ✅ Esta semana
Practica los pasos 1 a 4 todos los días.

## 10 · Clase 10 · Obsérvate y di ¡cambio!
*Semana 3 · Pasos 5 y 6: conocer al yo viejo y cortarle el paso*

Esta semana te vuelves experta en la versión que quieres dejar, tan experta que la vas a ver venir antes de que llegue.

### Paso 5: observar y recordar
### Tus pensamientos automáticos
Cada emoción trae su propio repertorio de frases que te dices sin darte cuenta. Casi todo lo que haces empieza con un pensamiento, pero que lo pienses no quiere decir que sea cierto. Muchas veces es un eco del pasado.

Ejemplos:
- "Nunca me va a alcanzar."
- "Nadie me escucha."
- "Ella siempre me hace enojar."
- "Hoy ya es mal día, ni modo."
- "Así soy, igual que mi mamá."
- "Mejor empiezo el lunes."

### Tus conductas automáticas
También hay cosas que haces para volver a sentir esa emoción o para no sentirla un rato. Comer de más, comprar lo que no necesitas, quejarte con alguien, scrollear horas, buscar pleito, posponer, chismear, encerrarte, hablar del pasado.

### Memoriza tu lista
Escribe tus pensamientos y conductas automáticas y repásalas hasta sabértelas. En la meditación, obsérvate siendo esa persona y recuerda: **así ya no quiero ser**. La lista va a crecer y afinarse durante la semana. Está bien.

Cuando conoces tan bien tus programas, ya no se te pasan. Los ves desde que empiezan, y esa es tu libertad.

### Paso 6: ¡cambio!
### El juego del cambio
En la meditación, imagina situaciones donde normalmente caes en lo de siempre y di en voz alta **"¡Cambio!"**:
1. Imagínate pensando y sintiendo en automático. Di "¡Cambio!".
2. Imagina a la persona o la situación que más te engancha. Di "¡Cambio!".
3. Imagina un momento en que tendrías un "buen pretexto" para portarte como siempre. Di "¡Cambio!".

### En la vida real
Durante el día, cada vez que te cachas en un pensamiento o conducta de la lista, di "¡Cambio!", en voz alta si se puede. Con el tiempo tu voz se vuelve la más fuerte de tu cabeza.

Puedes agregar: "Esto no es amoroso conmigo. Prefiero estar tranquila y libre que repetir lo mismo."

> Cada vez que interrumpes el programa viejo, se debilita un poco.

### Por qué funciona
Es como la campana sin comida: si algo te detonaba siempre y dejas de responder igual, poco a poco deja de detonarte. La persona que te sacaba de quicio pierde ese poder porque tú ya no le das la reacción de siempre.

### La sesión de la semana 3
1. Abre la puerta.
2. Reconoce.
3. Admite y declara.
4. Suelta.
5. Obsérvate siendo el yo viejo y recuerda que ya no quieres ser así.
6. Imagina dos o tres situaciones y di "¡Cambio!".

### ✍️ Escribe
- Tus pensamientos automáticos (mínimo cinco).
- Tus conductas automáticas (mínimo cinco).
- Tres situaciones de tu semana donde vas a usar "¡Cambio!".

### ✅ Esta semana
Practica los pasos 1 a 6 todos los días y usa "¡Cambio!" afuera de la meditación al menos tres veces al día.

## 11 · Clase 11 · Crea a la nueva tú
*Semana 4 · Paso 7: imaginar, ensayar y crear*

Ya quitaste la hierba mala. Ahora siembras. Esta semana diseñas a la nueva tú y la ensayas hasta que se te haga natural.

### Crear: diseña a la nueva tú
Para construir una mente nueva necesitas hacerte preguntas nuevas, de esas que te obligan a imaginar. Responde con calma en tu cuaderno:

### Quién quiero ser
- ¿Cuál es la mejor versión de mí?
- ¿A quién admiro y cómo se comporta?
- ¿Cómo sería yo si fuera tranquila, segura, generosa…?
- ¿Qué me diría a mí misma si ya fuera esa persona?

### Cómo pienso
- ¿Cuál es mi nueva actitud?
- ¿Qué quiero creer de mí?
- ¿En qué pensamientos voy a poner mi energía?

### Cómo actúo
- ¿Qué hace esta mujer en un día normal?
- ¿Cómo habla con su familia, su equipo, sus clientas?
- ¿Cómo responde cuando algo sale mal?

### Cómo me siento
- ¿Qué siente la nueva yo al despertar?
- ¿Cómo es su energía?

### Ensayar: memoriza a la nueva tú
En la meditación, después de soltar y decir "¡Cambio!", conviértete en la nueva tú. Piensa como ella, imagina cómo camina, cómo respira, cómo habla. Lo más importante: **siente lo que ella siente**. Alegría, gratitud, calma, amor, fuerza.

Luego relájate unos segundos y hazlo otra vez. Y otra. Cada vez debe salir con menos esfuerzo. No sigas la lista igualita cada día; deja que sea creativo.

Si en algún momento te aburres, es buena señal: se está volviendo familiar.

> No te levantes de la silla siendo la misma persona que se sentó.

### Crear tu nuevo futuro
Ya siendo la nueva tú, con esa energía alta, imagina lo que quieres que llegue a tu vida: una relación sana, un negocio que crece, salud, paz en tu casa. Ve cada imagen unos segundos con certeza y gratitud, como si ya fuera tuya, y suéltala. Luego la siguiente.

No intentes decidir cómo, cuándo ni con quién. Suelta los detalles.

### Una advertencia honesta
Imaginar no reemplaza actuar. Ensayar la nueva tú te prepara para tomar decisiones distintas, pero el negocio crece con trabajo y la salud se cuida con médicos y hábitos. Esta práctica cambia a la persona que toma esas decisiones.

### La sesión de la semana 4
1. Abre la puerta.
2. Reconoce.
3. Admite y declara.
4. Suelta.
5. Obsérvate y recuerda.
6. "¡Cambio!"
7. Crea y ensaya a la nueva tú; imagina tu futuro con gratitud.

### ✍️ Escribe
Escribe a la nueva tú en presente, como si ya fuera real: cómo piensa, cómo actúa y cómo se siente. Mínimo diez líneas.

### ✅ Esta semana
Practica la sesión completa todos los días. Usa la herramienta "La sesión completa" como guía.

## 12 · Clase 12 · Vívelo todo el día
*Semana 4 en adelante · Que la nueva tú salga de la silla*

De nada sirve ser la nueva tú 40 minutos y la de siempre las otras quince horas. Esta clase es para llevarlo a tu día.

### Demostrar
Imagina que desayunas súper sano y luego te pasas el día comiendo papitas. Eso es meditar como la nueva tú y vivir como la vieja. La meditación es el ensayo; tu día es la función.

Demostrar es actuar de acuerdo con lo que ensayaste: tomar las decisiones que ella tomaría, hablar como ella hablaría, reaccionar como ella reaccionaría. Que tu comportamiento vaya alineado con tu intención.

### Pon recordatorios en tu día
Antes de salir de la sesión, planea tus momentos:
- "En la regadera voy a dar gracias por tres cosas."
- "Camino a la oficina voy a ir contenta, no repasando pendientes."
- "Cuando vea a mi líder o a mi equipo, voy a ser la nueva yo."
- "A la hora de comer me tomo un minuto para recordar quién soy."
- "Cuando lleguen mis hijos, voy a estar presente."

### La revisión de la noche
Antes de dormir, hazte estas preguntas:
- ¿Cómo me fue hoy?
- ¿En qué momento me salí y por qué?
- ¿Con quién reaccioné y dónde?
- ¿Cuándo me fui en automático?
- Si me vuelve a pasar, ¿cómo lo haría distinto?

Esa última respuesta es oro: la ensayas en tu mente y la sumas a tu meditación del día siguiente.

> Equivocarte no es fallar el curso. Notarlo es justo la práctica.

### Las señales
Cuando vives con una energía distinta, empiezas a notar cosas: coincidencias, oportunidades, conversaciones que fluyen, ideas nuevas, menos pleitos. Anótalas. Te ayudan a ver que lo de adentro sí se refleja afuera y te motivan a seguir.

Ojo: no todo lo que pase será una señal y no todo lo malo es tu culpa. Úsalas como motivación, no como examen.

### Cerrar la brecha
Cuando como te ven es como eres, ya no tienes nada que esconder ni que sostener. Esa es la verdadera ligereza, y de ahí sale una alegría que no depende de lo de afuera. Y cuando estás bien, te dan ganas de compartirlo con los demás.

### Y después
Trabaja con la misma emoción entre cuatro y seis semanas. Más o menos cada mes, revisa: ¿todavía siento esto?, ¿qué otra emoción se nota ahora? Cuando sientas que una bajó, elige la siguiente capa y repite el proceso.

### ✍️ Escribe
Escribe tu plan de mañana con tres recordatorios concretos y la hora de cada uno.

### ✅ Todos los días
- Sesión completa en la mañana.
- Tres recordatorios durante el día.
- Revisión de la noche.

## 13 · La sesión completa
*Herramienta · El guion de los siete pasos para leer o grabar*

Úsalo como guía mientras te aprendes la secuencia. Si lo grabas con tu voz, habla lento y deja pausas largas.

### Antes de empezar
Lugar de siempre, celular lejos, espalda derecha, pies en el piso. Repasa lo que escribiste en tu cuaderno: tu emoción, tus pensamientos automáticos y a tu nueva yo.

### 1. Abre la puerta (unos 20 minutos)
Cierra los ojos. Respira lento por la nariz y suelta por la boca, varias veces, hasta que llegues al presente.

Ahora pon tu atención en el espacio que ocupa tu cabeza… su volumen, su peso… Baja a tu frente… tus ojos… tu nariz… tus labios… tu quijada… tus orejas. Siente el espacio que ocupa tu cuello… tu pecho y tu espalda… tus hombros, tus brazos, tus manos… tu abdomen… tu cadera… tus piernas… tus pies.

Siente todo tu cuerpo como un solo volumen en el espacio. Ahora siente el espacio que rodea tu cuerpo… Y ahora el espacio de todo el cuarto… Quédate ahí un momento.

### 2. Reconoce
Trae a tu mente la emoción que estás desaprendiendo. Nota dónde vive en tu cuerpo. No la corras. Obsérvala. Recuerda cómo piensas cuando te sientes así.

### 3. Admite y declara
Por dentro, dile a esa inteligencia más grande que tú quién has sido y qué has estado escondiendo. Sin miedo: no te juzga.

Ahora, en voz alta y bajito, di la emoción que sueltas.

### 4. Suelta
Pide que esa parte de ti se transforme en algo mejor, de la forma que te toque. Entrégala: por una puerta, en una carta, en una caja… Da gracias como si ya estuviera hecho.

### 5. Obsérvate y recuerda
Mírate siendo la de siempre: tus pensamientos automáticos, lo que haces cuando te sientes así. Recuerda: así ya no quiero ser.

### 6. ¡Cambio!
Imagina dos o tres situaciones donde normalmente caes. En cada una, di en voz alta: "¡Cambio!".

### 7. Crea y ensaya
Ahora conviértete en la nueva tú. ¿Cómo piensa? ¿Cómo camina? ¿Cómo habla? Siente lo que ella siente: alegría, gratitud, calma, amor.

Relájate unos segundos y hazlo otra vez, con menos esfuerzo.

Desde esa energía, imagina lo que quieres que llegue a tu vida. Ve cada imagen unos segundos con certeza y gratitud, y suéltala. Luego la siguiente.

### Para cerrar
Recuerda quién vas a ser al abrir los ojos. Planea dos o tres momentos de tu día donde vas a ser ella. Respira profundo y, cuando estés lista, abre los ojos.

### 💬 Si lo vas a grabar
Deja silencios de 20 a 30 segundos en cada parte del paso 1. Pon música suave sin letra de fondo si te ayuda. Graba una versión por semana: la de la semana 1 solo con el paso 1, la de la semana 2 con los pasos 1 a 4, y así.

## 14 · Listas para elegir
*Herramienta · Emociones, estados de mente, pensamientos y conductas*

Para cuando no encuentras las palabras. Elige lo que te suene y agrega lo tuyo.

### Emociones de supervivencia
Elige una para desaprender:
- Inseguridad
- Vergüenza
- Tristeza
- Ansiedad
- Preocupación
- Culpa
- Miedo
- Enojo
- Frustración
- Resentimiento
- Envidia
- Juicio
- Arrepentimiento
- Sentirme víctima
- Sentir que no valgo
- Sentir que nunca alcanza
- Desánimo

### Estados de mente que traen
Elige uno o dos:
- Controladora
- Abrumada
- Quejumbrosa
- Culpo a los demás
- Confundida
- Distraída
- Me tengo lástima
- Desesperada
- Competitiva
- Necesito que me reconozcan
- Siempre con prisa
- Dramática
- Tímida, me escondo
- Necesitada
- Floja
- Insegura o sobrada
- Muy sensible o insensible

### Pensamientos automáticos
- "Nunca me va a alcanzar."
- "Nadie me escucha."
- "Todos se aprovechan de mí."
- "Es su culpa que mi vida esté así."
- "No soy tan inteligente."
- "No puedo cambiar."
- "Mejor empiezo otro día."
- "No tengo ganas."
- "Tengo que trabajar el doble que las demás."
- "Así soy, igual que mi mamá."
- "A ____ no le caigo bien."

### Conductas automáticas
- Encerrarme y sentirme mal sola
- Comer para no sentir
- Llamar a alguien para quejarme
- Scrollear horas
- Buscar pleito con quien quiero
- Comprar lo que no necesito
- Posponer
- Chismear
- Hablar de más del pasado
- Querer ser el centro de atención
- Presumir
- Dormir de más
- Gritar
- Manejar enojada

### Emociones de la nueva tú
Para la semana 4:
- Alegría
- Gratitud
- Calma
- Amor
- Libertad
- Confianza
- Inspiración
- Entusiasmo
- Fuerza

## 15 · La revisión de la noche
*Herramienta · Cinco preguntas antes de dormir*

Cinco minutos antes de dormir para ver en qué momento te fuiste en automático y cómo lo harías distinto.

### Las preguntas
1. ¿Cómo me fue hoy siendo la nueva yo, del 1 al 10?
2. ¿En qué momento me salí y por qué?
3. ¿Con quién o con qué reaccioné?
4. ¿Cuándo me fui en automático?
5. Si me vuelve a pasar, ¿qué haría distinto?

### Ensaya la respuesta
Cierra los ojos un minuto y vive la escena otra vez, pero ahora reaccionando como la nueva tú. Siéntelo. Mañana súmalo a tu meditación.

### Las señales del día
Anota cualquier cosa nueva o inesperada que haya pasado: una coincidencia, una oportunidad, una plática que fluyó, una idea. No para juzgar si "funciona", sino para notar.

> No es un examen. Es tu bitácora.

### ✍️ Escribe
Usa el cuaderno de esta herramienta para tu revisión de hoy.

## 16 · Tus cuatro semanas
*Herramienta · El calendario de práctica*

La práctica completa en una vista. Si una semana no te sale, repítela.

### Antes de empezar
- Lee las clases 1 a 6.
- Elige tu lugar, tu hora y ten tu cuaderno.

### Semana 1 · Abre la puerta
- Lee la clase 7.
- Diario: paso 1 (unos 20 minutos).
- Anota cómo te fue en una línea.

### Semana 2 · Reconoce, admite y suelta
- Lee las clases 8 y 9 y escribe tus respuestas.
- Diario: pasos 1 a 4 (unos 30 a 40 minutos).
- Elige tu frase para soltar.

### Semana 3 · Obsérvate y ¡cambio!
- Lee la clase 10 y escribe tus listas.
- Diario: pasos 1 a 6 (unos 40 minutos).
- Afuera: "¡Cambio!" al menos tres veces al día.

### Semana 4 · Crea a la nueva tú
- Lee las clases 11 y 12 y escribe a la nueva tú.
- Diario: sesión completa (40 a 50 minutos).
- Recordatorios durante el día y revisión de la noche.

### Después
- Sigue con la sesión completa todos los días.
- Trabaja la misma emoción de cuatro a seis semanas.
- Cada mes, revisa qué cambió y elige la siguiente capa.

### ✅ Tu registro
Usa el cuaderno de abajo para tachar tus días: escribe la fecha y qué pasos hiciste.
