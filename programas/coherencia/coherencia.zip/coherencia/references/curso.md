# Coherencia · contenido completo del curso

Usa este contenido para dar cada clase. Escríbelo en tus palabras con la plantilla del SKILL.md (añade la sección 🧘 La práctica con los pasos de la meditación de la clase).

# Clase 0 · Bienvenida a Coherencia
_Cómo funciona este curso_
Coherencia es un curso de práctica, no de teoría. Son 10 clases cortas para aprender a salir del modo supervivencia, entrenar tu atención y sentir hoy la emoción de la vida que quieres crear.

## De dónde sale
Este curso nace de un libro sobre meditación, cerebro y emociones que quisimos compartir con el equipo. Tomamos sus ideas principales y las bajamos a tu día: con hijas, pedidos, mensajes y poco tiempo.

## Lo que vas a practicar
- **Darte cuenta** de cuándo estás viviendo en automático.
- **Volver al presente** en un minuto, aunque el día esté pesado.
- **Una intención clara** para tu vida, escrita en una hoja.
- **Emociones elevadas**: gratitud, alegría, amor, confianza. Sentirlas antes de que pase lo que esperas.
- **Cinco meditaciones** cortas que puedes hacer en casa: la del presente, la de los centros, la respiración, la del corazón y la caminando.
- **Tu película del futuro**, un video de un minuto hecho en tu celular.

## Cómo aprovecharlo
1. **Una clase por semana.** Léela en 5 o 10 minutos y haz la práctica en los días siguientes.
2. **Practica poquito pero diario.** Diez minutos todos los días hacen más que una hora el domingo.
3. **Escribe en tu cuaderno** al final de cada clase. Se guarda en tu celular.
4. **Comparte en el grupo.** Practicar acompañada sostiene más que practicar sola.

> No se trata de meditar perfecto. Se trata de regresar, una y otra vez.

## Antes de empezar
Estas prácticas son para tu bienestar y tu enfoque. No sustituyen a tu médico, a tu tratamiento ni a terapia. Si estás embarazada, tienes presión alta o algún tema de salud, haz la respiración de la Clase 5 suave y sin retener el aire.

## 🪞 Mírate al espejo
¿En qué momentos del día sientes que vives en piloto automático?

## ✍️ Ejercicio
Escribe tres cosas que haces todos los días exactamente igual (cómo despiertas, qué ves primero en el celular, cómo hablas cuando estás cansada).

## ✅ Tu tarea de la semana
Elige tu lugar y tu hora para practicar: diez minutos, el mismo sitio, todos los días.

## 💬 Para compartir en el grupo
Cuéntale al equipo a qué hora vas a practicar para que alguien te pregunte cómo te fue.

# Clase 1 · Tu pasado no tiene que ser tu futuro
_Cómo funciona el piloto automático_
Si piensas lo mismo, decides lo mismo, haces lo mismo y sientes lo mismo, mañana se va a parecer mucho a ayer. No por mala suerte: por costumbre.

## El círculo que se repite
Imagina un día normal. Despiertas y lo primero que haces es recordar: los pendientes, la cuenta que no cuadra, la plática que salió mal. Esos pensamientos traen las mismas emociones de siempre. Desde esas emociones tomas las mismas decisiones. Las decisiones te llevan a los mismos actos, y los mismos actos producen las mismas experiencias. Y esas experiencias vuelven a despertar las mismas emociones.

Así, sin darte cuenta, tu pasado se convierte en tu futuro.

## El cuerpo también se acostumbra
Cuando vivimos con estrés por mucho tiempo, el cuerpo se acostumbra a esa química: a la prisa, a la preocupación, al enojo. Y lo que se vuelve costumbre, el cuerpo lo busca. Por eso a veces regresamos al mismo drama aunque no nos guste: se siente conocido.

El estrés sirve para una emergencia corta. El problema es vivir en emergencia todo el día: el cuerpo gasta su energía en sobrevivir y queda poca para crear, sanar o disfrutar.

## Ensayar en la mente cambia el cerebro
Hay estudios donde personas solo **imaginaron** que practicaban un ejercicio o una pieza de piano, sin moverse, y su cerebro cambió como si lo hubieran hecho. La mente ensaya y el cerebro se prepara.

Eso funciona en las dos direcciones. Si cada mañana ensayas en tu mente lo peor que puede pasar, estás preparando a tu cerebro para eso. Si ensayas a la mujer que quieres ser, lo preparas para ella.

> Lo que repites en tu mente, tu cuerpo lo aprende como si ya hubiera pasado.

## Cambiar es incómodo, y está bien
Cuando dejas de sentir lo de siempre, el cuerpo protesta. Aparece la flojera, la duda, el "mejor mañana". No es señal de que vas mal. Es señal de que estás saliendo de lo conocido.

## 🪞 Mírate al espejo
¿Cuál es la emoción que más repites en la semana? ¿Culpa, prisa, preocupación, enojo, frustración?

## ✍️ Ejercicio
1. Escribe esa emoción.
2. Anota qué pensamiento la enciende casi siempre.
3. Anota qué decisión tomas cuando te sientes así.
4. Escribe qué emoción quieres sentir en su lugar.

## ✅ Tu tarea de la semana
Cada vez que notes esa emoción conocida, di por dentro "esto es lo de siempre" y respira tres veces antes de responder.

## 💬 Para compartir en el grupo
¿Cuál es la emoción que más repites y cuál quieres sentir en su lugar?

# Clase 2 · El momento presente
_La puerta de entrada_
Todo lo nuevo pasa en el presente. Pero casi nunca estamos ahí: estamos en lo que ya pasó o preocupadas por lo que viene.

## Donde pones tu atención, pones tu energía
Si tu atención está en el mensaje que no te contestaron, en la deuda o en la plática de ayer, ahí se va tu energía. Por eso terminas el día agotada aunque "no hiciste tanto". Recuperar tu atención es recuperar tu energía.

## Las ondas del cerebro, en simple
- **Alerta (beta):** el modo de todos los días. Pensar, resolver, contestar. Si hay estrés, sube de más y no te deja descansar.
- **Calma (alfa):** cuando te relajas y miras hacia adentro, como cuando sueñas despierta.
- **Muy profundo (theta):** ese momento entre despierta y dormida.

Meditar es aprender a bajar del modo alerta al modo calma, a propósito.

## Salirte de ti misma un rato
La propuesta del libro es esta: para crear algo nuevo, por unos minutos tienes que dejar de ser la de siempre. Dejar de pensar en tu cuerpo, en tus pendientes, en las personas, en el lugar y en la hora. Ser solo atención.

Suena raro, pero lo has sentido: cuando te pierdes en una canción, en un atardecer o en un juego con tus hijas y se te olvida la hora. Eso es estar en el presente.

## Cuando te distraigas, regresa
Te vas a distraer mil veces. No pasa nada. Cada vez que te das cuenta y regresas, estás entrenando, como una repetición en el gym. La meditación no es no pensar; es regresar.

> Cada vez que regresas al presente, le ganas un poquito al piloto automático.

## La práctica: atención al espacio
Siéntate con la espalda derecha y cierra los ojos. Lleva tu atención, sin prisa, a:
1. El espacio detrás de tus ojos.
2. El espacio en el centro de tu cabeza.
3. El espacio alrededor de tu cabeza.
4. El espacio en tu garganta y alrededor de tu cuello.
5. El espacio en tu pecho y alrededor de tu cuerpo.
6. El espacio del cuarto donde estás, y luego más allá.

Quédate unos segundos en cada uno. Sentir el espacio, en vez de pensar en las cosas, calma la mente muy rápido.

## 🪞 Mírate al espejo
¿Dónde se fue tu atención hoy cuando despertaste?

## ✍️ Ejercicio
Haz la práctica de atención al espacio 10 minutos. Después escribe cuántas veces te distrajiste más o menos y cómo te sentiste al terminar.

## ✅ Tu tarea de la semana
Haz la práctica 5 días. Si un día no tienes 10 minutos, haz 3.

## 💬 Para compartir en el grupo
¿Qué te costó más: cerrar los ojos, quedarte quieta o no pensar en pendientes?

# Clase 3 · Sintoniza tu futuro
_Intención clara y emoción elevada_
Para crear algo nuevo necesitas dos cosas al mismo tiempo: saber qué quieres y sentirlo como si ya fuera tuyo.

## La idea del libro
El libro propone que todas las posibilidades ya existen como energía, como estaciones de radio que están en el aire aunque no las escuches. Tú no tienes que fabricarlas. Tienes que **sintonizarlas**: que tu energía, lo que piensas y lo que sientes, coincida con la de ese futuro.

Puedes verlo de forma más práctica: cuando piensas y sientes como la mujer que ya logró algo, tomas decisiones distintas, ves oportunidades que antes no veías y actúas con otra seguridad.

## Pensamiento y emoción tienen que ir juntos
Si piensas "soy abundante" pero sientes miedo, tu cuerpo le cree al miedo. La intención es la dirección; la emoción es la gasolina.

- **Intención clara:** qué quieres, con detalles.
- **Emoción elevada:** cómo te vas a sentir cuando pase. Gratitud, alegría, libertad, amor, confianza.

## La gratitud como atajo
Si no sabes cómo se siente algo que todavía no vives, usa la gratitud. Normalmente agradecemos después de recibir. Si agradeces antes, tu cuerpo empieza a vivirlo como si ya hubiera pasado.

> Agradecer antes de recibir es enseñarle a tu cuerpo cómo se siente ese futuro.

## Tu hoja de intención
1. Piensa en una experiencia que quieras vivir: un hábito, un logro, una relación más sana, más paz en casa.
2. Escríbela en una hoja con una **letra mayúscula** que la represente. Dibuja dos círculos alrededor.
3. Debajo, escribe **al menos cuatro detalles** de cómo se ve. Sin fechas.
4. Escribe **las emociones** que vas a sentir cuando pase.

## La meditación para sintonizar
1. Haz la atención al espacio de la Clase 2 hasta que te sientas en calma.
2. Suelta tu cuerpo, tus pendientes y la hora. Quédate solo como atención.
3. Recuerda tu letra y lo que significa. Siente esas emociones en tu pecho, como si ya fuera real.
4. Ensaya en tu mente un momento de ese futuro, con detalles.
5. Suéltalo. No tienes que controlar cómo ni cuándo.
6. Agradece por tu vida, tu cuerpo, tus retos y tu futuro.
7. Abre los ojos y levántate como la mujer que ya lo vivió.

## Lo que no es
No es pedir un deseo y sentarte a esperar. Tampoco garantiza fechas ni resultados. Es entrenar tu estado para que tus decisiones salgan de la confianza y no del miedo. La acción sigue siendo tuya.

## 🪞 Mírate al espejo
¿Hay algo que quieres pero en el fondo sientes que no te va a pasar?

## ✍️ Ejercicio
Haz tu hoja de intención completa: letra, detalles y emociones. Escríbela también en tu cuaderno.

## ✅ Tu tarea de la semana
Haz la meditación para sintonizar 4 veces esta semana, con tu hoja enfrente antes de cerrar los ojos.

## 💬 Para compartir en el grupo
Comparte solo tus emociones (no tu meta, si no quieres). ¿Qué vas a sentir cuando pase?

# Clase 4 · El recorrido de los centros
_Ocho puntos de atención_
Tu cuerpo tiene zonas donde se juntan nervios y glándulas. Llevar tu atención ahí, con calma y gratitud, es una de las prácticas favoritas del libro.

## Qué son los centros
El libro habla de siete centros de energía a lo largo del cuerpo y un octavo arriba de la cabeza. Cada uno coincide con una zona donde hay muchos nervios y glándulas que trabajan solas, sin que lo pienses: la digestión, el ritmo del corazón, las hormonas.

1. **Base:** el piso pélvico.
2. **Vientre bajo:** abajo del ombligo.
3. **Estómago:** la boca del estómago.
4. **Corazón:** el centro del pecho.
5. **Garganta.**
6. **Centro de la cabeza:** atrás de los ojos.
7. **Coronilla:** arriba de la cabeza.
8. **Arriba de ti:** como a un palmo y medio sobre tu cabeza.

## Por qué funciona la atención
Donde pones tu atención, pones tu energía. Cuando el estrés manda, esa energía se queda atorada en los primeros centros: sobrevivir, controlar, preocuparte. Al recorrer los centros con calma, le das a tu cuerpo otra orden: equilibrio, descanso, gratitud.

## Cómo se hace
1. Siéntate cómoda y cierra los ojos.
2. Lleva tu atención al primer centro. Luego al **espacio alrededor** de ese centro.
3. Cuando lo sientas, bendícelo: deséale lo mejor, por el bien de todos.
4. Siente una emoción elevada ahí: amor, gratitud, alegría.
5. Pasa al siguiente centro y repite.
6. En el octavo, arriba de tu cabeza, quédate en **gratitud**.
7. Siente la energía alrededor de todo tu cuerpo.
8. Acuéstate al menos 15 minutos. Deja que tu cuerpo integre.

> Si quieres sentirte en paz, practica sentir paz. Tu cuerpo aprende lo que repites.

## Si se te hace largo
Empieza con cuatro centros: estómago, corazón, garganta y cabeza. Cuando te salga natural, haz los ocho.

## 🪞 Mírate al espejo
¿En qué parte del cuerpo sientes el estrés? ¿El estómago, el pecho, la garganta?

## ✍️ Ejercicio
Haz el recorrido una vez. Al terminar anota en qué centro sentiste más y en cuál te costó más concentrarte.

## ✅ Tu tarea de la semana
Haz el recorrido tres veces. Una puede ser antes de dormir, acostada.

## 💬 Para compartir en el grupo
¿Cómo dormiste el día que hiciste el recorrido?

# Clase 5 · La respiración que sube la energía
_Saca la mente del cuerpo_
Cuando vivimos años con las mismas emociones, el cuerpo se vuelve la mente: reacciona antes de que pienses. Esta respiración ayuda a sacar esa energía de abajo y llevarla hacia arriba.

## Para qué sirve
Según el libro, la energía de la supervivencia (miedo, culpa, enojo, deseo de controlar) se queda en la parte baja del cuerpo. Esta respiración la sube hacia el corazón y la cabeza, donde la puedes usar para crear y no solo para aguantar.

Aunque no te convenza esa explicación, la vas a sentir: activa, despeja y te deja lista para meditar.

## Primero, aprende los músculos
1. Siéntate derecha, pies en el piso, manos en las piernas.
2. Aprieta el piso pélvico (los mismos músculos de cuando aguantas ir al baño). Cinco segundos y suelta. Tres veces. **Sigue respirando normal.**
3. Ahora aprieta el piso pélvico y el vientre bajo, hacia arriba y hacia adentro. Cinco segundos. Tres veces.
4. Ahora suma el abdomen alto: todo el centro del cuerpo firme. Cinco segundos. Tres veces.

## Luego, el camino del aire
1. Toca con un dedo la coronilla para saber dónde está. Quita el dedo.
2. Inhala lento por la nariz y sigue el aire con tu atención: piso pélvico, vientre, estómago, pecho, garganta, cabeza, coronilla.
3. Arriba, sostén unos segundos con tu atención ahí. Suelta.

## Todo junto
Inhala lento por la nariz mientras aprietas los tres grupos de músculos de abajo hacia arriba. Sube el aire por el centro del cuerpo hasta la coronilla. Sostén unos segundos apretando. Exhala y suelta todo. Repite dos o tres veces.

> No es aguantar hasta ponerte morada. Es una respiración lenta, larga y con intención.

## La práctica completa
1. Pon una canción que te inspire, de 4 a 7 minutos.
2. Haz la respiración varias veces durante la canción.
3. Después haz la atención al espacio (Clase 2).
4. Siente, una por una, varias emociones elevadas: gratitud, alegría, amor, libertad.
5. Agradece por una vida nueva antes de verla.

## Con cuidado
Si estás embarazada, tienes presión alta, te mareas o tienes algún tema de salud, hazla muy suave, sin retener el aire, o salta solo a la parte de las emociones.

## 🪞 Mírate al espejo
¿Qué emoción sientes que llevas "guardada" en el cuerpo desde hace tiempo?

## ✍️ Ejercicio
Practica solo la parte de los músculos y el camino del aire, cinco minutos. Anota qué tan fácil o difícil fue coordinarlo.

## ✅ Tu tarea de la semana
Haz la práctica completa con tu canción tres veces. Escribe qué canción elegiste.

## 💬 Para compartir en el grupo
Comparte tu canción para respirar. Hagamos una lista del equipo.

# Clase 6 · El corazón coherente
_Cuando la mente y el corazón dicen lo mismo_
El cerebro piensa; el corazón sabe. Cuando aprendes a sostener una emoción elevada en el pecho, tu cuerpo entra en orden.

## Qué es la coherencia
El ritmo del corazón no es como un reloj: cambia todo el tiempo. Con estrés, ese ritmo se vuelve desordenado. Con emociones como gratitud, cariño o paz, se ordena y forma una ola pareja. A eso se le llama **coherencia**, y le da nombre a este curso.

Cuando tu corazón está en coherencia, tu cerebro también se ordena: piensas más claro, reaccionas menos y decides mejor.

## Sostener, no solo sentir
Sentir gratitud un segundo es fácil. Lo que se entrena es **sostenerla**: quedarte en esa emoción aunque afuera haya ruido. Cuando lo logras, lo de afuera ya no te mueve tanto. Eso es dominar tu entorno en vez de que tu entorno te domine a ti.

> Cuando tu calma no depende de lo que pasa afuera, ya no eres reactiva: eres dueña de tu energía.

## Del egoísmo a la generosidad
Desde el miedo pensamos en nosotras. Desde el corazón abierto, pensamos en los demás. Por eso esta práctica cambia cómo hablas con tu familia, con tus clientas y con tu equipo.

## La práctica del corazón
1. Cierra los ojos, relaja el cuerpo y lleva tu atención al centro del pecho.
2. Respira como si el aire entrara y saliera por tu corazón. Cada vez más lento y profundo.
3. Cuando tu mente se vaya, regresa al pecho, al corazón y a la respiración.
4. Despierta una emoción elevada: piensa en algo o alguien que te dé ternura o gratitud.
5. Cuando la sientas en el pecho, mándala más allá de tu cuerpo, con tu intención.
6. Empieza con 10 minutos y ve subiendo.

## Con los ojos abiertos
Pon cuatro alarmas en el celular. Cuando suene una, deja lo que haces por un minuto, lleva la atención al pecho y siente gratitud. Eso es meditar sin cerrar los ojos.

## 🪞 Mírate al espejo
¿Quién o qué te saca de tu centro más rápido?

## ✍️ Ejercicio
Haz la práctica del corazón 10 minutos. Escribe la emoción que elegiste y en qué pensaste para despertarla.

## ✅ Tu tarea de la semana
Pon tus cuatro alarmas de gratitud y respétalas cinco días.

## 💬 Para compartir en el grupo
¿Qué alarma te costó más respetar y qué estabas haciendo cuando sonó?

# Clase 7 · Tu película del futuro
_Programa tu mente con imágenes_
Tu mente aprende de lo que ve y escucha muchas veces. Así que hazle una película de un minuto de tu futuro y mírala todos los días.

## Por qué funciona
Cuando estás muy relajada, en ese estado entre despierta y dormida, tu mente analiza menos y acepta más. Por eso los niños aprenden tanto antes de dormir. Si en ese momento ves imágenes de tu futuro con una canción que te mueve, tu cerebro lo va guardando como algo conocido.

En los talleres del libro, primero miran un video de caleidoscopio para entrar en ese estado y luego ven su película. Tú puedes hacer algo parecido con un video de caleidoscopio de YouTube y tu película.

## Cómo hacer tu película
1. **Elige un área:** salud, familia, pareja, negocio, tu casa, un viaje.
2. **Busca de 10 a 15 imágenes** que muestren ese futuro. Mejor si sales tú: una foto tuya sonriente al lado de lo que quieres.
3. **Escribe una frase corta en presente** para cada imagen: "Estoy en paz con mi cuerpo", "Mi casa está llena de risas", "Mi equipo crece conmigo".
4. **Elige una canción** que te emocione, de 3 a 4 minutos, y úsala solo para esto.
5. **Arma el video** en tu celular con CapCut, Canva o la app de fotos. Unos 3 o 4 segundos por imagen.

## Cómo mirarla
- En la mañana al despertar y en la noche antes de dormir.
- Primero unos minutos de la práctica del corazón (Clase 6), luego tu película.
- Siéntela, no solo la veas. Ponle la emoción de que ya pasó.

> Cuando ya sabes qué imagen sigue sin verla, tu cerebro ya la aprendió.

## Una sola canción
Con el tiempo, escuchar la canción va a traer las imágenes solas. Úsala en el coche o mientras cocinas para "ver" tu película con los ojos abiertos.

## Lleva un diario
Anota las coincidencias, las oportunidades y los cambios pequeños que vayas notando. Cuando mires atrás vas a ver el camino que te llevó ahí.

## Ojo
Tu película no es una lista de cosas para comprar. Pon cómo te quieres sentir y en quién te quieres convertir. Y no te compares con la película de nadie.

## 🪞 Mírate al espejo
Si tu vida fuera una película, ¿qué escena quieres vivir este año?

## ✍️ Ejercicio
Escribe en tu cuaderno las frases de tu película, una por imagen, todas en presente.

## ✅ Tu tarea de la semana
Arma tu película y mírala mañana y noche cinco días.

## 💬 Para compartir en el grupo
Comparte qué canción elegiste y una de tus frases.

# Clase 8 · Camina como tu yo del futuro
_Meditar con los ojos abiertos_
Puedes tener una meditación hermosa, abrir los ojos y regresar al mismo enojo de siempre en cinco minutos. Esta clase es para llevarte la meditación a la vida.

## El reto de abrir los ojos
Con los ojos cerrados es fácil sentirte en paz. Lo difícil es sostener esa energía cuando suena el teléfono, llora una niña o una clienta te deja en visto. La meditación caminando entrena justo eso: sentir tu futuro mientras te mueves.

## La práctica caminando
1. Busca un lugar tranquilo, mejor si es al aire libre: un parque, tu patio, una calle tranquila.
2. Cierra los ojos de pie. Lleva la atención al corazón y respira por ahí unos dos minutos.
3. Despierta emociones elevadas y mándalas alrededor de tu cuerpo.
4. Recuerda tu intención o tu letra (Clase 3) por dos o tres minutos.
5. Abre los ojos sin fijarte en nada. Mantén tu atención en el espacio alrededor de ti.
6. Camina como tu yo del futuro unos diez minutos. Cada paso, siente que ya lo eres.
7. Detente, cierra los ojos y vuelve a subir tu energía unos minutos.
8. Camina otros diez minutos.
9. Al final, quédate quieta, mano en el corazón, y di lo que sientes: "Soy libre", "Soy suficiente", "Estoy en paz".

## Pregúntate todo el día
La versión corta es una pregunta: **¿cómo lo haría la mujer que ya logró lo que quiero?** ¿Cómo contestaría este mensaje? ¿Cómo hablaría con su hija ahorita? ¿Cómo se sentaría? ¿Qué haría con esta hora libre?

> Con el tiempo empiezas a pensar, actuar y sentir como ella, porque ya instalaste esos caminos en tu cerebro.

## Ojos abiertos todo el día
Si te descubres reaccionando como antes, no te regañes. Respira, regresa al corazón y vuelve a elegir. Esa elección repetida es el cambio.

## 🪞 Mírate al espejo
¿En qué momento del día es más difícil ser tu yo del futuro?

## ✍️ Ejercicio
Describe a tu yo del futuro en cinco líneas: cómo se levanta, cómo habla, cómo trabaja, cómo descansa y cómo se siente.

## ✅ Tu tarea de la semana
Haz la meditación caminando una vez y, el resto de los días, hazte la pregunta "¿cómo lo haría ella?" tres veces al día.

## 💬 Para compartir en el grupo
Cuéntanos una decisión que tomaste esta semana como tu yo del futuro.

# Clase 9 · Más allá del tiempo
_Lo místico, con los pies en la tierra_
Esta es la parte más profunda del libro. Habla de experiencias muy intensas en meditación, de una pequeña glándula en el centro del cerebro y de salir de la idea normal del tiempo. Tómala con curiosidad.

## Espacio-tiempo y tiempo-espacio
En la vida diaria vivimos en el espacio y el tiempo pasa: vamos de un lugar a otro y miramos el reloj. El libro propone que en meditación muy profunda pasa lo contrario: sientes que el tiempo se detiene y tu atención se abre a algo mucho más grande.

Quizás ya lo viviste: una meditación donde sentiste que pasaron cinco minutos y fue media hora. O un momento de conexión tan fuerte que no tenías palabras.

## Conectarte con todo
El libro describe la práctica en dos pasos. Primero, dejar de ser alguien: sin cuerpo, sin nombre, sin pendientes. Luego, sentirte conectada con todo y con todos. Mucha gente describe esa sensación como unidad, paz o amor muy grande.

## La glándula pineal
Es una glándula pequeñita en el centro del cerebro que tiene que ver con el sueño (produce melatonina). El libro la ve como una antena para experiencias internas muy vívidas, como sueños con los ojos abiertos. Es una idea del autor; la ciencia todavía estudia mucho de lo que propone.

## La práctica, versión sencilla
1. Respira por el corazón y siente una emoción elevada.
2. Haz la respiración de la Clase 5 con una canción.
3. Pon música sin letra, de 10 a 15 minutos.
4. Suelta tu cuerpo, tu nombre y la hora. Solo atención.
5. Luego siente que estás conectada con todas las personas y todas las cosas.
6. Quédate ahí sin esperar nada. Cuando termines, regresa despacio.

> No persigas la experiencia. Practica, suelta y deja que llegue cuando llegue.

## Pies en la tierra
- No necesitas despertarte de madrugada. Duerme: tu descanso también es práctica.
- No hay experiencia "correcta". Si solo sentiste calma, eso ya vale.
- Si en meditación salen recuerdos o emociones muy fuertes, para, abre los ojos y busca apoyo con alguien de confianza o con un profesional.

## 🪞 Mírate al espejo
¿Alguna vez sentiste que el tiempo se detenía? ¿Qué estabas haciendo?

## ✍️ Ejercicio
Haz la práctica sencilla una vez y escribe lo que sentiste, sin juzgarlo, aunque sea "nada".

## ✅ Tu tarea de la semana
Pon una libreta junto a tu cama y anota tus sueños o ideas al despertar tres días.

## 💬 Para compartir en el grupo
¿Has vivido algún momento que no puedas explicar con palabras? Solo si te nace compartir.

# Clase 10 · Meditar juntas
_Coherencia en equipo_
Una mujer en calma cambia su casa. Un grupo de mujeres en calma cambia su entorno. Esta clase es para practicar en equipo.

## La fuerza del grupo
En los talleres del libro midieron a muchas personas meditando al mismo tiempo, y su corazón entraba en coherencia a la vez, como si se contagiaran. También hay estudios sobre grupos grandes que meditan con intención de paz. El libro concluye que nuestra energía influye en las demás aunque no estemos juntas físicamente.

Más allá de lo que digan los estudios, ya sabes cómo funciona: cuando una del equipo llega con buena energía, se nota. Y cuando alguien llega con drama, también.

## Una intención para las demás
La práctica en grupo no es para pedir para ti. Es para desearle lo mejor a otras: que sus metas se cumplan, que sus casas estén en paz, que su salud esté bien. Cuando abres el corazón por otra persona, el tuyo también se ordena.

## La práctica en equipo
1. Pónganse de acuerdo en un día y una hora, cada quien desde su casa o en llamada.
2. Respiren por el corazón y despierten una emoción elevada.
3. Sientan el espacio que ocupa su corazón y el espacio alrededor.
4. Imaginen al equipo completo, una por una, y mándenle esa energía.
5. Después imaginen su ciudad, su país y el planeta entero dentro del corazón.
6. Terminen agradeciendo.

> Lo que deseas con el corazón abierto para otras, también lo practicas para ti.

## Sostener la práctica
Ya terminaste las clases, pero la práctica sigue. Lo que cambia la vida no es haber leído esto: es hacerlo diario. Usa **Tu plan de 30 días** para que no se quede aquí.

## 🪞 Mírate al espejo
¿Qué energía le llevas al grupo cuando tienes un mal día?

## ✍️ Ejercicio
Escribe el nombre de tres compañeras del equipo y lo que les deseas con todo el corazón.

## ✅ Tu tarea de la semana
Propón en el grupo una meditación juntas de 15 minutos y hazla.

## 💬 Para compartir en el grupo
Manda a una compañera lo que le deseaste en el ejercicio.

# Herramienta · Tu hoja de intención
_Para tenerla enfrente al meditar_
Llénala una vez, léela antes de cada meditación y cámbiala cuando tu vida cambie.

## 1. Tu letra
Una letra mayúscula que represente lo que quieres vivir. Dibújala en grande con dos círculos alrededor.

## 2. Lo que significa
Al menos cuatro detalles de cómo se ve. Sin fechas.
- Ejemplo: "Tengo una rutina de mañana en paz."
- "Hablo con mis hijas con paciencia."
- "Tengo un negocio que me deja tiempo libre."
- "Duermo tranquila."

## 3. Cómo se siente
Las emociones que vas a sentir cuando pase. Elige las tuyas:
- Gratitud
- Libertad
- Alegría
- Paz
- Confianza
- Amor por la vida
- Sentirte suficiente

## 4. Tu frase
Una frase en presente que resuma todo: "Vivo en paz y con tiempo para lo que amo."

## 5. Cómo la usas
1. Léela con calma antes de cerrar los ojos.
2. Medita con la práctica de la Clase 3.
3. Al abrir los ojos, haz una acción pequeña que haría tu yo del futuro.

> Escribirlo a mano lo vuelve real. Ponla donde la veas.

# Herramienta · Guía rápida de prácticas
_Las meditaciones en una sola vista_
Todas las prácticas del curso, con su tiempo y para qué sirven. Elige según el día que tengas.

## 1 minuto
- **Alarma de gratitud** (Clase 6): atención al pecho y gratitud. Para cortar el estrés.
- **"¿Cómo lo haría ella?"** (Clase 8): una pregunta antes de responder.

## 10 minutos
- **Atención al espacio** (Clase 2): para bajar revoluciones y volver al presente.
- **Corazón coherente** (Clase 6): para calmarte y sostener una emoción.
- **Tu película del futuro** (Clase 7): mañana y noche.

## 20 a 30 minutos
- **Sintonizar tu futuro** (Clase 3): con tu hoja de intención.
- **Recorrido de los centros** (Clase 4): ideal antes de dormir.
- **Respiración con canción** (Clase 5): cuando te sientes sin energía.
- **Caminando** (Clase 8): para llevarte la práctica al día.

## Más largas, cuando tengas tiempo
- **Más allá del tiempo** (Clase 9).
- **Meditar juntas** (Clase 10): con el equipo, una vez a la semana o al mes.

## Para que te salga mejor
- Mismo lugar y misma hora.
- Música sin letra, lenta, que no te traiga recuerdos.
- Celular en modo avión.
- Si te distraes, regresa. Eso es la práctica.

# Herramienta · Tu plan de 30 días
_Para que la práctica se quede_
Cuatro semanas para pasar de leer a vivirlo. Marca cada día en tu cuaderno.

## Semana 1: volver al presente
- Diario: atención al espacio, 10 minutos.
- Detecta tu emoción de siempre y respira antes de reaccionar.
- Llena tu hoja de intención.

## Semana 2: sentir antes de ver
- Diario: sintonizar tu futuro, 15 a 20 minutos.
- Dos veces: recorrido de los centros antes de dormir.
- Cuatro alarmas de gratitud al día.

## Semana 3: tu película
- Arma tu película del futuro.
- Mírala mañana y noche.
- Dos veces: respiración con canción.

## Semana 4: llévalo a la vida
- Una meditación caminando.
- Pregúntate "¿cómo lo haría ella?" tres veces al día.
- Una meditación en equipo.

## Al terminar
Responde en tu cuaderno:
1. ¿Qué cambió en cómo reacciono?
2. ¿Qué coincidencias o cambios noté?
3. ¿Qué práctica me quedo para siempre?

> No tienes que hacerlo todo. Elige una práctica y no la sueltes.
