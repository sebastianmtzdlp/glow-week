# Tu era Creator: contenido del curso

Formato: cada clase empieza con `@@ número | etiqueta | título | tema`.

@@ 0 | Empieza aquí | Bienvenida a la nueva era | El curso en 5 minutos
Este curso te lleva de cero a vender en TikTok Shop como creadora. Aquí está el mapa completo antes de entrar a cada clase.

## Cómo funciona este negocio
En TikTok Shop hay dos papeles. El **seller** es la marca o tienda: tiene el inventario, pone precios y manda los paquetes. La **creadora** (también llamada afiliada) eres tú: haces videos o lives de productos que ya están en TikTok Shop, y cada vez que alguien compra desde tu video, ganas una comisión. No compras inventario, no haces envíos y no atiendes devoluciones. Tu trabajo es uno solo: hacer contenido que venda.

## Por qué funciona tan bien
La gente entra a TikTok a entretenerse, no a comprar. Cuando le aparece tu video, puede comprar sin salir de la app, incluso mientras sigue escuchándote. A esto se le llama **compra por descubrimiento**: la persona no sabía que quería algo hasta que lo vio. Además, el algoritmo se encarga de encontrar a quién le interesa cada producto, así que no tienes que buscar clientes ni tener un "nicho".

## El camino, paso a paso
1. **Llegar a 2,000 seguidores** (5,000 si estás en Estados Unidos) con videos cortos y sencillos. Es solo un requisito para desbloquear TikTok Shop.
2. **Activar tu cuenta de creadora** y aprender a moverte en TikTok Studio.
3. **Elegir productos con datos**, no solo por gusto.
4. **Hacer los tres tipos de video del embudo**: los que presentan el producto, los que resuelven dudas y los que cierran la venta con la oferta.
5. **Dominar el hook**: los primeros 2 segundos deciden si alguien se queda.
6. **Grabar con calidad** sin obsesionarte con la perfección.
7. **Ser constante**, subir la cantidad poco a poco y, si te late, hacer lives.
8. **Cuidar tu cuenta** de infracciones y aprovechar los retos que dan dinero extra.

> La habilidad más importante de todo el curso no es técnica: es la tolerancia a la frustración. Lo que TikTok castiga es la intermitencia; lo que premia es la constancia.

@@ 1 | Clase 1 | El despertar Creator | Qué es TikTok Shop y cómo llegar a 2,000 seguidores
En esta clase entiendes el modelo de negocio y arrancas con la primera meta: los 2,000 seguidores.

## Desaprender lo de Instagram
Si vienes de hacer marca personal en Instagram o Facebook, te enseñaron cosas como "no vendas todo el tiempo", "da contenido de valor", "ten un nicho" o "cuida que tu feed se vea bonito". Eso sigue funcionando allá, pero **en TikTok Shop no aplica**. Aquí no necesitas escoger un cliente ideal ni un tema: puedes vender una licuadora hoy y unos leggings mañana, porque cada video tiene su propio algoritmo que lo lleva a quien le interesa ese producto. Y nunca "vendes demasiado": vender es justo el objetivo de la plataforma.

Una ventaja enorme: en TikTok no te ven tu mamá, tus primas ni los amigos de tu esposo, sino gente que no te conoce. Eso quita mucha pena. Graba como si fueran pruebas.

## Seller vs. creadora
- **Seller:** dueño del producto y del stock. Pone precios, maneja inventario, envíos, devoluciones y servicio al cliente. Gana el margen y decide cuánta comisión paga a las creadoras.
- **Creadora (afiliada):** tú. Encuentras un producto que ya está en TikTok Shop, lo consigues (puede ser uno que ya tengas, uno comprado en otra tienda o, idealmente, comprado en TikTok Shop a otra creadora), haces el video y ganas comisión por cada venta.

> Cuidado: a veces aparece un letrero de "TikTok Shop te eligió para abrir tu tienda" o "90 días sin comisiones". **No lo aceptes.** Es para sellers, y regresar a creadora después es complicado (hay que escribir a soporte o abrir otra cuenta).

## Cuánto se gana
La comisión la pone el seller, casi siempre entre 5% y 12% (lo más común es alrededor de 8%). Ejemplo: una pluma de $400 con 10% te deja $40 por venta. Si ese video vende 50 plumas en un día, ganaste $2,000.

Lo mejor es que un video se queda "vivo". Puede vender el mismo día, o empezar a vender meses después. A Lore un video de tópers de cristal que no vendió nada en enero le vendió 388 unidades cuatro meses después, y tiene un video de leggings que vende todos los días desde hace un año. Eso convierte tus videos en un **ingreso residual**.

## Requisitos para ser creadora
- México: 2,000 seguidores, ser mayor de edad y haber subido al menos un video en los últimos 180 días.
- Estados Unidos: 5,000 seguidores.
- Algunas cuentas entran antes en **prueba piloto** (desde ~1,000 seguidores), pero con límites: menos productos disponibles, un tope de videos al día y menos alcance. La meta sigue siendo llegar a los 2,000.
- Solo puedes vender en el país donde estás físicamente.

## La estrategia para crecer: videos cortos (b-rolls)
Para llegar a los seguidores no se hacen videos de venta, sino videos cortitos pensados para viralizar:
1. **Graba momentos de 6 a 10 segundos** de lo que sea: tomando café, caminando, la carretera desde el coche, escribiendo en tu libreta. Entre más bonita la luz, mejor, pero no te compliques.
2. **Ponle música en tendencia.** Toca el circulito del audio de un video que te guste y elige "usar audio".
3. **Agrega una frase** que genere identificación, curiosidad o conversación, con la letra "Classic" blanca con fondo negro, más o menos al centro.
4. **Sube mínimo 3 al día.** Es un juego de números: entre más subas, más rápido uno se viraliza.

Se vale copiar tal cual las frases y la música de otras cuentas; en TikTok copiar ayuda, porque así funcionan las tendencias. Y no importa quién te siga: los videos de venta no se muestran a tus seguidores, sino a las personas interesadas en ese producto. Los 2,000 son solo un requisito.

> Ojo con cuentas falsas que se hacen pasar por Lore y ofrecen cripto o grupos de Telegram. Bloquéalas.

@@ 2 | Clase 2 | Tu oficina Creator | Activar tu cuenta y moverte en TikTok Studio
Aquí aprendes a activar tu cuenta y a moverte en el panel donde vive todo lo de TikTok Shop.

## Si todavía no llegas a los 2,000
- Sube de 3 a 5 o hasta 10 videos cortos al día. Revisa que los estés haciendo bien: 6 a 8 segundos, música en tendencia y una frase con letra normal (no texto de reflexiones hablado).
- Se vale **pagar $200 a $400** para promocionar el video que más vistas tiene; suele dar un buen empujón.
- Hay lives y videos de "te sigo y me sigues": entrar 15 o 20 minutos ayuda, pero no te quedes ahí todo el día.
- Cada cuenta avanza a su ritmo. Una alumna no vendió nada su primer mes y hoy gana $25,000 a la semana en comisiones. La diferencia fue no soltarlo.

> TikTok solo castiga una cosa: la **intermitencia**. Tres días subes, luego dos no, luego una semana nada... eso sí baja tus vistas. Si eres constante, te premia.

## Dónde está todo
Todo lo de TikTok Shop está en una sola ruta: **Perfil → TikTok Studio → TikTok Shop para creadores**. A veces aparece como un botón grande y a veces más abajo, en los cuadritos. Lo que está fuera de esa sección (programas de incentivos, misión de marca, regalos en lives) es TikTok normal y no te sirve para Shop.

## Activar tu cuenta
1. Entra a TikTok Shop para creadores, revisa las palomitas de requisitos y pica **Aplicar**.
2. Si sale "en revisión" o "rechazada", no pasa nada: vuelve a intentar en 2 o 3 días. Suele pasar cuando la cuenta creció muy rápido.
3. **Verifica tu identidad con calma**: CURP, nombre y fecha de nacimiento exactamente como en tu identificación; dirección donde te lleguen paquetes; cuenta bancaria y constancia de situación fiscal. Si algo no coincide, se atora todo.
4. Cuando te pregunte si las marcas pueden poner anuncios a tus videos, di que sí: te ayuda a vender más.

> Si arriba te aparece la palabra "Tienda", te diste de alta como seller por error. Escribe a soporte.

## Qué hay dentro de tu oficina
- **Estado de la cuenta:** tus puntos e infracciones.
- **Nivel:** del 1 al 6, según lo que vendes en el mes.
- **Retos y desafíos:** bonos por subir videos de ciertos productos.
- **Mercado de productos:** donde buscas y analizas productos con tus datos de creadora.
- **Administrar vitrina:** los productos que puedes vender.
- **Ganancias:** lo que te van a depositar.
- **Gestionar muestras:** las muestras gratis que pediste y lo que te falta grabar.

## Cómo y cuándo te pagan
TikTok deposita **los miércoles de madrugada**, pero no lo que vendiste esa semana: te paga **15 días después de que el producto llegó a casa del cliente**, porque el cliente puede devolverlo. Por eso las primeras ganancias tardan unas semanas en caer.

Dos números que vas a ver mucho:
- **GMV:** tus ventas totales. Es lo que cuenta para subir de nivel.
- **Comisión estimada:** lo que realmente te toca.

Un producto barato con comisión de $5 puede ser buen negocio si se vende mucho: a Lore unos plumones le vendían 500 en un día.

## Vitrina, carrito y muestras
- **Carrito** es para cuando tú compras algo. **Vitrina** es lo que tú vendes. Puedes tener cientos de productos en tu vitrina aunque no les hayas hecho video; a veces se venden solos porque TikTok se los ofrece a quien entra a tu perfil.
- **Muestra gratis:** la marca te regala el producto a cambio de un video. Al principio casi no las aprueban, porque ven que todavía no tienes ventas. Por eso conviene comprar tus primeros 3 a 5 productos.
- **Muestra reembolsable:** la pagas y te regresan el dinero cuando llegas a cierto número de ventas.

**Tarea:** explora el mercado de productos, agrega al menos 20 a tu vitrina y pide algunas muestras.

@@ 3 | Clase 3 | El arte del Winning Product | Cómo elegir productos ganadores
A partir de aquí TikTok Shop deja de ser teoría. Aprendes a escoger productos con criterio de negocio y a subir tu primer video con carrito.

Nunca sabes cuál va a ser tu producto ganador: a Lore le pegaron unas toallitas húmedas que aceptó casi por compromiso. Por eso conviene tener un poco de todo. Pero antes de invertir, revisa estos seis puntos.

## Los 6 filtros
1. **Demanda.** Abajo del nombre dice cuántos se han vendido. En TikTok, al revés de lo que pensarías, lo que más se vende es lo que más se va a seguir vendiendo: la gente ya lo vio muchas veces y la marca probablemente le está metiendo publicidad.
2. **Precio.** Combina productos caros (con pocas ventas suben mucho tu GMV y tu nivel) con productos baratos (se venden en volumen).
3. **Comisión.** En la ficha del producto hay una pestañita con dos flechitas; al deslizarla ves tu información de creadora. Fíjate en **cuántos pesos ganas**, no solo en el porcentaje. Unas botas con 8.5% pueden dejarte $245 por venta.
4. **Prueba social.** Buenos reviews (puedes mostrarlos en tu video) y la sección "Inspo de creadores", donde ves videos que ya vendieron ese producto.
5. **Ideas de video.** Si no se te ocurre nada que decir del producto, no lo pidas.
6. **Seller y stock.** Que sea **tienda oficial** o "tienda estrella" y tenga más de 100 unidades. Si un video se viraliza y el producto se agota, te quitan el carrito y se acaba la venta.

> Ejemplo bueno: un rizador en campaña, con 54% de descuento, 2,448 vendidos y tienda oficial. Ejemplo malo: una crema de un seller que no es la marca oficial, con 35 piezas en stock y 5 vendidas.

## Dónde encontrar productos
- **Mercado de productos → ordenar por "más vendido"**, o entra a la campaña del momento (por ejemplo, la venta quincenal): ahí las marcas traen descuentos y publicidad.
- **Lupa del "Para ti" → escribe lo que buscas → pestaña "Tienda".**
- Si el mismo producto lo venden varios sellers, puedes tener ambos en tu vitrina y, al subir el video, elegir el que pague más comisión o traiga descuento.

## Estilos de video
- **Faceless:** solo se ve el producto, con mucho movimiento.
- **Voice over:** grabas modelando o mostrando y después le pones tu voz. Es muy fácil al principio porque puedes leer tu guion.
- **Sketch:** una mini actuación, como una pareja platicando del producto.
- **A cámara:** hablas a la cámara con el producto en la mano. Es el que más usa Lore.

## Cómo subir un video con carrito
1. Ve a tu vitrina, entra al producto, desliza la flechita y pica **Crear → Cámara**. Así el producto ya queda ligado.
2. Si grabaste con la cámara normal, antes de publicar toca **Agregar enlace** y elige el producto.
3. **Antes de publicar, revisa que aparezca la canastita amarilla.** Un video de shop sin carrito es infracción.

## Reglas que conviene saber desde ya
- Tienes que tener el producto físicamente. Nada de fotos fijas como video de venta.
- Los menores de edad no pueden vender ni salir vendiendo. Unas manitas armando un juguete sí se valen.
- No digas el precio ni el porcentaje exacto: cambian de un día a otro y te pueden reportar. Mejor "menos de $200" o "trae descuentazo".
- No subas el mismo archivo dos veces; sí puedes reusar una toma con otro inicio y otro cierre.
- No hacen falta hashtags ni descripción, salvo en desafíos o si la marca lo pide.
- Si una muestra llega rota o de mala calidad, avísale al vendedor y no le hagas video.

@@ 4 | Clase 4 | El Funnel que vende | Los videos TOFU, MOFU y BOFU
Esta es la base de todo el marketing aplicada a TikTok, y la razón por la que unas creadoras venden mucho y otras casi nada.

En TikTok Shop no gana el video más bonito, ni el más educativo, ni el más viral. **Gana el que vende.** Lore ha tenido videos de 200 vistas que venden muchísimo. Para lograrlo, piensa tus videos como un embudo de ventas con tres niveles.

## TOFU: videos de descubrimiento
**Top of funnel.** Imagina que quien te ve nunca ha visto el producto. Aquí lo presentas completo: qué es, para qué sirve, cómo se usa y qué resultado da.
- **Ejemplos:** problema y solución, antes y después, demostración, mini tutorial.
- **Duración:** hasta un minuto.
- **Fórmula:** hook → problema → producto → resultado → carrito naranja.

Son los que todo el mundo hace, pero **no son los que más venden**, porque la persona apenas está conociendo el producto. Úsalos sobre todo con productos que todavía no están posicionados.

## MOFU: videos que resuelven dudas
**Middle of funnel.** Le hablas a alguien que ya vio el producto, le llamó la atención, pero tiene una duda que la detiene: "¿será original?", "¿estará chafa por barato?", "¿sabrá feo?", "¿cómo se usa?".
- **La clave:** hablas de **una sola objeción**. No vuelvas a explicar todo el producto.
- **Ejemplos:** review honesto, "así lo uso yo", "pensé que iba a estar chafa y mira", "cómo saber que es original".
- **Duración:** 30 a 40 segundos.
- **Fórmula:** hook → historia personal u objeción → prueba → carrito naranja.

Si todavía nadie te hace preguntas, invéntalas: piensa qué te habrías preguntado tú antes de comprarlo.

> Comparaciones sí, pero sin nombrar la marca cara. "Idénticos a los Lululemon" es infracción; "igualitos a los carísimos que siempre compraba" no.

## BOFU: videos que cierran la venta
**Bottom of funnel.** Le hablas a alguien que ya vio el producto mil veces y solo necesita el empujón. Aquí **solo hablas de la oferta**: el descuento, el precio bajo, la urgencia. Nada de ingredientes ni beneficios.
- **Ejemplos:** "le volvieron a bajar el precio", "está en oferta relámpago solo unas horas".
- **Duración:** 15 a 30 segundos.
- **Fórmula:** hook con la oferta → carrito → urgencia → carrito otra vez.
- **Solo con una oferta real.** Inventar un descuento enoja a la gente y te pueden infraccionar.

Lo bonito es que **el algoritmo hace el retargeting solo**: tus BOFU se los muestra a quienes ya vieron muchos videos del producto, aunque sean de otras creadoras. Tú cierras la venta que otras sembraron. Por eso hay críticas a este tipo de videos, pero funcionan.

## Cómo combinarlos
- Con un producto nuevo, haz **mínimo 3 videos: uno de cada tipo**, grabados en el mismo bloque.
- Si el producto ya es viral y trae descuento, puedes ir directo a BOFU.
- De cada BOFU haz unos 5: es más probable que uno pegue que apostarle a uno solo.
- Los **suplementos** casi siempre se venden con BOFU, porque no puedes hablar de enfermedades ni síntomas.
- Da igual si subes los videos juntos o repartidos en el día. Lore suele grabar 4 productos con 5 videos cada uno.
- Cuando un producto ya vende, **repítelo a diario**. Es mejor que estar probando productos nuevos sin parar.

## Siempre, siempre: el carrito naranja
No asumas que la gente sabe que puede comprar ahí mismo. Muchísimas personas todavía no lo saben. Explícalo: "arriba de mi nombre, donde dice Tienda, hay un carrito naranja; pícale y ahí mismo lo compras y te llega a tu casa". Y si hay descuento, cupones o envío gratis, dilo en ese momento.

@@ 5 | Clase 5 | El poder del Hook | Del scroll a la venta
Saber qué tipo de video hacer no basta: necesitas que la gente se quede a verlo. Esta clase es sobre los primeros segundos.

Todo video de venta pasa por cuatro pasos: **hook** (atrapar), **retención** (que se quede), **convicción** (que lo quiera) y **acción** (que compre). Antes de vender el producto, tienes que vender el video.

## La regla de oro
En TikTok la gente decide en unos **2 segundos** si se queda o sigue scrolleando. Por eso **nunca dejes silencio al inicio**. Cuando grabas es natural picar el botón y tardarte en hablar; antes de publicar, recorta ese pedazo hasta que el video empiece casi cortando tu primera palabra.

## Los tres tipos de hook
- **Visual:** lo que se ve. Mover mucho el producto, abrir una caja, grabar en el coche, traer lentes o gorra, acercarte y alejarte de la cámara, o poner una foto o video de alguien famoso que usa el producto (en México se puede; en Estados Unidos no).
- **Hablado:** tu primera frase.
- **Texto en pantalla:** la frase escrita de los primeros segundos.

Procura que cada video tenga **al menos dos de los tres**, y que cuenten la misma historia.

## Hooks que detienen el scroll
- **Problema:** "Si tu brasier se ve así, compra esto."
- **Resultado o teaser:** pones al inicio el momento más impactante, como el antes y después.
- **Curiosidad:** "No vayas a comprar esto…", "Te cuento lo que me pasó…".
- **Demostración:** abrir el paquete, ponerte la prenda en ese momento.
- **Identificación:** "Si tú, como yo, batallas con…"
- **Advertencia:** "Te vas a enojar si acabas de comprar esto…"

Listas de hooks hay miles (ChatGPT te da todas las que quieras). El chiste es cómo los combinas con lo visual.

## La estructura de un video que vende
1. **Hook** sin silencio antes.
2. **Un solo problema, dolor o deseo.** Es mejor grabar 5 videos con 5 problemas distintos que meter todo en uno.
3. **Solución y prueba:** muéstralo de cerca, la textura, los reviews.
4. **Llamado a la acción.** Manda al carrito **dos veces**: una en el primer cuarto o a la mitad del video, y otra al final, porque mucha gente no lo ve completo.

## Ejemplos que vendieron muchísimo
- **Bloqueador con color, $179,000 en ventas en un mes.** Hook visual moviendo mucho el producto, más una influencer famosa que lo usa. El dolor no fue "te vas a manchar", sino "te ahorras un paso: ya quedas maquillada".
- **Pantalones de vestir, $130,000 en un mes.** "No vayas a comprar estos pantalones si no sabes cómo llevártelos con tres descuentos."
- **Suplemento con los tres hooks:** aplastando la pastilla en cámara, "esta es la razón por la que siempre hay que leer los reviews" dicho y escrito.

## Consejos para que te crean
- **Habla como amiga, no como experta.** "No sé cómo se llama esta tela, pero está bien suavecita" vende más que un dato técnico.
- **Ataca el dolor que la persona quiere resolver**, no las especificaciones. De un brasier, la gente quiere que no apriete, no marque y no se encaje.
- **El hate da alcance.** Los videos más criticados suelen ser los que más venden, porque la conversación los viraliza.
- **Para sacar ideas**, entra al perfil de una creadora que venda mucho, ordena por "Popular" y analiza solo sus primeros segundos.
- **Pide guiones a ChatGPT con detalle:** manda la foto del producto y di qué tipo de video quieres, que el hook funcione en TikTok, qué problema resuelve y que termine mandando al carrito naranja.
- Duración: de 15 segundos a un minuto. Sin portadas, descripción ni hashtags.
- Puedes grabar muchos videos con el mismo outfit: el algoritmo los manda a audiencias distintas.
- De cada producto haz de 3 a 5 videos antes de descartarlo.
- Videos hechos con inteligencia artificial: prohibidos.

## Cómo saber si hay descuento
Nadie te avisa. Antes de grabar, revisa producto por producto: si el precio está en rojo con el original tachado, hay descuento; abajo pueden aparecer cupones rosas o un letrero de oferta relámpago con "termina en X horas".

@@ 6 | Clase 6 | Luz, cámara y Sold Out | Cómo grabar con calidad sin perfección
Un buen producto con un buen guion no sirve si el video está oscuro, no se escucha o no se ve el producto. Esta clase es sobre la parte técnica.

TikTok Shop califica la calidad de tus videos. Así como las infracciones te quitan puntos, **cada lunes te puede dar hasta 10 puntos** si tus videos son claros, se escuchan bien y se nota que están hechos con intención.

## El punto medio
- **No hagas anuncios.** Videos súper producidos, con muchas tomas, letreros y efectos, parecen publicidad y la gente los pasa.
- **Tampoco videos descuidados.** Oscuros, con el celular mal puesto o sin que se vea nada.
- **La meta:** que se sienta como una videollamada con una amiga, pero con buena luz, buen sonido y el producto a la mano. Lo "casual" puede ser intencional: acomodar el celular y luego sentarte, por ejemplo.
- **La perfección no existe.** Si te equivocas, ríete y sigue: eso lo hace más real.

## El producto es el protagonista
- Debe aparecer en los **primeros 2 segundos** y estar **más cerca de la cámara que tu cara**.
- **Muévelo todo el tiempo:** ábrelo, úntalo, acércalo, aléjalo, hazlo sonar. La meta es que la persona sienta que ya lo tocó.
- Un robot revisa que el producto se vea. A una creadora la infraccionaron por vender fajas con ropa encima: no se veía la faja.
- **Guarda las cajas.** Te sirven para mostrar caja y producto.
- Aquí no se trata de "vender sin vender": desde el primer segundo se ve qué es, qué problema resuelve y cómo se usa.

## Luz, sonido y equipo
- **Luz de ventana, de frente a ti.** Muestra el color y la textura reales; el aro de luz borra detalles (te ves más bonita, pero se ve menos real). Nunca con la ventana atrás de ti.
- **El fondo casi no importa**, porque los videos son cerrados en ti y el producto.
- **Micrófono solo si hay mucho eco.** Apaga sonidos que venden, como abrir el empaque o tocar la tela.
- **Limpia el lente** con tu playera antes de cada video.
- El tripié es opcional. Lore graba con la cámara frontal, directo desde TikTok.

## Tomas y encuadre
- **Sin cara:** mueve el celular alrededor del producto: de arriba, de frente, de lado, muy de cerca y completo.
- **Contigo:** celular fijo, y el que se mueve es el producto.
- Casi todo se puede grabar en **una sola toma**. Dos tomas también funcionan.

## Edición
- **Graba, edita y publica dentro de TikTok.** El editor es igual a CapCut y te ahorra mucho tiempo.
- Solo recorta el silencio del inicio y los errores; si acaso, agrega una foto.
- **Más videos le ganan a la perfección.** Mejor tres videos directos que uno editado durante una hora.

@@ 7 | Clase 7 | Mindset y la era del Live | Constancia, sistema de trabajo y lives
Lo difícil de TikTok Shop no es grabar; es sostenerlo. Esta clase habla de cómo organizarte, cómo lidiar con las críticas y cómo vender en vivo.

## Ser visible incomoda
Cuando empiezas a publicar, alguien va a opinar: conocidos que dicen "ahora vende chanclitas" o desconocidos que comentan tu pelo. Casi siempre viene del desconocimiento o de la envidia, y habla más de la otra persona que de ti. Lo que duele es cuando tocan una inseguridad propia; ahí vale la pena trabajarlo.

Y un dato práctico: **el hate da alcance.** Lore no borra comentarios negativos; a veces otros la defienden y esa conversación viraliza el video y le trae ventas.

## Un sistema que puedas sostener
- **Publicar, observar, ajustar, repetir.** Con 10, 20 o 100 videos empiezas a ver qué vende, qué se viraliza y hasta en qué lugar de tu casa te conviene grabar.
- **Sube la cantidad poco a poco:** 1 video a la semana → 1 al día → 3 → 5 → 10. Si de golpe subes 20, el algoritmo no lo sostiene y tú tampoco. Lore graba unos 20 al día en unas 2 horas, pero empezó con uno a la semana.
- **Graba por bloques.** Un rato solo para investigar productos e ideas, otro solo para grabar (sin editar, sin WhatsApp, sin revisar estadísticas) y otro para editar y publicar.
- **Busca tu mejor hora de energía.** La hora de publicar casi no importa: una alumna doctora graba y publica todo en la noche y está entre las mejores de México.
- Puedes recomendar **todo lo que usas en tu vida diaria**, te dediques a lo que te dediques.
- **Ten videos en borradores** para los días en que no puedas grabar. Un día sin subir no pasa nada; varios seguidos sí.

## Cuando algo sale raro
- **Un video con miles de vistas pero sin ventas es normal.** Repite ese hook, pero habla más de la oferta.
- **Si el carrito no aparece**, espera unos minutos; si no, usa "eliminar y volver a editar" y agrégalo otra vez.
- **Si el producto se agota**, no borres el video: el carrito vuelve cuando resurten.
- No te paralices por algo chiquito. Pregúntale a ChatGPT, a soporte o a la cuenta de TikTok Shop México Creators.

## Qué es vender en vivo
El live es la otra forma de vender, y hacia allá va el mercado: en China hay lives 24 horas con hasta un millón de personas. La gente puede ver el producto por todos lados, preguntarte en vivo y comprar ahí mismo, a veces con descuentos exclusivos del live. Hay creadoras que venden millones al mes solo en lives.

## Cómo hacer tu live
1. **Prepárate:** buena conexión, celular cargado o conectado, tripié, luz de frente, productos a la mano y lo básico de cada uno anotado.
2. **Abre el live:** botón **+ → Live → canastita → agregar productos** (hasta unos 99). Pon arriba tu producto más vendido.
3. **Arranca como si llevaras horas.** Nada de "hola, ahorita empezamos": la gente que entra no sabe cuánto llevas.
4. **Fija el producto del que estás hablando** y mantenlo visible todo el tiempo.
5. **Repite el ciclo sin parar:** hook → mostrar → demostrar → beneficios → dudas → oferta → "los que ya lo agregaron, paguen su carrito" → preguntas. La gente solo se queda 1 o 2 minutos, así que no te va a oír repetir.
6. **Sube 2 o 3 videos del mismo producto antes del live.** Los videos llevan gente al live y el live impulsa los videos.

El algoritmo mide sobre todo tu **primera hora**: si hay ventas y movimiento, te sigue mandando gente.

## Reglas de los lives
- Nada de alcohol ni bebidas que lo parezcan.
- No dejes la pantalla vacía, ni silencios largos, ni una imagen fija, ni muestres un producto distinto al fijado, ni uses audios pregrabados.
- No te ausentes sin que haya movimiento en cámara (Lore usa una base giratoria con productos si tiene que pararse).
- Un **moderador** (una amiga, tu pareja o tu segundo celular) puede fijar productos, bloquear gente y poner sonidos de aplausos cuando alguien compra.

## Datos útiles
- **Niveles:** hay 6, según tus ventas del mes. El nivel 5 es alrededor de $600,000 y el 6 alrededor de $2,000,000.
- **Muestras:** al inicio te dejan pedir unas 5; en nivel 3, unas 10; más arriba, sin límite. Cuando te llega una, tienes **14 días** para hacerle video.
- No puedes comprar en tu propia vitrina. Cómprale a otras creadoras: ellas ganan comisión y el favor regresa.
- Si no sabes qué decir en un live, practica con lives de ejercicio o de lectura usando productos.

@@ 8 | Clase 8 | Las reglas del juego | Infracciones, apelaciones y retos
Las infracciones son parte del juego, como las tarjetas amarillas en el fútbol. Aquí aprendes a evitarlas, a apelarlas y a ganar dinero extra con los retos.

## El estado de tu cuenta
En TikTok Studio → TikTok Shop para creadores, arriba de tu nombre, ves si tu cuenta está "en buen estado". Se mide en puntos:
- **200 a 1,000:** saludable.
- **Alrededor de 150 a 199:** precaución; no hagas nada arriesgado.
- **Menos de ~150:** en riesgo; conviene pausar la cuenta. Te pueden bloquear los videos de shop unos días o, en casos graves, cerrarla.

Una infracción suele quitar entre 4 y 8 puntos; una **advertencia** no quita nada. Cada lunes TikTok da puntos por buenos videos y ventas, y las infracciones **se borran a los 90 días**. Para perder la cuenta necesitarías muchísimas.

## Qué te puede infraccionar
- **El producto:** que esté prohibido o parezca otra cosa (a Lore le marcaron un masajeador como producto para adultos).
- **Las promesas:** "elimina", "cura", "adelgaza", "resultados garantizados en 7 días".
- **El contenido:** muy oscuro, una foto fija en lugar de video, o que no se vea bien el producto.
- **Los derechos:** música, videos o identidad de otras personas, o "dupes" nombrando la marca cara.
- **La compra:** descuentos o stock falsos, o mandar a la gente a WhatsApp o a otra página.
- **Categorías delicadas:** salud, suplementos, pérdida de peso, aparatos médicos, alcohol y productos para adultos. Evita palabras como diabetes, estrés, ansiedad, tiroides o cáncer.

## Cómo decirlo sin que te infraccionen
- En vez de "elimina el acné": "¿tienes granitos en la espalda o en las pompis? Cambia el jabón de tu regadera por este".
- En vez de "te quita la ansiedad": describe la situación: "si en las noches no puedes dormir porque te quedas pensando…".
- En vez de prometer: "está diseñado para…", "según la información del producto…", "en mi experiencia, noté…".
- Con suplementos, habla de la oferta más que del beneficio.
- Pídele a ChatGPT palabras alternativas, o pásale las reglas de la comunidad para que tus guiones salgan seguros.

## Qué hacer si te infraccionan
1. **No borres el video.** Si lo borras, ya no puedes apelar.
2. **Respira.** No decidas desde el miedo; a todas les pasa.
3. **Lee la política** que te marcan y revisa el video para entender qué la causó.
4. **Toma screenshots** de la infracción y 3 o 4 capturas del video (inicio, mitad y final).
5. **Pídele a ChatGPT el texto de la apelación**, explicando tu caso y pidiendo revisión manual.
6. **Apela siempre**, aunque creas que tienen razón. La primera infracción la pone un robot, y muchas veces un humano la quita.

## Retos, campañas y tareas
En TikTok Shop para creadores → herramientas encuentras **Desafíos**, **Campañas** y **Tareas** (también salen como avisos). Te pagan por cumplir metas, por ejemplo:
- 3 videos de ciertos productos → $150.
- Publicar 21 videos en el mes → hasta $1,100.
- Metas de ventas quincenales → hasta $25,000.

Las metas cambian según tu nivel. Tienes que **unirte** al reto, pero los videos cuentan aunque no los hagas desde ahí, siempre que el producto participe. Además de dinero, te ayudan a agarrar ritmo.

## Otras herramientas que sirven
- **Aprende de creadores:** videos que ya vendieron mucho; ideal cuando te quedas sin ideas.
- **Teleprompter**, **vincular productos** a videos que se quedaron sin carrito y **sets de productos** para tus lives.
- **Academia:** cientos de videos oficiales con tutoriales.

## Respuestas rápidas
- Si hablaste de un descuento que era real cuando grabaste y te reportan, apela explicando la fecha.
- Los giveaways en lives se negocian con la marca, y no se dice "rifa" ni "sorteo".
- No transmitas el mismo live en dos cuentas.
- Las agencias suelen quedarse con comisión de todas tus ventas; si firmas, que sea a prueba y sin que te quiten comisión.
- Tu tarjeta para cobrar se agrega en Ganancias, en el ícono de tarjeta de arriba a la derecha (tarjeta o Mercado Pago).
- Espera a tener tu primera cuenta en nivel 5 o 6 antes de abrir una segunda.

@@ 9 | Herramientas | Tu checklist antes del Post | Revísalo con cada video
Revisa esto con cada video de venta. Si no cumple todo, súbelo de todos modos: nunca sabes cuál va a pegar.

## Antes de publicar
- Empieza sin silencio: recortaste el inicio.
- Tiene al menos 2 de los 3 hooks: visual, hablado y texto.
- El producto sale en los primeros 2 segundos, claro, de cerca y en movimiento.
- Hablas de un solo problema, deseo u objeción.
- Sabes si es TOFU, MOFU o BOFU.
- Revisaste hoy si tiene descuento; si hablas de la oferta, es real, y no dices el precio ni el porcentaje exacto.
- Cero promesas de resultados o de salud, sin marcas ajenas y sin mandar fuera de TikTok.
- Luz de frente y se escucha bien.
- Mandas al carrito naranja dos veces y explicas dónde está.
- **La canastita amarilla con el producto está agregada.**

## Rutina semanal sugerida
- Bloque de investigación: descuentos, campañas, retos y videos que venden en "Aprende de creadores".
- Bloque de grabación: varios productos con varios videos cada uno.
- Bloque de edición y publicación dentro de TikTok.
- Repite tus productos ganadores cada día y mete algunas muestras nuevas cada semana.
- Revisa el estado de tu cuenta y apela cualquier infracción.

@@ 10 | Herramientas | El diccionario Creator | Las palabras de TikTok Shop
Las palabras que vas a escuchar todo el tiempo en TikTok Shop.

- **Creadora / afiliada:** tú. Haces videos de productos de otros y ganas comisión.
- **Seller:** dueño del producto y del stock.
- **Vitrina (showcase):** los productos que puedes vender y por los que cobras comisión.
- **Carrito naranja:** el botón del video por donde la gente compra.
- **Mercado de productos:** buscador de productos con tus datos de creadora (comisión, stock, ventas).
- **GMV:** tus ventas totales. Define tu nivel.
- **Comisión estimada:** lo que te toca de esas ventas.
- **Niveles 1 a 6:** rangos según tus ventas del mes; desbloquean alcance y muestras.
- **Prueba piloto:** acceso anticipado con ~1,000 seguidores, con límites.
- **B-roll:** los videos cortos con música y frase para crecer seguidores.
- **Hook o gancho:** lo que detiene el scroll en los primeros 2 segundos.
- **TOFU / MOFU / BOFU:** videos para presentar, para resolver una duda y para cerrar con la oferta.
- **Muestra gratis:** producto que la marca te regala a cambio de un video (tienes 14 días para hacerlo).
- **Muestra reembolsable:** la pagas y te la regresan al llegar a cierto número de ventas.
- **Spark code:** código que le das a una marca para que ponga anuncios a tu video.
- **Oferta relámpago:** descuento de pocas horas, ideal para videos BOFU.
- **Estado de la cuenta:** tus puntos (sana arriba de 200).
- **Apelar:** pedir que una persona revise una infracción.
- **Faceless, voice over, sketch:** estilos de video: sin cara, con voz grabada después, y mini actuación.


---

# Preguntas frecuentes

Formato: `## Categoría | clase relacionada` y `### Pregunta`.

## Empezar y seguidores | 1

### ¿Necesito saber de TikTok o tener seguidores para empezar?
No. Solo necesitas compromiso y ganas de aprender. De hecho, quienes llegan sin saber nada tienen ventaja: no traen mañas de Instagram que haya que desaprender. Todo lo técnico se aprende picándole y, si algo no aparece, preguntándole a ChatGPT o buscándolo en YouTube.

### ¿Cuántos seguidores necesito para vender?
En México, **2,000 seguidores**, ser mayor de edad y haber subido al menos un video en los últimos 180 días. En Estados Unidos son 5,000. Algunas cuentas entran antes en **prueba piloto** (desde unos 1,000), pero con límites: menos productos, un tope de videos al día y menos alcance. Aunque te dejen entrar en piloto, sigue creciendo hasta los 2,000.

### ¿Cómo llego rápido a los 2,000 seguidores?
Con videos cortos pensados para viralizar (b-rolls):
1. Graba momentos de **6 a 10 segundos** de lo que sea: tu café, caminando, la carretera desde el coche.
2. Ponle **música en tendencia**: toca el circulito del audio de un video que te guste y elige "usar audio".
3. Agrega **una frase** que genere identificación, curiosidad o conversación, con la letra "Classic" en blanco con fondo negro.
4. Sube **mínimo 3 al día**; si no avanzas, sube a 5 o 10.
Se vale copiar frases y música de otras cuentas: en TikTok así funcionan las tendencias.

### Llevo días subiendo videos y no crezco, ¿qué hago?
Primero revisa que tus videos estén bien hechos: cortos, con música en tendencia y una frase (no audios de reflexiones). Luego sube la cantidad a 5 o 10 al día. También puedes **pagar $200 a $400** para promocionar el video con más vistas, y entrar 15 o 20 minutos a lives o videos de "te sigo y me sigues". Y no pares: cada cuenta tiene su ritmo, y lo único que TikTok castiga es dejar de subir.

### ¿Importa quién me siga?
No. Los videos de venta no se muestran a tus seguidores, sino a las personas interesadas en ese producto. Los 2,000 son solo un requisito. Si te siguen cuentas raras, ni las veas; cuando llegues a la meta hasta las puedes bloquear.

### Me salió "TikTok Shop te eligió para abrir tu tienda", ¿lo acepto?
**No.** Ese letrero (a veces dice "90 días sin comisiones") es para sellers, es decir, dueños de productos. Si lo aceptas, regresar a creadora es complicado: tendrías que escribir a soporte o abrir otra cuenta.

## Tu cuenta, pagos y comisiones | 2

### ¿Dónde encuentro todo lo de TikTok Shop?
En **Perfil → TikTok Studio → TikTok Shop para creadores**. A veces sale como botón grande y a veces más abajo, en los cuadritos. Ahí están tu vitrina, el mercado de productos, tus ganancias, muestras, retos y el estado de tu cuenta. Lo que está fuera de esa sección (programas de incentivos, regalos en lives) es TikTok normal.

### Mi cuenta dice "en revisión" o "rechazada", ¿qué hago?
No pasa nada. Vuelve a intentar en 2 o 3 días desde el mismo lugar. Suele pasar cuando la cuenta creció muy rápido, porque TikTok revisa que no sea un bot. Tarde o temprano te aceptan.

### ¿Qué necesito para verificar mi identidad?
CURP, nombre y fecha de nacimiento **exactamente** como en tu identificación, una dirección donde te lleguen paquetes, tu cuenta bancaria y la constancia de situación fiscal. Hazlo con calma: si algo no coincide, se atora todo. Para dudas fiscales, pregúntale a tu contador.

### ¿Cuándo y cómo me pagan?
TikTok deposita **los miércoles de madrugada** en la cuenta que registraste. Pero no paga lo que vendiste esa semana: paga **15 días después de que el producto llegó a casa del cliente**, porque el cliente puede devolverlo. Por eso las primeras ganancias tardan unas semanas.

### ¿Dónde pongo mi tarjeta para que me paguen?
En TikTok Shop para creadores → **Ganancias** → el ícono de tarjeta de arriba a la derecha. Puedes poner tu tarjeta de débito o Mercado Pago.

### ¿Cuánto se gana por venta?
La comisión la pone cada marca, casi siempre entre 5% y 12% (lo común es alrededor de 8%). Ejemplo: un producto de $400 con 10% te deja $40 por venta; si ese video vende 50 en un día, ganaste $2,000. En la ficha de cada producto ves cuántos pesos exactos ganas.

### ¿Qué es el GMV?
Tus **ventas totales** desde tu vitrina. Es lo que cuenta para subir de nivel. Tu ganancia real es la "comisión estimada". Por eso conviene tener productos caros (suben mucho el GMV) y baratos (se venden en volumen).

### ¿Qué son los niveles?
Hay 6 niveles según lo que vendes al mes. Cada nivel te da más alcance, más muestras gratis y más apoyo. Como referencia, el nivel 5 es alrededor de $600,000 al mes y el 6 alrededor de $2,000,000. Si te llega "ya pasaste a nivel 1", ¡felicidades!, ya empezaste.

### ¿Qué diferencia hay entre carrito y vitrina?
El **carrito** es para cuando tú compras algo. La **vitrina** es lo que tú vendes. Puedes tener cientos de productos en tu vitrina aunque no les hayas hecho video; a veces se venden solos porque TikTok se los ofrece a quien entra a tu perfil.

### ¿Puedo comprar en mi propia vitrina?
No, TikTok no te deja. Compra en el mercado de productos o, mejor, a otra creadora: ella gana su comisión y el favor regresa.

## Productos y muestras | 3

### ¿Cómo sé si un producto vale la pena?
Revisa seis cosas:
1. **Ventas:** mira cuántos se han vendido. En TikTok, lo más vendido se sigue vendiendo.
2. **Precio:** combina caros y baratos.
3. **Comisión en pesos:** desliza la pestañita con flechitas de la ficha.
4. **Reviews** y la sección "Inspo de creadores".
5. **Que se te ocurran ideas** de video.
6. **Tienda oficial y más de 100 en stock.** Si se agota, te quitan el carrito.

### ¿Dónde busco productos?
En **Mercado de productos**, ordenando por "más vendido" o entrando a la campaña del momento (ahí vienen con descuentos). También puedes usar la lupa del "Para ti", escribir lo que buscas y abrir la pestaña **Tienda**.

### ¿Cómo pido muestras gratis?
En la ficha del producto, si dice "muestra gratis", pícale, elige color y talla y envía la solicitud. La marca decide si te la aprueba. Al principio casi no las aprueban porque todavía no tienes ventas, así que conviene comprar tus primeros 3 a 5 productos. Con más nivel te dejan pedir más (unas 5 al inicio, unas 10 en nivel 3).

### Ya me llegó una muestra, ¿cuánto tiempo tengo?
**14 días** para hacerle video. Tu única obligación es grabarlo. En "Gestionar muestras" ves cuáles te faltan.

### ¿Qué es una muestra reembolsable?
La pagas tú, y la marca te regresa el dinero cuando llegas a cierto número de ventas con ese producto.

### Me llegó un producto roto o de mala calidad, ¿qué hago?
Avísale al vendedor y no le hagas video. No vale la pena recomendar algo que no te convence.

### ¿Tengo que tener el producto físicamente?
Sí, la regla dice que lo tengas. Además vende mucho más cuando lo muestras, lo abres y lo usas. Una foto fija del producto no cuenta como video de venta.

## Hacer videos que vendan | 4

### ¿Qué tipo de videos debo hacer?
Tres tipos, como un embudo:
- **TOFU:** para quien no conoce el producto. Lo presentas completo (hasta 1 minuto).
- **MOFU:** para quien ya lo vio y tiene una duda. Resuelves **una sola** objeción, como "¿será original?" (30 a 40 segundos).
- **BOFU:** para quien ya está lista. **Solo hablas de la oferta** y mandas al carrito (15 a 30 segundos).
Con un producto nuevo haz uno de cada tipo. Los BOFU son los que más cierran.

### ¿Cómo hago un video BOFU?
Solo si el producto tiene una **oferta real**. Empieza hablando de la oferta ("le volvieron a bajar el precio"), manda al carrito, crea urgencia ("es por pocas horas") y manda al carrito otra vez. Nada de ingredientes ni beneficios. Haz unos 5 del mismo producto: es más probable que uno pegue.

### ¿Qué es un hook y cómo hago uno bueno?
Es lo que detiene el scroll en los **primeros 2 segundos**. Nunca dejes silencio al inicio: recorta hasta que el video empiece casi cortando tu primera palabra. Usa al menos dos de estos tres: **visual** (mover el producto, abrir una caja, grabar en el coche), **hablado** (tu primera frase) y **texto en pantalla**. Hooks que funcionan: "Si tu ___ se ve así, compra esto", "No vayas a comprar ___ si no sabes…", "Te vas a enojar si acabas de comprar esto".

### ¿Cuánto deben durar los videos?
Entre 15 segundos y 1 minuto. Los BOFU, cortitos; los que presentan el producto, un poco más largos. No pasa nada si uno dura un poco más o menos.

### ¿Cuántos videos subo al día?
Empieza con lo que puedas sostener (1 a 3 al día) y sube poco a poco a 5, 10 o más. No hay límite. Lo que TikTok castiga es la intermitencia, no la cantidad. De cada producto nuevo haz de 3 a 5 videos antes de descartarlo.

### ¿Importa a qué hora publico?
No. Puedes subir todos juntos en la noche o repartirlos en el día; funciona igual. Graba a la hora en que tengas más energía.

### ¿Cómo agrego el carrito naranja a mi video?
Desde tu vitrina, entra al producto, desliza la flechita y pica **Crear → Cámara**. Si grabaste con la cámara normal, antes de publicar toca **Agregar enlace** y elige el producto. Antes de publicar, **revisa que aparezca la canastita amarilla**: un video de shop sin carrito es infracción.

### No me aparece el carrito en el video, ¿qué hago?
A veces tarda unos minutos. Si pasan 15 minutos y no sale, usa "eliminar y volver a editar", agrégalo otra vez y publica. Si el producto se agotó, el carrito desaparece; no borres el video, vuelve solito cuando resurten.

### ¿Cómo sé si un producto tiene descuento?
Nadie te avisa: revisa producto por producto antes de grabar. Si el precio está en rojo con el original tachado, hay descuento. Abajo pueden salir cupones rosas o un letrero de oferta relámpago con "termina en X horas".

### ¿Puedo decir el precio o el porcentaje de descuento?
Mejor no. Los precios y descuentos cambian de un día a otro, y si alguien ve tu video cuando ya cambió, te pueden reportar. Di "trae descuentazo" o "menos de $200".

### ¿Pongo hashtags, descripción o portada?
No hacen diferencia. Solo usa hashtags cuando hay un desafío o la marca te lo pide.

### Mi video tiene miles de vistas pero no vende, ¿por qué?
Es normal. Una cosa es llamar la atención y otra cerrar la venta. Repite ese mismo hook, pero habla más de la oferta y manda al carrito con claridad. Hay videos de 200 vistas que venden mucho.

## Grabar | 6

### ¿Necesito aro de luz, micrófono o tripié?
No. La mejor luz es la **de una ventana, de frente a ti**: muestra el color y la textura reales. El micrófono solo si hay mucho eco, porque apaga sonidos que venden (abrir el empaque, la tela). El tripié es opcional.

### ¿Edito en CapCut o en TikTok?
Graba y edita **dentro de TikTok**: el editor es igual a CapCut y te ahorra tiempo. Solo recorta el silencio del inicio y los errores. Más videos le ganan a la perfección.

### ¿Tengo que salir yo en los videos?
No necesariamente. Hay videos sin cara (solo el producto con mucho movimiento), con voz grabada después, mini actuaciones o hablando a cámara. Lo importante es que **el producto se vea claro** desde los primeros segundos.

### ¿Pueden salir mis hijos en los videos?
Los menores de edad no pueden vender ni salir vendiendo. Que se oigan de fondo no importa, y unas manitas armando un juguete sí se valen.

### ¿Puedo grabar varios videos con la misma ropa?
Sí. El algoritmo los manda a personas distintas, así que nadie lo nota.

## Lives | 7

### ¿Cómo hago un live?
1. Pica **+ → Live**, abre la canastita y agrega tus productos (el más vendido hasta arriba).
2. Ten celular cargado, buena conexión, luz de frente y los productos a la mano.
3. Arranca con tu producto ganador **como si llevaras horas vendiendo**.
4. **Fija** el producto del que estás hablando y mantenlo visible.
5. Repite el ciclo: mostrar, demostrar, beneficios, dudas, oferta, "paguen su carrito". La gente solo se queda 1 o 2 minutos.
Antes del live, sube 2 o 3 videos de ese producto: te llevan gente.

### ¿Qué está prohibido en un live?
Alcohol (o algo que lo parezca), pantalla vacía, silencios largos, una imagen fija, mostrar un producto distinto al fijado, audios pregrabados y ausentarte sin que haya movimiento en cámara.

### Hice mi primer live y no entró nadie
Es normal en los primeros. Sigue haciéndolos. Si no sabes qué decir, practica con lives de ejercicio o de lectura usando productos.

### ¿Hacer lives me baja las vistas de los videos?
No. Son algoritmos distintos y se impulsan entre sí: la gente ve tu video, ve que estás en vivo y entra, o te ve en vivo y después compra en el video.

## Infracciones y retos | 8

### Me pusieron una infracción, ¿qué hago?
1. **No borres el video**: si lo borras ya no puedes apelar.
2. Respira; a todas les pasa y casi siempre tiene solución.
3. Lee qué política marcaron y revisa tu video.
4. Toma screenshots de la infracción y 3 o 4 capturas del video.
5. Pídele a ChatGPT el texto de la apelación, pidiendo revisión manual.
6. **Apela siempre**: la pone un robot y muchas veces un humano la quita.

### ¿Me pueden cerrar la cuenta por una infracción?
Es muy difícil. Tu cuenta se mide en puntos: arriba de 200 está sana. Una infracción quita unos 4 a 8 puntos, una advertencia no quita nada, cada lunes te dan puntos por buenos videos y las infracciones se borran a los 90 días. Si alguna vez bajas mucho, pausa la cuenta un tiempo.

### ¿Qué palabras no debo decir?
Nada que suene a promesa o a salud: "elimina", "cura", "adelgaza", "resultados garantizados", ni enfermedades como diabetes, estrés, ansiedad o cáncer. Tampoco nombres marcas ajenas para comparar ni mandes gente a WhatsApp o a otra página.

### ¿Cómo hablo de un suplemento o una crema sin que me infraccionen?
Describe la situación en vez de prometer. En lugar de "elimina el acné": "¿tienes granitos en la espalda? Cambia el jabón de tu regadera por este". En lugar de "quita la ansiedad": "si en las noches no puedes dormir porque te quedas pensando…". Usa "en mi experiencia…" o "está diseñado para…". Con suplementos, habla sobre todo de la oferta.

### ¿Qué son los retos y cómo participo?
Son metas que TikTok paga: por ejemplo, 3 videos de ciertos productos por $150, o metas de ventas quincenales de hasta $25,000. Están en TikTok Shop para creadores → **Desafíos, Campañas y Tareas**. Tienes que **unirte**, pero los videos cuentan aunque no los hagas desde ahí, siempre que el producto participe.

### ¿Me conviene una agencia?
Con cuidado: muchas se quedan con comisión de todas tus ventas, no solo de lo que te ayudan. Si firmas, que sea a prueba por poco tiempo y sin que te quiten comisión.

### ¿Abro una segunda cuenta?
Todavía no. Concéntrate en una hasta llegar a nivel 5 o 6. Dos cuentas al mismo tiempo solo dividen tu energía.

### Me da pena lo que digan de mis videos
Es normal; ser visible incomoda. Los comentarios negativos casi siempre hablan más de quien los escribe que de ti. Y un dato: el hate da alcance, y los videos con más críticas suelen ser los que más venden.
