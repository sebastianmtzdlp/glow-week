# El Sí · contenido completo del curso

## 0 · Bienvenida a El Sí
*Empieza aquí · Por qué la gente dice que sí*

Este curso es para que entiendas qué pasa en la cabeza de alguien justo antes de decir que sí, y para que lo uses con honestidad. También para que te des cuenta cuando alguien lo usa contigo.

### De qué se trata
Todos los días tomamos cientos de decisiones y no hay tiempo de pensar cada una a fondo. Por eso la mente usa **atajos**: reglas rápidas que casi siempre funcionan. "Si me dieron algo, devuelvo." "Si ya dije que sí, sigo." "Si todas lo usan, ha de ser bueno." "Si me cae bien, le creo." "Si sabe del tema, le hago caso." "Si se acaba, lo quiero."

Esos seis atajos son la base de este curso. Un psicólogo pasó años estudiándolos en laboratorio y, además, trabajando de incógnito con vendedores, recaudadores y publicistas para ver cómo los usaban en la vida real. Lo que encontró sirve para dos cosas: para pedir mejor y para defenderte mejor.

> Un atajo no es bueno ni malo. Lo que importa es si la señal que lo dispara es verdadera.

### Si ya tomaste El Clic
El Clic te enseñó a entender la mente de tu clienta: qué siente, qué necesita de fondo y qué significa para ella cada producto. **El Sí** es la otra mitad: los seis atajos que hacen que una persona diga que sí, cómo usarlos sin trampa y cómo reconocerlos cuando te los aplican a ti. Se complementan, pero puedes tomar este solo.

### Cómo está armado
- **Clase 1.** Cómo funcionan los atajos y el primer truco que casi nadie nota: el contraste.
- **Clases 2 a 7.** Un atajo por clase: Te doy, Lo dije, Todas lo hacen, Me caes bien, Ella sabe y Se acaba. Cada clase trae la versión honesta para tu negocio y cómo decir que no cuando te lo aplican.
- **Clase 8.** La regla que une todo: señales verdaderas sí, señales falsas nunca.
- **Herramientas.** Un checklist antes de pedir un sí, tu escudo para decir que no y una guía para líderes.

### La regla del curso
Todo lo que vas a aprender funciona. Por eso mismo tiene una regla: **solo se vale con señales verdaderas**. Una muestra regalada de verdad, una opinión real de una clienta, una promoción que de verdad termina el viernes. Inventar urgencia, fingir que todas compran o presionar a una amiga que no se atreve a decirte que no te puede dar una venta hoy, pero te quita la clienta, la amistad y el nombre.

### 🪞 Para pensar
Piensa en la última vez que dijiste que sí a algo y después te arrepentiste. ¿Qué te hizo decir que sí en ese momento?

### ✍️ Escribe
Escribe en una frase qué quieres llevarte de este curso. Por ejemplo: "Quiero pedir sin sentir que presiono."

## 1 · Clase 1 · Clic y en automático
*Clase 1 · Los atajos y el contraste*

La mente no tiene tiempo de pensar cada decisión. Así que, cuando ve cierta señal, presiona un botón y corre una respuesta ya grabada.

### El botón que corre solo
En la naturaleza hay ejemplos muy claros. Hay aves que cuidan a sus crías solo porque escuchan cierto sonido. Si el sonido viene de otro lado, cuidan lo que sea que lo haga. No ven a la cría: escuchan la señal y responden. **Clic, y corre la respuesta.**

Las personas no somos tan distintas. Un estudio muy famoso lo mostró con una fila para sacar copias. Cuando alguien pedía pasar primero "porque tengo prisa", casi todos lo dejaban. Lo sorprendente fue que cuando pedía pasar "porque tengo que sacar unas copias" (que es justo lo que todos estaban haciendo), casi todos lo dejaban también. La palabra **"porque"** bastó para disparar el sí. La razón casi no importó.

> La mente no siempre escucha la razón. Muchas veces solo escucha que hay una razón.

### Por qué existen los atajos
Los atajos no son un defecto. Son la forma en que la mente ahorra energía. La mayoría de las veces funcionan: lo caro suele ser mejor, lo que muchos eligen suele estar bien, la experta suele saber. El problema es que **cualquiera que conozca la señal puede activarla**, aunque la cosa no lo valga.

Por ejemplo: hay una historia de una tienda que no lograba vender unas piezas de joyería. La dueña dejó una nota para que las bajaran a la mitad. La empleada entendió mal y las subió al doble. Se vendieron todas en un día. Las clientas pensaron "caro igual a bueno" y no se detuvieron a ver la pieza.

### El primer atajo: el contraste
Antes de los seis atajos grandes, hay uno que está en todos lados. **Lo que ves primero cambia cómo ves lo segundo.** Si metes la mano en agua fría y luego en agua tibia, la tibia se siente caliente. Con los precios pasa igual: después de ver algo caro, lo siguiente se siente barato.

Los vendedores de casas lo saben y enseñan primero una casa fea y cara. Los de ropa venden primero el traje y luego la corbata, porque después de un gasto grande, uno chico casi no se siente.

### La versión honesta en tu negocio
El contraste no es trampa por sí mismo. Es trampa cuando enseñas algo que no tiene sentido solo para que lo otro parezca barato.

- **Sí se vale:** enseñar primero la rutina completa que de verdad le recomiendas y luego la versión básica, para que ella elija con todo el panorama.
- **Sí se vale:** dar la razón de lo que recomiendas. "Te recomiendo este primero porque tu piel se reseca en las tardes."
- **No se vale:** inventar un "precio antes" que nunca existió para que el de hoy parezca oferta.

### Cómo decir que no
Cuando sientas que algo "se ve barato", pregúntate: **¿barato comparado con qué?** Si la comparación te la acaban de poner enfrente, vuelve a ver el precio solo, sin lo de al lado.

### 🪞 Para pensar
¿En qué compra reciente te ganó el contraste? Piensa en el "ya que estoy aquí".

### ✍️ Escribe
Escribe la razón real por la que recomiendas tu producto favorito, empezando con "porque". Que sea una razón que de verdad le sirva a tu clienta.

### ✅ Para esta semana
- Fíjate en tres lugares donde te pongan un precio alto primero para que el siguiente parezca bajo.
- En tus próximas tres recomendaciones, da siempre la razón.

## 2 · Clase 2 · Te doy
*Clase 2 · La reciprocidad*

Cuando alguien nos da algo, sentimos que le debemos. Es una de las reglas más viejas y más fuertes que existen.

### La regla de devolver
En todas las culturas del mundo existe la misma regla: **si me das, te devuelvo.** Gracias a ella podemos ayudar a alguien sabiendo que no se pierde. Es la base de la confianza y de la vida en comunidad.

Es tan fuerte que funciona aunque no nos caiga bien la persona y aunque no hayamos pedido el regalo. En un estudio, un desconocido le regaló un refresco a otra persona y después le pidió que le comprara boletos de una rifa. Quienes recibieron el refresco compraron casi el doble, y no importó si el desconocido les había caído bien o mal.

> Un regalo que no pediste igual te deja con la sensación de que debes algo.

### Dar primero
Por eso las muestras gratis funcionan tan bien. No solo porque la clienta prueba el producto, sino porque recibió algo. Hay empresas de venta por catálogo que dejan una charola con productos en casa de la clienta unos días, sin compromiso. Cuando regresan, la mayoría compra algo. Prueba y regla de devolver, juntas.

### Ceder también es dar
La regla no solo funciona con regalos. También con **concesiones**. Si alguien te pide algo grande, le dices que no, y luego te pide algo más chico, sientes que esa persona cedió y que te toca ceder a ti. Por eso pedir primero lo grande y luego lo pequeño funciona tanto.

Un ejemplo clásico: un niño scout le pidió a un señor que le comprara boletos caros para un evento. El señor dijo que no. Entonces el niño le dijo: "Bueno, ¿y unas barras de chocolate? Son más baratas." El señor compró dos barras. No le gustaba el chocolate.

### La versión honesta en tu negocio
- **Da sin hilos.** Una muestra, un consejo, una rutina armada para ella. Dalo porque quieres que le vaya bien, no para cobrárselo después. Si das esperando, se nota.
- **Da algo que le sirva a ella.** Una muestra del tono correcto vale más que una bolsa de cosas al azar.
- **Ofrece lo grande solo si de verdad lo recomiendas.** Si le propones la rutina completa y te dice que no, ofrecerle el limpiador solo está bien, siempre que la rutina completa fuera una recomendación real y no un truco para que el limpiador parezca poco.
- **Haz que el "no" sea fácil.** "Si no te late, cero pena, me regresas lo que no uses." Eso hace que la próxima vez te reciba con gusto.

### Cómo decir que no
No tienes que rechazar todos los regalos. Recibe lo que te den, pero ve lo que es. Si el regalo resulta ser una herramienta de venta, **no te obliga a nada**. La regla dice que un favor se devuelve con un favor, no que una táctica se paga con una compra.

### 🪞 Para pensar
¿Alguna vez compraste algo solo porque te dieron una muestra o una atención y sentiste que "ni modo de no"? ¿Cómo te sentiste después?

### ✍️ Escribe
Escribe tres cosas que puedes dar a tus clientas esta semana sin esperar nada a cambio. Una que cueste dinero y dos que no.

### ✅ Para esta semana
- Da al menos una de esas tres cosas.
- Cuando te ofrezcan algo con intención de venta, nota la sensación de "le debo" y ponle nombre.

### 💬 Para tu equipo
Comparte con tu equipo la idea de dar sin hilos. ¿Qué es lo mejor que alguien les ha dado sin pedirles nada?

## 3 · Clase 3 · Lo dije
*Clase 3 · Compromiso y coherencia*

Una vez que decimos algo o tomamos una postura, queremos ser congruentes con eso. Cambiar de opinión se siente feo.

### Queremos ser coherentes
Ser coherente tiene muy buena fama: es de gente confiable, madura y que cumple. Por eso, cuando decimos o hacemos algo, sentimos presión por actuar de acuerdo con eso después. A veces la coherencia nos ahorra pensar: ya decidí, ya no le muevo.

Un estudio lo mostró en una playa. Alguien dejaba su radio en la toalla y se iba. Un "ladrón" se lo llevaba. Casi nadie hacía nada. Pero cuando la persona antes de irse le pedía al vecino "¿me echas un ojo?" y el vecino decía que sí, casi todos corrían detrás del ladrón. Un "sí" chiquito cambió todo.

> Lo que dices en voz alta te va dibujando por dentro.

### Los pequeños sí
Los compromisos chiquitos abren la puerta a los grandes. En otro estudio, a unos vecinos les pidieron poner un letrero gigante y feo en su jardín sobre manejar con cuidado. Casi todos dijeron que no. A otros vecinos, semanas antes, les habían pedido poner un letrerito pequeño. De esos, la gran mayoría aceptó el letrero gigante. El primer sí les cambió la idea de quiénes eran: "soy de las personas que se preocupan por esto".

### Lo que hace un compromiso más fuerte
Un compromiso pesa más cuando:
- **Es activo.** Lo escribiste o lo hiciste, no solo lo pensaste.
- **Es público.** Otras personas lo saben.
- **Costó trabajo.** Mientras más esfuerzo, más lo cuidamos.
- **Es tuyo.** Lo elegiste tú, sin que nadie te presionara. Este es el más importante: si alguien te obliga, no lo sientes tuyo.

### La trampa de la bola baja
Hay una táctica que usa la coherencia en contra de la persona. Te ofrecen un precio buenísimo, dices que sí, empiezas a imaginar cómo vas a usar lo que compraste… y justo antes de pagar "aparece" un costo extra. Muchos pagan igual, porque ya se sentían dueños. Eso no se hace nunca.

### La versión honesta en tu negocio
- **Que ella diga su meta.** En lugar de decirle tú qué necesita, pregúntale: "¿Qué te gustaría ver en tu piel en un mes?" Una meta dicha por ella vale más que diez argumentos tuyos.
- **Que lo escriba ella.** Si arma su rutina contigo, que la anote en su celular. Es su plan, no tu venta.
- **Empieza chico, de verdad.** Una muestra, una prueba de una semana, un solo producto. Si le funciona, ella sola va a querer más.
- **El precio que dijiste es el precio.** Nada de sorpresas al final.

### Cómo decir que no
Hay dos señales para saber cuándo la coherencia te está jugando chueco. La primera es en el **estómago**: esa sensación de "no quiero, pero ya dije que sí". Cuando la sientas, dilo en voz alta: "Me doy cuenta de que estoy diciendo que sí solo porque ya me comprometí, y no quiero."

La segunda es en el **corazón**, y sirve cuando ya no estás segura. Pregúntate: **"Sabiendo lo que hoy sé, si pudiera regresar el tiempo, ¿volvería a decir que sí?"** Fíjate en lo primero que sientes, antes de que la cabeza empiece a justificar.

### 🪞 Para pensar
¿Hay algo que sigues haciendo solo porque un día dijiste que lo ibas a hacer? ¿Volverías a decir que sí hoy?

### ✍️ Escribe
Escribe la pregunta que le vas a hacer a tu próxima clienta para que ella diga su meta con sus propias palabras.

### ✅ Para esta semana
- Haz esa pregunta en tres pláticas y escucha la respuesta sin interrumpir.
- Revisa un compromiso tuyo con la pregunta del corazón.

## 4 · Clase 4 · Todas lo hacen
*Clase 4 · La prueba social*

Cuando no sabemos qué hacer, vemos qué hacen los demás. Sobre todo, los que se parecen a nosotras.

### Vemos a los demás
Si un restaurante está lleno y el de al lado vacío, entras al lleno. Si un video tiene miles de comentarios, te detienes a verlo. Es la **prueba social**: decidir qué está bien según lo que hace la gente. Casi siempre funciona, porque si mucha gente hace algo, suele ser por algo.

Es tan fuerte que hasta las risas grabadas de los programas de comedia hacen que la gente se ría más, aunque todos sepan que son falsas.

> Cuando no estamos seguras, copiamos. Y copiamos más a quien se parece a nosotras.

### Cuándo pesa más
La prueba social es más fuerte en dos situaciones:
- **Cuando hay duda.** Si la persona no sabe qué elegir, ve qué eligieron otras. Una clienta que nunca ha usado sérum se fija mucho más en las opiniones que una que ya tiene su favorito.
- **Cuando son parecidas.** Nos influye mucho más alguien como nosotras: misma edad, mismo tipo de piel, misma vida. La opinión de una mamá de tres que trabaja vale más para otra mamá de tres que la de una modelo.

### Cuando todos esperan
La prueba social también tiene un lado peligroso. Cuando alguien necesita ayuda en un lugar lleno de gente, muchas veces nadie hace nada, porque todos ven que los demás tampoco hacen nada y piensan "seguro no es grave". El libro da un consejo que vale la pena guardar: si algún día necesitas ayuda en la calle, **no le grites a la multitud. Escoge a una persona**: "Usted, el de la camisa azul, llame a una ambulancia." Eso rompe la duda.

### La versión honesta en tu negocio
- **Testimonios reales y parecidos.** Pide a tus clientas felices que te cuenten cómo les fue, con sus palabras y con su permiso. Y enséñale a cada clienta el testimonio de alguien parecido a ella.
- **Cuenta lo que de verdad pasa.** "Este es el que más me piden las mamás que trabajan" solo si es cierto.
- **Fotos de antes y después sin filtro.** Y sin prometer que a todas les va a pasar igual.
- **No inventes comentarios, ventas ni "se me agotó".** Una sola mentira descubierta borra todos tus testimonios verdaderos.

### Cómo decir que no
La prueba social falla en dos casos. Uno, cuando la evidencia es falsa: reseñas compradas, "testimonios espontáneos" actuados, filas armadas. Si lo notas, no solo no compres: date permiso de desconfiar de quien lo hizo. Dos, cuando todos siguen a todos y nadie sabe por qué. De vez en cuando levanta la vista y pregúntate: **¿esto es bueno para mí o solo lo estoy haciendo porque todas lo hacen?**

### 🪞 Para pensar
¿Qué compraste este año porque "todas lo tenían"? ¿Te sirvió?

### ✍️ Escribe
Escribe el nombre de dos clientas felices a las que les puedes pedir su testimonio. Al lado, escribe a qué tipo de clienta se parecen.

### ✅ Para esta semana
- Pide esos dos testimonios, con permiso para compartirlos.
- Guárdalos ordenados por tipo de clienta.

## 5 · Clase 5 · Me caes bien
*Clase 5 · La simpatía*

Le decimos que sí más fácil a la gente que conocemos y que nos cae bien. Esto en venta directa es poderoso y delicado al mismo tiempo.

### La amiga que vende
Las reuniones de venta en casa son el ejemplo más claro de este atajo. La que vende no es solo la demostradora: la que invita es una amiga. Las invitadas compran por el producto, sí, pero también porque se lo están comprando a alguien que quieren. Muchas compran sin necesitar nada, solo por no quedar mal.

Esto es justo lo que hace a la venta directa tan fuerte. Y también lo que la puede volver incómoda. Si tu amiga siente que no te puede decir que no, la venta de hoy puede ser la amistad de mañana.

> Que te quieran no significa que te deban una compra.

### Qué nos hace caer bien
Hay cinco cosas que hacen que alguien nos caiga bien rápido:
- **El atractivo.** Sin darnos cuenta, a la gente arreglada le creemos más. Por eso tu presentación sí importa.
- **El parecido.** Nos cae bien quien se parece a nosotras: en la forma de vestir, en lo que le gusta, en de dónde viene.
- **Los halagos.** Funcionan incluso cuando sabemos que son por algo. Por eso hay que usarlos con cuidado: solo los verdaderos.
- **El trato frecuente.** Lo conocido nos gusta más. Y si en ese trato hacemos cosas juntas, con una meta en común, nos cae todavía mejor.
- **La asociación.** Nos contagiamos del sentimiento que rodea a algo. Por eso las marcas se ponen junto a cosas bonitas y por eso al que trae malas noticias le va mal aunque no tenga la culpa.

### La versión honesta en tu negocio
- **Parecido verdadero.** Busca lo que de verdad tienen en común. Si ella es mamá y tú también, platica de eso. No inventes gustos que no tienes.
- **Halagos ciertos y concretos.** "Qué bonito te queda ese tono" solo si es verdad. Mejor uno real que cinco de cajón.
- **Equipo con tu clienta.** Ponte de su lado: "Vamos a encontrar lo que le funcione a tu piel." Tú y ella contra el problema, no tú contra ella.
- **Separa la amistad de la venta.** En una reunión, dilo claro: "Vinieron a pasarla bien. Si algo les late, me dicen, y si no, igual las quiero aquí." Ese "no pasa nada" hace que regresen.

### Cómo decir que no
No tienes que vigilar cada cosa que hace alguien para caerte bien. Solo fíjate en una señal: **"¿En este rato, esta persona me cayó mejor de lo que esperaba?"** Si la respuesta es sí, separa a la persona del producto. Pregúntate qué pensarías del producto si te lo ofreciera alguien que no conoces. Esa es tu respuesta.

### 🪞 Para pensar
¿Alguna vez le compraste a una amiga algo que no querías? ¿Qué te hubiera ayudado a decirle que no?

### ✍️ Escribe
Escribe la frase con la que vas a abrir tu próxima reunión o plática para que tus invitadas sepan que pueden decir que no.

### ✅ Para esta semana
- Usa esa frase.
- Haz un halago verdadero y concreto a tres clientas, sin venderles nada en ese mensaje.

### 💬 Para tu equipo
Pregunta en tu grupo: ¿cuál es la diferencia entre caer bien y presionar con cariño? Junten ejemplos de las dos.

## 6 · Clase 6 · Ella sabe
*Clase 6 · La autoridad*

Le hacemos caso a quien sabe. Y a veces, sin darnos cuenta, a quien solo parece que sabe.

### Obedecemos a quien parece saber
Desde niñas aprendemos que hacerle caso a quien sabe nos conviene: a la doctora, a la maestra, a la experta. Casi siempre es buena idea. El problema es que reaccionamos a los **símbolos** de autoridad casi tanto como a la autoridad real.

Hubo un estudio en un hospital que lo mostró muy fuerte. Alguien llamaba por teléfono a las enfermeras diciendo ser un doctor que nadie conocía y les pedía dar una dosis de un medicamento que pasaba el límite. Casi todas iban a darla. Solo las detuvieron antes de llegar al paciente. Un título por teléfono pesó más que su propio conocimiento.

> No le hacemos caso a la persona. Le hacemos caso a la bata, al título y al tono.

### Los tres símbolos
- **Los títulos.** "Doctora", "experta", "directora". Pesan aunque no tengan nada que ver con el tema.
- **La ropa.** Un uniforme o un traje hacen que la gente obedezca más, incluso cuando la petición no tiene sentido.
- **Los adornos.** Un coche caro, una oficina elegante, muchos seguidores. Hacen que alguien parezca importante.

### La versión honesta en tu negocio
- **Gánate la autoridad.** Aprende de verdad sobre tipos de piel, ingredientes y cómo se usa cada producto. Cuando sabes, se nota sin que lo digas.
- **Di lo que sabes y lo que no.** "Esto no lo sé, déjame preguntarle a mi líder" te da más confianza que inventar.
- **Admite un punto débil primero.** "Este es más caro que el de farmacia, pero te dura el doble." Cuando reconoces algo en contra, te creen más lo que viene después.
- **Nunca juegues a la doctora.** No diagnostiques problemas de piel ni prometas curar nada. Si hay algo médico, mándala con una dermatóloga. Eso también es autoridad.

### Cómo decir que no
Hazte dos preguntas cuando alguien con aire de experto te quiera convencer. Primera: **"¿De verdad sabe de esto?"** No si tiene un título, sino si su título tiene que ver con lo que te está diciendo. Segunda: **"¿Qué tan honesta puede ser conmigo aquí?"** ¿Gana algo si le haces caso? Una experta honesta también te dice lo malo.

### 🪞 Para pensar
¿A quién le haces caso solo por cómo se ve o por cuántos seguidores tiene? ¿Sabe de verdad del tema?

### ✍️ Escribe
Escribe un punto débil honesto de tu producto estrella y lo que lo compensa. Así lo vas a decir la próxima vez.

### ✅ Para esta semana
- Aprende algo nuevo y cierto sobre un ingrediente de tus productos.
- Di tu punto débil honesto en al menos una plática.

## 7 · Clase 7 · Se acaba
*Clase 7 · La escasez*

Lo que se acaba lo queremos más. Y lo que nos quitan, más todavía.

### Queremos lo que se acaba
Lo escaso se siente valioso. Si algo es difícil de conseguir, pensamos que ha de ser bueno. Además, cuando sentimos que vamos a perder la oportunidad, nos duele más perder que lo que nos alegraría ganar.

En un estudio le dieron a la gente galletas en un frasco. A unos les dieron un frasco con diez galletas y a otros con dos. Las de dos se calificaron como más ricas. Y las mejores calificadas fueron las de un frasco que empezó con diez y de pronto quedó en dos. **Lo que de repente se vuelve escaso se quiere todavía más.** Y si se acabó porque otras lo quisieron, más.

> La prisa no es una razón. Es una señal de que alguien quiere que no pienses.

### Cómo se usa
- **"Solo quedan pocas."** Edición limitada, últimas piezas.
- **"Solo hoy."** Fechas límite.
- **"Otra persona también lo quiere."** La competencia hace que queramos ganar, más que tener.
- **"Ya no te dejan."** Cuando nos prohíben algo, lo queremos más. Por eso decirle a alguien "no deberías" muchas veces sale al revés.

### La versión honesta en tu negocio
- **Solo escasez real.** Si la promoción de verdad termina el viernes, dilo con claridad y con tiempo. Si la edición de verdad es limitada, dilo. Si no, no.
- **Avisa antes, no al final.** "Te aviso desde hoy que el tono que te gustó sale de catálogo a fin de mes" es un favor. "Decide ya o lo pierdes" en medio de la plática es presión.
- **Di lo que tiene de único.** A veces lo escaso no es la cantidad, es la información: "Esto lo acabo de aprender y te lo quería contar a ti primero." Solo si es verdad.
- **Nada de "si no compras hoy te arrepientes".** Una clienta que compró con miedo no regresa.

### Cómo decir que no
La escasez se siente en el cuerpo: prisa, calor, ganas de ganarle a alguien. **Esa ola de emoción es tu señal para frenar.** Respira y pregúntate: **"¿Lo quiero para tenerlo o para usarlo?"** Si es para usarlo, recuerda que lo escaso no sabe ni se ve mejor. Las galletas eran las mismas.

### 🪞 Para pensar
¿Cuándo fue la última vez que compraste algo por miedo a que se acabara? ¿Lo usaste?

### ✍️ Escribe
Revisa tu próximo anuncio de promoción. Escríbelo de forma que diga la fecha límite real, sin presión. Por ejemplo: "La promo dura hasta el viernes. Si te interesa, aquí estoy."

### ✅ Para esta semana
- Publica una promoción con su fecha real y sin palabras de urgencia.
- Cuando sientas la prisa de comprar algo, espera un día.

## 8 · Clase 8 · Señales verdaderas
*Clase 8 · La regla que une todo*

Los seis atajos existen porque nos ayudan. Cuidarlos es parte de tu trabajo.

### Por qué los atajos importan cada vez más
Vivimos con más información y más opciones que nunca. Nadie puede investigar a fondo cada compra, cada mensaje y cada decisión. Por eso cada día dependemos más de los atajos. Y por eso cada día hay más gente que los quiere usar para sacar provecho.

> Quien usa una señal verdadera te está ayudando a decidir. Quien la falsifica te está robando la decisión.

### Aliada o tramposa
Esta es la distinción más importante del curso. Hay dos formas de usar los atajos:
- **La aliada** te da información verdadera para que decidas rápido y bien. "Es el más vendido" (y lo es). "Me lo dio mi dermatóloga" (y es cierto). "La promo termina el viernes" (y termina). Te ahorra tiempo y te ayuda.
- **La tramposa** inventa la señal. Comentarios falsos, urgencia inventada, títulos que no tiene, precios "antes" que nunca existieron. No solo te engaña a ti: echa a perder el atajo para todos, porque cada vez creemos menos.

Tú quieres ser la aliada de tus clientas. Y, cuando te toque estar del otro lado, tienes derecho a no comprarle a la tramposa y a decirle por qué.

### Las seis preguntas de la aliada
Antes de usar cualquier atajo, pregúntate:
1. **Te doy.** ¿Lo que doy sirve aunque no me compre?
2. **Lo dije.** ¿El compromiso lo eligió ella, sin presión?
3. **Todas lo hacen.** ¿Lo que cuento de otras clientas es cierto?
4. **Me caes bien.** ¿Mi cercanía es real, y le dejo fácil decirme que no?
5. **Ella sabe.** ¿Sé de verdad lo que estoy diciendo?
6. **Se acaba.** ¿La fecha o el límite son reales?

Si alguna respuesta es no, cambia lo que vas a hacer.

### Tu negocio a largo plazo
En venta directa tu nombre es tu negocio. Vives de clientas que regresan y de amigas que te recomiendan. La presión puede traer una venta hoy. La honestidad te trae a la misma clienta por años, y a sus amigas.

### 🪞 Para pensar
¿Cuál de los seis atajos usas más sin darte cuenta? ¿Lo usas como aliada?

### ✍️ Escribe
Escribe tu propia regla para vender, en una frase. Por ejemplo: "Solo digo lo que es cierto y siempre dejo fácil el no."

### ✅ Para cerrar el curso
- Pega tu regla donde la veas.
- Usa el checklist de la siguiente herramienta antes de tu próxima promoción.

### 💬 Para tu equipo
Compartan sus reglas en el grupo. Con las mejores, armen la regla del equipo.

## 9 · Tu checklist del sí
*Herramientas · Seis preguntas antes de pedir*

Usa esta lista antes de una promoción, una reunión o un mensaje de venta. Tarda dos minutos.

### Antes de pedir
- **¿Di algo primero?** Una muestra, un consejo, una rutina. ¿Sirve aunque no compre?
- **¿Le pregunté su meta?** ¿Ella dijo con sus palabras qué quiere?
- **¿Tengo un testimonio real de alguien parecido a ella?** ¿Tengo permiso para compartirlo?
- **¿Le dejé fácil el no?** ¿Le dije que no pasa nada si no compra?
- **¿Sé lo que estoy diciendo?** ¿Mencioné un punto débil honesto?
- **¿La fecha o el límite son reales?** ¿Avisé con tiempo?

### Las palabras que evitas
- "Última oportunidad" (si no lo es).
- "Todas lo están comprando" (si no es cierto).
- "Antes costaba…" (si nunca costó eso).
- "Te va a quitar las manchas" o cualquier promesa de salud.
- "Ni modo que no me apoyes."

### Las frases que sí
- "Te recomiendo este porque…"
- "¿Qué te gustaría ver en tu piel en un mes?"
- "A una clienta con tu tipo de piel le funcionó así."
- "Si no te late, cero pena."
- "Es más caro que el de farmacia, pero te dura el doble."
- "La promo dura hasta el viernes. Te aviso con tiempo."

### ✍️ Escribe
Pasa tu próximo mensaje de venta por esta lista y reescríbelo aquí.

## 10 · Tu escudo
*Herramientas · Cómo decir que no cuando te lo aplican a ti*

A ti también te venden. Clientas, proveedores, cursos, redes y a veces hasta tu propio negocio. Esta es tu guía rápida para notar el atajo y decidir con calma.

### La señal y la pregunta de cada atajo
- **Te doy.** Señal: sientes que "le debes". Pregunta: ¿fue un regalo o una herramienta de venta? Si fue herramienta, no debes nada.
- **Lo dije.** Señal: nudo en el estómago de "no quiero, pero ya dije". Pregunta: sabiendo lo que hoy sé, ¿volvería a decir que sí?
- **Todas lo hacen.** Señal: "si todas lo tienen, ha de ser bueno". Pregunta: ¿la evidencia es real y es de gente como yo?
- **Me caes bien.** Señal: esta persona te cayó mejor de lo que esperabas en poco tiempo. Pregunta: ¿qué pensaría del producto si me lo ofreciera alguien que no conozco?
- **Ella sabe.** Señal: título, ropa o seguidores. Preguntas: ¿de verdad sabe de esto? ¿Qué gana si le hago caso?
- **Se acaba.** Señal: prisa y calor en el cuerpo. Pregunta: ¿lo quiero para tenerlo o para usarlo?

### En tu negocio
Las mismas reglas aplican cuando alguien te quiere convencer de comprar inventario, subir de nivel este mes o meterte a una promoción. Usa el escudo igual:
- Nunca compres inventario con dinero que no tienes.
- Una meta tuya se cuida, pero si ya no te hace sentido, puedes cambiarla.
- "Se acaba el mes" no es una razón para endeudarte.

### Frases para decir que no
- "Gracias, lo voy a pensar con calma y te aviso."
- "Hoy no, pero me encantó platicar contigo."
- "No compro con prisa. Si sigue mañana, lo veo."
- "Ya no me hace sentido lo que dije, y prefiero decírtelo."

### ✍️ Escribe
Escribe una situación en la que te cuesta decir que no y la frase que vas a usar la próxima vez.

## 11 · Para líderes
*Herramientas · Los seis atajos en tu equipo*

Si diriges un equipo, los atajos también aparecen al motivar, al reclutar y al dar el ejemplo. Aquí tienes cómo usarlos sin presionar.

### Te doy
Dale a tu equipo antes de pedirle: capacitación, tiempo, una llamada cuando lo necesitan. Un equipo que recibe, responde.

### Lo dije
Que cada una escriba su propia meta, con sus números y sus tiempos. No le pongas la tuya. Revísenla juntas cada mes y deja que la cambie si su vida cambió.

### Todas lo hacen
Comparte historias reales de compañeras parecidas a ella, no solo de las que más venden. "Una mamá que trabaja de tiempo completo empezó con dos clientas por semana" inspira más que el top del mes.

### Me caes bien
Celebra en público, corrige en privado. Busquen metas en común como equipo. La cercanía real es lo que hace que una se quede.

### Ella sabe
Sé la que sabe del producto y del negocio, y di lo que no sabes. Nunca prometas ingresos ni pongas como normal un caso excepcional.

### Se acaba
Usa fechas reales (cierres, lanzamientos) y avisa con tiempo. Nunca uses "se acaba el mes" para que alguien compre lo que no puede pagar.

### Al reclutar
Cuenta lo bueno y lo difícil. Una invitada que entra sabiendo todo se queda. Una que entró con presión se va, y se va enojada.

### ✍️ Escribe
Escoge un atajo que vas a usar mejor con tu equipo este mes y escribe cómo.
