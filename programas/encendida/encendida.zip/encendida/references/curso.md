# Encendida · contenido completo del curso

Cada bloque empieza con: @@ número | sección | título | subtítulo

@@ 0 | Empieza aquí | Bienvenida a Encendida | Lo básico, bien hecho, en 40 días
Encendida es el punto de partida: el curso para dejar de ver las redes como algo abrumador y empezar a usarlas como una herramienta real para crecer. No es magia ni "inspírate y ya". Es estructura, claridad y hacer lo básico bien.

## Qué vas a aprender
- A entender para qué sirve cada red y cada formato.
- A dejar tu perfil listo para atraer, no solo para existir.
- A conocer a tu clienta ideal y hablarle directo.
- A crear contenido con intención, no por impulso.
- A abrir conversaciones reales con tus historias.

## Cómo funciona
Son 9 clases cortas, 3 retos y 4 herramientas. Avanza a tu ritmo, pero ponte una meta: **terminar en 40 días**. Puedes saltar a cualquier clase desde el menú; si es tu primera vez, te recomendamos ir en orden.

Tres momentos para revisarte:
- **Día 1:** lee esta bienvenida, cambia algo de tu perfil y preséntate en el grupo.
- **Día 20:** anota qué ya aplicaste y qué te falta.
- **Día 40:** haz el cierre y decide tu siguiente paso.

## Esto es un maratón, no una carrera de 100 metros
Nadie corre un maratón sin saber cuál, dónde ni cuándo. En redes pasa igual: si no sabes para qué publicas, cómo vas a vender ni a quién le hablas, estás corriendo sin rumbo. Define desde hoy qué vendes, a quién y cuánto te gustaría que eso te dejara al mes. Ponerle número a tu meta no es ambición fea: es dirección.

## Seguidores no es lo mismo que ventas
Aquí no estamos formando influencers. Estamos formando mujeres que venden un producto o servicio. Hay cuentas con cien mil seguidores que venden menos que una de diez mil. La diferencia está en la claridad, en la confianza que generas y en tener un sistema.

## Los pensamientos que te van a querer frenar
"Me van a criticar", "nadie me ve", "esto no es para mí". Esos pensamientos le llegan a todas, empiecen o lleven años. No se apagan con un número de seguidores. La diferencia es si te quedas ahí o lo haces a pesar de ellos. Quédate con la gente a la que sí inspiras: muchas te ven en silencio aunque no te escriban.

> Lo que no está en tus hábitos se siente difícil. Crear contenido tiene que volverse tan normal como lavarte los dientes.

## 🪞 Mírate al espejo
Del 1 al 10, ¿qué tanto dominas hoy tus redes? Sé honesta. ¿Qué piensas de las redes sociales: que son difíciles, que no son para ti, que son una oportunidad?

## ✍️ Ejercicio
1. Escribe **qué vendes** y **a quién** en una sola frase.
2. Escribe tu **meta para estos 40 días** (algo que puedas medir: publicar 4 veces por semana, abrir 10 conversaciones, terminar tu perfil).
3. Escribe **el pensamiento que más te frena** y una frase con la que le vas a contestar.

## ✅ Tu tarea
Sube una historia contando que empezaste este curso y por qué lo estás haciendo.

## 💬 Para compartir en el grupo
Preséntate en una línea: qué haces y para quién lo haces.

@@ 1 | Clase 1 | Para qué sirven las redes | Primero entretienen, luego venden
Antes de pensar en qué publicar, hay que entender para qué existen las redes y para qué te sirve cada una. Si no, terminas usando tu perfil como catálogo y te preguntas por qué nadie compra.

## Las redes se hicieron para entretener
Pregunta clave: ¿para qué existen las redes sociales? No para vender. Se crearon para entretener, distraer y conectar, como en su momento la televisión. Los comerciales existen, pero no son el programa. El error más común es querer vender primero y conectar después. Es al revés: **entretienes, conectas emocionalmente y desde ahí te compran.**

> La pregunta no es "¿cómo vendo más?". Es "¿cómo puedo entretener a la gente que quiero atraer con lo que hago?".

## Instagram: presencia, comunidad y conversión
Es visual, pero tiene mucho potencial para crear comunidad, posicionarte y vender. Sirve para construir una imagen coherente, mostrar tu proceso y tu estilo de vida, y educar. Aquí publicas reels, carruseles, fotos, historias y lives, y conviertes seguidoras en clientas con destacadas, link y mensajes directos.

## Facebook: comunidad, servicio y anuncios
Mucha gente cree que "ya no se usa", pero sigue siendo muy útil. Sirve para grupos privados, para una página profesional donde centralizas tu información y para anuncios pagados (comparte sistema de anuncios con Instagram). Tiene botones como "Más información" o "WhatsApp" para contacto directo.

## TikTok: alcance orgánico y autenticidad
Es la red de video corto que más alcance da a cuentas nuevas o pequeñas. Sirve para que te descubra gente que todavía no te sigue, mostrar tu personalidad de forma simple y llevar tráfico a tus otras redes.

## ¿Cuál elijo primero?
No necesitas estar en todas al mismo tiempo. Empieza con la que te salga más natural y luego crece con estrategia.
- ¿Quieres crear comunidad y mostrar tu proceso? → **Instagram**.
- ¿Quieres algo más estructurado o hacer anuncios? → **Facebook**.
- ¿Quieres que te descubra más gente aunque estés empezando? → **TikTok**.

## 🪞 Mírate al espejo
Hoy, ¿tu perfil se parece más a un catálogo o a un lugar donde la gente se queda?

## ✍️ Ejercicio
1. Elige tu **red principal** para estos 40 días y escribe por qué.
2. Responde la pregunta clave: escribe **5 formas de entretener** a tu clienta usando tu producto o servicio (usarlo en tu día, un antes y después, un error común, una historia, un reto).

## ✅ Tu tarea
Publica una de esas 5 ideas esta semana.

## 💬 Para compartir en el grupo
Comparte tu mejor idea para entretener con lo que vendes.

@@ 2 | Clase 2 | Tu vitrina de confianza | Publicar no es lo mismo que vender
Las redes ya no son un hobby ni cuestión de suerte. Hoy son una vitrina donde la gente se asoma para decidir si confía en ti.

## Subir no es avanzar
Pasar ocho horas en el celular no es tener una estrategia. Publicar todos los días sin rumbo cansa, frustra y te hace pensar "esto no es para mí". Es mejor publicar menos, con intención, que publicar por publicar.

## La joyería
Imagina que entras a una joyería. En segundos sabes si lo que ves se siente de calidad o se siente hueco. Tu perfil funciona igual: quien llega por primera vez decide en segundos si se queda, te sigue o se va.

## Qué tiene que ver alguien que llega a tu perfil
- **Tu promesa:** qué haces y para quién, clarito.
- **Resultados y testimonios:** es lo que más genera confianza. Satura de resultados reales.
- **Quién eres:** tu historia corta, para que conecten contigo.
- **Tú saliendo a cuadro:** las publicaciones donde sales tú casi siempre conectan más que las fotos de producto solas.
- **Una forma fácil de contactarte.**

## El orden importa
Si tu promesa es grande y lo primero que encuentran es el catálogo de la empresa, la expectativa baja. Primero la promesa, luego la prueba (resultados), luego quién eres y al final el producto. Tu vida personal sí cabe, pero conectada a tu promesa.

## Menos ruido, más claridad
Muchas tipografías, muchos colores, mucho texto o imágenes que no son tuyas saturan la vitrina. Humaniza tu marca: muestra tu proceso y sal tú.

> Si alguien que no te conoce entra a tu perfil, ¿entendería en 5 segundos qué haces y por qué confiar en ti?

## 🪞 Mírate al espejo
Escribe en una frase qué crees que proyecta tu perfil. Luego pídele a alguien que no te conozca tanto que te diga qué proyecta. ¿Coincide?

## ✍️ Ejercicio
Usa el **Checklist de tu vitrina** (en Herramientas) y califícate del 1 al 10 en cada punto. Elige los 2 más bajos.

## ✅ Tu tarea
Arregla esos 2 puntos esta semana.

## 💬 Para compartir en el grupo
Comparte tu perfil y la frase de lo que quieres que proyecte. Pide una opinión honesta.

@@ 3 | Clase 3 | Los formatos de Instagram | Cada uno tiene su trabajo
Es normal confundirse con todo lo que ofrece Instagram. Cada formato tiene una función. Saber cuál usar te ahorra tiempo y hace que tu mensaje llegue.

## Post
Una imagen o video en tu cuadrícula. Es lo que ven cuando visitan tu perfil. Sirve para una idea puntual, una foto profesional, un resultado o una promoción. Es permanente. El diseño y el texto importan: háblale a tu clienta ideal, no a "todo el mundo".

## Carrusel
Hasta 10 imágenes o textos que se deslizan. Sirve para enseñar paso a paso, contar una historia, mostrar un antes y después o dar varios consejos. Es de los mejores formatos para educar y vender sin ser invasiva. La primera imagen es el gancho: tiene que invitar a deslizar.

## Reel
Video vertical corto. Es el formato que más alcance le da a gente que todavía no te sigue. Sirve para entretener, educar rápido y mostrar tu personalidad.

## Historias
Fotos o videos verticales que duran 24 horas. Sirven para tu día a día, detrás de cámaras, encuestas y preguntas. Son tu espacio de cercanía. Lo imperfecto vende: no tienen que verse tan producidas.

## Destacadas
Historias que guardas debajo de tu bio. Son el menú de tu perfil, como una mini página web. Sirven para resumir quién eres, qué vendes, resultados, testimonios y preguntas frecuentes. Usa portadas coherentes y agrupa por tema.

## No uses todo a la vez
Empieza por el que más te acomode. Pero recuerda: tu audiencia necesita verte, entenderte y sentir que estás presente.

## 🪞 Mírate al espejo
¿Qué formato usas más? ¿Es porque te funciona o porque es el más cómodo?

## ✍️ Ejercicio
Para tu negocio, escribe **una idea para cada formato**: un post, un carrusel, un reel, una historia y una destacada.

## ✅ Tu tarea
Publica tu primer carrusel educativo esta semana.

## 💬 Para compartir en el grupo
Comparte la portada de tu carrusel y pregunta si te dan ganas de deslizar.

@@ 4 | Clase 4 | Configura tu cuenta | Un local con letrero y luces prendidas
Una cuenta mal configurada es como un local sin letrero, sin entrada clara y con las luces apagadas. Antes de pensar en qué publicar, deja tu perfil listo para recibir visitas y convertirlas.

## Nombre de usuario y nombre de perfil
Piensa cómo te buscaría alguien que no te conoce pero te necesita. En el nombre de perfil incluye lo que haces o a quién ayudas, no solo tu nombre. Así apareces cuando buscan ese tema.

## Tu bio: tu presentación en segundos
Una fórmula sencilla:

> Te ayudo a **[resolver qué problema]** · **cómo** lo hago · **en cuánto tiempo** o con qué resultado.

Usa emojis para guiar la vista, no para rellenar. Evita frases vagas como "hacemos tus ideas realidad": di qué haces exactamente. Si tu promesa suena igual a la de todas, ponte creativa y especifícala más.

## El link
Ponlo a trabajar. Si atiendes por WhatsApp, pon el link directo a WhatsApp: convierte más que mandar a la gente a otra red. Usa verbos de acción: "Escríbeme", "Quiero mi guía", "Agenda aquí".

## Cuenta profesional
Si tu cuenta es personal, cámbiala a **Profesional** o **Creadora**. Así ves estadísticas y puedes agregar botones de contacto. Activa el botón de WhatsApp si atiendes por ahí.

## Destacadas en orden
Un orden que funciona:
1. **Resultados / testimonios**
2. **Quién soy** (tu historia corta)
3. **Qué ofrezco** (producto o servicio)
4. **Preguntas frecuentes**
5. **Cómo empezar** (contacto)

Mantenlas al día: una destacada con promociones de hace meses se ve abandonada.

## 🪞 Mírate al espejo
Lee tu bio como si no te conocieras. ¿Entiendes qué haces, para quién y qué hacer después?

## ✍️ Ejercicio
1. Reescribe tu **nombre de perfil** con lo que haces.
2. Escribe **3 versiones de tu bio** con la fórmula y elige una.
3. Haz la lista de tus **destacadas** en el orden de arriba.

## ✅ Tu tarea
Cambia tu bio, tu link y tus destacadas esta semana.

## 💬 Para compartir en el grupo
Comparte tus 3 versiones de bio y deja que el grupo vote.

@@ 5 | Clase 5 | Tu clienta ideal | A quién le hablas cuando publicas
Si le hablas a todo el mundo, nadie siente que le hablas a ella. Esta clase es para conocer a esa persona tan bien que sepas qué decirle antes de que conozca tu producto.

## Ponle cara
Dale nombre, edad y ciudad. Luego responde:
- ¿A qué se dedica?
- ¿Qué lugares frecuenta?
- ¿Qué hobbies tiene?
- ¿Qué es lo más importante para ella al comprar? (precio, calidad, rapidez, confianza)
- ¿Qué problema tiene hoy?

## Qué consume
¿A qué cuentas sigue? ¿Qué tienen en común esas cuentas? ¿De qué hablan? Observarlas te dice qué tipo de contenido ya le gusta. Y anota las **preguntas frecuentes** que busca resolver: cada una es un contenido.

## La venta no depende del producto
Ni siquiera del precio. Depende de que tengas claro **el resultado final** que va a tener tu clienta. Lo que separa un producto que se vende de uno que no es el foco: saber qué gran problema resuelve.

## Su día antes y después de ti
Llena este cuadro:

| | Antes de conocerte | Después de conocerte |
|---|---|---|
| Tiene | | |
| Siente | | |
| Su día es | | |
| Su estado | | |

Ejemplo (servicio de organización para mamás que trabajan): antes tiene pendientes por todos lados, siente que no le alcanza el día, su día es correr de un lado a otro. Después tiene una rutina sencilla, se siente tranquila y le sobra un rato para ella.

## Tu diferenciador
Termina con tres preguntas:
1. ¿Cuáles son los beneficios de tu producto o servicio?
2. ¿Qué hace diferente tu propuesta?
3. ¿Qué pierde tu clienta si no lo tiene?

> Vender no es solo dinero: es ayudar a alguien a tomar una buena decisión. Allá afuera hay alguien que necesita lo que tú tienes.

## 🪞 Mírate al espejo
¿Tu clienta ideal se parece a ti antes de resolver lo que hoy ya resolviste?

## ✍️ Ejercicio
Llena la **Ficha de tu clienta ideal** completa (en Herramientas), incluyendo el cuadro de antes y después.

## ✅ Tu tarea
Convierte 5 de sus preguntas frecuentes en 5 ideas de contenido.

## 💬 Para compartir en el grupo
Comparte tu cuadro de antes y después.

@@ 6 | Clase 6 | Tu voz es tu diferencia | Ser repetitiva, verdadera y constante
El producto se lo pueden comprar a cualquiera. Lo que hace que te lo compren a ti es tu voz: cómo explicas, cómo acompañas, lo que vives.

## Qué es una marca personal
Es todo lo que comunicas cuando hablas y cuando no hablas. Es lo que la gente dice de ti cuando no estás. El objetivo: que cuando alguien tenga el problema que tú resuelves, la primera persona en la que piense seas tú.

## El secreto: ser repetitiva
La gente pasa por 15 o 20 cuentas en menos de un minuto. Para que te recuerden, tu mensaje tiene que repetirse una y otra vez, de forma entretenida. No necesitas la estrategia más difícil; necesitas la que puedas sostener.

## La estrategia que sí sostienes es la verdadera
La que ya vives todos los días. Si tu contenido sale de tu vida real, nunca se te acaba. Cuando dices "no sé qué subir", muchas veces significa que no estás aprendiendo nada nuevo. Lee, escucha, toma clases, practica: lo que aprendes y vives es contenido.

## Tu resultado va de la mano de tu crecimiento
No se pueden vender sueños luciendo como pesadilla. La primera que tiene que vivir inspirada eres tú. Y la inspiración está en la acción: tu historia número 50 hablando a cámara va a ser mucho mejor que la primera, pero solo si haces la primera.

## Sobre las críticas
Mientras más pública te haces, más vas a incomodar a cierto tipo de gente. No puedes controlar el ojo de quien te mira. Si quisieras gustarle a todo el mundo, no hay curso que enseñe eso. Quédate con quienes sí inspiras.

## Educar con autoridad
Si sientes que te cuesta el contenido educativo, trabaja en tu tema: ¿desde dónde quieres que te vean como referente? Ninguna cuenta inspira "nada más porque sí": inspira porque se dedica a algo, porque muestra algo real.

## 🪞 Mírate al espejo
Si alguien tiene el problema que resuelves, ¿hoy pensaría en ti? ¿Por qué sí o por qué no?

## ✍️ Ejercicio
1. Escribe **la frase** por la que quieres que te recuerden (tu mensaje repetitivo).
2. Escribe **5 formas distintas** de decir ese mismo mensaje (historia, consejo, error común, ejemplo de tu día, pregunta).
3. Elige **una cosa que vas a aprender** este mes para tener más que aportar.

## ✅ Tu tarea
Graba una historia hablando a cámara con tu mensaje, aunque no salga perfecta.

## 💬 Para compartir en el grupo
Comparte tu frase y pide al grupo que te diga si te la creen.

@@ 7 | Clase 7 | Los 3 pilares que sí venden | Qué subir y qué día
Ya sabes a quién le hablas y desde dónde. Ahora toca ordenar qué publicas. Tres tipos de contenido, en proporciones que no cansan a nadie.

## Los tres pilares
- **Estilo de vida y entretenimiento — 40%:** tu día, tu proceso, tus gustos, humor, detrás de cámaras. Conecta.
- **Educativo — 40%:** enseñas algo útil de tu tema. Da autoridad.
- **Venta — 20%:** tu producto, tu servicio, tu invitación. Convierte.

Vender sí se vale. Lo que no funciona es llenar tus historias de flyers de promoción.

## Una semana sugerida
Cuatro publicaciones a la semana, más historias diarias:
- **Lunes y martes — educativo.** La gente empieza la semana con ganas de aprender.
- **Jueves — entretenimiento o venta.** Ya están cansadas y quieren distraerse.
- **Domingo — motivación y estilo de vida.** Es un día más emocional: entra bien lo aspiracional y lo inspirador.

No está escrito en piedra. Es un punto de partida para probar.

## Los horarios se testean
"¿A qué hora subo?" no tiene una respuesta para todas. Prueba en la mañana, en la tarde y en la noche, observa qué pasa con tu contenido y repite lo que mejor te funcione. Una pista: el educativo suele funcionar mejor en la mañana, cuando la gente está fresca, y el entretenimiento en la noche.

## Vender de forma entretenida
En lugar de 10 historias con fotos de promociones, haz una historia bien pensada: te arreglas o usas los productos mientras platicas, muestras lo que está en promoción y cierras con "escríbeme y te mando la lista". Vendiste sin saturar.

## 🪞 Mírate al espejo
Mira tus últimas 9 publicaciones. ¿Qué porcentaje es venta? ¿Cuál pilar te falta?

## ✍️ Ejercicio
Llena el **Plan semanal** (en Herramientas): una idea por día con su pilar.

## ✅ Tu tarea
Publica las 4 publicaciones de la semana y anota la hora en que subiste cada una.

## 💬 Para compartir en el grupo
Comparte tu plan semanal.

@@ 8 | Clase 8 | Organiza tu contenido | Ir un paso adelante
La organización es la base de una marca personal que se sostiene. Si vas al día, el día que se enferma tu hijo o tienes mucho trabajo, desapareces.

## Un stock de una semana
Ten mínimo **una semana de contenido educativo listo** por adelantado. Algunas prefieren dos. Así, en una semana difícil, lo único que tienes que hacer es publicar. Las tendencias las agregas sobre la marcha.

## Elige la herramienta que menos fricción te dé
Un tablero digital (como Trello o Notion), las notas del celular o una libreta impresa. Lo importante es que vacíes tus ideas por día: qué vas a publicar, qué formato, qué texto lleva. Si una aplicación te angustia, a la antigüita con tu libreta.

## Menos es más
Al inicio, empieza sencillo:
- **Imagen:** cabello presentable, piel cuidada, maquillaje natural, ropa básica. Si la pared es de color, mejor una blusa lisa.
- **Lugar:** encuentra tu rincón con buena luz y repítelo.
- **Edición:** cortes para quitar silencios, música bajita (como 5 de 100), tipografía sencilla y centrada, dentro de la zona segura de la pantalla.
- **Expresiones:** no tienes que exagerar para transmitir.

## Tu dicción importa más que los efectos
Un video sencillo, con buena luz y un mensaje claro, gana. Practica hablando frente al espejo, como si alguien te escuchara. Se entrena.

## Consume lo que quieres crear
Mira cuentas que admires y fíjate en sus tipografías, audios, lugares y edición. Así se educa tu ojo.

## El hábito, como en el gimnasio
Al inicio tienes que ser muy disciplinada. Si un día fallas, no tires la semana: vuelves al día siguiente. Ese es el hábito.

## 🪞 Mírate al espejo
¿Cuántas veces esta semana publicaste "porque tocaba" sin haberlo planeado?

## ✍️ Ejercicio
1. Elige tu **herramienta** (tablero, notas o libreta).
2. Escribe **7 ideas de contenido educativo** listas para grabar.
3. Elige tu **rincón de grabación** y pruébalo con luz de día.

## ✅ Tu tarea
Graba y deja listo tu stock de una semana.

## 💬 Para compartir en el grupo
Comparte una foto de tu tablero o de tu libreta.

@@ 9 | Clase 9 | Historias que retienen | Cuéntalo en una, no en veinte
Las historias son tu espacio diario de cercanía. Pero si cuentas algo en 20 historias, la gente se va a la tercera. Esta clase es para decir más con menos.

## Edita antes de subir
Graba con la cámara del celular, corta silencios, repeticiones y lo que no aporta, y súbelo como una sola historia de un minuto. Una historia que retiene a la gente completa le dice a la plataforma que tu contenido entretiene.

## La regla de las 6 o 7
Si llevas 6 o 7 historias y no has terminado de contar lo que te pasó, hay que mejorar cómo comunicas. Verte y editarte también te entrena a hablar mejor.

## Observa tus números
Fíjate en qué historia empiezan a irse. Si siempre bajan en la tercera, ahí está tu pista: más corto, más directo, más entretenido.

## Promociones en dos historias
Reto creativo: muestra todo lo que tienes en promoción en **máximo dos historias**. Actúa, maquilla a alguien, sal a la calle, cuéntalo como si fuera un programa. Mientras más creativa, mejor.

## Historias diarias, sin agotarte
No necesitas contar toda tu vida. Una mañana, un proceso, un aprendizaje, una pregunta. Poco, bien contado, todos los días.

## 🪞 Mírate al espejo
Revisa tus historias de ayer. ¿Cuántas eran? ¿En cuál empezaron a irse?

## ✍️ Ejercicio
Toma algo que contarías en 5 historias y escríbelo para contarlo en **1 historia de un minuto**: inicio que atrape, lo importante, cierre.

## ✅ Tu tarea
Haz el reto de promociones en dos historias.

## 💬 Para compartir en el grupo
Comparte tu historia del reto y lo que aprendiste editando.

@@ 10 | Reto 1 | Cuatro historias que abren conversación | Dolor, confrontación, valor y palabra clave
Este reto es para dejar de crear contenido que solo entretiene y empezar a abrir conversaciones reales. El objetivo es guiar a la persona correcta a tomar una decisión. Puedes hacer los retos en el orden que quieras; uno por semana es más que suficiente.

## Cómo se hace
Sube 4 historias seguidas, habladas o con texto e imagen. No necesitas producción perfecta: lo que importa es el mensaje y el orden. No te saltes pasos ni mezcles historias.

## Historia 1 · Dolor
Aquí no vendes, conectas. Habla de algo que tu clienta vive y ya normalizó, aunque le cueste tiempo, energía o dinero. Nada de soluciones ni de "yo te ayudo".

> "Sentirte ocupada todo el día y aun así sentir que no avanzaste no es falta de tiempo… es falta de estructura."

## Historia 2 · Confrontación
La haces pensar. No atacas, pero incomodas lo suficiente para mover algo. Una pregunta o afirmación directa que la invite a hacerse responsable, sin culpa.

> "¿Cuántas veces has dicho 'luego lo organizo'? Seguir sin un sistema también es una decisión."

## Historia 3 · Valor
Demuestras que sabes. Una idea clara y práctica que la haga pensar "esto tiene sentido". Nada de frases bonitas vacías.

> "Casi siempre te sientes saturada no por tener demasiadas cosas, sino por no tener prioridades. Elige solo 3 tareas clave al día."

## Historia 4 · Palabra clave
Ahora sí invitas, sin pena. No vendes el producto: invitas a platicar. Sé clara, usa una palabra clave y que se sienta personal.

> "Si te sentiste identificada y quieres organizarte distinto, respóndeme 'ORDEN' y te cuento cómo."

## No funciona si…
Quieres vender desde la primera historia o suenas genérica. Funciona cuando respetas el orden, hablas claro y confías en el proceso.

## ✍️ Ejercicio
Escribe tus 4 historias en tu cuaderno antes de grabarlas, una por bloque.

## ✅ Tu tarea
Súbelas en un mismo día y cuenta cuántas personas respondieron con tu palabra clave.

## 💬 Para compartir en el grupo
Comparte captura de tus 4 historias para recibir comentarios.

@@ 11 | Reto 2 | Mi verdadero diferencial | Lo común, mi forma y por qué cambia todo
Deja de decir "soy diferente" y empieza a explicar por qué. No desde el ego, desde el enfoque. Este reto construye autoridad sin vender.

## Cómo se hace
Tres historias seguidas. Nada de precios, promociones ni invitaciones. Habla desde tu experiencia, no desde la teoría.

Antes de grabar, pregúntate: ¿qué hace la mayoría en mi tema? ¿Qué hago yo distinto en el proceso, no solo en el resultado?

## Historia 1 · Lo común
Describe lo normal en tu industria. No ataques, solo observa. "La mayoría se enfoca en…", "Muchas hacen…".

> "La mayoría cree que ser productiva es hacer más."

## Historia 2 · Mi forma
Explica tu enfoque. "Yo trabajo desde…", "Mi enfoque es…".

> "Yo trabajo desde la claridad de prioridades."

## Historia 3 · Por qué cambia todo
Conecta tu forma con lo que vive tu clienta. "Y eso importa porque…".

> "Porque cuando sabes qué sí importa, dejas de vivir agotada."

## Para qué te sirve
Para comunicar tu valor sin forzarlo, diferenciarte sin gritar y empezar a sonar como referente. Y para dejar de compararte.

## ✍️ Ejercicio
Escribe tus 3 historias usando las fórmulas.

## ✅ Tu tarea
Súbelas y anota qué mensajes te llegaron.

## 💬 Para compartir en el grupo
Comparte tu historia 2: tu forma.

@@ 12 | Reto 3 | Un pensamiento que no digo seguido | Humanízate sin desbordarte
Este reto rompe la imagen de perfección y genera cercanía real. No es terapia: es una verdad bien comunicada.

## Cómo se hace
Una sola historia hablada, de 30 a 60 segundos, sin leer guion y con tono tranquilo.

Antes de grabar, pregúntate: ¿qué pienso pero casi no digo por miedo a verme vulnerable?

## La estructura
1. **Nombra el pensamiento.**
2. **Dilo sin drama.**
3. **Cierra con conciencia**, no con una solución.

## Ejemplos
> "Hay días en los que dudo si voy por buen camino. Y aun así sigo, porque entendí que dudar no es retroceder."

> "A veces también me canso de sostener todo. La diferencia es que hoy ya no me juzgo por sentirlo."

## Cuida el límite
Comparte lo que ya procesaste, no una herida abierta. Si algo todavía te duele mucho, no es para historias: es para hablarlo con alguien de confianza.

## Para qué te sirve
Más respuestas reales, más identificación y menos miedo a mostrarte.

## ✍️ Ejercicio
Escribe tu pensamiento en una frase y tu cierre en otra. Luego grábalo sin leer.

## ✅ Tu tarea
Súbelo y responde con cariño cada mensaje que te llegue.

## 💬 Para compartir en el grupo
Cuenta cómo te sentiste antes y después de subirlo.

@@ 13 | Cierre | Día 40 | Lo que ya cambió y tu siguiente paso
Llegaste al final. Eso no es casualidad: es una decisión que tomaste contigo. Ahora toca mirar hacia atrás para ver lo que ya cambió y decidir qué sigue.

## Revisa tu antes y después
Compara tu perfil de hoy con el del día 1: tu bio, tus destacadas, tu forma de hablar en historias, tu constancia. Tómale captura y guárdala.

## Lo que ya tienes
- Tu red principal elegida.
- Tu perfil configurado para atraer.
- Tu clienta ideal clara.
- Tu mensaje repetitivo.
- Tus 3 pilares y tu plan semanal.
- Tu stock de contenido.
- Tres retos que abren conversaciones.

## Lo que sigue
Lo básico ya está. Si quieres trabajar a fondo tu marca, tu historia y tus ventas, el siguiente paso natural es **Visible**. Si lo que más te cuesta es la constancia y organizarte, **Ritmo** es para ti.

## 🪞 Mírate al espejo
¿Qué hiciste en estos 40 días que antes no te atrevías a hacer?

## ✍️ Ejercicio
1. Escribe **3 cosas que ya cambiaste**.
2. Escribe **3 cosas que te faltan**.
3. Elige **tu siguiente paso** y ponle fecha.

## ✅ Tu tarea
Sube una historia contando qué aprendiste en este curso.

## 💬 Para compartir en el grupo
Comparte tu antes y después de perfil.

@@ 14 | Herramientas | Ficha de tu clienta ideal | Para hablarle directo
Llénala con calma. Mientras más concreta, más fácil vas a saber qué publicar.

## Datos básicos
- Nombre:
- Edad:
- Ciudad:
- ¿A qué se dedica?
- ¿Qué lugares frecuenta?
- ¿Qué hobbies tiene?
- ¿Qué le importa más al comprar?
- ¿Qué problema tiene hoy?
- Descríbela en 10 palabras:

## Lo que consume
- 5 cuentas que sigue:
- ¿Qué tienen en común esas cuentas?
- ¿De qué hablan?
- 5 preguntas frecuentes que quiere resolver:

## Antes y después de ti
| | Antes | Después |
|---|---|---|
| Tiene | | |
| Siente | | |
| Su día es | | |
| Su estado | | |

## Tu diferenciador
- Beneficios de tu producto o servicio:
- Lo que hace diferente tu propuesta:
- Lo que pierde si no lo tiene:

@@ 15 | Herramientas | Tu perfil en 10 minutos | Bio, link y destacadas
Una guía rápida para dejar tu perfil listo.

## Nombre de perfil
Tu nombre + lo que haces. Ejemplo: "Ana · Organización para mamás".

## Bio
> Te ayudo a [problema] · [cómo] · [en cuánto tiempo o con qué resultado]
> [Una línea de quién eres o tu toque personal]
> 👇 [Llamada a la acción]

## Link
Directo a WhatsApp o a lo que quieres que hagan. Texto con verbo: "Escríbeme aquí".

## Destacadas, en este orden
1. Resultados / testimonios
2. Quién soy
3. Qué ofrezco
4. Preguntas frecuentes
5. Cómo empezar

## Configuración
- Cuenta profesional o de creadora.
- Botón de contacto o WhatsApp activado.
- Foto de perfil donde se te vea la cara, con buena luz.

@@ 16 | Herramientas | Plan semanal | Cuatro publicaciones con intención
Copia esta tabla en tu libreta o tablero cada semana.

## La semana
| Día | Pilar | Formato | Idea | Hora |
|---|---|---|---|---|
| Lunes | Educativo | | | |
| Martes | Educativo | | | |
| Jueves | Entretenimiento o venta | | | |
| Domingo | Motivación / estilo de vida | | | |

## Historias diarias
- Mañana: algo de tu día o tu rutina.
- Tarde: un aprendizaje, un proceso o una pregunta.
- Una vez por semana: un reto o una invitación con palabra clave.

## Al final de la semana
- ¿Cuál publicación funcionó mejor?
- ¿A qué hora la subiste?
- ¿Qué repites la próxima semana?

@@ 17 | Herramientas | Checklist de tu vitrina | Califícate del 1 al 10
Revisa tu perfil como si fueras alguien que llega por primera vez.

## Califica cada punto del 1 al 10
- Se entiende en 5 segundos qué hago y para quién.
- Mi promesa es específica, no genérica.
- Lo primero que se ve son resultados o testimonios reales.
- Se ve quién soy y por qué confiar en mí.
- Salgo yo a cuadro en varias publicaciones.
- Mis destacadas están ordenadas y al día.
- El link lleva directo a contactarme.
- Las tipografías y colores no saturan.
- Publico con constancia (al menos 4 veces por semana).
- Mis historias cuentan algo en pocas historias.

## Qué hacer con el resultado
Elige los 2 puntos más bajos y trabájalos esta semana. Vuelve a calificarte al día 40.

# Preguntas frecuentes

## Empezar | 0

### ¿Tengo que tomar las clases en orden?
La primera vez te lo recomendamos, porque cada clase usa lo de la anterior. Pero puedes saltar a cualquier clase o reto desde el menú.

### ¿Por qué 40 días?
Es una meta para que no se quede a medias. Son 9 clases y 3 retos: más o menos una clase cada 3 o 4 días y un reto por semana.

### ¿Dónde guardo mis ejercicios?
En el cuaderno al final de cada clase. Se guarda solo en este dispositivo y navegador. Si cambias de celular o borras los datos, se pierde, así que copia lo importante.

### Nunca he hecho contenido, ¿este curso es para mí?
Sí. Encendida es justo para empezar desde cero: entender las redes, dejar tu perfil listo y crear tus primeros contenidos con intención.

## Perfil | 4

### ¿Qué pongo en mi bio?
Usa la fórmula: te ayudo a [problema], cómo lo haces y en cuánto tiempo o con qué resultado. Está en la Clase 4 y en la herramienta "Tu perfil en 10 minutos".

### ¿Pongo el link de mi Facebook o el de WhatsApp?
Si atiendes por WhatsApp, pon el de WhatsApp. Es más fácil que te escriban directo a que den una vuelta por otra red.

### ¿Qué destacadas debo tener?
Resultados o testimonios, quién soy, qué ofrezco, preguntas frecuentes y cómo empezar. Mantenlas al día.

### ¿Puedo mostrar a mi familia y mi vida personal?
Sí, y conecta mucho. Solo cuida que esté conectado con tu promesa y que no sea lo primero que alguien ve si llega buscando lo que vendes.

## Contenido | 7

### ¿Cuántas veces a la semana publico?
Una buena base: 4 publicaciones a la semana más historias diarias. Mejor menos y bien hecho que mucho sin rumbo.

### ¿A qué hora publico?
No hay una hora mágica. Prueba en distintos horarios, observa tus números y repite lo que te funcione. Como pista, el educativo suele ir bien en la mañana y el entretenimiento en la noche.

### ¿Cuánto debo vender en mi contenido?
Como referencia: 40% estilo de vida y entretenimiento, 40% educativo y 20% venta. Vender sí se vale, solo no llenes tus historias de flyers.

### No sé qué subir.
Regresa a las preguntas frecuentes de tu clienta ideal (Clase 5) y a tu mensaje repetitivo (Clase 6). Y aprende algo nuevo cada semana: lo que aprendes también es contenido.

### Me da pena salir a cuadro.
Es muy normal. Empieza con una historia corta hablando de algo que dominas. La número 50 va a salir mucho mejor que la primera, pero solo si haces la primera.

### ¿Puedo usar inteligencia artificial?
Sí, como asistente. Tú pones la idea y la IA te ayuda a ordenarla. Revisa siempre que suene a ti.

## Historias y retos | 10

### Mis historias pierden vistas a la tercera.
Edita antes de subir: corta silencios y repeticiones y cuenta lo mismo en una historia de un minuto. Está en la Clase 9.

### ¿En qué orden hago los retos?
En el que quieras. Cada reto es independiente. Uno por semana es más que suficiente.

### Hice el reto de las 4 historias y nadie respondió.
Revisa que no hayas vendido desde la primera historia y que tu palabra clave sea clara. A veces la respuesta llega a la segunda o tercera vez. Repítelo.

### ¿Está bien decir que mi promoción se acaba hoy para que se decidan?
Solo si es verdad. Nunca inventes escasez, descuentos ni garantías: si se descubre, pierdes la venta y la confianza.

## El mentor | 0

### ¿Qué es "Tu mentora"?
Es la mentora de Encendida dentro de Claude. Te da las clases una por una, revisa tus ejercicios y te ayuda con tu bio, tus ideas de contenido y tus retos.

### ¿Tengo que pagar Claude?
No. Funciona con la cuenta gratis de claude.ai. La cuenta gratis tiene un límite de mensajes por día.

### ¿Cómo la instalo?
Descarga la mentora (.zip) en la pestaña Tu mentora. En Claude entra a Customize → Skills, toca "+", luego "Create skill" → "Upload a skill" y sube el zip sin descomprimir.
