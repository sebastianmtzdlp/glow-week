# Imán · contenido completo del curso

Cada bloque empieza con: @@ número | sección | título | subtítulo

@@ 0 | Empieza aquí | Bienvenida a Imán | De perseguir a atraer
Imán es un programa de 30 días para que tus redes atraigan a las personas correctas en lugar de que tú las persigas. Vas a definir a quién le hablas, ordenar tu contenido, abrir conversaciones y convertirlas en clientas y socias, sin sonar a catálogo ni a vendedora desesperada.

## La regla del 10 y el 90
El curso te da el 10%: la estrategia, las herramientas y los ejemplos. El 90% eres tú: tu actitud, tu acción diaria y tu constancia. Nadie nació con el chip; es una habilidad, como andar en bicicleta. Primero te caes y luego te sale.

## Aprende para enseñar
No basta con que tú sepas hacerlo. Si no sabes enseñárselo a tu equipo, tu equipo no crece. Toma cada clase pensando cómo la vas a explicar.

## Tus tres cuentas
- **Personal:** familia, memes, lo que quieras.
- **Laboratorio:** solo para investigar y guardar ideas de tu tema. No la uses para entretenerte.
- **Negocio:** la que publica. Ahí solo interactúas con tu comunidad.

## Lo que vas a construir
- Tu nicho y tu promesa.
- Tu perfil como página de aterrizaje.
- Tu mezcla 7-2-1: atraer, conectar y convertir.
- Tus guiones de conexión, de venta y de mensajes.
- Tu historia, tu voz y tu sistema para no quedarte en blanco.
- Tus herramientas: edición, Canva, IA, historias.

> Aquí no vienes a entretenerte. Vienes a hacerlo con intención.

## 🪞 Mírate al espejo
¿Hoy persigues a la gente o la gente llega a ti?

## ✍️ Ejercicio
1. Escribe qué quieres que pase en tus redes en 30 días.
2. Crea tu cuenta laboratorio si no la tienes.
3. Elige tu horario diario para la clase y para publicar.

## ✅ Tu tarea
Ve la siguiente clase con libreta y sin estar haciendo otra cosa.

## 💬 Para compartir en el grupo
Comparte tu meta de 30 días.

@@ 1 | Clase 1 | Tu nicho eres tú | A quién le hablas y qué le resuelves
Si mañana te rompes un dedo, vas con la especialista en manos, no con el médico general. En redes pasa igual: la gente sigue y le compra a quien resuelve su problema concreto. Hablarle a todas es no venderle a nadie.

## No vendes productos, vendes cambios
No vendes un suplemento: vendes sentirte con energía. No vendes un rubor: vendes seguridad al salir. No vendes "ingreso residual": vendes llegar a fin de mes tranquila.

## Tu tema grande y tu tema chico
La marca ya te pone en un tema grande: bienestar, belleza o emprendimiento. Dentro de él, elige **un tema chico**, un problema que conoces bien: falta de tiempo, piel grasa, cansancio de mamá que no para, ganas de volver a sentirte profesional. Puedes seguir mostrando otros productos; tu posicionamiento es uno.

## Tu nicho eres tú
La forma más fácil de encontrarlo: piensa en el mensaje que tú necesitabas escuchar. Lo que te frenaba, lo que te dolía, lo que te dio vergüenza, lo que te costó. Si un tema no es tuyo, se te nota en la cara.

## La prueba de fuego
¿Puedes hablar de ese tema todos los días? Si no te maquillas, no elijas maquillaje.

## Empieza por un problema, no por el dinero
Hablar de ingresos o de liderazgo sin trayectoria casi no conecta y suena a promesa. Empieza por un problema que tus productos ayudan a resolver. El negocio se cuenta en tu contenido de conexión y de venta.

## Tu frase
> Quiero ser conocida por ayudar a **[quiénes]** que **[problema]**, que están cansadas de **[lo que ya intentaron]** y quieren **[resultado]**.

Tu promesa es tu brújula, no un anuncio. Escríbela sin plazos ni resultados que no puedes garantizar.

## 🪞 Mírate al espejo
¿Qué mensaje te hubiera gustado leer hace un año?

## ✍️ Ejercicio
1. Escribe 5 problemas que tú viviste y tus productos ayudan a resolver.
2. Elige uno con la prueba de fuego.
3. Completa tu frase y guárdala en un documento llamado "Mi nicho".
4. Si te atoras, pide a tu asistente de IA: "Escribe el diario de un día de una mujer que [tu problema], en primera persona, sin soluciones".

## ✅ Tu tarea
Pega tu frase en tus notas del celular para tenerla siempre a mano.

## 💬 Para compartir en el grupo
Comparte tu frase.

@@ 2 | Clase 2 | Tu perfil es tu página de aterrizaje | Tres segundos para quedarse
Cuando alguien entra a tu perfil no puede ver una tienda: tiene que ver a una persona. En tres segundos decide si se queda.

## Lo básico
1. **Foto:** tu cara, bien iluminada, real. Nunca hecha con IA. Sin logos, flores, atardeceres ni fotos de grupo.
2. **Usuario y nombre:** tu nombre real. Nada de "nombre.marca" o "la tiendita de…". Tu marca personal te acompaña aunque cambies de empresa.
3. **Bio:** quién eres → a quién ayudas y en qué → algo de prueba (tu experiencia, tu proceso) → llamado a la acción.
4. **Link:** una página de enlaces gratis (como Linktree o Beacons) con botones: "Quiero saber más" (a tu WhatsApp), "Quiero comprar", "Únete a mi equipo", "Sobre mí".
5. **Botones de contacto** a tu WhatsApp.

## Destacadas en orden
**Empieza aquí → Mi historia → Resultados → Cómo funciona / preguntas → Tips.** Pocas y con portadas del mismo estilo. Evita "Varios", catálogos y promociones viejas.

## Tres publicaciones fijadas
1. **Tu presentación:** "Si eres nueva por aquí, déjame presentarme…": quién eres, por qué empezaste, a quién ayudas, qué vas a encontrar aquí.
2. **Tu contenido de valor** que más funcionó.
3. **Un testimonio o tu transformación**, sin promesas.

## Si empiezas de cero
Archiva (no borres) lo que parece catálogo y sube tres publicaciones:
1. Tu presentación: "de aquí en adelante, esto es lo que vas a encontrar".
2. Tu historia: yo era… → me frustraba… → el punto de quiebre → lo que pasó después → lo que aprendí. Sin vender.
3. Algo útil sobre tu tema, con "guárdalo para después".

## Canal de difusión
Si ya tienes comunidad, abre un canal de difusión en Instagram para frases, consejos y avisos. Te mantiene cerca.

> Mejor hecho que perfecto. El pelo en la blusa solo lo ves tú.

## 🪞 Mírate al espejo
Si hoy entrara tu clienta ideal a tu perfil, ¿se sentiría en el lugar correcto?

## ✍️ Ejercicio
Usa la **Ficha de nicho y perfil** (en Herramientas) para reescribir tu bio, tus destacadas y tus fijados.

## ✅ Tu tarea
Cambia hoy foto, nombre, bio y link.

## 💬 Para compartir en el grupo
Comparte tu perfil antes y después.

@@ 3 | Clase 3 | De consumidora a creadora | Lo que pasa en tu cabeza cuando no publicas
No publicar casi nunca es falta de creatividad. Tu cerebro está hecho para cuidarte y ahorrar energía, no para exponerte. Entenderlo te quita culpa y te da herramientas.

## Tu cerebro evalúa cuatro cosas
Amenaza, gasto de energía, recompensa y seguridad. Cuando estás cansada, saturada o ansiosa, entra en modo ahorro: más scroll, más compras impulsivas, más "mañana lo hago".

## Recompensa rápida contra recompensa lenta
Los likes y el scroll dan satisfacción inmediata. El negocio da recompensa diferida: a veces te compran y a veces no. Si te acostumbras solo a lo inmediato, el proceso lento se vuelve insoportable y ante un "no" te refugias en el celular.

## Consumir para inspirarte o para anestesiarte
Consumir contenido puede darte ideas. El problema es usarlo para no sentir: para tapar un vacío, el cansancio o la comparación.

## Dos sistemas al crear
- **Uno te empuja:** las ganas de crecer, de ser vista, de lograr algo.
- **Otro te frena:** el miedo a equivocarte, a que te juzguen, a fallar en público. Para tu cuerpo, subir un reel puede sentirse como un peligro real.

Y a veces el miedo no es "¿y si no funciona?", sino "¿y si funciona y no lo puedo sostener?".

## El cambio de identidad
1. Tolerar la incomodidad sin huir.
2. Regularte sin anestesiarte: pausas sin celular, caminar, escribir, respirar.
3. Recuperar tu energía: menos pestañas abiertas, menos multitarea.
4. Crear sin esperar aplauso inmediato: con calendario, no con ganas.
5. Sostener el crecimiento sin abandonarte.

> Consumir no te quita tiempo; te quita energía para crear.

## 🪞 Mírate al espejo
¿Qué parte de ti gana cuando tú no publicas?

## ✍️ Ejercicio
1. ¿Cuándo fue la última vez que hiciste scroll o compraste algo sin pensar? ¿Qué estabas evitando sentir?
2. ¿Qué cambiaría en tu vida si de verdad te fuera bien? ¿Qué parte de eso te asusta?
3. Marca cuáles de los 5 puntos del cambio de identidad ya practicas.

## ✅ Tu tarea
Elige tu miedo más chico y hazlo hoy: una historia hablando a cámara, un reel sencillo o un comentario respondido.

## 💬 Para compartir en el grupo
Comparte qué miedo enfrentaste hoy.

## Un cuidado
Si sientes ansiedad, tristeza o cansancio que no se van, habla con alguien de confianza o con una profesional. Ningún curso sustituye eso.

@@ 4 | Clase 4 | Mentalidad de negocio | Herramientas, no frases bonitas
Repetir frases positivas no basta. La mentalidad se entrena con herramientas y repetición, como un músculo.

## Seis pilares
1. **Observarte:** notar qué piensas y qué dices.
2. **Elegir:** qué consumes, con quién te juntas, cómo reaccionas.
3. **Metas claras:** si no sabes qué quieres, haz la lista de lo que ya no quieres.
4. **Hábitos:** se forman con semanas de repetición, no en tres días.
5. **Visualizar:** cinco minutos al día imaginando lo que estás construyendo.
6. **Medir:** revisar cada semana qué hiciste.

## Donde pones atención, crece
Tu cabeza funciona como el algoritmo: te muestra más de lo que miras. Si todo el día buscas lo que sale mal, lo vas a encontrar.

## Tus creencias sobre el dinero
Escribe las frases que escuchaste de niña: "el dinero no crece en los árboles", "los ricos son malos", "nunca hables de cuánto ganas". Revisa cuáles te sirven y cuáles te frenan. Puedes honrar a tu familia sin cargar sus miedos.

## Herramientas diarias
- **Escribe a mano** tu agenda y tus intenciones del día.
- **Corta la queja:** no alimentes conversaciones de "todo está terrible".
- **Aprende a recibir:** cuando te hagan un cumplido, di "gracias".
- **Celébrate:** prémiate por lo que cumpliste, sin esperar que otros lo noten.
- **Pon límites con cariño.**
- **Cambia la narrativa:** de "trabajo como burro" a "mi trabajo me lo permite".

> Lo que repites, lo practicas. Lo que practicas, lo vuelves.

## 🪞 Mírate al espejo
¿Qué frase sobre el dinero escuchaste más en tu casa?

## ✍️ Ejercicio
1. Escribe 3 creencias sobre el dinero que te frenan y cómo las reescribirías.
2. Escribe 3 cosas que ya no quieres en tu vida y conviértelas en metas.

## ✅ Tu tarea
Durante una semana, escribe cada mañana tu intención del día en una línea.

## 💬 Para compartir en el grupo
Comparte una creencia que vas a soltar.

@@ 5 | Clase 5 | Atrae, conecta, convierte | La mezcla 7-2-1 y los formatos que ya funcionan
Si no vendes, casi nunca es por falta de producción: te faltan ojos nuevos y estás mezclando todo. La mezcla 7-2-1 ordena tu contenido.

## La mezcla
De cada 10 publicaciones:
- **7 para atraer:** contenido que gente nueva comparte y guarda.
- **2 para conectar:** contenido que crea vínculo y confianza.
- **1 para convertir:** una invitación clara a comprar, platicar o conocer el negocio.

Desde el primer día, no "primero puros virales y luego el resto". Una sola pieza puede atraer y conectar a la vez. Las historias van aparte: ahí conectas y vendes todos los días.

## Formatos que ya funcionan
Desde tu cuenta laboratorio, busca en la lupa palabras del mundo de tu clienta y fíjate en piezas que cumplan:
1. Muchas vistas.
2. Muchos compartidos.
3. De cuentas pequeñas, para que sepas que funcionó la idea y no la fama.
4. Alineadas con lo que le resuelves a tu clienta.
5. Que puedas hacer tú en casa.

Guarda las que cumplan. Prueba varias palabras; si no encuentras, pide ideas de palabras a tu asistente de IA.

## Haz tu versión
Toma el formato: duración, tipo de escena, estructura del texto, ritmo. Grábalo tú, con tus palabras, tu casa y un audio de la app. Nunca descargues ni resubas un video ajeno ni copies textos palabra por palabra. El 7 no es tu esencia; tu esencia va en el 2 y el 1, pero hasta el 7 se ve mejor con tu toque.

## Qué cuenta para el algoritmo
Compartidos, guardados, comentarios y envíos pesan más que los likes. Responde comentarios para mantener viva la publicación. Las palabras que escribes en el video y la descripción ayudan a que te encuentren.

## Frecuencia
Mínimo una publicación al día. Los reels de alcance suelen ser cortos: de 4 a 10 segundos.

## Graba tu banco de clips
Graba clips de 2 a 5 segundos de todo: trabajando, cocinando, caminando, con tu perro. Te sirven para montar textos encima.

## 🪞 Mírate al espejo
¿Tus últimas publicaciones atraen gente nueva o solo le hablan a quien ya te sigue?

## ✍️ Ejercicio
Guarda **10 formatos** que cumplan las 5 reglas, en tu cuenta laboratorio.

## ✅ Tu tarea
Graba y publica tu versión de 3 de ellos esta semana.

## 💬 Para compartir en el grupo
Arma un microgrupo para intercambiar formatos que encuentren.

@@ 6 | Clase 6 | Contenido que conecta | Cinco tipos que abren conversaciones
El contenido de conexión no busca vistas: busca conversaciones. Un reel de conexión con pocas vistas y unos cuantos mensajes vale más que uno viral sin ninguno.

> No te falla el cierre; te faltan conversaciones abiertas.

## 1. Testimonio
Más que el resultado, cuenta el proceso: qué sentías antes y cómo te sientes ahora. Usa testimonios reales, tuyos o de alguien que te dé permiso. Sin promesas de salud ni de dinero.

## 2. Lo que ya intentó
Habla de lo que tu clienta ya probó y no le funcionó: comprar sin rumbo, empezar y soltar, sentirse sola en un negocio. Nunca nombres marcas, empresas ni personas. El objetivo es pasar de la frustración a la claridad.

## 3. Espejo
Que diga "me leyó la mente". Tiene que ser ultraespecífico:
- No: "Tú que quieres ser más constante".
- Sí: "Te prometes empezar el lunes y el jueves ya lo soltaste".

## 4. Verdad incómoda
Decir con respeto lo que todas piensan y nadie dice: "No es que no tengas tiempo, es que todavía no es tu prioridad". Sin humillar ni culpar. Prepárate: este contenido genera opiniones.

## 5. Autoridad
Muestra por qué sabes: tu experiencia, tu proceso, lo que haces diferente, lo que aprendiste. No necesitas ser experta titulada; la autoridad crece con resultados reales y constancia.

## La palabra clave
Cierra con "escríbeme [PALABRA] y seguimos por mensaje". Puedes automatizar la primera respuesta con una herramienta como ManyChat:
1. Conecta tu cuenta de Instagram.
2. Crea la automatización "comenta una palabra y recibe un mensaje", de preferencia para tu próxima publicación.
3. Agrega la palabra y sus faltas de ortografía comunes.
4. Escribe una respuesta pública corta y un primer mensaje cálido.
5. Después, continúa tú la conversación.

## 🪞 Mírate al espejo
¿Cuál de los cinco tipos te sale más natural? ¿Cuál evitas?

## ✍️ Ejercicio
Escribe una pieza de cada tipo para tu nicho. Pídele a tu asistente de IA que te ayude y luego ajústala: frase más fuerte al inicio, menos saltos de línea, tu forma de hablar.

## ✅ Tu tarea
Publica tu pieza tipo espejo con palabra clave.

## 💬 Para compartir en el grupo
Comparte tu espejo.

@@ 7 | Clase 7 | Contenido que convierte | La estructura de siete pasos
El contenido de conversión no tiene que cerrar la venta en la publicación. Tiene que mover a la persona un paso hacia una decisión.

## Cinco tipos de publicación de venta
1. Venta directa de un producto.
2. Invitación a conocer el negocio.
3. Invitación a platicar por mensaje.
4. Un test, una guía o un regalo para filtrar y luego recomendar.
5. Un evento o plática especial.

## La estructura
1. **Gancho:** detiene el scroll con curiosidad o identificación.
2. **Situación:** lo que vive tu audiencia, para que piense "está hablando de mí".
3. **Qué pasa si sigue igual:** con respeto, sin exagerar ni asustar.
4. **Otra forma de verlo:** rompes una creencia.
5. **Hay una salida:** el producto, el sistema o la oportunidad, sin explicarlo todo.
6. **Prueba:** tu experiencia o un testimonio real.
7. **Llamado claro:** "escribe RUTINA", "escribe EQUIPO".

## Ejemplo
**Gancho:** "No necesitas maquillarte más; necesitas dejar de comprar sin rumbo."
**Situación:** "Tienes un cajón lleno de cosas que no usas."
**Si sigue igual:** "Sigues gastando y sigues sin sentirte lista en cinco minutos."
**Otra forma de verlo:** "El problema no es tu cara, es que nadie te armó una rutina para tu tipo de piel."
**Salida:** "Una rutina sencilla de 4 pasos."
**Prueba:** "Es la que uso todos los días antes de llevar a mis hijos."
**Llamado:** "Escribe RUTINA y te digo cuál te va."

## Con tu asistente de IA
Pega los 7 pasos y pide: "Con esta estructura, dame un guion para convertir a [tu clienta]". Luego "conviértelo en reel" y "ahora en carrusel".

## 🪞 Mírate al espejo
¿Tus publicaciones de venta piden algo claro o solo muestran el producto?

## ✍️ Ejercicio
Llena la **Plantilla de 7 pasos** (en Herramientas) para un producto y para el negocio.

## ✅ Tu tarea
Publica tu pieza de conversión de la semana.

## 💬 Para compartir en el grupo
Comparte tu gancho.

@@ 8 | Clase 8 | Conversaciones que cierran | El guion de ocho pasos
El cierre no pasa en la publicación: pasa en la conversación. Y en la conversación gana la que pregunta más y habla menos.

## Los ocho pasos
1. **Apertura humana:** "Hola, vi que me escribiste RUTINA. Antes de decirte nada, ¿qué es lo que más te frustra ahorita con esto?"
2. **Entender su situación:** "¿Qué ya intentaste?", "¿qué no te funcionó?" Escucha; no corrijas.
3. **Profundizar:** "¿En qué momento del día lo sientes más?"
4. **Otra forma de verlo:** "A veces el problema no es X, es probar cosas sin un plan para tu caso."
5. **Imaginar el cambio:** "Si esto se resolviera, ¿qué cambiaría en tu día?"
6. **La solución:** "Justo por lo que me cuentas, uso [producto / trabajo con este modelo]."
7. **Validar sin prometer de más:** comparte tu experiencia real. La verdad es suficiente. Prometer de más es la razón por la que la gente se va.
8. **Invitar:** "Si te hace sentido, te explico paso a paso" o "¿quieres que te recomiende algo?"

## Consejos de oro
- No expliques de más ni mandes audios larguísimos.
- No des el precio sin contexto cuando hablas del negocio; en un producto sencillo, sí.
- No intentes convencer: deja que ella llegue a su conclusión.
- No necesitas hacer todas las preguntas.
- Termina cada mensaje con una pregunta.
- Si te deja en visto: "Hola, quedamos pendientes. ¿Te sigue interesando?"
- Respeta un no.

## La rutina 3-3-3
Cada día: **3 historias** de conexión, **3 conversaciones nuevas** y **3 seguimientos** a personas interesadas.

> El contenido atrae; las conversaciones venden.

## 🪞 Mírate al espejo
En tu última conversación de venta, ¿quién habló más, tú o ella?

## ✍️ Ejercicio
Copia el **Guion de 8 pasos** (en Herramientas) y adáptalo a tus palabras.

## ✅ Tu tarea
Haz la rutina 3-3-3 durante 5 días seguidos.

## 💬 Para compartir en el grupo
Comparte qué pregunta te abrió mejor la conversación.

@@ 9 | Clase 9 | Crear la necesidad sin manipular | Problema, conexión y solución
La gente no compra productos: compra soluciones a algo que ya siente. Crear la necesidad no es inventarla; es ayudar a que la persona reconozca lo que ya vive.

## Tres perfiles que no venden
1. **El catálogo ambulante:** producto, precio y descuento sin contexto.
2. **La vendedora desesperada:** "inscríbete conmigo, yo te apoyo".
3. **La fantasma tímida:** crece en seguidores pero casi no muestra lo que vende.

## El orden correcto
**Problema → conexión → solución.** Como en una tienda: si la vendedora te aborda con "¿qué buscas?", huyes; si te dice "hace calor y esta tela es fresca", te interesa.

## La fórmula
1. **Nombra la situación** con tanta precisión que tu clienta sienta que lo escribiste para ella. Usa su lenguaje, no el de un anuncio.
2. **Explica lo que aprendiste:** por qué pasa, desde tu experiencia y en palabras sencillas. Nada de diagnósticos ni explicaciones médicas.
3. **Tu experiencia y un llamado suave.** Tu testimonio es el puente.

## La plantilla del gancho
> "Las personas que [situación 1], [situación 2] y [situación 3]… esto es para ti."

Ejemplo: "Las mamás que se arreglan en el coche, se maquillan en el semáforo y nunca encuentran el labial… esto es para ti." No des la solución en el gancho; déjala para la descripción o el video.

## Antes y después
- **Antes:** "Este labial cuesta $___. Escríbeme."
- **Después:** "Si a mediodía ya no queda nada de tu labial, te va a pasar lo que a mí. Me lo puse a las 7 y a las 5 seguía igual. Escribe LABIAL y te digo cuál es."

## Lo que no se hace
- No prometas resultados de salud ni hables de enfermedades.
- No "metas el dedo en la llaga" ni exageres el miedo.
- No uses el dolor de alguien que está pasando un momento muy duro para venderle.

## 🪞 Mírate al espejo
¿Tu último post empezaba por el producto o por la persona?

## ✍️ Ejercicio
Para tus 4 productos favoritos, escribe 3 situaciones reales que vive tu clienta y un gancho con la plantilla.

## ✅ Tu tarea
Publica uno, observa quién comenta y escríbele.

## 💬 Para compartir en el grupo
Comparte tu mejor gancho.

@@ 10 | Clase 10 | Tus objeciones como contenido | Lo que tú pensabas antes
Lo que tú pensabas antes de entrar, y lo que tus prospectos piensan sin decirlo, es el contenido que más conversaciones abre.

## Por qué funciona
Publicar "libertad financiera, únete" no hace sentir a nadie que es para ella. Publicar "yo también pensaba que esto era una pirámide" genera identificación: "ella también lo pensó".

## Objeciones típicas
- Los productos son baratos, algo han de tener.
- Es una pirámide o una estafa.
- Me da pena que me vean mis conocidos.
- No sé de redes; a ti la cámara te quiere.
- No tengo tiempo ni dinero.
- No me quiero amarrar a una compra mensual.
- Ya hay demasiadas mujeres haciendo esto.
- Ya es tarde para empezar.
- Me da pena vender.

## De dónde salen
1. **Tu historia:** ¿qué pensabas tú antes?
2. **Tu equipo:** historias de compañeras, siempre con su permiso.
3. **Tus conversaciones:** anota cada evasiva en una libreta de "objeciones e ideas".

## Tres formatos
1. **Responder la duda** tal cual.
2. **Mito contra realidad.**
3. **"Pensé que… luego entendí…"**: reencuadra en una línea.

Responde con honestidad: si una duda es razonable, dilo. No ataques a otras empresas.

## Con tu asistente de IA
> Actúa como experta en contenido que conecta. Mi objeción era: [lo que pensabas]. Lo que me decía: [...]. Lo que descubrí: [...]. Mi audiencia: [...]. Mi tono: [...]. Dame un post con foto, un guion de reel y un carrusel que haga pensar "ella también lo pensó". Si suena genérico, dímelo y ajústalo. Sin promesas de ingresos.

Itera hasta que suene a ti. Y no respondas comentarios con IA: se nota.

## 🪞 Mírate al espejo
¿Cuál fue tu objeción más grande antes de empezar?

## ✍️ Ejercicio
Escribe tus 3 objeciones principales y una pieza para cada una.

## ✅ Tu tarea
Publica hoy una pieza de objeción, aunque sea imperfecta.

## 💬 Para compartir en el grupo
Comparte la objeción que más te costó soltar.

@@ 11 | Clase 11 | Tu historia vende | Nombrar lo que la gente nunca supo explicar
La gente olvida lo que dijiste, pero no cómo la hiciste sentir. En un mundo lleno de contenido, lo que te diferencia es tu historia contada desde la verdad, no desde la perfección.

## Lo que ya no conecta
Frases de Pinterest, perfección todo el tiempo, tono de gurú, querer impresionar.

## Corregir contra nombrar
- Vacía: "Solo sé auténtica". Conecta: "No es que no sepas qué compartir; es que exponerte te da miedo al juicio."
- Vacía: "Aprende a poner límites". Conecta: "A veces dices que sí porque te da más miedo decepcionar que agotarte."

La gente se siente vista cuando describes algo que nunca había sabido explicar.

## Tu historia en tres preguntas
1. ¿Quién era yo antes del negocio?
2. ¿Qué quería cambiar?
3. ¿Qué estoy construyendo hoy?

Y para ideas más profundas: una emoción que normalmente ocultas, algo que te daba vergüenza admitir, algo que sentías y no sabías explicar.

## No tiene que ser trágica
"En quién me tuve que convertir para sostener esto" es una historia igual de poderosa. Comparte lo que ya procesaste, no una herida abierta.

## No te fragmentes
No necesitas una cuenta para tu profesión, otra para tu maternidad y otra para tu negocio. Integra todo en una sola propuesta.

## Stickers de producto en historias
1. Usa una foto tuya del producto con fondo liso.
2. Historias → elige tu fondo.
3. Ícono de stickers → **Recortes** → elige la foto → toca el producto.
4. **Usar sticker.** Queda guardado para reutilizarlo.
5. Agrega texto y **subtítulos automáticos** desde el mismo menú de stickers.

> La confianza no se construye con perfección, sino con coherencia acumulada.

## 🪞 Mírate al espejo
¿Y si lo que escondes es justo lo que haría que alguien se sienta menos sola?

## ✍️ Ejercicio
Responde las tres preguntas y conviértelas en una serie de historias con stickers.

## ✅ Tu tarea
Sube la serie hoy.

## 💬 Para compartir en el grupo
Comparte tu respuesta a "¿qué estoy construyendo hoy?".

@@ 12 | Clase 12 | No necesitas ser creativa | Necesitas un sistema
Sin sistema aparece el miedo, y el miedo paraliza. La creatividad no nace de la nada: nace de observar tu vida con intención.

## Tres tipos de contenido
El que **abre la puerta** (atraer), el que **construye confianza** (conectar) y el que **invita** (convertir). No todo tiene que explotar. Si 20 personas te escuchan, caben en tu sala: son 20 oportunidades.

## Cuando no sepas qué publicar
- ¿Qué me pasaba antes?
- ¿Qué estoy aprendiendo ahora?
- ¿Qué me daba pena y qué descubrí?
- ¿Qué duda tuve que otra mujer puede tener?

## Cuatro fórmulas de texto
1. **"Antes pensaba… ahora entiendo…"** — "Antes pensaba que vender era insistir; ahora entiendo que es acompañar."
2. **"Pensé que se trataba de… y se trata de…"** — "Pensé que se trataba de ser influencer; se trata de construir confianza con la persona correcta."
3. **"Si hoy te sientes así, escucha esto"** — "Si hoy te da pena vender, quizá no necesitas vender más fuerte, sino conectar mejor."
4. **Historia + aprendizaje + invitación** — "Cuando empecé me daba pena hablar de productos… entendí que compartir lo que te ayuda también es servir. Si quieres aprender sin sentirte intensa, escríbeme."

## Llamados que no suenan intensos
Convertir es mostrar el siguiente paso, no presionar.
- "Si esto te hizo sentido, escríbeme."
- "Si quieres probar antes de decidir, te explico cómo."
- "Si quieres hacerlo sin sentirte sola, búscame."

## Tu banco de ideas
1. Guarda cada reel que te guste.
2. Pregúntate: ¿por qué me llamó la atención?, ¿qué emoción me tocó?, ¿qué diría yo?
3. Apunta varias ideas por reel.
4. Lleva una libreta con conversaciones, miedos, objeciones y frases de tu día.

## 🪞 Mírate al espejo
¿Cuántas ideas se te fueron esta semana por no anotarlas?

## ✍️ Ejercicio
Escribe 2 piezas con cada fórmula: 8 en total.

## ✅ Tu tarea
Empieza tu banco de ideas hoy, con 10 apuntes.

## 💬 Para compartir en el grupo
Comparte tu frase "Antes pensaba… ahora entiendo…".

@@ 13 | Clase 13 | Influencia que convierte | Tu voz, tu historia y tu intención
Influir no es ser famosa: es provocar algo en alguien. Si una persona se anima por verte, ya influiste.

## El apoyo llega de desconocidas
Casi nunca son tus conocidos los que comentan. Los mensajes de "me encanta verte, me ayuda" llegan de gente que no conoces.

## La seguridad llega después
No antes. Tu primer video puede tomarte quince intentos. La valiente no es la que no tiene miedo, sino la que lo hace con miedo.

## Lo que no convierte y lo que sí
- **No:** puras fichas, puras selfies, solo vender.
- **Sí:** la experiencia de uso, la solución a algo que se vive, tu transformación contada con verdad.

## Encuentra tu voz
Está en lo que viviste, lo que te dolió, lo que superaste, lo que aprendiste y lo que hoy puedes enseñar. La gente compra energía, seguridad e identidad antes que productos.

## La fórmula
**Gancho → historia → emoción → solución → llamado.**
"Me daba miedo mostrarme, pero esconderme no me llevaba a ningún lado. Hoy mi contenido me ha dado comunidad y conversaciones nuevas. Si yo pude con miedo, tú también. Escríbeme INFO."

## Antes de publicar, pregúntate
- ¿Qué quiero que sientan?
- ¿Qué quiero que crean?
- ¿Qué quiero que hagan?
- ¿Cómo quiero que se sientan después de verme?

## Sobre los comentarios negativos
Lo que estás construyendo pesa más que la opinión de desconocidos. Borra lo ofensivo o déjalo pasar; no te enganches.

> Cuando el propósito crece, el miedo baja.

## 🪞 Mírate al espejo
¿Para quién estás creando: para gustarle a todos o para ayudar a alguien?

## ✍️ Ejercicio
Escribe tu historia con la fórmula para un carrusel.

## ✅ Tu tarea
Publícalo y dale seguimiento a cada "INFO".

## 💬 Para compartir en el grupo
Comparte tu gancho.

@@ 14 | Clase 14 | Visibilidad sin miedo | El reto de siete días
No estás atorada por falta de información o de talento. Estás evitando mostrarte. Y en este negocio, si nadie te ve, nadie confía en ti.

## Los tres miedos
1. **Al juicio:** "¿qué van a decir?", "ya se cree influencer".
2. **Al rechazo:** cero likes, 200 vistas. Va a pasar; dalo por hecho.
3. **A no ser suficiente:** que no quede perfecto, trabarte.

Tu mente no te sabotea: te protege. Pero el músculo crece cuando se rompe.

## Preguntas para destrabarte
¿Cuánto me cuesta hoy no mostrarme? ¿Cuánto tiempo más voy a seguir así? ¿Qué pasa si en seis meses sigo igual?

## Tu método
- **Valor:** vendes el beneficio, no el producto.
- **Acción imperfecta:** siempre gana.
- **Constancia:** le gana al talento.
- **Conversaciones:** un post solo no vende.
- **Autenticidad:** tu historia, no la de otra.
- **Ejemplo:** tu equipo hace lo que te ve hacer.
- **Evolución:** si estás cómoda, te estancaste.

## Cuando alguien interactúa
No mandes el link y ya. "Gracias por preguntar, vi que te interesó X. ¿Qué buscas resolver?" Escucha y cierra con una pregunta.

## Si tienes pocos seguidores
Imagina a tus 120 seguidores en tu sala. Con 20 ya puedes vender.

## El reto de 7 días
Cada día, de lunes a domingo:
- 3 historias, al menos una hablando a cámara.
- 3 conversaciones nuevas.
- 1 publicación con la metodología.
- 1 invitación a conocer tus productos o el negocio.

Sin presión de cerrar: la meta es mostrarte y conversar.

## 🪞 Mírate al espejo
¿Qué precio estás pagando por ser invisible?

## ✍️ Ejercicio
Escribe la publicación que llevas semanas evitando.

## ✅ Tu tarea
Hoy: publícala, escríbele a 3 personas y sube una historia hablando a cámara. Mañana empieza el reto.

## 💬 Para compartir en el grupo
Cada noche, comparte tu avance del reto.

@@ 15 | Clase 15 | Edición para principiantes | Todas las apps tienen la misma lógica
No necesitas ser diseñadora. Canva, CapCut, Edits e Instagram comparten la misma lógica: si entiendes una, entiendes todas.

## La lógica común
- Creas una cuenta, eliges formato, trabajas en un lienzo y descargas.
- **Menú principal y menú secundario:** eliges una herramienta (texto) y aparecen sus opciones (fuente, color, tamaño).
- **Línea de tiempo** en todo lo que es video.
- **Historial de proyectos** para volver a lo que hiciste.
- La corona o el diamante marcan lo que es de paga.

Las apps se actualizan y mueven botones, pero la lógica no cambia. Empieza gratis y paga cuando se te quede chica.

## Carrusel con la misma foto (Canva, celular)
1. Redes sociales → Post de Instagram.
2. Subidos → tu foto → ajústala al lienzo.
3. Texto → escribe tu título → color blanco.
4. Duplica la página tres veces.
5. En las páginas 2 a 4, baja la **transparencia** de la foto y cambia el texto.
6. Descargar → PNG → todas las páginas.

## Video horizontal a vertical (Edits)
1. "+" → elige el video.
2. Pellizca para agrandarlo y llenar la pantalla.
3. Si cambia el encuadre, **divide** y reacomoda cada parte.

## Subtítulos
- **Edits:** Subtítulos → revisa y corrige.
- **CapCut:** Subtítulos automáticos → estilo.

Si una app no te deja hacer algo, pásate a otra. Puedes combinar varias en un mismo video.

## Plantillas de CapCut
Plantillas → busca un tema → Usar plantilla → elige tus fotos o videos → Exportar. Usa la plantilla por sus movimientos y transiciones; el contenido es tuyo.

## Publicar un carrusel
"+" → Publicación → selección múltiple → numera en orden → música y filtro → texto → Compartir.

## Derechos
Los recursos de Canva y CapCut se pueden usar. No descargues ni resubas videos ajenos.

> Usa lo que ya está hecho; tu tiempo es para vender.

## ✍️ Ejercicio
Haz el carrusel de la misma foto y un video con subtítulos.

## ✅ Tu tarea
Publica el carrusel como tu pieza de conexión.

## 💬 Para compartir en el grupo
Comparte tu carrusel.

@@ 16 | Clase 16 | Tu paleta y tus diseños | Color, Canva y capas
Tu marca se reconoce por repetición: los mismos colores, las mismas fuentes, el mismo estilo. No necesitas diseñadora; necesitas consistencia.

## Tu paleta
Elige 2 o 3 colores según cómo quieres que se sienta tu clienta, no solo por gusto. Como guía (no ley):
- **Azul:** confianza, calma.
- **Verde:** naturaleza, frescura.
- **Morado:** elegancia, exclusividad.
- **Café y beige:** cercanía, tradición.
- **Rosa:** dulzura, feminidad.
- **Negro:** elegancia; con dorado se ve especial.
- **Rojo:** atención; úsalo para acentos y avisos reales, nunca para fingir urgencia.

Tu paleta tiene que ser congruente contigo: en tus fotos, tus lives y tu forma de presentarte.

## Kit de marca en Canva
Marca → Crear kit → sube tu logo o una imagen → máximo 3 a 5 colores → una fuente para títulos, otra para subtítulos.

## Personaliza plantillas
Plantilla → Personalizar → aplica tu kit → cambia foto y texto. Si dos vecinos que venden cosas distintas usan la misma plantilla, se ve; hazla tuya.

## Post con la foto delante del título
1. Crear → Post de Instagram (formato 3:4).
2. Fondo de tu paleta.
3. Sube tu foto y estírala.
4. **Duplícala**: a la de arriba quítale el fondo; a la de abajo bájale la transparencia o ponle un filtro.
5. En **Posición**, pon el título entre las dos fotos.
6. Agrega un elemento difuminado si queda un corte feo.
7. Última página: fondo liso y llamado ("Comenta LABIAL y te mando el link").

## Reglas rápidas
- Máximo 2 o 3 tipografías. Nada de cursivas en títulos: en el celular no se leen.
- Si no encuentras un elemento en español, búscalo en inglés.

## ✍️ Ejercicio
Define tu paleta, crea tu kit y diseña un post con la foto delante del título.

## ✅ Tu tarea
Úsalo en tu próxima pieza de conexión.

## 💬 Para compartir en el grupo
Comparte tu paleta y qué quieres transmitir.

@@ 17 | Clase 17 | Tu asistente de IA con criterio | Que no suene igual que todas
Tu asistente de IA no adivina y está hecho para nunca quedarse callado: a veces inventa. Verifica siempre. La primera respuesta casi nunca es la buena.

## El prompt en seis partes
1. **Rol:** "actúa como estratega de contenido…"
2. **Tarea:** escribe, resume, ordena.
3. **Contexto:** para qué y para quién.
4. **Formato:** lista, guion, carrusel, cuántas versiones.
5. **Tono.**
6. **Criterios:** qué sí y qué no. Agrega "no seas complaciente".

**Pobre:** "Hazme un post sobre mi negocio."
**Bueno:** "Actúa como estratega de contenido. Escribe un post para Instagram dirigido a mujeres de 28 a 45 interesadas en crecer profesionalmente. Que despierte curiosidad, que no explique el negocio y que no suene a multinivel. Dame copy, cierre y 3 ganchos. No uses 'sé tu propia jefa' ni 'ingresos ilimitados'."

## Cinco trucos
1. **Que te pregunte primero:** "Antes de escribir, hazme las preguntas que necesites, una por una."
2. **Háblale:** usa el modo de voz y platica como con tu amiga.
3. **Tu jefa exigente:** "Revisa este texto como una mujer que ya vio demasiados mensajes. Dime qué está flojo o genérico y cómo mejorarlo. Sé dura pero propositiva. No cambies mi idea."
4. **Que suene a ti:** las IA repiten la muletilla "no es X, es Y" y todo Instagram suena igual. Pide: "Reescríbelo cercano y natural, sin comparaciones de 'no es esto, es aquello'." Luego ponle tu toque.
5. **Imágenes:** sube una foto de tus productos y pide que la analice y te diga cómo mejorarla (luz, orden, fondo). Después: "Dame un caption, una idea de historia y un gancho a partir de esta foto."

## Lo que no
- No respondas comentarios con IA.
- No uses imágenes de IA como tu foto de perfil ni para fingir resultados.

## ✍️ Ejercicio
Escribe tu prompt base de seis partes y pásalo por tu "jefa exigente".

## ✅ Tu tarea
Guarda tus 3 mejores prompts en la herramienta **Prompts con criterio**.

## 💬 Para compartir en el grupo
Comparte un antes y después de un texto mejorado.

@@ 18 | Clase 18 | Contenido de recomendación real | Como se lo contarías a una amiga
El contenido que más vende es el que parece una recomendación real de una persona común, no un anuncio perfecto. La gente ya no cree en la hamburguesa del comercial: cree en la foto de la reseña.

## Qué es
Contenido natural y cotidiano usando lo que de verdad usas. No necesitas miles de seguidores. Solo muestra productos que te gustan; si algo no te gusta, no lo promuevas aunque esté en promoción.

## Lo técnico
- **Luz** de ventana.
- **Audio** claro.
- **Ritmo:** cambia de toma cada 1 o 2 segundos.
- **Gancho** rápido; puede ser solo un texto.
- **Tu tono de voz**, no el de otras.
- **Progreso, no perfección:** comparte tu proceso aunque todavía no tengas resultados.

## "No tengo una vida interesante"
Documenta en lugar de crear. Cada noche piensa: "mañana tengo esto, esto y esto, ¿qué de eso es contenido?".

## Tipos
- "Ayúdenme a elegir" (como mandarle opciones a tu familia).
- Arréglate conmigo, sin producción.
- Tu rutina de piel o maquillaje.
- Abrir un paquete como si se lo enseñaras a una amiga.
- Mini reseña.
- Voz encima de clips de tu día.
- "Acompáñame" con un giro: "…a una boda y se me olvidó el maquillaje".

## La fórmula
**Gancho → experiencia → revelación al final → llamado.** "Probé este aceite que todo mundo recomienda…" y hasta el final dices cuál es.

## Ganchos fáciles
"Si eres mamá, necesitas ver esto." "Todo el mundo me preguntó por esto." "Nunca me esperé esto de…" "No compres esto si…"

## Si te pagan, dilo
Si una marca te paga o te da producto a cambio de contenido, márcalo como colaboración pagada con la herramienta de la red. La confianza es tu activo.

## 🪞 Mírate al espejo
¿Lo que publicas se lo contarías igual a una amiga si no lo grabaras?

## ✍️ Ejercicio
Graba 3 clips para historias: muestras el producto, lo usas platicando por qué te gusta, enseñas el resultado y cierras con un llamado.

## ✅ Tu tarea
Publica un "acompáñame" con giro.

## 💬 Para compartir en el grupo
Comparte tus 3 clips.

@@ 19 | Clase 19 | Historias limpias y estratégicas | Claridad, no perfección
Entre más clara seas, más vendes. Cada historia necesita un objetivo, una sola idea y un llamado.

## Limpia contra saturada
- **Limpia:** se entiende en 2 segundos, se ve coherente contigo, una idea por historia.
- **Saturada:** tres o más tipografías, párrafos largos, muchos stickers y colores que no se repiten.

Si la gente tiene que esforzarse para entender, se la salta.

## Checklist de 4 puntos
1. **Identidad mínima:** 1 o 2 tipografías, 2 o 3 colores, un estilo de texto constante.
2. **Jerarquía:** frase principal grande, texto secundario más chico, llamado pequeño pero claro.
3. **Stickers con dirección:** cada uno dice qué hacer: tocar, responder, reaccionar.
4. **Que respire:** no llenes la pantalla; si el fondo es ruidoso, ponle un velo.

## La secuencia
1. Estoy viviendo algo.
2. Lo cuento: qué pasó.
3. Lo que aprendí.
4. Abro la plática o pido una acción.

Hazla cada 3 días o una vez a la semana.

## Errores comunes
- Meter todo en una sola historia.
- Copiar estilos que no son tuyos.
- Saturar de "compra, está en descuento" todos los días.
- No pedir nada.

## Trucos de Instagram
- **Color:** cuentagotas para tomar un color de la foto; botón "A" para fondo o letra de color.
- **Capas:** mantén presionado el texto para mandarlo delante o detrás de un sticker.
- **Velo:** Dibujar → marcador de punta plana → mantén presionada la pantalla.
- **Menciones limpias:** arrastra la etiqueta fuera de la pantalla.
- **Pantalla verde:** filtros → busca "Green screen" → elige tu foto → graba hablando encima.
- **Recortes:** stickers → Recortes → tu foto.
- **Encuesta** para "ayúdenme a elegir".

## Horarios
No hay hora mágica. Revisa en tus estadísticas cuándo está conectada tu audiencia.

> Lo bonito no vende; vende la claridad. Lo bonito llega con la constancia.

## ✍️ Ejercicio
Arma una secuencia de 4 con algo que estás viviendo hoy.

## ✅ Tu tarea
Revisa tus historias de la semana con el checklist de 4 puntos.

## 💬 Para compartir en el grupo
Comparte tu secuencia.

@@ 20 | Clase 20 | Graduación | Termina una versión de ti
El programa termina; tu forma de trabajar no. Ya tienes la estrategia. Ahora toca aplicarla con constancia y enseñarla.

## Lo que el conocimiento pide
Conocimiento que no se enseña se pierde. Graba tus propias capacitaciones cortas para tu equipo y guárdalas en un lugar donde las encuentren. Entre más enseñas, más entiendes.

## Dimensiona lo que logras
25 personas son un salón. 150, un evento. 3,000 vistas son un teatro lleno. No hagas pequeño lo que ya está pasando.

## Los seguidores apapachan el ego
Importan las conversaciones, las vistas de tu gente y las respuestas. Perder seguidores que no son tu clienta está bien.

## Regresa
Si no te gustan tus resultados, vuelve a la clase que te hizo clic: nicho, conexión, conversión, mensajes o visibilidad. Si algo ya funciona, duplícalo.

## Lo que hace una persona que logra
No espera permiso, se organiza, estudia, se prepara antes de la oportunidad, resuelve, simplifica su vida y no sostiene lo insostenible.

## Lo que ya tienes
- Tu nicho y tu perfil.
- Tu mezcla 7-2-1 y tu laboratorio.
- Tus cinco tipos de conexión y tu estructura de venta.
- Tu guion de mensajes y tu rutina 3-3-3.
- Tu historia, tus fórmulas y tu banco de ideas.
- Tus herramientas.

## 🪞 Mírate al espejo
¿Qué versión de ti termina hoy?

## ✍️ Ejercicio
Escribe tu compromiso: qué aprendiste, qué vas a seguir haciendo cada semana y cómo se lo vas a enseñar a tu equipo.

## ✅ Tu tarea
Elige la primera clase que vas a enseñar y ponle fecha.

## 💬 Para compartir en el grupo
Comparte tu compromiso.

@@ 21 | Herramientas | Ficha de nicho y perfil | Tu base en una hoja
Llénala y guárdala. Pégala cada vez que trabajes con tu asistente de IA.

## Mi nicho
- Mi tema grande (bienestar, belleza, emprendimiento):
- Mi tema chico (un problema):
- ¿Lo puedo hablar todos los días?
- Mi frase: "Quiero ser conocida por ayudar a ___ que ___, que están cansadas de ___ y quieren ___."

## Mi clienta
- ¿Cómo se siente en su día?
- ¿Qué ya intentó?
- ¿Qué frases usa?
- ¿Qué quiere en el fondo?

## Mi perfil
- Foto: mi cara, real, con buena luz.
- Nombre y usuario: mi nombre.
- Bio: quién soy · a quién ayudo · prueba · llamado.
- Link: WhatsApp · comprar · equipo · sobre mí.
- Destacadas: Empieza aquí · Mi historia · Resultados · Cómo funciona · Tips.
- Fijados: presentación · mi mejor contenido de valor · testimonio.

@@ 22 | Herramientas | Plantilla de 7 pasos | Para tu contenido de venta
Llena una por producto y una para el negocio.

## La plantilla
1. **Gancho:**
2. **Situación que vive:**
3. **Qué pasa si sigue igual (sin exagerar):**
4. **Otra forma de verlo:**
5. **Hay una salida:**
6. **Mi prueba (experiencia o testimonio real):**
7. **Llamado (palabra clave):**

## Revisa antes de publicar
- ¿Suena a mí?
- ¿Prometo algo que no puedo garantizar?
- ¿El llamado es claro?

@@ 23 | Herramientas | Guion de 8 pasos | Para tus mensajes
Adáptalo a tus palabras. No necesitas usar todos los pasos.

## El guion
1. **Apertura:** "Hola, vi que me escribiste ___. Antes de decirte nada, ¿qué es lo que más te frustra ahorita con esto?"
2. **Situación:** "¿Qué ya intentaste? ¿Qué no te funcionó?"
3. **Profundizar:** "¿En qué momento lo sientes más?"
4. **Otra forma de verlo:** "A veces el problema no es ___, es ___."
5. **Imaginar:** "Si esto se resolviera, ¿qué cambiaría en tu día?"
6. **Solución:** "Justo por lo que me cuentas, uso / trabajo con ___."
7. **Validar:** mi experiencia real, sin prometer de más.
8. **Invitar:** "Si te hace sentido, te explico paso a paso. ¿Te parece?"

## Seguimiento
"Hola, quedamos pendientes. ¿Te sigue interesando?"

## Rutina 3-3-3
- 3 historias de conexión.
- 3 conversaciones nuevas.
- 3 seguimientos.

@@ 24 | Herramientas | Fórmulas y banco de ideas | Para no quedarte en blanco
## Fórmulas
- "Antes pensaba… ahora entiendo…"
- "Pensé que se trataba de… y se trata de…"
- "Si hoy te sientes así, escucha esto…"
- Historia + aprendizaje + invitación.
- "Las personas que ___, ___ y ___… esto es para ti."
- Gancho → historia → emoción → solución → llamado.
- Gancho → experiencia → revelación → llamado.

## Preguntas para ideas
- ¿Qué me pasaba antes?
- ¿Qué estoy aprendiendo?
- ¿Qué me daba pena y qué descubrí?
- ¿Qué objeción tuve?
- ¿Qué me preguntaron esta semana?

## Llamados suaves
- "Si esto te hizo sentido, escríbeme."
- "Si quieres probar antes de decidir, te explico cómo."
- "Comenta ___ y te mando la info."

@@ 25 | Herramientas | Prompts con criterio | Para tu asistente de IA
## Prompt base
> Actúa como [rol]. Soy [quién] y ayudo a [clienta] con [problema]. Escribe [pieza] para [canal]. Tono [tono]. Dame 3 versiones. No uses promesas de ingresos ni de salud, ni frases como "sé tu propia jefa". No seas complaciente.

## Que te pregunte
> Antes de escribir, hazme las preguntas que necesites, una por una. No empieces todavía.

## Jefa exigente
> Revisa este texto como una mujer que ya vio demasiados mensajes. Dime qué está flojo o genérico y cómo mejorarlo. Sé dura pero propositiva. No cambies mi idea.

## Que suene a mí
> Reescríbelo cercano y natural, como hablo yo. Sin comparaciones de "no es esto, es aquello". Frases cortas.

## Conexión
> Dame una pieza tipo espejo para [clienta] que la haga pensar "me leyó la mente". Ultraespecífica.

## Objeciones
> Mi objeción era [___]. Lo que descubrí fue [___]. Dame un guion de reel y un carrusel que haga pensar "ella también lo pensó".

## Foto de producto
> Analiza esta foto: qué funciona y qué mejorarías (luz, orden, fondo). Luego dame un caption, una idea de historia y un gancho.

# Preguntas frecuentes

## Empezar | 0

### ¿Tengo que tomar las clases en orden?
La primera vez te lo recomendamos: la base va primero. Pero puedes ir a cualquier clase desde el menú.

### ¿En qué se diferencia de Trazo?
Trazo te da lo esencial para arrancar. Imán va más a fondo en la estrategia: los cinco tipos de conexión, la estructura de venta, los guiones de mensajes, las objeciones, tu historia y la visibilidad.

### ¿Dónde guardo mis ejercicios?
En el cuaderno al final de cada clase. Se guarda solo en este dispositivo y navegador. Copia lo importante a tu libreta.

### ¿Para qué es la cuenta laboratorio?
Para investigar formatos y guardar ideas sin confundir a tu cuenta de negocio. En la de negocio solo interactúas con tu comunidad.

## Nicho y perfil | 1

### ¿Puedo tener dos nichos?
Elige uno como ancla. Puedes mostrar otros productos, pero tu posicionamiento es uno.

### ¿Puedo poner el nombre de la marca en mi usuario?
Mejor no. Usa tu nombre. Tu marca personal te acompaña aunque cambies de empresa.

### ¿Borro mis publicaciones viejas?
Mejor archívalas. Así limpias tu perfil sin perder tu historial.

## Contenido | 5

### ¿Cuántas veces publico?
Al menos una vez al día, siguiendo la mezcla 7-2-1. Las historias van aparte, todos los días.

### ¿Puedo copiar un reel viral?
Toma el formato, no el video. Hazlo con tus palabras, tu espacio y un audio de la app. No descargues ni resubas contenido ajeno ni copies textos palabra por palabra.

### Mi contenido de conexión tiene pocas vistas.
Es normal. Ese contenido no busca vistas, busca conversaciones. Mide cuántos mensajes abrió.

### ¿Puedo usar testimonios de otras?
Solo reales y con su permiso. Nunca inventes testimonios ni cifras.

## Ventas | 8

### ¿Le doy el precio cuando me lo preguntan?
En un producto sencillo, sí. Para el negocio, primero pregunta qué busca y en qué momento está.

### ¿Puedo decir que un producto desinflama o quita algo?
No. Cuenta tu experiencia de uso sin prometer resultados de salud y sin hablar de enfermedades. Si alguien tiene un tema de salud, que lo vea con su médico.

### ¿Puedo decir cuánto gano?
No prometas ingresos ni uses cifras como gancho. Comparte tu experiencia y lo que te gusta del negocio.

### ¿Está bien decir "solo hoy" para que se decidan?
Solo si es verdad. Nunca inventes escasez, descuentos ni garantías.

### Si una marca me paga por contenido, ¿lo digo?
Sí. Márcalo como colaboración pagada. La confianza es tu activo más valioso.

## El mentor | 0

### ¿Qué es "Tu mentora"?
Es la mentora de Imán dentro de Claude. Te da las clases una por una, revisa tu nicho y tu perfil, y te ayuda con piezas de conexión y venta, mensajes, objeciones y prompts.

### ¿Tengo que pagar Claude?
No. Funciona con la cuenta gratis de claude.ai. La cuenta gratis tiene un límite de mensajes por día.

### ¿Cómo la instalo?
Descarga la mentora (.zip) en la pestaña Tu mentora. En Claude entra a Customize → Skills, toca "+", luego "Create skill" → "Upload a skill" y sube el zip sin descomprimir.
