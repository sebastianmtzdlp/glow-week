# El Clic · contenido completo del curso

Fuente para el modo curso. Cada bloque `@@ número | etiqueta | título | tema` es una lección; la primera línea es la introducción y las secciones con 🪞 ✍️ ✅ 💬 son la parte "Tu turno".

@@ 0 | Empieza aquí | Bienvenida a El Clic | Vender sin sentir que vendes
El Clic es ese segundo en que la mente de alguien dice "sí, esto es para mí". Este curso es para que entiendas qué lo provoca y lo cuides en cada plática con tus clientas.

## Por qué este curso
Hoy casi todo se parece. Hay cientos de personas vendiendo cremas, perfumes y maquillaje, y desde afuera todo suena igual: "de calidad", "precio increíble", "el mejor". Cuando todo suena igual, la única diferencia que queda es el precio, y competir por precio es trabajar casi gratis.

La salida no es gritar más fuerte. Es entender **cómo decide la mente** y hablarle a eso: a lo que tu clienta siente, teme y sueña, no solo a lo que dice que quiere.

## Lo que vas a construir
- Tu **necesidad de fondo**: lo que de verdad compra tu clienta cuando te compra.
- Tu forma de abrir una plática con **atención, emoción y recuerdo**.
- Tus **tres opciones** para que la mente pueda elegir.
- El **significado** de tu producto estrella, más allá de lo que hace.
- Tus **historias** de venta, honestas y con pruebas.
- Tu **guion de El Clic** para un tipo de clienta.
- Tu **reto de 66 días**, 15 minutos al día.

## Antes de empezar: la regla de oro
Todo lo que vas a aprender sirve para conectar mejor, no para manipular. Si un producto no le sirve a alguien, no se lo vendas. No inventes miedos, no prometas resultados de salud y nunca mientas. Cuando ayudas de verdad, la clienta regresa y te recomienda.

> Vender sin vender: escucha primero, ayuda siempre y la venta llega sola.

## Cómo aprovecharlo
1. **Una clase por semana.** Son lecturas cortas, de unos 7 minutos.
2. **Haz el ejercicio en el cuaderno** que viene al final de cada clase.
3. **Pruébalo esa misma semana** con una clienta real. Esto se aprende en la plática, no en la lectura.
4. **Comparte en el grupo** lo que te funcionó. Lo que a ti te salió, a otra le ahorra meses.

## 🪞 Mírate al espejo
Piensa en tu última venta. ¿Por qué crees que te compró? ¿Y si la razón real fuera otra?

## ✍️ Ejercicio
Escribe las tres frases que más usas para vender. Guárdalas: al final del curso las vas a reescribir.

## ✅ Tu tarea de la semana
Platica con una clienta sin ofrecerle nada. Solo pregúntale cómo está y escucha. Anota qué te contó.

## 💬 Para compartir en el grupo
¿Cuál es la frase que más usas para vender? Compártela tal cual, sin pena.

@@ 1 | Clase 1 | La mente compra primero | Nadie sabe bien por qué compra
La mayor parte de una decisión de compra pasa por debajo de lo consciente. La persona compra y después busca razones para explicarlo.

## La gente no sabe por qué compra
Pregúntale a alguien por qué eligió ese perfume y te dirá "porque huele rico". Pero había otros veinte que olían rico. Lo que pasó por dentro (un recuerdo, una emoción, cómo se imaginó usándolo) casi nunca lo sabe decir. Los estudios de este tema dicen que **la gran mayoría de la decisión es inconsciente** y solo una parte pequeña es lógica.

Eso no significa que tu clienta sea tonta. Significa que es humana. Todas compramos así, también tú.

## Primero se siente, luego se justifica
La mente decide con la emoción y luego le pide a la parte lógica que le dé argumentos. Por eso alguien sale a comprar "algo práctico" y regresa con lo que le encantó, y después te explica muy convencida por qué era lo más práctico.

> La emoción decide. La lógica firma.

## Cuando todo se parece, gana la que conecta
Si tú y otras diez personas dicen lo mismo ("es de calidad", "está en promoción"), la mente no ve diferencia, y cuando no ve diferencia elige lo más barato. Tu ventaja no es decir más cosas, es decir **las cosas que le importan a ella**.

## Vender sin vender
Mientras más suena a "discurso de vendedora", más se cierra la mente. Lo que abre es lo contrario: preguntar, escuchar, platicar de su vida. Si una clienta te cuenta que tiene dos hijos, que no tiene tiempo y que extraña arreglarse, ya sabes qué ofrecerle y cómo decírselo. Si no le preguntas, estás hablando a ciegas.

## Las dos formas de vender
- La vendedora de siempre habla mucho, explica características y usa el mismo discurso con todas.
- La que vende a la mente pregunta, escucha, usa todo el cuerpo para comunicar, adapta lo que dice a cada persona y sabe que la gente compra para sentirse bien y quitarse un miedo de encima.

## 🪞 Mírate al espejo
En tus últimas pláticas de venta, ¿quién habló más: tú o tu clienta?

## ✍️ Ejercicio
1. Piensa en algo que compraste este mes y que no necesitabas.
2. Escribe la razón "lógica" que te diste.
3. Ahora escribe la razón real: ¿qué sentiste?, ¿qué te imaginaste?

## ✅ Tu tarea de la semana
En tu próxima plática de venta haz al menos tres preguntas antes de mencionar un solo producto.

## 💬 Para compartir en el grupo
Cuenta algo que compraste por emoción y la excusa lógica que te diste. Va a dar risa y vas a aprender.

@@ 2 | Clase 2 | La necesidad de fondo | Lo que de verdad se compra
Debajo de cada compra hay una necesidad muy básica, casi de instinto. Si la encuentras, sabes qué decir.

## Tres partes que deciden juntas
Una forma sencilla de entender la mente es imaginar tres partes que trabajan juntas:
- **La que sobrevive.** Busca estar a salvo, cuidarse, pertenecer al grupo. No piensa, reacciona.
- **La que siente.** Guarda recuerdos y emociones. Un olor te puede regresar veinte años en un segundo.
- **La que explica.** Es la lógica. Es la única que habla, por eso siempre racionalizamos lo que hacemos.

La que explica cree que manda, pero la que sobrevive y la que siente llevan el volante. Por eso alguien te dice "no te compro por el precio" cuando la razón real es otra.

## La necesidad de fondo
Todo producto toca alguna necesidad básica. Estas son las más comunes:
- **Seguridad y protección:** estar a salvo, cuidar a los suyos.
- **Pertenecer:** ser aceptada por su grupo.
- **Reconocimiento:** que la vean, que la admiren.
- **Placer:** darse un gusto, sentirse bien.
- **Control y orden:** tener las cosas bajo control.
- **Libertad:** escapar un ratito de la rutina.
- **Explorar:** probar algo nuevo, descubrir.
- **Trascender:** dejar algo, ser ejemplo, la familia.

Casi siempre hay varias, pero una pesa más. Esa es la que buscas.

## Aterrizado a lo que vendemos
Una mamá que compra una crema no compra crema: compra **cinco minutos para ella** (placer y libertad) y verse bien en las fotos con sus hijos (trascender). Una mujer que compra un perfume para una boda compra **que la volteen a ver** (reconocimiento). Una clienta que compra la rutina completa compra **sentir que tiene su piel bajo control**.

> No vendes el producto. Vendes la necesidad que cubre.

## Cuidado con decirlo en voz alta
La necesidad de fondo es para que tú la entiendas, no para anunciarla. No le digas "esto es para que tus amigas te acepten". Dile "con este tono vas a llegar a la reunión sintiéndote increíble". Ella entiende lo demás.

## 🪞 Mírate al espejo
¿Cuál es la necesidad de fondo de tu producto que más vendes? ¿La has usado alguna vez al hablar de él?

## ✍️ Ejercicio
1. Escribe tus 3 productos que más vendes.
2. Para cada uno, elige la necesidad de fondo que más pesa.
3. Escribe una frase para cada uno que hable de esa necesidad sin nombrarla.

## ✅ Tu tarea de la semana
Usa una de esas frases con tres clientas y anota cómo reaccionaron.

## 💬 Para compartir en el grupo
Comparte tu producto estrella y la necesidad de fondo que encontraste. A ver si el equipo coincide.

@@ 3 | Clase 3 | Cómo decide la mente | Atención, emoción y recuerdo
Para que alguien diga que sí tienen que pasar tres cosas, en orden. Si falta una, no hay clic.

## Las tres llaves
1. **Atención.** Si no te pone atención, el juego no empieza. Se logra con algo conocido y luego algo nuevo, con algo que entienda fácil y con un poquito de expectativa: "espérate a ver cómo se siente en la piel".
2. **Emoción.** Que lo que le dices le haga sentir algo bueno. Ojo: puedes llamar la atención y aun así provocar una emoción negativa o ninguna.
3. **Recuerdo.** Que conecte lo que vendes con su propia vida: cómo le va a servir a ella, en su día, con su familia. Ahí es cuando se anima a pagar.

> Atención abre la puerta. Emoción la invita a pasar. Recuerdo la hace quedarse.

## La mente necesita tres opciones
Con una sola opción la mente no puede decidir, y si no le das opciones se va a buscarlas a otro lado. Con muchas se confunde. Tres es el número que funciona: tres tonos, tres tamaños, tres paquetes. Y aunque cada opción se sienta "lógica", detrás de cada una hay una emoción: la que me hace sentir atrevida, la que me hace sentir inteligente, la que me hace sentir que me consiento.

## Emoción con un dato para justificar
Nadie quiere sentir que compró "por impulso". Cuando notes que tu clienta ya se enamoró del producto, dale un dato lógico que le dé tranquilidad: cuánto le dura, cómo se usa, qué incluye. Así se va contenta y con argumentos para contarle a quien le pregunte.

## Cuando se vuelve todo números
Si la plática se queda solo en precios y comparaciones, regrésala a lo que siente. Pregunta para qué lo quiere, cuándo lo va a usar, cómo se quiere ver. Cuando se pierde la emoción, el precio se vuelve un monstruo.

## 🪞 Mírate al espejo
¿Cuál de las tres llaves se te olvida más? ¿Te quedas en la atención y no llegas al recuerdo?

## ✍️ Ejercicio
Para tu producto estrella escribe:
1. Una frase para ganar **atención** (algo conocido más algo nuevo).
2. Una frase de **emoción** (cómo se va a sentir).
3. Una frase de **recuerdo** (cómo encaja en su vida, en su día).
4. Las **tres opciones** que le vas a ofrecer.

## ✅ Tu tarea de la semana
Ofrece siempre tres opciones esta semana, en lugar de una o de todo el catálogo.

## 💬 Para compartir en el grupo
¿Cuáles son tus tres opciones para tu producto estrella?

@@ 4 | Clase 4 | Lo que la mente busca | Cinco cosas que tu clienta quiere sentir
En cualquier plática de venta, la mente de tu clienta está buscando cinco cosas. Si se las das, se queda contigo.

## 1. Sorpréndeme
A la mente le encanta lo nuevo, pero anclado en algo que ya conoce. No tienes que inventar productos nuevos; muéstrale un ángulo que no había visto: otra forma de usarlo, otro momento del día, otra combinación. Sin exagerar: si suena a circo o a promesa imposible, se desconecta.

## 2. Hazme sentir inteligente
El peor error es que tu clienta se sienta tonta. Nada de tecnicismos ni nombres de ingredientes que no entiende. Explícalo con lo que vive: "es la que se absorbe rápido y no te deja brillosa". Dale la razón, hazla sentir que ella eligió bien.

## 3. Déjame preguntar
La mente aprende mejor cuando ella pregunta y tú respondes, que cuando le sueltas todo de golpe. Si te repite una pregunta, no te desesperes: está disfrutando escuchar otra vez lo que le gustó. Y nunca le preguntes "¿me entendiste?". Pregunta **"¿fui clara?"**: la responsabilidad de explicarte bien es tuya.

## 4. Quítame un dolor
Lo que más fideliza no es la sorpresa ni el placer: es **quitarle un dolor**. Una mala experiencia con otra marca, un pedido que nunca llegó, una piel que nada le funciona. Déjala contar. Hazla sentir comprendida: "sí, eso pasa, no eres la única, tiene solución". Y si te dice un miedo, contéstalo siempre. Si no sabes, dile "no lo sé, déjame averiguarlo ahorita". Nunca dejes un miedo sin respuesta.

## 5. Siente conmigo
Tu clienta quiere sentir que hablas con una persona, no con una máquina de vender. Muestra tus emociones y fíjate en las suyas. Si ella habla con las manos, tú también. Si va despacio, tú también. Ese espejo natural hace que se sienta en confianza.

> Hazme sentir inteligente, entendida y acompañada, y te compro a ti.

## El orden que funciona
Primero sorpréndela para ganar su atención, luego hazla sentir inteligente, déjala preguntar, escucha su dolor, y todo el tiempo siente con ella.

## 🪞 Mírate al espejo
¿Alguna vez una clienta se fue confundida o se sintió tonta en tu plática? ¿Qué pasó?

## ✍️ Ejercicio
1. Escribe cómo explicas hoy tu producto estrella.
2. Reescríbelo sin una sola palabra técnica, como se lo dirías a tu mamá.
3. Escribe qué dolor le quita a tu clienta.

## ✅ Tu tarea de la semana
Pregúntale a tres clientas: "¿qué es lo que menos te ha gustado de otras marcas que has probado?" y anota las respuestas.

## 💬 Para compartir en el grupo
Comparte un dolor de tus clientas que tu producto resuelve.

@@ 5 | Clase 5 | El significado | Las cosas valen por lo que significan
Las cosas valen más por lo que significan que por lo que son. Cuando tu producto significa algo, el precio deja de ser el tema.

## Lo que es y lo que significa
Un labial es pigmento en una barra. Pero para tu clienta puede significar "hoy me arreglé para mí", "me siento lista para la entrevista" o "volví a sentirme bonita después del bebé". Ese significado es lo que compra, y por eso paga gustosa.

## De dónde sale el significado
Una decisión de compra mezcla tres cosas:
- **Lo que ella opina.** Es lo que te dice, y es lo que menos pesa.
- **Su cultura.** Lo que ese producto significa en su entorno, con sus amigas, en su ciudad.
- **Su biología.** Lo que todas compartimos: queremos cuidarnos, pertenecer, que nos vean.

Donde se juntan la cultura y la biología nace el significado. Ese es el imán.

## Mismo producto, distinto significado
Imagina que alguien recibe un regalo precioso y le encanta. Luego le cuentan, muy orgullosos, que lo compraron en oferta en el súper. El regalo es el mismo, pero ya no se siente igual. **No cambió el producto, cambió lo que significaba.** Cuida cómo presentas, cómo entregas y cómo hablas de lo que vendes.

## Pregúntale cómo se quiere sentir
Una de las preguntas más poderosas es: **"¿Cómo te quieres sentir?"** o "¿para qué ocasión lo quieres?". Con su respuesta ya sabes qué ofrecerle y cómo decirlo: "este tono te va a hacer sentir segura en tu presentación".

## El precio y el significado
La vendedora que cree que todo se trata de precio no conoce el significado de lo que vende. Bajar el precio no te hace ganar: te hace trabajar más por menos. Cuando la diferencia de precio es pequeña, gana la que conectó con lo que el producto significa.

> Si la única razón para comprarte es que eres más barata, cualquiera te reemplaza.

## No se dice, se da a entender
El significado no se anuncia ("esto es para que tus amigas te envidien"). Se transmite con cómo lo presentas, con la historia, con el empaque, con tu forma de entregarlo.

## 🪞 Mírate al espejo
¿Has bajado tus precios o regalado de más por miedo a que no te compren?

## ✍️ Ejercicio
1. Elige tu producto estrella.
2. Escribe qué **es** en una línea.
3. Escribe tres cosas que puede **significar** para distintas clientas.
4. Escribe cómo vas a entregarlo para cuidar ese significado (empaque, nota, mensaje).

## ✅ Tu tarea de la semana
Pregunta "¿cómo te quieres sentir?" o "¿para qué ocasión es?" en cada venta de la semana.

## 💬 Para compartir en el grupo
¿Qué significa tu producto estrella para tus clientas? Comparte la mejor respuesta que te hayan dado.

@@ 6 | Clase 6 | Miedos e historias | Lo que mueve y lo que convence
Casi todo lo que compramos sirve para calmar algún miedo. Y nada explica mejor que una historia.

## Los miedos que ya existen
Comprar algo casi siempre calma un miedo: a verse cansada, a no gustar, a quedarse fuera, a perder tiempo, a gastar mal. Tu trabajo **no es crear miedos**: eso es manipular y no lo hacemos. Tu trabajo es descubrir los que tu clienta ya trae y darle una solución honesta.

Pregúntate siempre: ¿qué le preocupa a mi clienta cuando llega a comprar? Si no lo sabes, ese miedo juega en tu contra. Si lo sabes, puedes acompañarla.

## Tres tipos de historia
A la mente le encantan las historias, y cada tipo hace un trabajo distinto:
- **La historia incómoda llama la atención.** Empieza reconociendo lo que no está bien: "te voy a ser honesta, muchas cremas prometen de más". Cuando reconoces lo malo, te creen lo bueno.
- **La historia positiva mueve a la acción.** Un caso real o un dato verdadero, con prueba: la reseña de una clienta, una foto real de cómo le quedó el tono (con su permiso), la ficha del producto.
- **La historia tranquila justifica.** Cuando te dice "lo voy a pensar", no la presiones: "claro, piénsalo bien. Te dejo esta información para que la veas con calma".

> Los datos informan. Las historias convencen. La verdad sostiene.

## La escalera: seguridad, comodidad y gusto
Todo producto debe dar tres cosas, en este orden:
1. **Seguridad:** "es confiable, no te va a hacer daño, tu dinero está bien invertido".
2. **Comodidad:** "es fácil de usar, no te complica la mañana".
3. **Gusto:** "y vas a disfrutar usarlo, cómo huele, cómo se siente".

Si empiezas por el gusto sin dar seguridad, la mente desconfía.

## Del dato al disfrute y del disfrute al significado
Empieza por lo lógico (qué hace y para qué sirve), llévala a lo que va a disfrutar y termina en lo que significa para ella. No te quedes en un solo nivel: es un viaje.

## Tu carpeta de pruebas
Si una clienta te dice "escuché que esa marca no es buena", no discutas. Pregunta dónde lo escuchó y qué le dijeron. Luego enséñale pruebas reales: reseñas, artículos, testimonios con permiso. Lo que sale de tu boca se duda; lo que ve con sus ojos, se cree. Junta esas pruebas en una carpeta en tu celular.

## 🪞 Mírate al espejo
¿Qué miedos trae tu clienta ideal cuando llega a comprar?

## ✍️ Ejercicio
1. Escribe tres miedos reales de tu clienta ideal.
2. Para tu producto estrella, escribe una historia incómoda, una positiva y una tranquila.
3. Ordena tus argumentos en la escalera: seguridad, comodidad, gusto.

## ✅ Tu tarea de la semana
Arma tu carpeta de pruebas en el celular con al menos cinco reseñas, fotos o testimonios reales (con permiso).

## 💬 Para compartir en el grupo
¿Cuál es la objeción que más escuchas? Juntemos pruebas entre todas.

@@ 7 | Clase 7 | Cuerpo, sentidos y trato | Cómo se siente estar contigo
Tus palabras son solo una parte de lo que comunicas. Tu cuerpo, tu tono y lo que tu clienta toca y huele dicen más.

## Tu cuerpo habla primero
El cuerpo comunica desde mucho antes que las palabras. Si dices "cuéntame qué buscas" con los brazos cruzados y viendo el celular, tu clienta escucha "no me interesas". Y el tono cambia todo: "qué bonita estás" puede sonar a cumplido o a burla.

## La mirada guía
Mírala a los ojos cuando le hablas y luego lleva tu mirada al producto: ella va a seguirla. Si le dices "mira este tono" mientras ves a otro lado, se pierde. En video y en redes pasa igual: mira a la cámara cuando hablas y al producto cuando lo enseñas.

## Los cinco sentidos venden
La mente decide con todos los sentidos, y en belleza eso es oro:
- **Tacto:** que lo toque, que se lo pruebe en la mano.
- **Olfato:** que huela el perfume, la crema, el producto abierto.
- **Vista:** que vea el tono en su piel, no en la foto.
- **Gusto y comodidad:** un vaso de agua, algo dulce, un lugar para sentarse. Alguien con sed o cansada no compra.
- **Oído:** música tranquila si recibes en casa o en un evento.

## Dale espacio
A nadie le gusta que lo persigan. Saluda con calidez y déjala ver y soñar con calma. Mantente cerca y atenta para cuando termine de explorar y te necesite.

## Coincide antes de agregar
Si te dice "me dijeron que esos productos resecan", no le digas "eso no es cierto". Primero dale la razón en lo que tenga: "tienes razón, hay pieles que se resecan con algunos productos". Luego agrega: "por eso te recomiendo esta, que tiene hidratación extra; si quieres pruébala en la mano".

## Cuida a su gente
Si llega con sus hijos, atiéndelos también: salúdalos, ofréceles agua, algo para entretenerse. Una mamá no olvida a quien trató bien a sus hijos.

## Corto, claro y con historias
Lo simple gana. Los primeros y los últimos minutos son los que más se recuerdan, así que prepara bien cómo abres y cómo cierras. Y explica con comparaciones y refranes: una buena analogía vale más que un párrafo.

> Sonríe de verdad. El buen humor relaja, conecta y vende.

## Palabras que activan
Usa verbos de acción: lograr, disfrutar, proteger, transformar, consentir, alcanzar. "Con esta rutina vas a disfrutar tus mañanas" se queda más que "esta rutina es muy buena".

## 🪞 Mírate al espejo
Si te grabaras vendiendo, ¿qué diría tu cuerpo sin el audio?

## ✍️ Ejercicio
1. Grábate un minuto explicando tu producto estrella.
2. Míralo sin sonido: ¿qué comunica tu cuerpo?
3. Escribe cómo vas a involucrar al menos tres sentidos en tu próxima venta.

## ✅ Tu tarea de la semana
En cada venta de esta semana, haz que tu clienta toque o huela el producto antes de hablarle del precio.

## 💬 Para compartir en el grupo
¿Qué haces para que tus clientas prueben con los sentidos? Comparte tu truco.

@@ 8 | Clase 8 | Seguimiento y tu mente vendedora | La relación sigue después del sí
La venta no termina cuando te pagan. Y antes que la clienta, la primera mente que tienes que preparar es la tuya.

## Seguimiento sin presionar
La mente necesita espacio para pensar. Escribirle tres veces al día "¿ya te decidiste?" la aleja. El seguimiento que funciona **aporta algo**: un tip para su tipo de piel, un video de cómo usar el producto, algo que te acordaste por ella. Así, cuando esté lista, te busca a ti.

## Primero amistad, luego negocio
Las mejores ventas pasan con gente que te conoce y te tiene confianza. Interésate por su vida, por su trabajo, por sus hijos, de verdad. Pero no mezcles: si te invitan a una fiesta, disfruta la fiesta. Al otro día, si viene al caso, platican del negocio.

## Un error bien atendido
Cuando algo sale mal (un pedido que no llegó, un tono que no le quedó), ahí empieza el fracaso o la lealtad para siempre. La clienta llega lista para pelear. Escúchala completa, dale la razón y resuélvelo con generosidad: "tienes toda la razón, no era mi intención fallarte; vamos a cambiarlo por el que sí te queda". Esa clienta se vuelve tu fan.

## El orgullo de vender
A muchas les da pena decir que venden. Cámbialo: no "vendo cremas", sino **"ayudo a mujeres ocupadas a cuidarse en cinco minutos"**. Cuando tú y tu familia entienden el valor de lo que haces, se te nota en todo.

## Tu mente también decide
- **Declara tu meta con claridad.** Si te pones un techo bajo, tu mente se acomoda a ese techo.
- **Usa el no como gasolina.** Quince minutos después de un "no", pregúntate: ¿qué dije?, ¿en qué momento se desconectó?, ¿qué cambio la próxima vez?
- **La pasión sostiene.** Vender cansa; lo que te mantiene es creer en lo que vendes y disfrutar ayudar.

> El cerebro prefiere quedarse igual. El hábito le gana a la flojera.

## El reto: 48 horas y 66 días
1. Tienes **48 horas** para aplicar algo de este curso con una clienta real. Si dejas pasar más tiempo, lo más probable es que ya no lo hagas.
2. Dedica **15 minutos al día durante 66 días** a mejorar cómo vendes: leer, practicar tu guion, grabarte, escuchar. Es el tiempo que suele tomar volver algo un hábito.

## 🪞 Mírate al espejo
¿Cómo describes lo que haces cuando alguien te pregunta a qué te dedicas?

## ✍️ Ejercicio
1. Reescribe "a qué te dedicas" en una frase que diga a quién ayudas y cómo.
2. Regresa a las tres frases de venta que escribiste en la Bienvenida y reescríbelas con lo que aprendiste.
3. Escribe tu acción para las próximas 48 horas.

## ✅ Tu tarea de la semana
Empieza tu reto de 66 días con la herramienta **Tu reto de 66 días**.

## 💬 Para compartir en el grupo
Comparte tus frases de antes y de después. Celebren el cambio.

@@ 9 | Herramientas | Tu guion de El Clic | Arma tu plática para un tipo de clienta
No es un guion para recitar. Es una estructura para que tú construyas tus propias palabras. Si cambia la clienta, cambia todo.

## Antes de hablar: tres preguntas
1. **¿Quién es?** Un tipo de clienta concreto: mamá ocupada, recién egresada, señora que se quiere consentir, novia a punto de casarse.
2. **¿Cuál es su necesidad de fondo?** Seguridad, pertenecer, reconocimiento, placer, control, libertad, explorar o trascender.
3. **¿Qué miedo trae?** El que tú puedes ayudar a calmar con honestidad.

## Luego, las tres llaves
- **Atención:** una historia real o algo que reconoces con honestidad.
- **Emoción:** cómo se va a sentir, con sus propias palabras.
- **Recuerdo:** cómo encaja en su vida y su día.

## Ejemplo: rutina de cuidado para una mamá ocupada
- **Quién:** mamá de dos, trabaja, siente que ya no tiene tiempo para ella.
- **Necesidad de fondo:** libertad (un ratito para ella) y trascender (verse bien con sus hijos).
- **Miedo:** verse cansada, sentirse descuidada, gastar en algo que no va a usar.
- **Atención:** "Te voy a ser honesta: la mayoría de las rutinas de diez pasos terminan olvidadas en el baño."
- **Emoción:** "Esta es de tres pasos. Son cinco minutos en la mañana que son solo tuyos, y se nota."
- **Recuerdo:** "Imagínate en la foto del cumpleaños de tu hija, sintiéndote fresca y contenta contigo."
- **Dato para justificar:** "Te dura alrededor de dos meses usándola diario."
- **Tres opciones:** solo la crema, la rutina de tres pasos o la rutina con el sérum.

## Tu turno
Llena el mismo esquema para tu clienta más común. Luego hazlo para otra muy distinta y fíjate cuánto cambia.

> ¿Quieres que te ayuden a armarlo? Pídeselo al mentor en la pestaña **Tu mentor**.

@@ 10 | Herramientas | Tu reto de 66 días | 15 minutos al día
El cerebro prefiere quedarse igual porque cambiar le cuesta energía. El hábito es lo que le gana. Aquí tienes ideas para tus 15 minutos diarios.

## Las primeras 48 horas
Elige una sola cosa del curso y aplícala con una clienta real antes de que pasen dos días. Anota qué pasó.

## Ideas para tus 15 minutos
- Reescribe la descripción de un producto sin palabras técnicas.
- Practica tu guion de El Clic en voz alta o grábate.
- Mira un video tuyo vendiendo sin sonido y revisa tu cuerpo.
- Agrega una prueba nueva a tu carpeta (una reseña, una foto con permiso).
- Escribe a una clienta solo para aportarle algo, sin vender.
- Repasa una clase y haz su ejercicio otra vez.
- Después de un "no", escribe qué dijiste y qué cambiarías.

## Cómo llevar la cuenta
- Marca cada día en tu calendario o en el cuaderno de esta herramienta.
- Si fallas un día, no empiezas de cero: retomas al día siguiente.
- Cada semana, comparte en el grupo una cosa que aprendiste.

> El día 67 ya no te va a costar. Ya va a ser parte de ti.

@@ 11 | Herramientas | Para líderes de equipo | Motivar sin gritar
Si diriges un equipo, estas ideas te ayudan a que nadie se quede atrás.

## Que nadie se quede fuera
Cuando siempre ganan las mismas tres, las demás dejan de intentarlo. Haz como los juegos que te ayudan a pasar de nivel cuando te atoras: si alguien no logra la meta grande, dale una más pequeña que sí pueda cumplir, y luego la siguiente. Que nadie termine un mes sintiendo que no sirve para esto.

## Premios que se sueñan
Un premio en efectivo muchas veces se va en la casa, los pagos y los niños. Un premio que ella sueña tener pero no se compraría con su dinero (una bolsa, una experiencia, un día de spa) mueve más. Eso sí, no preguntes qué premio quieren: casi todas van a decir "dinero".

## Reconocer frente a quien importa
Un diploma frente a las compañeras está bien, pero lo que de verdad pesa es que su familia vea su logro. Busca formas de reconocerla donde su gente lo vea: un mensaje para compartir, una celebración donde pueda invitar a los suyos.

## Hacerlas sentir necesarias
No es lo mismo "si no llegas a la meta, no te necesitamos" que "te necesitamos aquí, por eso vamos juntas por la meta". La primera apaga; la segunda enciende.

## Cuando alguien quiere sumarse
Más que el currículum, platica con ella sobre:
- Un reto que haya superado en su vida.
- Algo que la apasione y que **haga**, no solo que mire.
- Cómo reacciona cuando algo le sale mal.
- Qué tan cómoda se siente diciendo que quiere crecer.

> Un equipo motivado se siente parte de algo. El dinero importa, pero pertenecer importa más.
