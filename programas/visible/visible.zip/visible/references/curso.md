# Visible: contenido del curso

Formato: cada clase empieza con `@@ número | etiqueta | título | tema`. Las clases 15 a 19 son herramientas.

@@ 0 | Empieza aquí | Bienvenida a Visible | Lo que va a pasar en estos 90 días
Visible es una temporada de 90 días para construir tu marca personal, ordenar tu contenido y aprender a vender sin sentir que persigues a nadie. Antes de empezar, conviene saber lo que va a pasar contigo en el camino.

## La emoción del inicio se acaba
Todo lo nuevo emociona. Pasa con un celular nuevo: los primeros días lo limpias, le pones funda y mica. A las semanas ya se cayó dos veces y ni lo notas. Con este curso va a pasar igual: hoy traes ganas, pero en unas semanas la emoción baja. Eso no significa que vas mal. Significa que entraste a la parte real.

> No se trata de emocionarte al empezar, sino de mantenerte cuando nadie te está aplaudiendo.

## Tu cerebro te va a querer regresar
Tu mente está hecha para protegerte de lo incómodo y lo desconocido. Por eso, cuando empiezas algo nuevo, aparecen frases como "esto no es para ti", "das pena", "nadie te ve", "otra vez vas a fallar". Hasta el cuerpo se queja, como cuando vuelves al gimnasio. Cuando lo notes, dilo así: "mi mente está haciendo su trabajo; yo voy a hacer el mío". Y avanza con todo y miedo.

## Tres cosas que te sostienen
- **Resiliencia:** levantarte rápido de un mal día. Ya lloraste, ya dudaste; mañana vuelves a grabar. En días difíciles pregúntate "¿qué sí puedo hacer hoy?" en lugar de "¿por qué no puedo?".
- **Disciplina:** hacer lo que dijiste, aunque no tengas ganas. Poquito, pero diario. Y cero negociaciones contigo misma del tipo "nadie se va a dar cuenta si hoy no publico".
- **Enfoque:** poner tu energía en lo que importa. La dueña de un negocio no está disponible para todo ni para todos.

## Compórtate como la dueña que quieres ser
Haz una lista de cómo es la dueña de negocio que quieres llegar a ser: a qué hora se levanta, cómo se arregla, qué consume, cómo organiza su semana, cómo trata a su equipo. No le pongas tu nombre todavía. Después marca, sin juzgarte, cuáles de esas cosas ya haces. Empieza a comportarte como ella desde hoy, no "hasta que" llegue el resultado.

## Celebra acciones, no likes
Durante estos 90 días no vas a celebrar que un video se hizo viral. Vas a celebrar que cumpliste tus publicaciones de la semana, que contaste tu historia, que tuviste una conversación difícil. El resultado llega como consecuencia.

## 🪞 Mírate al espejo
¿Qué frases te dice tu mente cuando empiezas algo nuevo? ¿Cuál es la que más te frena?

## ✍️ Ejercicio
1. Escribe tu **gran objetivo de 90 días**. Que te saque de tu zona cómoda, pero que sea alcanzable.
2. Define **3 acciones innegociables** que vas a hacer cada semana.
3. Escribe tu **plan de rescate**: qué vas a hacer el día que te caigas para levantarte al día siguiente.
4. Anota **3 cosas que vas a dejar de hacer** porque te dispersan.

## ✅ Tu tarea de la semana
Agenda en tu calendario un bloque fijo para el curso y otro para crear contenido, como si fueran juntas de trabajo.

## 💬 Para compartir en el grupo
Comparte tu objetivo de 90 días y tus 3 innegociables. Que el equipo te los recuerde.

@@ 1 | Clase 1 | Los planos de tu marca | Qué estás construyendo y para qué
Si no sabes qué estás construyendo, a la mitad del camino vas a querer cambiar todo. Esta clase es para dibujar los planos antes de poner ladrillos.

## Tu negocio es un reflejo de ti
Antes de pensar en estrategias, piensa en ti. Tu negocio crece hasta donde creces tú. Si construyes desde la carencia, la prisa o la herida, se nota. Si construyes desde tu propósito, también se nota.

## ¿Qué estás construyendo?
No es lo mismo construir una **marca personal**, una **comunidad**, una **empresa** o solo **presencia en redes**. Las cuatro son válidas, pero cada una pide cosas distintas. La pregunta incómoda: lo que haces hoy, ¿tiene forma o solo te mantiene ocupada?

## Los planos de la casa
Imagina tu marca como una casa. ¿Es una casa de un piso, de dos, una cabaña, un hotel? Si no tienes planos, a la mitad vas a decir "mejor quiero la cocina del otro lado" o "mejor sí quería alberca", y vas a perder tiempo, dinero y energía. Los planos no son tu meta: son tus valores y la raíz de lo que construyes (autenticidad, disfrutar el proceso, libertad, viajar con tu familia).

## Una meta que puedas creer
Pon una meta de dinero retadora, pero congruente con lo que haces hoy. Si hoy no facturas nada, una meta enorme te va a desmotivar porque no la vas a ver cerca. Y habla de dinero con naturalidad: estás construyendo un negocio, no un pasatiempo.

> La distancia entre lo que dices que quieres y lo que haces cada día es el camino más corto a la frustración.

## El costo escondido de construir sin plan
Publicar y publicar sin rumbo te lleva a improvisar, compararte, perder energía, desconectarte de tu audiencia y terminar agotada sin vender. Por eso esta parte introspectiva va primero: después, ejecutar es lo fácil.

## Tu negocio como sistema
Piensa en tu negocio como un sistema con cinco piezas:
1. **Una marca clara:** tus valores y lo que proyectas.
2. **Tu oferta:** el producto, servicio o negocio que vendes.
3. **La audiencia correcta:** las personas a las que de verdad les interesa.
4. **Tu rutina de contenido:** qué, cuándo y cómo publicas.
5. **Una mente resiliente** que sostenga todo lo anterior.

Con un sistema, el primer "no" no te tumba. Sin sistema, cualquier piedra te saca del camino.

## 🪞 Mírate al espejo
¿Tus hábitos de hoy muestran que tu marca es una prioridad en tu vida?

## ✍️ Ejercicio
1. Responde: ¿estoy construyendo una marca personal, una comunidad, una empresa o presencia digital?
2. Dibuja los planos de tu casa, como lo haría una niña. A cada cuarto ponle un valor o una razón de ser.
3. Completa la frase: "Estoy construyendo ________ para ________."

## ✅ Tu tarea de la semana
Toma foto de tus planos y ponlos donde los veas todos los días.

## 💬 Para compartir en el grupo
Comparte tu frase "Estoy construyendo… para…" y, si te animas, la foto de tus planos.

@@ 2 | Clase 2 | Las bases de una marca que vende | Autoridad, propuesta de valor y tu forma de ser
Hay cuentas que no venden un peso y cuentas que venden todos los días. La diferencia casi nunca son los seguidores: es qué tanto te ven como alguien que sabe del tema.

## Catálogo o autoridad
Si tu cuenta es un catálogo de productos, solo vas a pescar a quien ya tenía urgencia de comprar. Cuando apareces tú, enseñas, muestras cómo lo usas y por qué lo elegiste, la gente te tiene en la mente todo el tiempo, no solo cuando necesita el producto. Esa es la magia de la marca personal.

## Base 1: claridad de tu modelo de negocio
Responde sin titubear:
- ¿Qué vendes?
- ¿A quién se lo vendes?
- ¿Cómo lo entregas?
- ¿Cuánto cuesta, cuánto ganas y cuánto reinviertes?

Si no sabes tu margen, es muy difícil crecer.

## Base 2: tu propuesta de valor
¿Por qué tú, por qué ahora y por qué no alguien más? En venta directa, muchas venden el mismo producto al mismo precio. Lo único distinto eres tú: tu esencia, lo que sabes, cómo acompañas, tu forma de ver la vida.

## Base 3: humanizar tu marca (bien hecho)
Humanizar **no** es:
- Hablar sin parar a la cámara.
- Contar tus desgracias sin dejar ninguna enseñanza.
- Aparecer solo cuando estás de buenas y desaparecer semanas.

Humanizar **sí** es compartir lo que vives con un mensaje al final. Si tuviste un día terrible, no te quedes en la queja: cuenta qué aprendiste. Y es mantenerte constante en los buenos y en los malos días.

> Antes de compartir algo personal, pregúntate: ¿qué quiero aportar con esto?

## Conócete para comunicar
Tu marca refleja tu personalidad. Hay cuatro estilos naturales (los vas a encontrar en la herramienta **Test de tu estilo**): La Líder, La Chispa, La Arquitecta y La Cálida. Ninguno es mejor. Conocer el tuyo te ayuda a usar tus fortalezas y a no autosabotearte con tus puntos débiles.

## ¿Qué quieres que sientan?
Dos cuentas pueden tener el mismo nicho y el mismo objetivo, pero provocar emociones opuestas. Una confronta ("levántate media hora antes, deja de justificarte"); otra abraza ("tranquila, mañana es otro día"). Decide qué emoción quieres que sienta alguien al entrar a tu perfil.

## Mentalidad de directora
Tu tiempo, tus ideas y tu contenido son activos de tu negocio, no un hobby. Crear contenido es parte de tu trabajo, como contestar a tus clientas.

## 🪞 Mírate al espejo
Si alguien entra hoy a tu perfil, ¿ve un catálogo o ve a una persona que sabe y acompaña?

## ✍️ Ejercicio
1. Responde las 4 preguntas de tu modelo de negocio.
2. Escribe en 3 líneas por qué alguien debería comprarte a ti y no a otra que vende lo mismo.
3. Elige la emoción principal que quieres provocar en tu perfil.

## ✅ Tu tarea de la semana
Haz el **Test de tu estilo** en Herramientas y escribe una fortaleza que vas a usar y un reto que vas a cuidar.

## 💬 Para compartir en el grupo
¿Qué estilo te salió y qué emoción quieres provocar en tu perfil?

@@ 3 | Clase 3 | Tu nicho y tu tribu | A quién viniste a servir
Si le hablas a todo el mundo, no le hablas a nadie. Esta clase es para saber exactamente a quién le hablas y qué problema le resuelves.

## Tu nicho es tu yo del pasado
Una forma sencilla de encontrar tu nicho: piensa en ti antes de resolver el problema que hoy ya tienes resuelto. ¿Cómo te sentías? ¿Perdida, frustrada, cansada, insegura? A esa mujer es a la que le hablas. Le puedes decir con autoridad "yo tengo el camino para salir de ahí", porque tú ya estás del otro lado.

## No vendes productos, vendes lo que provocan
Si vendes belleza, no te quedes en "vendo productos" ni en los ingredientes. Nadie anda por la vida buscando ingredientes: busca sentirse mejor. Pregúntate qué te hizo sentir a ti ese producto: seguridad, ganas de cuidarte, volver a mostrarte. Ahí está tu nicho.

## Tu producto, dentro de tu vida
El nicho no es una jaula. Puedes compartir tu vida (rutina, viajes, maternidad, ejercicio, espiritualidad) siempre que conectes tu producto con ella:
- Si vendes joyería y te gusta viajar: cómo organizas tus piezas en la maleta.
- Si te encanta tu matrimonio: los cinco regalos que te gusta recibir, y uno es joyería.
- Si vendes cuidado personal: tu rutina real, cómo empacas los pedidos, el día que te equivocaste de caja y esa clienta se volvió tu amiga.

> Instagram y TikTok están hechos para entretener. La pregunta es: ¿cómo hago que mi contenido entretenga y termine en una venta?

## Construye una tribu
Las personas buscan pertenecer. Una tribu se identifica, se apoya y se queda contigo por mucho tiempo. Tu nicho no es solo quien te compra; es quien quieres que se vuelva fiel a ti.

## No le vas a gustar a todos (y está bien)
Gustarle a todo el mundo es señal de que no estás comunicando con claridad. Si a alguien no le gusta tu contenido, no es personal: probablemente no eres para esa persona.

## Que sea rentable
Elige un nicho que pueda pagar lo que ofreces. Y uno que disfrutes tanto que lo harías aunque no te pagaran.

## 🪞 Mírate al espejo
¿Qué problema tenías antes que hoy ya tienes resuelto gracias a tu negocio?

## ✍️ Ejercicio
Llena la **Ficha de tu clienta ideal** (en Herramientas). Sobre todo la tabla del antes y el después: qué tiene, qué siente, cómo es su día y cómo se ve antes y después de conocerte.

## ✅ Tu tarea de la semana
Revisa tus últimas 9 publicaciones: ¿le hablan a tu clienta ideal o a todo el mundo? Marca cuáles sí y cuáles no.

## 💬 Para compartir en el grupo
Describe a tu clienta ideal en tres líneas y que el equipo te diga si le queda claro.

@@ 4 | Clase 4 | Fuego lento | Paciencia con estrategia
Vivimos queriendo todo en 30 segundos. Pero un negocio que dura no se cocina en el microondas: se cocina a fuego lento.

## Fuego rápido vs fuego lento
Con **fuego rápido** quieres resultados ya: el reel con miles de comentarios, ventas la primera semana, multiplicar tu negocio en un mes. Y cuando no pasa, te frustras y lo dejas. Con **fuego lento** sabes que tardas más, pero estás usando buenos ingredientes, y lo que sale vale la pena.

> Lo viral entretiene. Lo constante transforma.

## Señales de fuego rápido
- Te frustras si un contenido no pega.
- Lanzas todo sin estrategia.
- Te saltas clases porque "eso ya lo sé".
- Necesitas que tu familia o tus amigas te feliciten.
- Cambias de idea de negocio cada semana o cada quince días.

Sobre la validación: no esperes aplausos de tu círculo cercano. Muchas veces el reconocimiento llega primero de desconocidos. La satisfacción más grande está en lo que haces en privado.

## El ciclo del trabajo profundo
1. **Visión clara:** si todavía titubeas sobre a dónde vas, regresa a la Clase 1.
2. **Planificación:** qué hábitos y rutinas te llevan al resultado. Incluso a qué hora te bañas y arreglas, para que cuando prendas la cámara ya estés lista.
3. **Acción enfocada:** decide en qué momentos usas el celular para trabajar y en cuáles te das permiso de distraerte.
4. **Revisión y repetición:** revisa qué funciona, ajusta y repite. Sin repetición no hay resultado.

## Cinco pasos para cambiar de fuego
1. No mires atrás con culpa por el tiempo perdido; mira hacia adelante.
2. Celebra los avances pequeños.
3. Empieza con cambios chiquitos: levantarte 30 minutos antes, dejar tu ropa lista, bañarte antes de llevar a los niños.
4. Diseña rutinas que puedas sostener (dos hojas de un libro al día es mejor que prometer un libro por semana).
5. Antes de consumir, crea.

## 🪞 Mírate al espejo
¿Dejas cosas a la mitad? ¿Lanzas desde el miedo, desde la aprobación o desde una visión clara?

## ✍️ Ejercicio
1. Marca cuántas señales de fuego rápido tienes.
2. Escribe una rutina diaria sencilla y alcanzable para tu negocio (máximo 4 acciones).
3. Define tu momento sin distracciones de cada día.

## ✅ Tu tarea de la semana
Sigue tu rutina 5 días seguidos y anota cómo te fue cada día.

## 💬 Para compartir en el grupo
¿Cuál es la señal de fuego rápido que más te identifica y qué vas a cambiar?

@@ 5 | Clase 5 | Tu historia | Storytelling que conecta y posiciona
No te puedo hablar de vender ni de crear contenido antes de que tengas tu historia. Si no dominas tu historia, la gente se pierde en tu mensaje.

## No tiene que ser trágica
Tu historia no necesita ser la más dramática del mundo. Necesita tener un problema resuelto y una razón fuerte de ser. A veces lo más pequeño es lo más poderoso: alguien que antes no podía tomarse su café con calma y hoy sí.

## ¿Qué historia de tu vida conecta con lo que haces?
Ve al fondo. No "porque el producto era bueno". Tal vez creciste viendo a tu mamá en venta directa, o emprendiste para estar con tus hijos, o porque no querías depender de nadie, o porque un jefe te hizo sentir que no valías. Ahí está el origen de tu propósito.

## Tres dolores resueltos
Escribe tres dolores que tenías hace tiempo y que hoy ya resolviste, aunque sean pequeños: "era insegura", "me estresaba el dinero", "no estaba presente con mis hijos". Estos dolores son los que te posicionan, porque tienes algo real que contar.

## La estructura
1. **Antes:** cómo era tu vida, qué sentías, qué te faltaba.
2. **Lo que dolía de verdad:** el dolor silencioso detrás de lo obvio.
3. **El giro:** qué descubriste, cómo llegó la oportunidad, qué decidiste.
4. **Hoy:** cómo es tu vida ahora. Con datos, si puedes (las mentes más analíticas confían en números).
5. **La invitación:** a quién invitas y qué le pides que haga.

> Las historias que más conectan tienen la herida sanada. Se cuentan desde la transformación, nunca desde el papel de víctima.

## Una historia, muchas veces
Tu historia no se cuenta una vez y ya. Se cuenta muchas veces y en muchos formatos: un reel, un carrusel, historias, un live. A veces con más detalle, a veces con menos, pero siempre la misma historia, congruente. Si un día cuentas que tuviste poco dinero y otro día que viajabas todo el tiempo, la gente deja de creerte.

## Si haces venta directa
Si vendes producto y también formas equipo, enfoca la mayor parte de tu historia en lo que el negocio cambió en tu vida y la menor parte en el producto. Tú eres la prueba: tu estilo de vida vende más que una ficha técnica.

## Cómo grabarla
- Vertical, con luz natural de frente, sin filtros.
- Cámara fija y centrada (un tripié o unos libros).
- Habla claro y con energía. Unos audífonos con micrófono sirven.
- Agrega escenas de apoyo: tú trabajando, con tu familia, en una videollamada.
- Arréglate como si te fuera a ver alguien que te puede cambiar la vida.
- No esperes a sentirte lista. Puedes practicar antes y repetir cuantas veces quieras.

## Limpieza digital
Antes de contar tu historia, limpia tu entorno: deja de seguir cuentas que no te aportan, silencia historias que te distraen y conviven más con las cuentas que sí te inspiran.

## 🪞 Mírate al espejo
¿Cuál fue el momento exacto en que decidiste emprender? ¿Qué estabas viviendo?

## ✍️ Ejercicio
Escribe tu historia con la **Plantilla de tu historia** (en Herramientas). Que puedas contarla en un minuto.

## ✅ Tu tarea de la semana
Graba y publica tu historia en un reel hablado a cámara. Bonus: un carrusel de antes y después con fotos de esa etapa y de hoy.

## 💬 Para compartir en el grupo
Comparte tu reel y comenta el de otra compañera.

@@ 6 | Clase 6 | Tus pilares de contenido | Dejar de improvisar
Si publicas mucho y no avanzas, probablemente no es falta de esfuerzo, sino de dirección. Los pilares son los temas fijos que guían tu contenido cada semana.

## Qué reflejan tus pilares
1. Lo que sabes o has vivido.
2. Lo que tu audiencia necesita o desea.
3. Lo que te posiciona para vender.

## Los cuatro pilares
- **Educativo:** enseñas. Tips, errores comunes, tutoriales, "te enseño cómo". Es el que menos alcance tiene, pero el que más rápido te posiciona como autoridad. Cuando tu clienta ideal entra a tu perfil, esto es lo que la convence. Y no temas regalar conocimiento: entre más valor das, más seguridad tienen de comprarte.
- **Inspiracional:** cuentas tu historia en pedacitos, tus aprendizajes, tu estilo de vida. Que la gente diga "tiene una vida que quiero y me siento identificada con ella".
- **Entretenimiento:** la gente entra a redes a pasarla bien. Tendencias adaptadas a tu nicho, humor, historias cotidianas. Es el que más tráfico te trae.
- **Venta:** qué ofreces, para quién, cómo y cuándo. Aquí invitas a la acción.

> No todos los días vas a vender, pero todos los días construyes percepción.

## Cómo repartirlos
Una semana de 4 publicaciones puede verse así:
- Lunes: educativo.
- Martes: estilo de vida o entretenimiento.
- Jueves: educativo o inspiracional.
- Domingo: venta.

Como referencia, cerca de 40% educativo, 40% estilo de vida y entretenimiento y 20% venta. Ajusta según lo que veas que funciona con tu audiencia. Prueba primero publicar en la mañana y luego en la noche, y quédate con el horario que mejor te funcione.

## Errores comunes
- Copiar tal cual a otras cuentas.
- Cambiar de pilares por aburrimiento o porque las primeras semanas no funcionaron.
- Elegir pilares solo porque tienen más likes. Los likes no son ventas.
- Querer hacer todos los pilares el mismo día.

## Si no sabes qué enseñar
Aliméntate todo el tiempo: libros, podcasts, cursos, tu propia experiencia. Una marca con autoridad siempre tiene algo nuevo que dar.

## 🪞 Mírate al espejo
De tus últimas 10 publicaciones, ¿cuántas fueron de cada pilar?

## ✍️ Ejercicio
1. Ponle nombre propio a cada uno de tus 4 pilares.
2. Para cada uno responde: ¿por qué lo elegí? y ¿qué quiero que sienta o aprenda mi comunidad?
3. Escribe **10 ideas de contenido** por pilar.

## ✅ Tu tarea de la semana
Publica 4 contenidos, uno de cada pilar.

## 💬 Para compartir en el grupo
Comparte tus 4 pilares con su nombre.

@@ 7 | Clase 7 | Formatos y grabación | Cómo lo dices también comunica
El formato es el puente entre tu idea y la pantalla. Es lo que le pone tu sello a la estrategia.

## No dejes que la IA elija por ti
Puedes apoyarte en inteligencia artificial, pero el formato tiene que salir de ti, de tu personalidad y de tu entorno. Si encuentras el formato que le gusta a tu audiencia, puedes usarlo mucho tiempo.

## Formatos para probar
- Video hablado a cámara.
- Vlog con varias escenas.
- Voz en off sobre escenas tuyas.
- Videos cortos de 4 a 6 segundos con un texto que enganche y una descripción larga.
- Carruseles fáciles de leer.
- Tendencias adaptadas a tu nicho, solo si las dominas.

Elige un formato principal para perfeccionarte y complementa con formatos sencillos que dan alcance por sí solos. Si todavía no editas bien, edita menos pero bien.

## Tu banco de escenas
Grábate todos los días dos o tres clips de tu estilo de vida que sumen a tu mensaje: tu café, leyendo, trabajando, con tus hijos, arreglándote, empacando pedidos. Ese banco te va a salvar los días sin ideas. Si hablas de libertad, necesitas escenas que proyecten libertad.

## Una historia al mes
Al menos una vez al mes cuenta algo de ti, de tu forma de ver la vida o de tu porqué, en video o en carrusel.

## Tips de grabación
- Usa la **cámara trasera**: tiene mucha mejor calidad.
- El lente gran angular (0.5) te sirve para grabarte sola desde arriba o desde abajo.
- **Limpia el lente** antes de grabar. Siempre.
- Cambia algo cada 5 segundos: ángulo, acercamiento o texto.
- Si hablas, la música va muy bajita.
- Fondo **limpio y ordenado**. No tiene que ser estético, pero sí ordenado.

## Activa tu ojo de creadora
Cuando estés en redes, no consumas como espectadora: observa cómo se graban, qué luz usan, qué ángulos y qué ritmo tienen los videos que te gustan.

## 🪞 Mírate al espejo
¿Con qué formato te sientes más tú?

## ✍️ Ejercicio
1. Elige tu formato principal y dos formatos de apoyo.
2. Haz una lista de 10 escenas de tu vida que sumen a tu mensaje.

## ✅ Tu tarea de la semana
Graba diario dos o tres clips para tu banco de escenas.

## 💬 Para compartir en el grupo
¿Qué formato vas a dominar estos 90 días?

@@ 8 | Clase 8 | Tu sistema de contenido | Organizar, planear y usar la IA a tu favor
No existe una marca personal sostenible sin contenido planeado. Esta clase es para dejar de crear según tu humor.

## Lo que no puedes hacer
- Ir al día.
- Improvisar.
- Depender de las tendencias.
- Crear solo cuando tienes ganas.

## Lo que sí necesitas
Orden, sistema, claridad y anticipación. Elige la herramienta que te dé menos fricción (un tablero tipo Trello, Notion, tu calendario o una libreta).

## Cada contenido, con cuatro piezas
1. **Concepto:** la idea general y por qué importa.
2. **Contenido:** el guion o los puntos del video, carrusel o post.
3. **Hook:** la primera frase que evita el scroll.
4. **Descripción:** el texto que acompaña la publicación, con su llamado a la acción.

## La IA como asistente, no como cerebro
La inteligencia artificial responde al nivel de las instrucciones que le das. Para que te sirva:
1. **Preséntate primero:** quién eres, qué vendes, quién es tu audiencia, cómo hablas, tu objetivo actual y qué necesitas siempre (por ejemplo, un llamado a la acción al final).
2. **Dile qué estás creando:** el tipo de contenido, el objetivo, el tono y la estructura (hook, desarrollo, cierre).
3. **Pide opciones** y corrige: "más corto", "más cálido", "más directo".
4. **Divide lo grande:** en lugar de "hazme un mes de contenido", empieza por una semana.

Tú eres la mente creativa; las herramientas son el canal. Revisa siempre que suene a ti.

## Cuentas faro
Elige de 3 a 5 cuentas que te inspiren y estén alineadas contigo. No para copiarlas, sino para observar su estructura, temas y estilo, y traducirlo a tu voz. Úsalas cuando no sepas qué publicar o sientas que nada funciona.

## 🪞 Mírate al espejo
¿Cuántas veces esta semana publicaste algo que se te ocurrió ese mismo día?

## ✍️ Ejercicio
1. Arma tu presentación para la IA (usa la herramienta **Prompts para tu contenido**).
2. Elige tus 3 a 5 cuentas faro y escribe qué te inspira de cada una.

## ✅ Tu tarea de la semana
Planea una semana completa de contenido con sus cuatro piezas, antes de que empiece la semana.

## 💬 Para compartir en el grupo
Comparte una de tus cuentas faro y qué vas a adaptar a tu estilo.

@@ 9 | Clase 9 | Edición básica | Que lo esencial esté bien hecho
No necesitas mil efectos. Necesitas que lo básico te sume. Todo esto se puede hacer en CapCut desde el celular.

## 1. Mejora la luz
Antes de editar nada, ajusta el video completo: un poco más de brillo, un poco menos de contraste, un poco más de saturación y de luminosidad. Si el audio tiene ruido, usa la opción de reducir ruido.

## 2. Recorta los silencios
Corta exactamente donde terminas una frase y donde empiezas la siguiente. Que casi no haya respiración entre una idea y otra: eso atrapa la atención. Quita las partes donde te trabaste o donde se ve algo desordenado.

## 3. Acercamientos
Haz un acercamiento cada 5 o 6 segundos o cuando digas algo importante. Le da movimiento a un video grabado en un solo ángulo. Para que funcione, grábate con un poco de distancia.

## 4. Textos con palabras clave
Los subtítulos completos ya no se usan tanto. Mejor pon en pantalla solo las palabras clave o la pregunta del inicio. Una sola tipografía fácil de leer, centrada, sin colores raros. Que el texto dure lo mismo que tardas en decirlo.

## 5. Sonidos y música
Efectos de sonido discretos en los momentos clave (una palabra importante, una transición). Música de fondo como máximo al 10% del volumen cuando hablas.

## 6. Retoque, no filtro
Si quieres mejorar tu piel, usa el retoque con mucha moderación (suavizado alrededor de 10 a 15%). Los filtros que te cambian la cara se ven falsos y además pueden darte problemas para pagar publicidad.

> Más vale un video sencillo y limpio que uno lleno de efectos sin buen gusto.

## 🪞 Mírate al espejo
¿Qué te frena más de editar: el tiempo, la técnica o el perfeccionismo?

## ✍️ Ejercicio
Toma un video que ya tengas y aplícale los 6 pasos.

## ✅ Tu tarea de la semana
Edita y publica dos videos con luz, recortes, acercamientos y palabras clave.

## 💬 Para compartir en el grupo
Comparte el antes y el después de tu edición.

@@ 10 | Clase 10 | Creatividad y bloqueos | Cuando ya no sabes qué subir
Es normal que a mitad del camino te bloquees. Lo que no es normal es quedarte ahí.

## La creatividad se entrena
La creatividad es la capacidad de convertir tus ideas y experiencias en algo original. No es solo para artistas ni es estar eufórica todo el tiempo. Se alimenta de la curiosidad (como la de un niño que hace diez preguntas de camino a la escuela) y de conocerte a ti misma.

> Creer que no eres creativa es el primer bloqueo. Sí lo eres.

## Conectar contigo
Del 1 al 10, ¿qué tan conectada estás contigo hoy? Vivir en piloto automático por mucho tiempo apaga la creatividad. Conocerte, saber qué sientes y por qué, es la base para crear desde un lugar auténtico.

## Los tres bloqueos
- **Mental:** perfeccionismo, querer cumplir expectativas de alguien que ni existe, falta de claridad, exceso de información sin aplicar y compararte.
- **Emocional:** estrés, ansiedad por el futuro, desmotivación, miedo a la crítica, agotamiento. Aquí toca ser amable contigo. Y si sientes ansiedad o tristeza fuertes por mucho tiempo, busca ayuda profesional: eso va primero que cualquier contenido.
- **De hábitos:** procrastinar, no tener rutina, levantarte tarde, no organizarte, vivir en sesiones de aprendizaje sin ejecutar. Este depende cien por ciento de ti: tu palabra es un contrato.

## Cómo salir
1. **Autocompasión:** sé amable contigo; los bloqueos son parte del proceso.
2. **Metas pequeñas:** un microhábito a la vez.
3. **Una rutina** que te mantenga con energía.
4. **Descansos reales**, lejos del celular, no viendo TikTok.
5. **Nuevas fuentes de inspiración:** libros, películas, caminar, un parque.
6. **Tu tribu:** habla con otras personas que estén creando. No vas a encontrar la creatividad donde la perdiste: cambia de lugar.

## Hacks inmediatos
- **Vaciado mental:** escribe todo lo que tienes en la cabeza durante unos minutos, sin filtro.
- **Lluvia de 20 ideas:** diez minutos para anotar al menos 20 ideas sin juzgarlas. Las primeras suelen ser obvias; las buenas aparecen después de la sexta.
- **Libreta siempre a la mano** para lo que se te ocurra.
- **Descarta lo obvio:** si es lo primero que se le ocurriría a cualquiera (o a la IA), estírate un poco más.

## 🪞 Mírate al espejo
¿Cuál de los tres bloqueos te visita más seguido?

## ✍️ Ejercicio
Haz una lluvia de 20 ideas sobre el reto más grande de tu negocio hoy.

## ✅ Tu tarea de la semana
Publica un reel donde tu creatividad sea la protagonista: en otro lugar, con otro ángulo, bailando, cantando o con algo que nunca hayas probado.

## 💬 Para compartir en el grupo
Comparte tu reel creativo y cuenta de dónde salió la idea.

@@ 11 | Clase 11 | Vender es servir | Tu relación con las ventas y tu convicción
Si la palabra "vender" te incomoda, esta clase es para ti. Antes de técnicas, hay que sanar la relación con vender.

## Siempre te has vendido
Te vendes al pedir un trabajo, al hacer amigas, en una relación. Todos los días comunicas por qué vale la pena elegirte. Vender no es forzar: es ayudar a alguien a tomar una buena decisión con algo en lo que tú crees.

> ¿Cómo cambiaría tu mensaje si tu objetivo fuera servir y no solo cobrar?

## La convicción vende antes que tus palabras
Puedes tener el mejor guion del mundo, pero si no crees en lo que vendes, se nota. La gente compra porque confía en ti y en cómo la haces sentir. La convicción no es gritar ni actuar: es la energía que sale cuando hablas de algo que usas, amas y te ha funcionado. Si tú no eres prueba de tu producto, cuesta venderlo. Y si de verdad dudas de lo que vendes, es de valientes reevaluar.

## Tu lenguaje no verbal
Tu postura, tu mirada, tu voz y tu imagen hablan antes que tú. Hombros atrás, voz firme, mirada a los ojos, presentable. Cuidar tu alimentación, tu descanso y moverte también se nota en tu energía.

## Los tres miedos
Rechazo, juicio y fracaso. Son los que más hacen que una mujer abandone. No se evaden: se atraviesan. Cuando te callas por miedo, le regalas tu poder, dejas de construir credibilidad y pierdes oportunidades. Para atravesarlos:
1. **Nómbralo:** escribe qué temes exactamente y cuál sería el peor escenario. Ponerle palabras le quita peso.
2. **Abrázalo:** acepta lo que sientes sin pelearte. Lo que se acepta se puede trabajar.
3. **Decide:** elige actuar con valentía, aunque sea con miedo.

Mucha gente te va a decir que no o te va a dejar en visto. No es personal. Es parte del camino.

## 🪞 Mírate al espejo
¿Cuándo fue la última vez que te callaste o no ofreciste algo por miedo? ¿Qué oportunidad crees que perdiste?

## ✍️ Ejercicio
1. Escribe **10 razones** por las que crees en tu producto o negocio. Si no llegas a 10, reflexiona por qué.
2. Repite cada mañana: "Lo que ofrezco ayuda de verdad. Yo soy prueba de que funciona. Hoy alguien lo necesita y me va a encontrar."
3. Escribe tus miedos de vender con los tres pasos: nómbralo, abrázalo, decide.

## ✅ Tu tarea de la semana
Grábate un minuto, sin guion, explicando por qué lo que ofreces le cambia algo a la gente.

## 💬 Para compartir en el grupo
Comparte tus 3 razones favoritas de las 10.

@@ 12 | Clase 12 | Conversaciones que cierran | Del interés a la decisión
El contenido abre puertas, pero no vende solo. La mayoría de las ventas se cierran en conversaciones directas: una llamada, una videollamada, un café.

## Si no vendes, cuenta tus conversaciones
¿Cuántas conversaciones de venta tuviste la semana pasada? Si la respuesta es cero, ahí está el problema. Crear contenido debería ser ya la parte fácil; tu tiempo fuerte tiene que ir a conversar.

## Las ventas son números
Como referencia para empezar: en algo de precio alto necesitas alrededor de 10 conversaciones para cerrar una; en algo más accesible, alrededor de 5. Si cierras una de cada diez en algo caro, vas bien. Lo que no se mide no se mejora. Y que tu techo de hoy sea tu piso de mañana.

## Una conversación decisiva termina en uno de tres
1. **Sí, con pago.** Ten todo listo: link de pago, datos de transferencia, el siguiente paso.
2. **No, gracias.** También es una buena salida: te quita incertidumbre. No es personal.
3. **Apartado.** No puede pagar todo hoy, pero se compromete con una parte y una fecha.

"Lo voy a pensar" y "luego te aviso" no son salidas. El seguimiento de verdad es para quien apartó, no para una lista interminable de "a lo mejor".

## Cómo llevar la conversación
- **La venta empieza en los primeros minutos:** puntual, presentable, con energía. Saluda con seguridad y haz dos o tres preguntas para conectar.
- **Quien pregunta dirige.** No es un discurso. Si te responden con otra pregunta, contesta y regresa con la tuya.
- **Encuentra el dolor que no está resuelto.** Si alguien tuvo acné hace meses, quizá ya no necesita eso, pero quedó insegura por las manchas. Esa es la necesidad real.
- **Habla al modo en que decide cada persona.** Unas deciden por **seguridad** (les preocupa equivocarse o perder la oportunidad), otras por **emoción** (historia, pertenencia, cómo se van a sentir) y otras por **datos** (qué incluye, cuánto cuesta, resultados de otras). Observa sus redes y cómo platica para darte una idea.
- **Contesta rápido.** Ella se puede tardar en responderte; tú no.

## Tres razones para decidir hoy (siempre reales)
- **Un motivo para hoy:** un bono o precio especial que de verdad termina en una fecha.
- **Una seguridad:** qué la respalda. Tu acompañamiento, la política real de la empresa, tu plan para sus primeros días.
- **Algo limitado de verdad:** pocos lugares en tu acompañamiento, una edición especial.

> Nunca inventes escasez, descuentos ni garantías. Si se descubre, pierdes la venta y la confianza.

## Cuando dicen…
- **"Lo tengo que pensar":** "Me parece bien. ¿Qué es lo que te gustaría pensar?" Hagan juntas una lista de pros y contras y decidan con eso.
- **"Lo tengo que hablar con mi pareja":** "Claro. ¿Qué crees que te va a preguntar?" Resuelvan esas dudas juntas u ofrece una llamada corta con los dos.
- **"Es muy caro":** separa precio de valor. "¿Comparado con qué?" y muestra qué incluye y qué resultado busca. Si de verdad no le alcanza, ofrécele el apartado o una opción de entrada.
- **"No tengo tiempo":** "¿Cuánto tiempo a la semana podrías darle?" Muestra cómo se ve con 20 minutos al día.
- **"Mejor mañana":** "¿Qué cambiaría mañana?" Si no hay una razón real, propón tomar la decisión ahora; si la hay, agenda la fecha exacta.

## 🪞 Mírate al espejo
¿Podrías decir el nombre de las últimas 10 personas a las que les ofreciste tu producto o negocio? ¿Qué te dijo cada una?

## ✍️ Ejercicio
1. Calcula cuántas conversaciones necesitas al mes para tu meta.
2. Escribe tus tres razones para decidir hoy, todas reales.
3. Escribe tus respuestas a las 5 objeciones con tus palabras.

## ✅ Tu tarea de la semana
Ten al menos 3 conversaciones de venta (o el doble de las que tuviste la semana pasada) y anota en qué terminó cada una.

## 💬 Para compartir en el grupo
¿Cuántas conversaciones te propones esta semana?

@@ 13 | Clase 13 | Historias que venden y reclutan | Secuencias de 4 historias
Las historias de Instagram son el lugar perfecto para vender sin parecer vendedora. Aquí tienes tres secuencias de cuatro historias.

## Secuencia A: vender sin parecer vendedora
1. **Humanízate:** una emoción o mini historia del día con la que tu audiencia se identifique. Todavía sin producto.
2. **El problema:** lo que vive tu comunidad, contado como "detrás de cámaras". Que digan "soy yo".
3. **La solución, desde tu experiencia:** "esto me ha funcionado a mí". Beneficios, no características. Como se lo contarías a una amiga.
4. **Llamado a la acción claro:** una palabra para que te escriban. Si tienes un bono real, es el momento.

## Secuencia B: activar y vender
1. **Dolor:** algo real y vulnerable.
2. **Confrontación:** "¿hasta cuándo vas a normalizar…?" Firme, sin regañar.
3. **Mucho valor:** un consejo útil o un mito desmentido.
4. **Llamado + regalo:** un regalo digital que tú creas (una guía, una mini clase, un checklist) para quien te escriba.

## Secuencia C: reclutar sin perseguir
Solo con texto sobre fotos. No necesitas hablar a cámara.
1. **Abre la curiosidad:** "Hoy voy a contar algo que nunca me había atrevido a decir…". No expliques todavía.
2. **Tu dolor (ya resuelto):** "Hace X tiempo yo estaba…". Desde la transformación, nunca desde la víctima.
3. **Lo que descubriste:** "Descubrí que…". Solo lo suficiente para que quieran saber más.
4. **La invitación:** "Hoy sé que hay mujeres sintiéndose como yo me sentía… Si quieres que platiquemos, mándame la palabra ____."

> Curiosidad + dolor con el que se identifiquen + transformación + invitación tranquila. Eso genera conversaciones. "Únete a mi equipo" no.

## Reglas para todas
- El texto se tiene que leer rápido: buen tamaño, contraste y fondo limpio.
- Máximo dos tipografías y frases cortas.
- Que se vea como una conversación real, no como un anuncio.
- Fotos imperfectas que transmitan emoción funcionan mejor que fotos producidas.
- No prometas ingresos ni resultados de salud. Cuenta tu experiencia.
- El objetivo no son vistas: son conversaciones.

## Tu banco visual
1. **Inspiración:** busca en Pinterest sesiones de fotos de marca personal de tu rubro y guarda las que te hagan decir "esa soy yo".
2. **Diseño:** elige uno o dos outfits, un concepto (paz, poder, cercanía, movimiento) y un lugar.
3. **Producción:** de 5 a 10 fotos y de 3 a 5 clips verticales. No busques la toma perfecta: busca la energía.
4. **Compartir:** elige tus favoritas y cuenta la historia detrás.

## 🪞 Mírate al espejo
¿Tus historias de esta semana invitaban a platicar o solo informaban?

## ✍️ Ejercicio
Escribe una secuencia completa (A, B o C) para tu negocio, historia por historia.

## ✅ Tu tarea de la semana
Publica tu secuencia y haz tu sesión de banco visual.

## 💬 Para compartir en el grupo
¿Cuántas conversaciones te generó tu secuencia?

@@ 14 | Clase 14 | Publicidad para crecer | Seguidores reales y anuncios que generan conversaciones
Pagar publicidad no es comprar seguidores. Es llevar tu mejor contenido a personas que no te conocen y a las que les puede interesar.

## Antes de pagar un peso
Tu perfil tiene que estar listo para recibir gente: descripción con una promesa clara, destacados (quién soy, qué hago, testimonios), contenido constante y de calidad. Si tu contenido no es magnético, ninguna cantidad de dinero va a hacer que se queden.

## Promocionar para ganar seguidores
1. Elige un contenido que de verdad aporte valor y se vea bien (no cualquiera).
2. Hazlo **desde la computadora**, no desde la app (suele salir más caro y rendir menos).
3. Objetivo: **visitas al perfil**.
4. Público: crea el tuyo. Ubicación según dónde vendes, rango de edad de 5 a 10 años, mujeres si es tu caso, y **un solo interés** (máximo dos o tres).
5. Presupuesto: empieza con lo mínimo diario y mínimo 10 días.
6. Activa al menos tres contenidos.
7. **Revisa a las 24 horas.** Si casi no hay seguidores nuevos, pausa y revisa el contenido.

## Anuncios que generan conversaciones
La estructura del video:
1. **Hook al dolor:** "¿Tienes cajones llenos de accesorios y sientes que ninguno te representa?"
2. **A quién le hablas:** "Este video es para mujeres que…". Quien no es, se va; quien sí, se queda.
3. **Empatiza con su dolor:** "Yo también pasé años…".
4. **Una solución gratuita:** una guía, una lista, una clase gratis.
5. **Llamado a la acción** con un sistema detrás: si dices "mándame mensaje", ya sabes qué vas a contestar y cómo vas a agendar.

## Calidad
En publicidad compites con muchísimas creadoras. Entre mejor la calidad, más barato te sale cada clic. Graba con el mejor celular que consigas, buenos cortes, varios ángulos y presencia profesional sin perder tu esencia. Graba al menos tres o cuatro versiones para ver cuál funciona mejor.

> Tu anuncio no tiene que gustarle a todos. Tiene que hablarle directo a quien ya te está buscando sin saberlo.

Los precios mínimos y las opciones de las plataformas cambian seguido; revisa siempre lo que te muestra la herramienta al momento de crear tu anuncio.

## 🪞 Mírate al espejo
Si hoy llegaran 1,000 personas nuevas a tu perfil, ¿se quedarían?

## ✍️ Ejercicio
1. Haz la revisión de tu perfil: descripción, destacados y últimas 9 publicaciones.
2. Escribe el guion de un anuncio con los 5 pasos.

## ✅ Tu tarea de la semana
Promociona tres contenidos con el mínimo presupuesto y revisa los resultados a las 24 horas.

## 💬 Para compartir en el grupo
Comparte tu guion de anuncio para que el equipo te dé retroalimentación.

@@ 15 | Herramientas | Ficha de tu clienta ideal | Para hablarle directo
Llénala pensando en una sola persona. Ponle nombre.

## Quién es
- Nombre, edad y ciudad.
- ¿A qué se dedica?
- ¿Qué lugares frecuenta y qué hobbies tiene?
- ¿Qué es lo más importante para ella al comprar?
- ¿Qué problema tiene hoy?

## Qué consume
- 5 cuentas o personas que sigue.
- ¿Qué tienen en común esas cuentas?
- 5 preguntas que se hace y quiere resolver.

## Antes y después de conocerte
- **Qué tiene:** antes / después.
- **Qué siente:** antes / después.
- **Cómo es su día:** antes / después.
- **Cómo se ve y se percibe:** antes / después.

## Tu diferencia
1. Los beneficios de lo que ofreces.
2. Lo que hace diferente tu propuesta.
3. Lo que pierde si no lo compra.

> Una venta no depende del producto ni del precio. Depende de que tengas claro el resultado que tu clienta va a obtener.

@@ 16 | Herramientas | Test de tu estilo | Cómo es tu energía natural
Elige la opción que más se parezca a ti en cada pregunta y cuenta qué letra se repite más.

## Las preguntas
1. Cuando comparto algo de mi marca, me importa que: (A) sea fresco y creativo, (B) sea claro y profesional, (C) se sienta cercano, (D) inspire respeto.
2. Quien me ve trabajar diría que soy: (A) alegre y llena de ideas, (B) organizada y detallista, (C) paciente y empática, (D) decidida y firme.
3. Cuando aparece un reto: (A) busco otra forma creativa, (B) reviso el proceso, (C) escucho a todos, (D) decido rápido y actúo.
4. Me sale natural: (A) contar historias divertidas, (B) explicar paso a paso, (C) mensajes cálidos, (D) hablar con fuerza y dirección.
5. Lo que más me detiene: (A) empiezo mucho y termino poco, (B) me exijo tanto que tardo en mostrarme, (C) no pongo límites y me desgasto, (D) puedo parecer fría o dura.
6. En un equipo soy la que: (A) motiva, (B) organiza, (C) acompaña, (D) dirige.

## Los resultados
- **Mayoría A · La Chispa:** energía, creatividad y entusiasmo. Tu reto: convertir tus ideas en procesos. La constancia es lo que hará crecer tu negocio.
- **Mayoría B · La Arquitecta:** orden, detalle y confianza. Tu reto: mostrarte aunque no esté perfecto. La gente conecta con lo humano, no con lo impecable.
- **Mayoría C · La Cálida:** empatía, lealtad y calma. Tu reto: atreverte a liderar y decidir. Tu gente busca tu calidez, pero también tu dirección.
- **Mayoría D · La Líder:** visión, determinación y autoridad. Tu reto: suavizar tu fuerza con humanidad para que no solo te admiren, también se sientan acompañadas.

> Conocerte te deja usar tus fortalezas y no autosabotearte con tus retos.

@@ 17 | Herramientas | Plantilla de tu historia | Para contarla en un minuto
Escríbela primero, léela en voz alta y ajústala hasta que suene a ti.

## Los cinco momentos
1. **Antes:** "Hace ____ yo ____." ¿Qué sentías? ¿Qué te faltaba?
2. **Lo que dolía de verdad:** "Lo que más me pesaba no era ____, era ____."
3. **El giro:** "Un día ____ y decidí ____."
4. **Hoy:** "Hoy ____." Agrega un dato si lo tienes.
5. **La invitación:** "Si tú también ____, ____." Y una acción concreta: comenta una palabra, mándame mensaje.

## Revisa antes de grabar
- ¿Se entiende en un minuto?
- ¿La herida está sanada? ¿Se cuenta desde la transformación?
- ¿Tu clienta ideal se reconocería en el "antes"?
- ¿Es congruente con lo que has contado otras veces?
- ¿Evitaste prometer resultados de salud o ingresos?

@@ 18 | Herramientas | Prompts para tu contenido | Para trabajar con la IA
Copia, llena los espacios y ajusta a tu voz.

## 1. Preséntate
"Guarda este contexto: soy ____, vendo ____, mi audiencia es ____ (sus dolores y deseos), hablo de forma ____ y uso frases como ____. Mi objetivo actual es ____. Siempre necesito un llamado a la acción al final. Confirma que entendiste."

## 2. Define tus guiones
"Quiero guiones con un hook de 3 a 5 segundos, de 20 a 35 segundos en total, lenguaje natural y ritmo de conversación. Estructura: hook, idea 1, idea 2 y cierre con reflexión o llamado a la acción. Evita frases vacías."

## 3. Guion por pilar
"Hazme un guion del pilar ____ (educativo, estilo de vida o venta) sobre ____. Dame 3 hooks, un guion completo y un llamado a la acción para historias."

## 4. Revisión de calidad
"Antes de entregarlo, revisa que suene a mí, que construya autoridad, que sea claro y que tenga ritmo. Si no cumple, reescríbelo."

## 5. Varias versiones
"Convierte este tema en tres versiones: una intensa, una suave y una disruptiva."

## 6. Una serie
"Voy a grabar varios contenidos sobre ____. Dame 5 guiones distintos: educativo, emocional, historia, humor y autoridad."

> La IA no es mágica: responde al nivel de las instrucciones que le das. Y lo último siempre lo decides tú.

@@ 19 | Herramientas | Checklist de la creadora | Diario, semanal y mensual
Para que tu marca avance aunque no tengas ganas.

## Cada día
- Mostrarte en historias.
- Grabar 2 o 3 clips para tu banco de escenas.
- Responder mensajes y comentarios rápido.
- Al menos una conversación con una clienta o prospecto.
- Un momento de aprendizaje (lectura, podcast, curso).

## Cada semana
- Publicar tus 4 contenidos según tus pilares.
- Planear la semana siguiente con anticipación.
- Una secuencia de historias que invite a platicar.
- Revisar qué funcionó y qué no.
- Celebrar tus acciones cumplidas.

## Cada mes
- Contar tu historia en algún formato.
- Hacer una sesión de banco visual.
- Revisar tus números: ventas, conversaciones, seguidores nuevos.
- Revisar tus cuentas faro y tus pilares.
- Reescribir tu objetivo si ya lo alcanzaste.


---

# Preguntas frecuentes

Formato: `## Categoría | clase relacionada` y `### Pregunta`.

## Empezar | 0

### ¿Tengo que tomar las clases en orden?
La primera vez, sí te lo recomendamos: las clases 1 a 5 son la base de todo lo demás. Pero puedes saltar a cualquier clase desde el menú cuando lo necesites.

### ¿Cuánto tiempo me toma cada clase?
Entre 5 y 10 minutos de lectura, más el ejercicio. La idea es que avances una clase por semana y te dé tiempo de aplicar.

### ¿Dónde guardo mis ejercicios?
En el cuaderno al final de cada clase. Se guarda solo en este dispositivo y navegador. Si cambias de celular o borras los datos del navegador, se pierde, así que copia lo importante a tu libreta.

### Ya empecé con muchas ganas, ¿por qué siento que se me están bajando?
Es normal y está explicado en la bienvenida. La emoción del inicio siempre baja. Regresa a tu objetivo de 90 días, a tus 3 innegociables y apóyate en el grupo.

## Marca y nicho | 3

### Vendo lo mismo que muchas, ¿cómo me diferencio?
Lo único que nadie puede copiar eres tú: tu historia, tu forma de explicar y de acompañar. Trabaja tu propuesta de valor (Clase 2) y tu historia (Clase 5).

### Si escojo un nicho, ¿ya no puedo hablar de mi vida?
Sí puedes, y deberías. El nicho no es una jaula. La clave es conectar tu producto con tu vida: tus viajes, tu rutina, tu maternidad, tus hobbies.

### ¿Cómo sé quién es mi clienta ideal?
Piensa en ti antes de resolver el problema que hoy ya tienes resuelto. Luego llena la Ficha de tu clienta ideal en Herramientas.

### Me da pena que mi familia vea mi contenido.
Es muy común. Tu contenido no es para tu familia, es para tu clienta ideal. Muchas veces el reconocimiento llega primero de desconocidos.

## Contenido | 6

### ¿Cuántas veces a la semana publico?
Una buena base son 4 publicaciones a la semana, una por pilar, más historias diarias. Lo importante es sostenerlo.

### No sé qué enseñar en el pilar educativo.
Aliméntate todo el tiempo (libros, podcasts, cursos) y comparte lo que aprendes y vives. Los errores comunes de tus clientas y "te enseño cómo" son temas que nunca se acaban.

### ¿Puedo usar inteligencia artificial para mi contenido?
Sí, como asistente. Preséntale bien quién eres y qué necesitas, pide varias opciones y siempre revisa que suene a ti. El formato y la idea final los decides tú.

### No soy buena editando.
Edita menos, pero bien: luz, recortes sin silencios, acercamientos y palabras clave. Está todo en la Clase 9.

### Me bloqueé y ya no sé qué subir.
Revisa la Clase 10. Identifica si tu bloqueo es mental, emocional o de hábitos, haz una lluvia de 20 ideas y cambia de lugar.

## Ventas | 12

### Me da pena vender.
Recuerda que vender es ayudar a alguien a tomar una buena decisión con algo en lo que crees. Trabaja tu convicción con las 10 razones de la Clase 11.

### Me dicen "lo voy a pensar" y nunca regresan.
Pregunta qué es lo que le gustaría pensar y resuélvanlo juntas. Busca que la conversación termine en sí, no o apartado. Está en la Clase 12.

### ¿Está bien decir que quedan pocos lugares para que se decidan?
Solo si es verdad. Nunca inventes escasez, descuentos ni garantías: si se descubre, pierdes la venta y la confianza.

### ¿Cómo invito a alguien a mi equipo sin sentirme intensa?
Usa la secuencia de reclutamiento de la Clase 13: curiosidad, tu historia, lo que descubriste y una invitación tranquila. Comparte tu experiencia sin prometer ingresos.

### ¿Cuántas conversaciones necesito para vender?
Como referencia inicial, alrededor de 5 para algo accesible y 10 para algo de precio alto. Mide las tuyas y ajusta.

## Publicidad | 14

### ¿Pagar publicidad es comprar seguidores?
No. Comprar seguidores te da números falsos. La publicidad lleva tu mejor contenido a personas reales a las que les puede interesar.

### ¿Cuánto tengo que invertir?
Empieza con el mínimo que te permita la plataforma por al menos 10 días y revisa a las 24 horas. Los precios cambian, así que revisa lo que te muestra la herramienta.

## El mentor | 0

### ¿Qué es "Tu mentora"?
Es la mentora de Visible dentro de Claude. Te da las clases una por una, revisa tus ejercicios, te ayuda con tu historia, tus pilares, tus guiones y tus conversaciones de venta.

### ¿Tengo que pagar Claude?
No. Funciona con la cuenta gratis de claude.ai. La cuenta gratis tiene un límite de mensajes por día.

### ¿Cómo la instalo?
Descarga la mentora (.zip) en la pestaña Tu mentora. En Claude entra a Customize → Skills, toca "+", luego "Create skill" → "Upload a skill" y sube el zip sin descomprimir.
