# Ritmo · contenido completo del reto

Cada bloque empieza con: @@ número | sección | título | subtítulo

@@ 0 | Empieza aquí | Bienvenida a Ritmo | 30 días para dejar de postergarte
Ritmo es un reto de 30 días para ordenar tu tiempo, tu energía y tu mente, y volver a ponerte en tu propia agenda. Cada día trae una idea corta y una acción concreta. No necesitas más tiempo: necesitas más presencia.

## Lo que vas a trabajar
- **Semana 1 · Tu tiempo:** dejar de confundir estar ocupada con avanzar.
- **Semana 2 · Tu mente:** escuchar cómo te hablas y cambiar el guion.
- **Semana 3 · Tu claridad:** pequeñas victorias, días con intención y hábitos que se sostienen.
- **Semana 4 · Tu ritmo:** rituales, tu círculo y acción sin esperar a sentirte lista.

## Cómo usarlo
Un día a la vez, de preferencia en la mañana. Cada día toma entre 5 y 20 minutos. Si un día no puedes, no pasa nada: retomas al siguiente, sin castigo. Puedes saltar a cualquier día desde el menú, pero la primera vez funciona mejor en orden.

## Tres promesas de este reto
- Vas a actuar **desde la intención, no desde la culpa**.
- Vas a hacer las paces con la productividad: no se trata de hacer más.
- Vas a terminar con un ritmo tuyo, que puedas sostener.

> No viniste a ser eficiente. Viniste a ser tú, con dirección.

## Un cuidado importante
Ritmo es un reto de hábitos, no terapia. Si en algún momento algo te mueve mucho o te sientes muy cansada o triste por varios días, busca a alguien de confianza o a una profesional. Eso también es elegirte.

## ✍️ Ejercicio
1. Escribe **por qué empiezas este reto** en una frase.
2. Escribe **cómo quieres sentirte en el día 30**.
3. Elige **a qué hora** vas a hacer tu reto cada día.

## ✅ Hoy
Pon una alarma diaria con el nombre "Ritmo".

## 💬 Para compartir en el grupo
Comparte tu frase de por qué empiezas.

@@ 1 | Semana 1 · Tu tiempo | Día 1 · Ocupada no es productiva | Haz lo que importa, no todo
Nos enseñaron que estar ocupada es avanzar, que quien descansa se atrasa y que hacer todo es la meta. Hoy lo vamos a cuestionar. El poder no está en hacer más; está en hacer lo que importa.

## Sal del piloto automático
Esta semana es para mirar tu día con honestidad: qué se lleva tu tiempo y qué te deja a cambio. Sin juicio, solo con datos.

## ✍️ Ejercicio
Haz una **auditoría de energía**:
1. Escribe las **5 actividades** que más tiempo te consumen al día (personales o de trabajo).
2. A cada una hazle 3 preguntas: ¿Me acerca a lo que quiero? ¿Le doy el tiempo justo o se lleva de más? ¿Cómo quedo después: llena o drenada?
3. Marca con ⭐ las que te suman y con ⚠️ las que solo te mantienen "en modo ocupada".

## ✅ Hoy
Elige una actividad ⚠️ y recórtale 15 minutos.

## 💬 Para compartir en el grupo
¿Cuál fue tu sorpresa más grande de la auditoría?

@@ 2 | Semana 1 · Tu tiempo | Día 2 · Movimiento no es progreso | Correr sin rumbo también cansa
Moverte no siempre es avanzar. Y estar llena de pendientes no es lo mismo que ser productiva. Si tus mañanas empiezan con prisa, ansiedad y mil cosas sin intención, lo más probable es que el día se te vaya sin haber conectado contigo.

## Intención del día
Calidad sobre cantidad. Hacer menos, pero con más propósito.

## Haz una pausa incómoda
Detente un momento y mira si lo que haces cada mañana te acerca o te aleja de la mujer que quieres ser.

## ✍️ Ejercicio
Escribe **3 cosas que repites cada mañana solo por costumbre**, que no te dan paz, claridad ni avance.

## ✅ Hoy
Quita una de esas tres mañana temprano y observa cómo se siente.

## 💬 Para compartir en el grupo
Comparte la costumbre que vas a soltar.

@@ 3 | Semana 1 · Tu tiempo | Día 3 · Lo urgente grita | Lo importante susurra
Lo urgente aparece, suena fuerte y pide atención ya. Lo importante casi nunca grita: puede esperar… hasta que, por no atenderlo, se vuelve urgente. Así se forma el círculo que agota: siempre apagando fuegos y nunca avanzando en lo que de verdad importa.

## Las cuatro cajas
Clasifica tus pendientes en:
- **Urgente e importante:** hazlo hoy.
- **Importante, no urgente:** agéndalo. Aquí vive tu crecimiento (tu negocio, tu salud, tu familia).
- **Urgente, no importante:** delégalo o hazlo rápido.
- **Ni urgente ni importante:** suéltalo.

## Un cambio de frase
Cambia "no tengo tiempo" por "eso no es prioridad para mí ahora". Es incómoda, pero te dice la verdad sobre dónde pones tu tiempo y tu energía.

## ✍️ Ejercicio
Al final del día, revisa cómo usaste tu mañana y acomoda lo que hiciste en las cuatro cajas. ¿Esto refleja lo que de verdad te importa?

## ✅ Hoy
Agenda una sola cosa "importante, no urgente" para mañana.

## 💬 Para compartir en el grupo
¿En qué caja se te fue la mayor parte del día?

@@ 4 | Semana 1 · Tu tiempo | Día 4 · Tu energía matutina | No es lo que haces, es cómo te deja
Hay actividades que te encienden y te centran, y otras que te apagan o te sacan de tu centro. Hoy vas a mirar tu mañana con lupa.

## Tus primeras horas
Lo que haces en las primeras horas de tu día marca el resto. La luz de la mañana, moverte un poco y no empezar con el celular suelen ayudar a despertar con más claridad.

## ✍️ Ejercicio
Llena tu **Mapa de energía matutina** (en Herramientas):
1. Divide tu mañana en bloques de 30 minutos, desde que despiertas hasta mediodía.
2. Escribe qué haces en cada bloque.
3. Marca cuáles te **recargan**, cuáles te **drenan** y cuáles haces **en automático**.
4. Rediseña al menos **un bloque** para que se parezca más a ti.

> Si rediseñas tus mañanas, rediseñas tu vida.

## ✅ Hoy
Prueba mañana tu bloque rediseñado.

## 💬 Para compartir en el grupo
Comparte el bloque que cambiaste.

@@ 5 | Semana 1 · Tu tiempo | Día 5 · Tu agenda habla de ti | Lo importante se nota en el calendario
Todas decimos que nos importa cuidarnos, crecer y vivir con intención. Pero cuando abrimos el calendario, está lleno de todo menos de eso. No porque no lo queramos, sino porque no lo priorizamos.

## Tu vida se mueve por lo que haces
Si dices que quieres paz, ¿por qué tu agenda está llena de ruido? Si tu sueño es emprender, ¿por qué tu atención se la lleva el scroll? No es para culparte, es para abrir los ojos.

## ✍️ Ejercicio
1. Escribe **cómo usaste tu tiempo ayer**, hora por hora.
2. Marca lo que de verdad te acerca a la vida que dices querer.
3. Encuentra **1 hora** al día que podrías recuperar.
4. Decide **un cambio pequeño** para esa hora.

## ✅ Hoy
Bloquea esa hora en tu calendario como si fuera una cita.

## 💬 Para compartir en el grupo
¿Qué vas a hacer con tu hora recuperada?

@@ 6 | Semana 1 · Tu tiempo | Día 6 · Tiempo sagrado contigo | Descansar también es avanzar
Esta semana te toca regalarte una experiencia de 3 a 4 horas sola contigo. No para planear ni cumplir. Para recordarle a tu mente y a tu cuerpo que estar bien también es avanzar.

## Las reglas
- No vale quedarte en casa haciendo lo de siempre.
- Es sola, sin acompañantes.
- Celular en modo avión o fuera de vista.
- No vale "aprovechar el tiempo" para trabajar o estudiar.

## Ideas
- ¿Café en tu cocina? Mejor ve sola a ese café que siempre quisiste conocer.
- ¿Planear la semana en la sala? Hazlo en un parque, con libreta bonita.
- ¿Silencio en casa? Hazlo en un museo o en una caminata al atardecer.
- ¿Mascarilla en casa? Date un tratamiento o un masaje si está en tus posibilidades.

Que se sienta como un regalo. No tiene que ser caro, tiene que ser distinto.

## Durante la experiencia
Lleva una libreta. Escribe lo que ves, piensas y sientes. Observa tus ganas de revisar el celular.

## ✍️ Ejercicio
Al final responde:
1. ¿Qué sentí al desconectarme?
2. ¿Qué parte de mí se resistió y qué parte disfrutó?
3. ¿Puedo guardar este momento como referencia de lo que es vivir tranquila?
4. ¿Qué pasaría si esto fuera normal y no la excepción?

## ✅ Esta semana
Agenda tu experiencia antes del domingo.

## 💬 Para compartir en el grupo
Comparte una foto o una frase de tu experiencia.

@@ 7 | Semana 1 · Tu tiempo | Día 7 · Mi brecha | Lo que digo contra lo que hago
No hablo de tu vision board ni de lo que harás "cuando tengas tiempo". Hablo de lo que eliges cuando nadie te ve. Tus hábitos hablan más fuerte que tu discurso. Si hay distancia entre lo que dices que es prioridad y lo que haces, ahí está el poder que todavía no has reclamado.

## ✍️ Ejercicio
1. **Lo que digo que es prioridad:** escribe lo que dices que es importante (tu bienestar, tu negocio, tu familia, tu creatividad).
2. **Lo que de verdad hago por eso:** sé sincera, nadie lo va a ver.
3. **Cierra la brecha:** elige **una acción sencilla** para hoy que haga que tus hábitos se parezcan más a tus intenciones.

> Tu poder está en lo que eliges hoy, no en lo que juraste ayer.

## ✅ Hoy
Haz esa acción antes de que acabe el día.

## 💬 Para compartir en el grupo
Cierre de semana 1: ¿qué cambió en tu forma de ver tu tiempo?

@@ 8 | Semana 2 · Tu mente | Día 8 · Tu mente no es tu enemiga | Obsérvala sin juzgar
Si tu mente fuera una persona, ¿la dejarías hablarte como te habla? Lo que te repites moldea tus decisiones y hasta dónde te atreves a llegar. Pero muchas de esas frases no nacieron contigo: son creencias heredadas, miedos aprendidos, cosas que escuchaste tantas veces que las hiciste tuyas. Y lo aprendido se puede actualizar.

## ✍️ Ejercicio
1. Durante el día, cada vez que notes un pensamiento sobre ti, sobre alguien o sobre lo que haces, anótalo.
2. En la noche clasifícalo: ✅ **expansivo** (me ayuda, me calma, me motiva) o 🚫 **limitante** (me frena, me hace sentir chiquita).

## ✅ Hoy
Cuenta cuántos de cada tipo tuviste. Solo obsérvalo.

## 💬 Para compartir en el grupo
¿Te sorprendió algo de tu lista?

@@ 9 | Semana 2 · Tu mente | Día 9 · Tu primera frase del día | Cómo te hablas al despertar
Lo primero que te dices al abrir los ojos puede subirte, sabotearte o dejarte en automático. Hoy no vamos a ignorar esa voz: vamos a escucharla y, si no te habla con cariño, enseñarle otro idioma.

## Intención del día
Elegir pensamientos que te acerquen a tu mejor versión.

## ✍️ Ejercicio
1. Escribe **la primera frase** que pensaste hoy al despertar.
2. Reescríbela **como se la dirías a alguien que amas**, o como te la diría tu yo del futuro.
3. Guárdala como tu **frase de la semana**.

## ✅ Hoy
Ponla de fondo de pantalla o en un post-it en tu espejo.

## 💬 Para compartir en el grupo
Comparte tu frase original y tu versión nueva.

@@ 10 | Semana 2 · Tu mente | Día 10 · Tu radio interior | Pensamientos automáticos
Tu mente es como una radio prendida de fondo: frases y juicios tan familiares que ni los cuestionas. Pero que algo suene conocido no significa que sea cierto, ni que te haga bien.

## ✍️ Ejercicio
1. En los primeros minutos de tu mañana, cierra los ojos y escucha qué aparece. No lo cambies.
2. Anota tus **primeros 5 pensamientos**, aunque parezcan tontos o repetidos.
3. Clasifica cada uno: ¿me **expande**, me **limita** o es **neutral**?
4. Anota **qué emoción** te provoca cada uno (miedo, calma, vergüenza, motivación, duda).

> No creas todo lo que piensas, pero escúchalo todo para elegir mejor.

## ✅ Hoy
Elige el pensamiento que más te limita y escribe qué le contestarías.

## 💬 Para compartir en el grupo
¿Qué emoción se repitió más?

@@ 11 | Semana 2 · Tu mente | Día 11 · Siembra una nueva verdad | Lo que repites, lo crees
Tu mente no necesita pruebas para creerse algo: solo que se lo repitas. Así se instalaron las creencias que te apagan. Y así mismo puedes enseñarle otras que te sostengan. Hoy no vas a pelear con las viejas: vas a sembrar una nueva.

## ✍️ Ejercicio
1. Elige **una frase** que quieras empezar a creer, aunque hoy no la sientas del todo. En positivo, corta y clara.
2. Léela **en voz alta** varias veces, hasta que suene menos rara y más tuya.
3. Ponla **donde la veas** todos los días: espejo, escritorio, refri o fondo de pantalla.

Ideas:
- "Estoy lista para salir de mi zona cómoda."
- "No tengo que ser perfecta para avanzar."
- "Lo que sueño es posible para mí."
- "No todo está bien, y está bien."

## ✅ Hoy
Tómale foto a tu frase en su lugar.

## 💬 Para compartir en el grupo
Sube la foto de tu frase para inspirar a otras.

@@ 12 | Semana 2 · Tu mente | Día 12 · ¿Quién tiene el micrófono? | Cómo te hablas cuando fallas
Cuando todo va bien, es fácil hablarte bonito. La prueba es cuando fallas, te equivocas o estás cansada. ¿Quién toma el micrófono en esos momentos: la versión de ti que confía, o la que te critica y te repite lo peor?

## ✍️ Ejercicio
Escribe dos guiones cortos:
1. **Cómo le hablarías a alguien que amas** que está pasando un momento difícil.
2. **Cómo te hablas tú** en tus momentos difíciles.

Compáralos. ¿Hay mucha diferencia? ¿Qué guion quieres empezar a practicar?

> No importa tanto lo que pasa afuera, sino cómo lo tomas adentro.

## ✅ Hoy
Escribe una frase de tu **nuevo guion** para usarla la próxima vez que falles.

## 💬 Para compartir en el grupo
Comparte tu frase del nuevo guion.

@@ 13 | Semana 2 · Tu mente | Día 13 · Mañana sin pantalla | La primera hora es tuya
Si lo primero que haces al despertar es revisar el celular, empiezas el día respondiendo a lo que otros quieren de ti. Hoy vas a probar algo distinto: que la primera parte de tu mañana sea tuya.

## Por qué ayuda
Antes de abrir mensajes y redes, tu cabeza está más despejada para decidir. Si la llenas de notificaciones, empiezas reaccionando. Además, la luz natural en la mañana y una rutina de sueño más o menos constante suelen ayudar a despertar con más energía.

## Ideas para tu primera media hora
- Abre la ventana o sal a que te dé la luz.
- Un vaso de agua antes del café.
- Estírate o camina cinco minutos.
- Escribe tu intención del día.
- Lee tu frase del Día 11.

## ✍️ Ejercicio
Escribe **qué vas a hacer en tus primeros 30 minutos** mañana y **dónde va a dormir tu celular** (lejos de la cama).

## ✅ Hoy
Pon el celular a cargar fuera de tu cuarto esta noche.

## 💬 Para compartir en el grupo
Mañana cuenta cómo te fue con tu primera media hora.

@@ 14 | Semana 2 · Tu mente | Día 14 · Tu manifiesto | Decora tu mente
Para cerrar la semana, vas a juntar las frases que descubriste o creaste estos días y convertirlas en tu manifiesto.

## ✍️ Ejercicio
1. Elige **3 frases** de esta semana que quieras repetir hasta que sean tuyas.
2. Escribe tu manifiesto empezando con: **"A partir de hoy, elijo pensar y decirme…"** y completa con tus 3 frases.
3. Guárdalo donde lo veas a diario.

## ✅ Hoy
Haz un fondo de pantalla con tu manifiesto (puedes usar cualquier app de diseño o solo una nota).

## 💬 Para compartir en el grupo
Cierre de semana 2: comparte tu manifiesto.

@@ 15 | Semana 3 · Tu claridad | Día 15 · Pequeñas victorias | La regla de los 5 minutos
La claridad no vive en la agenda perfecta. Vive en pequeñas acciones que te devuelven la sensación de control: tender la cama, lavar tu taza, contestar ese mensaje.

## La carga mental
Cada pendiente sin resolver se queda abierto en tu cabeza, como pestañas abiertas en una computadora. Tu mente tiende a recordar lo que dejaste incompleto, y ese ruido de fondo gasta energía. Por eso a veces terminas el día agotada sin haber hecho nada "grande".

## La regla
> Si algo me toma menos de 5 minutos, lo hago en ese momento.

Micro-hábitos que ayudan: tender la cama, lavar la taza, colgar la ropa, guardar las llaves en su lugar, tirar papeles que no sirven, poner la alarma antes de dormir.

## ✍️ Ejercicio
1. Escribe **3 cosas pequeñas** que llevas rato posponiendo.
2. Si alguna toma menos de 5 minutos, **levántate y hazla ahora**.
3. Respira y nota cómo se siente que ya no esté en tu cabeza.
4. Si te animas, repite con otras 2 o 3.

## ✅ Hoy
Aplica la regla de los 5 minutos todo el día.

## 💬 Para compartir en el grupo
¿Cuántas pequeñas victorias juntaste hoy?

@@ 16 | Semana 3 · Tu claridad | Día 16 · Diseña tu día | Actividades estrella
Muchas pierden claridad por intentar meter su vida en un horario rígido, sin considerar que su energía cambia cada día. No necesitas despertar a las 5 ni meditar a las 7 en punto. Necesitas saber qué cosas, pase lo que pase, hacen que tu día "gane".

## Actividades estrella
Son esas pocas acciones no negociables que marcan el ritmo de tu día y te hacen sentir en control. Un buen mapa te guía, no te encierra.

## ✍️ Ejercicio
Haz tu mapa del día en tres bloques: **mañana, tarde y noche**. En cada uno elige al menos **3 actividades estrella**. Pregúntate:
- ¿Qué ya hago y quiero mantener?
- ¿Qué quiero probar?
- ¿Qué podría eliminar porque no me aporta?

## ✅ Hoy
Vive tu día con tu mapa y marca las estrellas que sí cumpliste.

## 💬 Para compartir en el grupo
Comparte tus 3 estrellas de la mañana.

@@ 17 | Semana 3 · Tu claridad | Día 17 · Cierra puertas | Lo que ya no quieres también cuenta
La claridad también es tener el valor de decirte qué ya no quieres. A veces no ves claro porque tienes demasiadas puertas abiertas: cosas que sostienes por costumbre, por miedo o por no incomodar. Cerrar una puerta no es perder. Es reconocer que ya cumplió su función.

## Sin portazos
No se trata de huir de tus responsabilidades ni de cortar todo de golpe. Se trata de reconocer con cariño qué ya no te sostiene.

## ✍️ Ejercicio
Haz tu **inventario de puertas**:
1. Escribe situaciones que toleras por costumbre, compromisos que aceptaste para no decepcionar, vínculos que te drenan y proyectos que ya no tienen sentido.
2. Frente a cada una responde: ¿Por qué sigo aquí? ¿Qué me costaría cerrarla? ¿Qué ganaría?
3. Marca las que estás lista para soltar esta semana con un gesto pequeño: una conversación, un no, un límite, una pausa.

## ✅ Hoy
Da un gesto pequeño con una de esas puertas.

## 💬 Para compartir en el grupo
Sin dar detalles, comparte cómo te sentiste al cerrar una.

@@ 18 | Semana 3 · Tu claridad | Día 18 · Tu cerebro aprende lo que repites | Una frase y un hábito
La claridad también es un músculo y se entrena. Cada vez que eliges enfocarte en lo que importa o completas una acción pequeña, ese camino se vuelve un poquito más fácil. A tu cerebro no le importa si es grande o chico: lo que repites, se refuerza; lo que dejas de usar, se debilita.

## ✍️ Ejercicio
1. Elige **una frase** que quieras que tu mente aprenda esta semana ("Mi día empieza conmigo", "Lo pequeño también cuenta").
2. Elige **un hábito sencillo** que la acompañe (tender la cama, agua antes del café, escribir tu intención, ordenar tu espacio antes de dormir).
3. Escríbelos juntos en una tarjeta o post-it y ponlo a la vista.

## ✅ Cada mañana de esta semana
Di tu frase en voz alta y haz tu hábito.

## 💬 Para compartir en el grupo
Comparte tu frase y tu hábito.

@@ 19 | Semana 3 · Tu claridad | Día 19 · Tus hábitos hablan | Auditoría de hábitos
"Quiero una vida con claridad" suena bonito. Pero lo que te acerca a esa vida no es lo que dices, sino lo que haces cada día. Los hábitos son hilos que tejes sin darte cuenta. Cada pequeño hábito es un voto por la persona que quieres ser.

## Ejemplos
| Me acercan | Me alejan |
|---|---|
| Preparar mi espacio la noche anterior | Postergar lo importante por lo fácil |
| Tomar agua al despertar | Empezar el día en redes |
| Escribir mis 3 prioridades | Comer frente a la computadora sin parar |
| Hacer pausas conscientes | Dormir con el celular en la mano |
| Planear lo importante antes que lo urgente | Quejarme sin hacer nada |

## ✍️ Ejercicio
Haz dos listas honestas: **hábitos que me acercan** y **hábitos que me alejan** de la vida que quiero.

## ✅ Hoy
Comprométete a practicar **uno que te acerca** y a dejar **uno que te aleja** durante una semana.

## 💬 Para compartir en el grupo
Comparte tu par: el que sumas y el que sueltas.

@@ 20 | Semana 3 · Tu claridad | Día 20 · Pausa y repaso | Mira lo que ya cambió
Llevas casi tres semanas. Hoy no hay tarea nueva: hoy toca mirar hacia atrás para no minimizar lo que ya hiciste. Muchas veces no notas tu avance hasta que lo escribes.

## Repasa
- ¿Qué costumbre soltaste de tus mañanas?
- ¿Qué frase nueva te estás diciendo?
- ¿Cuántas pequeñas victorias juntaste?
- ¿Qué actividad estrella sí estás cumpliendo?

## Si te atrasaste
No pasa nada. No tienes que reponer todos los días. Elige el que más te sirva y sigue desde aquí.

## ✍️ Ejercicio
Escribe **3 cosas que ya cambiaron** y **1 que todavía se te dificulta**.

## ✅ Hoy
Descansa del reto. Solo haz tu frase y tu hábito del Día 18.

## 💬 Para compartir en el grupo
Comparte tus 3 cambios.

@@ 21 | Semana 3 · Tu claridad | Día 21 · Tres valores para sostenerte | Más que ganas
Los hábitos que duran no nacen de un golpe de motivación ni de una agenda bonita. Nacen de practicar tres valores, sobre todo cuando ya no se siente emocionante.

## Los tres valores
1. **Constancia y persistencia.** Los grandes cambios llegan de muchas decisiones pequeñas repetidas, incluso cuando nadie aplaude.
2. **Terminar lo que empiezas.** Cada vez que dejas algo a medias, tu mente aprende que no puede confiar en ti. Cada vez que terminas algo, aunque sea pequeño, construyes respeto propio.
3. **Lo que practicas en privado.** Lo que haces cuando nadie te ve es lo que después se nota en público.

## ✍️ Ejercicio
Haz tu **diagnóstico de valores**:
- Áreas donde sí soy constante:
- Áreas donde abandono lo que empiezo:
- Hábitos en privado que me hacen sentir orgullosa:
- Hábitos en privado que quiero cambiar:
- El valor que elijo trabajar y por qué:
- Mi acción concreta de hoy:

## ✅ Hoy
Termina algo que dejaste a medias, por pequeño que sea.

## 💬 Para compartir en el grupo
Cierre de semana 3: ¿qué valor elegiste?

@@ 22 | Semana 4 · Tu ritmo | Día 22 · De hábito a ritual | Tu mañana con propósito
Una rutina impuesta o automática puede volverse una jaula. Un ritual es distinto: es algo que haces con atención y con una intención clara. No importa tanto qué haces, sino cómo y para qué.

## Hábito y ritual
Un **hábito** se repite y se vuelve automático: te ayuda a funcionar sin pensar. Un **ritual** también se repite, pero con presencia y significado. El hábito te mantiene en movimiento; el ritual te mantiene en tu centro.

## Cinco elementos de un ritual
- **Presencia:** sin distracciones.
- **Repetición consciente:** constancia, pero por elección.
- **Algo para los sentidos:** un aroma, una bebida, una música, una textura.
- **Un espacio:** un rincón o un objeto que lo marque.
- **Una intención:** paz, enfoque, claridad, gozo.

## ✍️ Ejercicio
Llena tu **Ritual matutino** (en Herramientas):
- ¿A qué hora me gustaría despertar de verdad?
- ¿Qué 3 acciones quiero repetir cada mañana con presencia?
- ¿Cómo quiero sentirme al empezar el día?
- ¿Qué detalle sensorial voy a incluir?
- ¿Cuál es mi intención para sostenerlo?

## ✅ Hoy
Pega tu ritual donde lo veas mañana temprano.

## 💬 Para compartir en el grupo
Comparte tus 3 acciones del ritual.

@@ 23 | Semana 4 · Tu ritmo | Día 23 · Movimiento con sentido | Una acción, no diez
La forma en que despiertas importa. Pero lo que haces después es lo que cambia tu vida. Hoy no hablamos de productividad, sino de coherencia: pequeñas decisiones que construyen, o sabotean, a la mujer que quiere emprender y crecer.

## Tres preguntas para tu mañana
1. ¿Qué **una** acción me acerca hoy a la mujer que quiero ser?
2. ¿Qué hábito repito que ya no me representa?
3. ¿Qué puedo hacer **hoy** por mi negocio, aunque sea mínimo?

## ✍️ Ejercicio
Escribe **3 cosas que sueles posponer** y elige **una** para hoy. Sin perfeccionismo, sin planear de más. Ideas:
- Publicar algo con intención en tus historias.
- Escribir 3 ideas de contenido.
- Acomodar tu espacio de trabajo.
- Mandar ese mensaje que llevas días pensando.
- Dedicar 20 minutos a tu proyecto.

## ✅ Hoy
Hazla y anota: ¿cómo me sentí? ¿Qué solté al cumplirla?

## 💬 Para compartir en el grupo
¿Qué acción elegiste?

@@ 24 | Semana 4 · Tu ritmo | Día 24 · Tu círculo | ¿Te impulsa o te arrastra?
Por más organizada que estés, las personas con las que compartes tu energía influyen en quién te estás volviendo. No se trata de juzgar ni de cortar a nadie por impulso. Se trata de mirar con honestidad.

## Tres preguntas
- ¿Quién me apoya incluso cuando dudo de mí?
- ¿Quién me recuerda quién soy cuando se me olvida?
- ¿Con quién me siento más chiquita?

Y una más: ¿yo soy de las que eleva o de las que apaga?

## ✍️ Ejercicio
Piensa en las 3 a 5 personas con las que más convives y responde sí o no:
- Cuando comparto una idea ambiciosa, ¿me dicen "hazlo" en lugar de "bájale"?
- ¿Tienen metas propias en construcción?
- ¿Celebran mis logros?
- ¿Salgo con más energía después de verlas?
- ¿Respetan mis límites?
- ¿Hablan más de lo que sueñan que de lo que odian?
- ¿Tienen hábitos que me gustaría tener?

Mientras más "no", más vale la pena poner límites o buscar nuevos espacios.

## ✅ Hoy
Agradécele a una persona de tu círculo que te impulsa.

## 💬 Para compartir en el grupo
¿Qué descubriste de tu círculo?

@@ 25 | Semana 4 · Tu ritmo | Día 25 · El círculo que quieres | Descríbelo y ve a buscarlo
Las emociones y los hábitos se contagian. Si convives con gente que avanza con claridad, es más fácil que tú también. Hoy vas a describir el círculo que quieres y dar el primer paso para encontrarlo.

## ✍️ Ejercicio
1. **Descríbelo en presente:** "Mis amigas son…", "Con las personas que me rodean hacemos…".
2. **Defínelas con detalle:** ¿Cómo piensan? ¿Qué hábitos tienen? ¿De qué platican? ¿Cómo te sientes con ellas?
3. **Acción:** ¿dónde está ese tipo de gente? Una comunidad, una clase, un grupo, un evento. Elige un lugar para empezar a aparecer.

> Tú eliges quién entra a tu energía.

## ✅ Hoy
Apúntate a un espacio nuevo o escribe a alguien que admiras.

## 💬 Para compartir en el grupo
Comparte un lugar donde vas a buscar ese círculo.

@@ 26 | Semana 4 · Tu ritmo | Día 26 · Salir del bloqueo | Procrastinar es una emoción
Procrastinar casi nunca es flojera. Es una respuesta a algo que no está claro, que se siente demasiado o que te da miedo. Por eso "motivarte más" no funciona. Lo que funciona es identificar qué tipo de bloqueo tienes y usar un hábito mínimo que corte la inercia.

## Cinco bloqueos, cinco interruptores
1. **Bloqueo mental (no sé por dónde empezar):** elige solo 3 tareas, en orden, y haz solo la primera hasta terminarla.
2. **Energía baja:** un vaso grande de agua y 10 a 15 minutos de caminar sin celular.
3. **Ruido interno:** escribe 5 a 10 minutos todo lo que piensas, sin orden.
4. **Exceso de distracción:** 15 a 30 minutos sin pantallas, una sola tarea, con temporizador.
5. **Miedo a hacerlo mal:** graba una nota de voz de un minuto: ¿qué voy a hacer hoy y por qué me importa? Escúchala.

## ✍️ Ejercicio
Llena tu **Hoja anti-bloqueo** (en Herramientas): ¿cómo me siento hoy?, ¿qué bloqueo identifico?, ¿qué hábito elijo?, ¿a qué hora lo hago?

> Tu tarea no es hacerlo perfecto. Es empezar de nuevo cada vez que lo necesites.

## ✅ Hoy
Usa tu interruptor en la tarea que más estás evitando.

## 💬 Para compartir en el grupo
¿Cuál es tu tipo de bloqueo más común?

@@ 27 | Semana 4 · Tu ritmo | Día 27 · Cinco acciones por tu negocio | Para dejar de postergar tu marca
Mientras más pospones, más pesada se siente tu marca. Hoy tienes 5 acciones sencillas para hacer hoy mismo. Elige al menos dos.

## 1. Alinea tu bio con lo que vendes
¿Dice qué haces y para quién? ¿Tiene una transformación clara? ¿Tiene una forma fácil de contactarte? Si ofreces varias cosas, que una sea la principal.

## 2. Muestra tu marca en acción
Graba una historia rápida de tu proceso real. No vendas: muestra en qué estás trabajando o qué preparas para tus clientas.

## 3. Escribe 3 ideas de contenido
- Algo que sé y mi audiencia necesita aprender.
- Un error que cometí y ya sé cómo evitar.
- Una historia real que conecta con lo que vendo.

## 4. Abre una conversación
Escribe a una clienta anterior, a alguien que siempre interactúa contigo o a una colega para colaborar. No vendas: acércate desde la conversación real.

## 5. Ordena una cosa de tu negocio digital
Tu carpeta de contenido o testimonios, ideas viejas que ya no usarás, tus mensajes pendientes o el link de tu bio.

## ✅ Hoy
Haz al menos 2 de las 5.

## 💬 Para compartir en el grupo
¿Cuáles hiciste?

@@ 28 | Semana 4 · Tu ritmo | Día 28 · Habla como si ya supieras | Actúa antes de sentirte lista
La claridad no va a llegar como revelación. Llega cuando te mueves como si ya la tuvieras. Nadie se siente lista antes de empezar; el momento en que actúas como esa versión de ti es cuando empiezas a serlo.

## ✍️ Ejercicio
Imagina que hoy despiertas siendo la versión de ti que ya vende con seguridad, tiene claro lo que ofrece y dejó de pedir permiso. Contesta como ella:
1. ¿Cómo hablarías hoy de tu producto o servicio?
2. ¿Qué historia subirías sin miedo a lo que piensen?
3. ¿Qué mensaje escribirías desde tu autenticidad?
4. ¿Qué dejarías de postergar?
5. ¿Cómo te presentarías si nadie te juzgara?

## Activa tu voz
Graba una historia o un video para ti donde te presentes como si ya supieras lo que haces y a quién ayudas, expliques qué ofreces y por qué crees en eso, y digas en voz alta una frase que nunca te habías atrevido a decir ("Soy buena en esto", "Estoy lista para trabajar contigo").

## ✅ Hoy
Sube la historia, o guárdala para ti si todavía no te animas.

## 💬 Para compartir en el grupo
Comparte tu frase nueva.

@@ 29 | Semana 4 · Tu ritmo | Día 29 · Carta a tu yo que ya empezó | Nombrar tu avance
Si no te detienes a nombrar tu avance, tu mente va a seguir creyendo que no hiciste suficiente. Hoy vas a escribir una carta como testigo de lo que te pasó en este reto.

## ¿A quién se la escribes?
Elige una: a tu yo del Día 1, a tu yo actual que está en transición, o a tu yo futura que ya vive con claridad.

## Qué puedes incluir
- ¿Qué descubriste de ti?
- ¿Qué historia dejaste de contarte?
- ¿Qué miedo enfrentaste que ya no se siente igual?
- ¿Qué aprendiste de tu ritmo y tus bloqueos?
- ¿Qué parte de ti apareció y ya no vas a esconder?
- ¿Qué te prometes de aquí en adelante?

Termina con **una frase** que quieras que te abrace cuando te sientas perdida.

## ✍️ Ejercicio
Escribe tu carta a mano o aquí en tu cuaderno.

## ✅ Hoy
Guárdala en un lugar donde la encuentres.

## 💬 Para compartir en el grupo
Si quieres, comparte solo tu frase final.

@@ 30 | Semana 4 · Tu ritmo | Día 30 · Ya no eres la misma | Abre una nueva etapa
Terminar no es tachar un pendiente. Es reconocer que algo cambió: ya no te hablas igual, no empiezas tus días igual y ya no estás tan dispuesta a posponerte. Hoy no cierras: abres una etapa en la que tú misma eres tu impulso.

## Tu carta en movimiento
Busca un espacio tranquilo. Prepara una bebida que te guste o pon música que te conecte. Escríbete desde tu **yo futura**, la que ya se eligió, se organiza y se honra. Habla en presente:
- ¿Cómo te sientes?
- ¿Qué hábitos tienes?
- ¿Qué dejaste atrás para llegar ahí?
- ¿Qué ya no estás dispuesta a postergar?

Al final escribe **una frase poderosa** para leer cada día.

## Lo que te llevas
Una decisión, una rutina que te sostiene y una comunidad que te recuerda que no estás sola. No necesitas otro "el lunes empiezo".

## Tu siguiente paso
Si quieres llevar este ritmo a tus redes, **Encendida** te da lo básico y **Visible** te ayuda a construir tu marca y vender.

## ✍️ Ejercicio
Escribe tu carta y tu frase.

## ✅ Hoy
Elige **3 hábitos de este reto** que te quedas para siempre.

## 💬 Para compartir en el grupo
Comparte tus 3 hábitos y tu frase.

@@ 31 | Herramientas | Las cuatro cajas | Urgente contra importante
Usa esta tabla cada mañana o cada domingo para tu semana.

## La tabla
| | Urgente | No urgente |
|---|---|---|
| **Importante** | Hazlo hoy | Agéndalo |
| **No importante** | Delégalo o hazlo rápido | Suéltalo |

## Cómo usarla
1. Vacía todos tus pendientes en una lista.
2. Ponle a cada uno su caja.
3. Agenda primero lo de "Importante, no urgente": ahí vive tu crecimiento.
4. Revisa al final del día: ¿en qué caja se te fue el tiempo?

## Frase para recordar
"No tengo tiempo" → "Eso no es prioridad para mí ahora".

@@ 32 | Herramientas | Mapa de energía matutina | Bloques de 30 minutos
Copia esta tabla en tu libreta.

## Mi mañana hoy
| Bloque | Qué hago | Me recarga / me drena / automático |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |

## Mi mañana rediseñada
| Bloque | Qué voy a hacer | Cómo quiero sentirme |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |

## Preguntas
- ¿Qué me recarga?
- ¿Qué me drena?
- ¿Qué hago en automático?
- ¿Qué bloque cambio primero?

@@ 33 | Herramientas | Tu ritual matutino | Plantilla para llenar
Escríbelo en una hoja bonita y pégala donde la veas cada mañana.

## Mi ritual
- Hora a la que quiero despertar:
- Mis 3 acciones con presencia:
  1.
  2.
  3.
- Cómo quiero sentirme al empezar el día:
- Mi detalle para los sentidos (aroma, bebida, música):
- Mi espacio:
- Mi intención:

## Recordatorio
No tiene que ser perfecto. Tiene que ser real y repetirse lo suficiente para volverse parte de ti.

@@ 34 | Herramientas | Hoja anti-bloqueo | Tu hábito mínimo del día
Úsala cada vez que sientas que estás posponiendo algo.

## Mi hoja de hoy
- ¿Cómo me siento hoy?
- ¿Qué tarea estoy evitando?
- ¿Qué tipo de bloqueo es? (mental · energía baja · ruido interno · distracción · miedo a hacerlo mal)
- ¿Qué interruptor elijo?
- ¿A qué hora lo hago?

## Los interruptores
- **Mental:** 3 tareas en orden, solo la primera.
- **Energía baja:** agua y 10 a 15 minutos de caminar.
- **Ruido interno:** escribir 5 a 10 minutos sin filtro.
- **Distracción:** 15 a 30 minutos sin pantallas, una sola tarea.
- **Miedo a hacerlo mal:** nota de voz de un minuto con tu qué y tu porqué.

## Frase
"Mi tarea no es hacerlo perfecto. Es empezar de nuevo."

# Preguntas frecuentes

## Empezar | 0

### ¿Tengo que hacer un día diario?
Es la idea, pero no es castigo. Si un día no puedes, retomas al siguiente. No tienes que reponer todos los días atrasados.

### ¿Cuánto tiempo me toma cada día?
Entre 5 y 20 minutos. El Día 6 es la excepción: es una experiencia de 3 a 4 horas que puedes hacer cualquier día de esa semana.

### ¿Puedo saltarme días?
Sí, desde el menú puedes ir a cualquier día. La primera vez funciona mejor en orden, porque cada semana construye sobre la anterior.

### ¿Dónde guardo mis ejercicios?
En el cuaderno al final de cada día. Se guarda solo en este dispositivo y navegador. Copia lo importante a tu libreta.

## Tiempo | 3

### Siempre me surgen urgencias y no hago lo importante.
Usa las cuatro cajas (Día 3) y agenda primero lo "importante, no urgente". Lo importante que no atiendes termina volviéndose urgente.

### No tengo tiempo para mí.
Haz el Día 5: escribe cómo usaste tu tiempo ayer y encuentra una hora que puedas recuperar. Casi siempre aparece.

### Me da culpa descansar.
Es muy común. El Día 6 está hecho justo para eso: entrenar a tu mente a que estar bien también es avanzar.

## Mente | 10

### ¿Las afirmaciones de verdad sirven?
Repetir una frase no hace magia, pero sí te ayuda a notar cómo te hablas y a practicar otra forma. Funciona mejor cuando la acompañas con una acción pequeña (Día 18).

### Me hablo muy feo cuando me equivoco.
Haz el ejercicio de los dos guiones del Día 12: cómo le hablarías a alguien que amas y cómo te hablas tú. Practica el primero contigo.

### Algo de esto me removió mucho.
Gracias por notarlo. Ritmo es un reto de hábitos, no terapia. Si algo te pesa por varios días, habla con alguien de confianza o con una profesional.

## Hábitos | 19

### Empiezo con todo y a la semana lo dejo.
Elige un solo hábito pequeño y termínalo (Día 21). Terminar cosas pequeñas te enseña a confiar en ti.

### ¿Qué hago cuando estoy bloqueada?
Identifica tu tipo de bloqueo y usa su interruptor: está en el Día 26 y en la Hoja anti-bloqueo.

### ¿Tengo que despertarme a las 5?
No. Tu ritual tiene que ser real para ti. Lo importante es que la primera parte de tu mañana sea tuya, no la hora.

## Negocio | 27

### ¿Esto me sirve para mi negocio?
Sí. Cuando ordenas tu tiempo y tu energía, tienes espacio para crear contenido y tener conversaciones. Los Días 23, 27 y 28 son directo para tu marca.

### ¿Qué sigue después del Día 30?
Quédate con 3 hábitos del reto. Si quieres llevarlo a tus redes, sigue con Encendida o Visible.

## El mentor | 0

### ¿Qué es "Tu mentora"?
Es la mentora de Ritmo dentro de Claude. Te da el día que quieras, te acompaña con los ejercicios y te ayuda a diseñar tu ritual y tu plan anti-bloqueo.

### ¿Tengo que pagar Claude?
No. Funciona con la cuenta gratis de claude.ai. La cuenta gratis tiene un límite de mensajes por día.

### ¿Cómo la instalo?
Descarga la mentora (.zip) en la pestaña Tu mentora. En Claude entra a Customize → Skills, toca "+", luego "Create skill" → "Upload a skill" y sube el zip sin descomprimir.
