# Ponte Pro · contenido completo del curso

## 0 · Bienvenida a Ponte Pro
*Empieza aquí · El curso en 5 minutos*

Este curso es para que dejes de "probar suerte" con tu negocio de Farmasi y lo trabajes como lo que es: una profesión. Con habilidades que se aprenden, se practican y se enseñan.

### De qué se trata
Casi todas entramos igual: con emoción, una lista de cinco o seis personas en la cabeza y la esperanza de que alguna diga que sí. Cuando no pasa, nos desinflamos y pensamos que "esto no funciona" o que "no soy buena para vender".

La idea de este curso es otra: **en este negocio no gana la que tiene suerte, gana la que se vuelve experta**. Y para volverte experta no necesitas un título, ni conocer a mucha gente, ni tener una personalidad especial. Necesitas dominar siete habilidades sencillas y practicarlas hasta que te salgan solas.

> No viniste a vender un producto. Viniste a aprender un oficio.

### Cómo está armado
- **Decide (clases 1 a 3).** Por qué este modelo de negocio tiene sentido hoy, los tres tipos de personas que hay en el network marketing y por qué la única variable de tu negocio eres tú.
- **Las 7 habilidades (clases 4 a 11).** Encontrar a quién hablarle, invitar (dos clases, porque es la habilidad más importante), presentar, dar seguimiento, ayudar a decidir, arrancar bien a tus nuevas y llenar los eventos.
- **Para largo (clases 12 y 13).** Cuánto tarda esto en serio, cómo se aprende y por qué vale la pena.
- **Herramientas.** El guion de invitación, respuestas a las dudas más comunes, la plática de arranque para tus nuevas y tu semana pro.

### Lo que necesitas
- Un cuaderno o una nota en tu celular para tu lista (o el cuaderno de cada clase, que se guarda en tu teléfono).
- El material que ya usa tu equipo: el catálogo, el video o la presentación de la oportunidad, muestras y el calendario de eventos.
- Ganas de practicar. Aquí casi todo se aprende haciendo.

### Antes de empezar
Este curso no promete ingresos. Lo que ganes depende de tu trabajo, de tus ventas a clientas reales y de cuánto tiempo le dediques. Lo que sí te promete es un método claro para dejar de improvisar.

### 🪞 Para pensar
¿Hasta hoy has tratado tu negocio como un pasatiempo, como un boleto de lotería o como una profesión? Sé honesta.

### ✍️ Escribe
Escribe en una frase por qué quieres volverte profesional. Por ejemplo: "Quiero que mi negocio deje de depender de mi ánimo del día."

## 1 · Clase 1 · No es perfecto, es mejor
*Decide · Por qué este modelo tiene sentido hoy*

Antes de aprender las habilidades, vale la pena entender por qué este negocio merece que lo tomes en serio.

### La lista del trabajo ideal
Si le preguntas a cualquier persona cómo sería su trabajo perfecto, casi todas dicen cosas parecidas. Primero lo que no quieren: jefe, tráfico, despertador, horarios ajenos, politiquería, techo de ingreso. Luego lo que sí quieren: un producto que les guste, ingresos que sigan llegando aunque no estén, gente con la que les dé gusto trabajar, tiempo libre, crecer como personas, poco riesgo y poca inversión para empezar.

Ahora piensa en las opciones que casi todas conocemos:
- **Trabajo de oficio u operativo.** Da satisfacción, pero cambias horas por dinero y tu ingreso tiene tope.
- **Empleo de oficina.** Se ve seguro, pero dependes de otros. O te vuelves experta en política interna para subir, o te escondes para que no te noten.
- **Ventas tradicionales.** Ganas por resultados, pero cada mes empiezas en cero y cualquier cambio de la empresa te mueve el piso.
- **Negocio propio tradicional.** Suena a libertad, pero muchas veces significa deudas, rentas, empleados y ser la primera en llegar y la última en irse.
- **Invertir.** Necesitas dinero, conocimiento y aceptar que no controlas lo que pasa.

Ninguna cumple la lista completa. No porque sean malas, sino porque fueron diseñadas para otra época.

### El mundo ya cambió
Cada vez más trabajos pagan por resultados y no por horas. La tecnología elimina puestos que antes parecían seguros. En ese mundo, el negocio en red tiene sentido: las marcas necesitan que alguien le cuente a la gente sobre sus productos, y en lugar de gastar todo en publicidad, le pagan a quien los recomienda.

Para ti eso significa algo concreto: puedes tener muchas de las ventajas de un negocio propio, con poca inversión, sin rentas ni empleados y sin un techo puesto por alguien más.

> No es perfecto. Es mejor que las otras opciones que tienes enfrente.

### La parte que nadie te dice
Hay un costo, y es mejor saberlo desde hoy: **por un tiempo, algunas personas van a pensar menos de ti**. Te van a decir que "eso no funciona" o que "es una pirámide".

¿Por qué? Porque la mayoría de quienes lo intentaron nunca empezaron un negocio. Entraron con una lista de cinco amigas, les hablaron sin preparación, no pasó nada y concluyeron que el modelo no sirve. Es como comprar un raspadito, que no te salga premio y decir que el dinero no existe.

Tu trabajo no es convencerlas a todas. Es entender de dónde viene esa opinión, no tomarla personal y seguir construyendo. Con el tiempo, tus resultados hablan.

### 🪞 Para pensar
De la lista del trabajo ideal, ¿qué tres cosas son las que más te importan a ti?

### ✍️ Escribe
Escribe qué te dirías a ti misma la próxima vez que alguien te diga "eso no funciona". Que sea una frase que te dé calma, no una para pelear.

### ✅ Hoy
Escribe tu propia lista del trabajo ideal: cinco cosas que no quieres y cinco que sí. Guárdala, la vas a usar en la clase 9.

## 2 · Clase 2 · Decide ser pro
*Decide · La Raspadita, la Aficionada y la Pro*

En este negocio hay tres tipos de personas. Todas hemos sido alguna. La pregunta es cuál vas a ser de aquí en adelante.

### La Raspadita
Entra como quien compra un boleto de lotería. Tiene en la cabeza a cinco o seis personas que "seguro van a entrar". Si alguna entra, sigue un rato. Si no, rompe el boleto y dice que esto no funciona. Su único plan es la suerte, y la suerte tiene que llegar rápido.

Ocho de cada diez personas empiezan así. No es un defecto, es que nadie les dijo que esto se aprende.

### La Aficionada
Ya se lo toma más en serio, pero pone su energía en cuatro cosas que no controla:
- **La suerte.** Espera encontrar a esa persona "estrella" que le cambie todo.
- **El momento.** ¿Entré a tiempo? ¿Ya hay muchas en mi ciudad? ¿La marca está muy grande o muy chica?
- **La posición.** ¿Estoy en el equipo correcto? ¿Mi líder me ayuda lo suficiente?
- **Los atajos.** Cada técnica nueva de redes, cada truco, cada anuncio. Siempre buscando la fórmula mágica.

### La Pro
Una profesional es **una experta en las habilidades que hacen crecer un equipo grande y sano**. Deja de pensar en la suerte, el momento, la posición y los atajos. Incluso deja de obsesionarse con el dinero. Se enfoca en sus habilidades y practica, practica, practica.

### Emoción con habilidad
Se dice mucho que "más vale entusiasmo sin saber que saber sin entusiasmo". ¿Y por qué elegir? Imagina a una doctora que te dice: "Nunca he hecho esta operación, pero estoy súper emocionada." ¿Te operarías con ella? El entusiasmo es buenísimo, pero tiene que ir con habilidad.

Una enfermera estudia años. Una estilista practica cientos de cortes. Pero cuando alguien entra a este negocio, muchas veces no le dedica ni una semana a aprender. Ser pro es darle a tu negocio el mismo respeto que le darías a cualquier carrera.

### Lo que pasa cuando decides
Cuando decides ser pro pasa algo curioso: **tu equipo empieza a crecer**. La gente siente tu compromiso. Piensa en alguna maestra, coach o jefa que se tomaba en serio su trabajo. Te inspiraba, ¿verdad? Tú puedes ser eso para otras.

Y la buena noticia: este negocio te deja ganar mientras aprendes. No tienes que esperar a ser experta para empezar a tener resultados. Solo no dejes de aprender cuando empiecen a llegar.

### 🪞 Para pensar
¿En cuál de los cuatro focos de la Aficionada (suerte, momento, posición, atajos) se te va más la energía?

### ✍️ Escribe
Escribe tu decisión con tus palabras. Por ejemplo: "A partir de hoy trato mi negocio como una profesión. Mi trabajo es dominar las siete habilidades."

### 💬 Cuéntame
Comparte tu decisión con tu líder o con tu mentora. Decirla en voz alta la vuelve real.

## 3 · Clase 3 · Tú eres la variable
*Decide · Responsabilidad total y las siete habilidades*

Tu negocio tiene tres piezas. Dos son iguales para todas. La tercera eres tú.

### Las tres piezas
1. **Los productos.** Todas en Farmasi vendemos el mismo catálogo. Si a otra le va bien con esos productos y a ti no, el problema no es el producto.
2. **El plan de ganancias.** Es el mismo para todas, sin importar tu edad, tu escolaridad o de dónde vienes. Si otra gana más con el mismo plan, el problema no es el plan.
3. **Tú.** Eres lo único que cambia. Y por eso eres la diferencia entre que funcione o no.

> Mismo catálogo, mismo plan. La diferencia eres tú, y eso es una buena noticia, porque tú sí puedes cambiar.

### Recurso, no excusa
En este negocio hay una epidemia: culpar a la líder de arriba. "Si mi líder me ayudara más, me iría mejor." Es comodísimo, y no sirve.

Te propongo algo fuerte. Ten una conversación (aunque sea solo contigo) que diga algo así: "Gracias por invitarme. Desde hoy te voy a usar como recurso, nunca como excusa. Si puedes ayudarme, qué padre. Si no, también está bien. Mi negocio empieza y termina conmigo."

No es pelearte con nadie. Es quitarle a otras el poder sobre tus resultados.

### Las siete habilidades
Esto no es ciencia espacial. Son siete habilidades, no setenta:
1. **Encontrar a quién hablarle.**
2. **Invitar** a conocer tu producto o tu negocio.
3. **Presentar.**
4. **Dar seguimiento.**
5. **Ayudar a decidir** a que se vuelva clienta o socia.
6. **Arrancar bien** a tus nuevas.
7. **Promover eventos.**

Cada una es sencilla. Lo que sorprende es lo poco que la mayoría las practica. Las siguientes ocho clases son una por una.

### Lo bueno de esta profesión
No necesitas pedir un crédito para estudiarla. Puedes ganar mientras aprendes. No importa tu edad, tu historia ni a quién conoces. Y hay mucha gente con interés en que te vaya bien y dispuesta a enseñarte.

### 🪞 Para pensar
¿A quién o a qué has culpado alguna vez por tus resultados? ¿Qué cambia si mañana dejas de hacerlo?

### ✍️ Escribe
Califica del 1 al 10 qué tan buena te sientes hoy en cada una de las siete habilidades. Vas a volver a esta lista al terminar el curso.

## 4 · Clase 4 · Tu lista viva
*Habilidad 1 · Encontrar a quién hablarle*

"Es que no conozco a nadie." Es la duda más común al empezar. Y no es cierta: encontrar gente es una habilidad, no una cuestión de suerte.

### Tres formas de hacer la lista
- **La Raspadita** hace una lista mental de cuatro o cinco personas y todo su futuro depende de lo que esas cinco digan.
- **La Aficionada** hace una lista escrita de cien. Sale con emoción, la lista se va acabando y su angustia va creciendo. Su mayor miedo es quedarse sin gente.
- **La Pro** también empieza con una lista escrita, pero **nunca la deja de alimentar**. Por eso le decimos tu lista viva.

### Los cuatro pasos de tu lista viva
**1. Saca todo de tu cabeza.** Escribe a todas las personas que conoces. A todas. No decidas si son "prospecto" o no. Tu amiga negativa va en la lista. La que te cae mal, también. La que ya te dijo que nunca entraría a algo así, también. Tu tía de 70 y tu sobrina de 19, también. Piensa en cada escuela, trabajo, colonia, iglesia, gimnasio, grupo de mamás y chat de WhatsApp en el que has estado. Si lo haces bien, salen cientos de nombres.

No tienes que hablarle a todas. Pero sí tienes que tenerlas escritas. Cuando vacías tu cabeza en papel, haces espacio para que aparezcan más.

**2. Piensa en a quién conocen ellas.** Tu hermana, ¿a quién conoce? Tu comadre, ¿con quién trabaja? Tus compañeras del gym, ¿quiénes son sus amigas? Casi siempre ya conoces a ese segundo círculo también. A la lista.

**3. Agrega dos personas al día.** Esta es la diferencia de la Pro. Todos los días conoces gente: en la fila de la tienda, en la junta de la escuela, en redes, con la señora que te atiende en la estética. Si agregas dos personas al día, seis días a la semana, en un año son más de 600 nombres. ¿Ves por qué una Pro no se preocupa por quedarse sin gente?

Ojo: agregar no es atacar. No le sueltas tu presentación a nadie en cuanto la conoces. La agregas, haces amistad, te mantienes en contacto y, cuando sea el momento, le cuentas lo que tienes.

**4. Sal a conocer gente a propósito.** Es difícil conocer gente si te escondes. Inscríbete a una clase, a un voluntariado, a un club de lectura, a un grupo de corredoras. Es bueno para tu negocio y, además, haces amigas.

> Una Pro no tiene miedo de quedarse sin gente, porque buscar gente es parte de su trabajo diario.

### En Farmasi
Tu lista viva también son tus clientas. Cada pedido es una relación. Anota su nombre, qué compró, cuándo se le acaba y qué le gustó. Muchas de tus futuras socias hoy son tus clientas.

### ✍️ Escribe
Pon un temporizador de 30 minutos y escribe todos los nombres que puedas. Sin filtrar. Luego, junto a 10 de ellos, anota a quién conocen.

### ✅ Hoy
Agrega dos personas nuevas a tu lista antes de dormir.

### 💬 Cuéntame
¿Cuántos nombres te salieron? ¿Te sorprendió?

## 5 · Clase 5 · Jardinera, no cazadora
*Habilidad 2 · Cómo se invita sin perseguir a nadie*

Invitar es la habilidad más importante de todas. Es la puerta: si nadie acepta ver lo que tienes, lo demás no importa. Y no necesitas fama ni influencia para hacerlo bien.

### Cazadora o jardinera
Hay dos maneras de invitar.

**La cazadora** sale con la oportunidad en la mano y le dispara a todo lo que se mueve. No le importan las relaciones, solo "cerrar". Su lema es: "unas sí, otras no, ¿y qué? la que sigue". Resultado: todas a su alrededor se sienten perseguidas y la empiezan a evitar. Y las pocas que entran copian lo mismo, fracasan y se van.

**La jardinera** siembra. Construye relaciones y confianza. Su meta inicial no es inscribir a nadie, sino **que la persona conozca y entienda lo que ofreces**, y que luego decida. Se comporta como una asesora: escucha, entiende qué le hace falta a la otra persona y le ofrece una solución con sentido común.

> Tu meta al invitar no es que entre. Tu meta es que entienda.

### No presentes, invita
Las Pro no "sueltan el rollo". Cuando es el momento, invitan a una de dos cosas:
- **A una herramienta:** el video de la oportunidad que usa tu equipo, el catálogo, una presentación en línea, una muestra del producto.
- **A un evento:** un café uno a uno, una llamada de tres con tu líder, una reunión en casa, un Zoom, una junta presencial o un evento grande.

Los eventos son lo más poderoso: la persona ve que hay más gente, siente el ambiente y escucha historias. Pero son más difíciles de agendar. Por eso, para empezar, **una herramienta suele ser el mejor primer paso**: la persona la ve en su tiempo, sin salir de casa. Después del video, la invitas al evento.

Usa lo que ya funciona en tu equipo. No inventes tu propio material. Y si tu equipo tiene una forma diaria de trabajar (por ejemplo, "dos videos compartidos al día"), súmate a ella.

### La fórmula
Si tuviera que resumir cómo se construye la libertad en este negocio, sería así: **lograr que un grupo grande de personas haga, de forma constante, unas pocas cosas sencillas durante mucho tiempo.** No se trata de ser la mejor convenciendo. Se trata de hacer cosas tan simples que todas las puedan copiar.

### Las cuatro reglas de la emoción
1. **Suelta el resultado.** Si te enganchas con "que entre", vas a vivir decepcionada y la gente va a sentir tu necesidad. Si te enfocas en que entienda, todo se vuelve más ligero.
2. **Sé tú.** Mucha gente se transforma en otra persona cuando invita, y eso incomoda a todas. Sé tú, en tu mejor versión.
3. **Pon pasión.** El entusiasmo se contagia. Pon una canción que te prenda antes de llamar. Sonríe aunque sea por teléfono, se nota.
4. **Párate firme.** Deja de pedir perdón. No es lo mismo "ya sé que he intentado mil cosas, pero a lo mejor esta sí" que "me cansé de la vida que llevaba y decidí tomar el control. Yo no apostaría en mi contra". Sé tú, pero más segura. Como un músculo: al principio aguantas poquito y luego cada vez más.

### 🪞 Para pensar
¿Alguna vez te sentiste cazadora? ¿Cómo reaccionó la gente?

### ✍️ Escribe
Reescribe tu forma de presentarte con postura firme. Empieza con: "Decidí tomar el control de…"

## 6 · Clase 6 · La invitación en 8 pasos
*Habilidad 2 · El trato, las confirmaciones y colgar a tiempo*

Ahora sí, el paso a paso. Esta invitación se hace en llamada o en persona. No por mensaje copiado y pegado: la herramienta sí se puede mandar por WhatsApp, pero la invitación se hace en vivo, con tu voz. Sirve con gente que conoces y con gente que vas conociendo.

### Los 8 pasos
1. Ten prisa.
2. Haz un cumplido.
3. Haz la invitación.
4. El trato: "Si te mando…, ¿lo ves?"
5. Que ella ponga el día.
6. Confirma ese día.
7. Agenda la llamada.
8. Despídete.

Parece mucho, pero toma tres minutos.

### Paso 1 · Ten prisa
Nos atrae la gente que tiene cosas que hacer. Si arrancas dando la impresión de que vas corriendo, la plática es más corta, hay menos preguntas y más respeto por tu tiempo. "Tengo mil cosas, pero me urgía hablar contigo." "Voy de salida, pero necesitaba decirte algo rápido."

### Paso 2 · Haz un cumplido
Tiene que ser sincero. "Siempre me has apoyado y te lo agradezco mucho." "Tienes una cabeza para los negocios que pocas tienen." "Me atendiste increíble, ¿a qué te dedicas además de esto?" Nos dicen pocos cumplidos y se sienten bien. Abre la puerta a escuchar.

### Paso 3 · Haz la invitación
Hay tres maneras, según la persona:

**De frente.** Para quien te conoce y te respeta, o para alguien que sabes que busca algo más. "¿Te acuerdas que me dijiste que ya no aguantas tu trabajo? ¿Era en serio o era broma? Creo que encontré una forma de que empieces a cambiar eso." Con gente que vas conociendo: "¿Piensas hacer lo mismo que haces hoy el resto de tu vida?"

**Pide consejo.** Juegas un poco hacia abajo y le pides su opinión. "Empecé un negocio y estoy nerviosa. Antes de arrancar quiero practicar con alguien de confianza, ¿me dejas practicar contigo?" O: "Tú sabes mucho de esto, ¿me ayudarías a ver si estoy tomando una buena decisión?"

**¿A quién conoces?** Le dices que no es para ella y le preguntas si conoce a alguien. "Lo que hago seguro no es para ti, pero ¿conoces a alguien con ganas de tener un ingreso extra?" Casi siempre te va a pedir más información antes de darte nombres (y muchas veces, por dentro, está pensando que a lo mejor sí es para ella). Respondes: "Claro, tiene sentido que quieras saber más antes de recomendar a alguien." Y pasas al paso 4.

### Paso 4 · El trato
Esta es la frase más poderosa del proceso: **"Si te mando…, ¿lo ves?"**
- "Si te mando un video de 15 minutos, ¿lo ves?"
- "Si te llevo el catálogo, ¿lo revisas?"
- "Si te dejo una muestra, ¿la pruebas?"
- "Si te invito a un Zoom corto, ¿te conectas?"

Funciona porque es un intercambio: tú haces algo si ella hace algo. No estás rogando ni pidiendo favores. Y deja claro que lo que tienes vale. Compáralo con "porfa, porfa, de verdad quiero que veas mi video". Se siente la diferencia, ¿no? La desesperación no atrae.

Si te pide más información antes: "Te entiendo, pero todo lo que preguntas viene en el video. La forma más rápida de entenderlo es verlo. Si te lo mando, ¿lo ves?" Si dice que no, le das las gracias y sigues. No le mandes el material.

### Paso 5 · Que ella ponga el día
Si te quedas en el paso 4, muy pocas lo van a ver. Pregunta: **"¿Cuándo crees que lo puedas ver, seguro?"** Y espera. No le sugieras tú el día. Al pensar en su agenda, lo vuelve real. Si te dice "un día de estos", le dices: "No quiero quitarte tiempo. ¿Qué te parece si ponemos un día en que seguro ya lo viste?"

### Paso 6 · Confirma ese día
"Entonces, si te marco el jueves en la tarde, ¿ya lo viste seguro, verdad?" Ella confirma o ajusta. La cita no la pusiste tú: la puso ella.

### Paso 7 · Agenda la llamada
"¿A qué número y a qué hora te marco?" Ya te dijo que sí cuatro veces. Ahora tienes una cita real. Y tu trabajo es cumplirla.

### Paso 8 · Despídete
¿No ibas con prisa? "¡Perfecto, hablamos el jueves! Me voy corriendo." Muchas hacen la cita y la deshacen hablando de más. Deja que la herramienta haga su trabajo.

### Un ejemplo completo
"Oye, voy de salida pero me urgía hablar contigo. Siempre me has apoyado muchísimo y te lo agradezco. Empecé un negocio y estoy nerviosa, ¿me dejas practicar contigo? ... ¡Gracias! Si te mando un video de 15 minutos, ¿lo ves? ... ¿Cuándo crees que lo veas seguro? ... ¿El jueves? Entonces si te marco el viernes en la mañana, ya lo viste seguro, ¿verdad? ... ¿A qué hora te marco? ... Perfecto, hablamos el viernes. ¡Me voy, gracias!"

> No hay buenas ni malas invitaciones. Solo hay invitaciones de las que aprendes.

### ✍️ Escribe
Elige a tres personas de tu lista. Para cada una, decide qué forma de invitación le va (de frente, pide consejo o a quién conoces) y escribe tu cumplido sincero.

### ✅ Hoy
Haz una invitación con los 8 pasos. Aunque te tiemble la voz.

### 💬 Cuéntame
¿Qué paso te costó más? ¿Qué te dijo la persona?

## 7 · Clase 7 · Mensajera, no mensaje
*Habilidad 3 · Presentar sin ser la experta*

Cuando la persona ve el video sola, tú no tienes que hacer nada más que dar seguimiento. Pero cuando estás con ella, hay una idea que lo cambia todo: **la protagonista no eres tú**.

### La trampa de ser la experta
Es natural querer saberlo todo: cada producto, cada ingrediente, cada porcentaje del plan. Y sentarte a decir "déjame contarte todo". El problema tiene tres partes:
1. Siempre habrá una pregunta que no sepas, y si te presentaste como experta, eso siembra duda.
2. La gente que te conoce sabe que no eres experta, y eso la pone más escéptica.
3. Aunque tú lo logres, tus nuevas no van a querer ni poder hacer lo mismo. Vas a terminar dando todas las presentaciones de tu equipo. Eso no es un negocio, es un trabajo.

### Lo que se copia
> En este negocio no importa lo que funciona. Importa lo que se puede copiar.

Por eso las Pro usan herramientas en lugar de su propia sabiduría, eventos en lugar de su propia presentación, y a otras socias (tu líder, una compañera con una historia parecida) para dar los datos. Si te preguntan algo, no siempre contestas tú: guías a la persona a la respuesta. "Eso lo explica muy bien la presentación del jueves." "Déjame conectarte con mi líder, que te lo cuenta mejor."

¿Qué pones tú? Pasión, entusiasmo, emoción y convicción. Eso sí es tuyo y eso sí se contagia.

### Tu historia en cuatro partes
A la gente no le interesa cuánto sabes, pero sí le interesa tu historia, mientras no la aburras. Toda buena historia tiene:
1. **De dónde vienes.**
2. **Lo que no te gustaba de ahí.**
3. **Cómo llegó este negocio (o el producto) a tu vida.**
4. **Tus resultados o cómo te sientes hoy con tu futuro.**

Ejemplo de estructura: "Soy mamá de dos y trabajaba en una oficina. Me perdía todo de mis hijos y el dinero no alcanzaba. Una amiga me enseñó los productos y luego el negocio. Hoy apenas empiezo, pero por primera vez siento que mi futuro depende de mí." Cuéntala en menos de un minuto. Si apenas empiezas, habla de cómo te sientes; no inventes resultados.

### Presentar en grupo
La que está al frente con el plumón suele ser la que más crece. Si te da pánico hablar en público, es normal. Se aprende por etapas:
1. **Tu historia.** Cuéntala en todos lados hasta que te salga sola.
2. **La presentación oficial de tu equipo.** Elige la de la mejor presentadora que conozcas, apréndetela casi palabra por palabra, grábate, escúchate y repite. Cuando la sabes de memoria, el miedo se convierte en ganas.
3. **Capacitaciones.** Cuando ya dominas lo anterior, empiezas a enseñar.

Y para cualquier presentación importante: elige un tema, escríbela, reescríbela, practícala y grábate. Cuando estás preparada, hasta se disfruta.

### ✍️ Escribe
Escribe tu historia en las cuatro partes. Luego léela en voz alta con cronómetro. Si pasa de un minuto, recórtala.

### ✅ Hoy
Grábate en nota de voz contando tu historia. Escúchala una vez y cambia una cosa.

## 8 · Clase 8 · El seguimiento
*Habilidad 4 · Cada contacto prepara el siguiente*

Dicen que la fortuna está en el seguimiento. Y es cierto, porque casi nadie lo hace bien.

### 1 · Seguimiento es cumplir lo que dijiste
Si dijiste que marcabas el viernes a las 6, marcas el viernes a las 6. En este negocio sobra gente que se emociona un día y desaparece al siguiente. Maneja tu negocio con una agenda (la del celular sirve). Si no puedes, avisa con anticipación y reagenda. La gente respeta a quien cumple y a quien valora su propio tiempo.

### 2 · Cada contacto sirve para agendar el siguiente
Al terminar una presentación, la pregunta natural es "¿qué te pareció?". Es de las peores: invita a la parte crítica de la mente a buscar peros para sonar lista. Y casi siempre acaba en "luego te digo", y ahí se pierde.

El cambio de mentalidad: **la única razón de un contacto es preparar el siguiente.** No tienes que "cerrar" en el primero. Tienes que mantener vivo el proceso hasta que la persona entienda y decida.

**Si no vio el video:** no te enojes ni le reclames. "No te preocupes, a todas se nos complica la semana. ¿Cuándo lo puedes ver, seguro seguro?" Y repites los pasos de confirmación.

**Si sí lo vio:** pregunta **"¿Qué fue lo que más te gustó?"** Esa respuesta te dice hacia dónde ir. Si dice "los productos", el siguiente paso es de producto (una muestra, el catálogo). Si dice "la idea de tener mi propio dinero", el siguiente paso es de negocio.

Luego: **"Del 1 al 10, donde 1 es nada de interés y 10 es lista para empezar, ¿dónde estás?"** Cualquier número arriba de 1 es bueno. Pregunta: "¿Qué te ayudaría a subir ese número?" Y ahí agendas el siguiente contacto: que pruebe el producto, que platique con su pareja con el material en mano, que hable con tu líder, que venga al evento. Nunca termines un contacto sin el siguiente agendado.

### 3 · Toma de cuatro a seis contactos
En promedio, una persona necesita de cuatro a seis contactos antes de entrar. Es un promedio: por cada una que entra a la primera, otra tarda diez. Algunas de las mejores socias tardaron años. Con prisa, pero con paciencia.

### 4 · Junta los contactos
La Raspadita le habla una vez y se va. La Aficionada da varios contactos a lo largo de meses. La Pro **los junta en el menor tiempo posible**: el video el lunes, una muestra el martes, una llamada con su líder el jueves y el evento el sábado. Si los separas por semanas, la vida la distrae y cada contacto es empezar de cero.

### Las dudas y las objeciones
Las objeciones son normales. Muchas veces la persona las dice para no parecer fácil. Tu meta no es ganar una discusión, es ayudarle a ver lo que todavía no ve. Si te pones a la defensiva, siembras duda. Si atacas, la alejas.

Casi todas las objeciones caben en dos grupos:
- **Duda de sí misma:** "No tengo dinero", "no tengo tiempo", "no soy vendedora", "no conozco a nadie", "estoy muy grande/muy chica".
- **Duda del modelo:** "¿Es una pirámide?", "no quiero molestar a mis amigas", "¿cuánto ganas tú?".

La herramienta más poderosa es la empatía: **"Te entiendo. A mí me pasó igual. Y esto fue lo que descubrí."** Tu historia (o la de otra socia) hace más que cualquier argumento. Evita las respuestas que hacen sentir tonta a la otra persona, del tipo "¿no tienes dinero pero sí pagas Netflix?". Se sienten horribles.

Con "¿es una pirámide?": si lo dice con emoción, casi siempre tiene una historia. "Oye, parece que te pasó algo, ¿qué pasó?" Escúchala. Luego explica con calma la diferencia: las pirámides son ilegales y viven de inscribir gente; un negocio en red legal vive de vender productos a clientas reales. En la herramienta de dudas tienes respuestas para cada una.

Y una buena noticia: son las mismas cinco o seis objeciones toda la vida. Las aprendes una vez.

### ✍️ Escribe
Escribe tu "te entiendo, me pasó, descubrí" para la objeción que más te da miedo.

### ✅ Hoy
Revisa tu agenda. ¿A quién le prometiste llamar y no lo has hecho? Hazlo hoy, o reagenda con un mensaje.

## 9 · Clase 9 · Ayudar a decidir
*Habilidad 5 · La postura y las cuatro preguntas*

Si das buen seguimiento, la persona va a entender lo que ofreces. Pero casi nadie te va a pedir sola el formato de inscripción. Tu trabajo es guiarla a una decisión.

### La postura
Cómo te paras, lo que dices y lo que traes puesto (literal y figurado) le dan confianza o le siembran dudas. Hay cinco cosas que hacen las Pro:
1. **Están desapegadas del resultado.** Lo opuesto a necesitadas. No quieren "agarrar" a nadie, quieren ayudar.
2. **Asumen que sí.** Están tan convencidas de que le va a servir que casi se sorprenden cuando alguien dice que no.
3. **Se ofrecen a sí mismas.** "Tenemos buenos productos y un buen plan, pero además me tienes a mí. Voy a crecer y podemos hacerlo juntas." No es "yo te hago todo", es "no vas a estar sola".
4. **Siempre están preparadas.** Traen el link de inscripción a la mano, saben qué kit recomendar y cómo se hace el primer pedido. Todo para empezar en ese momento.
5. **Preguntan y escuchan.** Están más interesadas que interesantes. Como una buena asesora: primero entiende, luego propone.

¿Y si todavía no te sale natural? Actúa como si. Al principio actúas el desapego, la seguridad, el "me tienes a mí". Con el tiempo, actúas menos y lo crees más.

### Preguntas que llevan a algo
En lugar de "¿qué te pareció?", usa preguntas que van hacia adelante: "¿Tuvo sentido?", "¿Qué fue lo que más te gustó?", "¿Ves cómo esto te podría servir?". Luego la escala del 1 al 10. Si necesita más información, agendas el siguiente contacto. Si se ve lista, pasas a las cuatro preguntas.

### Las cuatro preguntas del sí
1. **"Si empezaras medio tiempo, ¿cuánto tendrías que ganar al mes para que valga la pena tu tiempo?"** No le pongas tú la cifra. Pregúntale y espera.
2. **"¿Cuántas horas a la semana le podrías dedicar para construir eso?"**
3. **"¿Cuántos meses le darías esas horas para lograrlo?"**
4. **"Si te enseño cómo construir (su cifra) al mes, trabajando (sus horas) a la semana durante (sus meses), ¿estarías lista para empezar?"**

Si dice que sí, sacas el plan de ganancias y arman juntas un plan realista. Si te da números imposibles (mucho dinero, pocas horas, un mes), eres honesta como asesora: "Con esas expectativas no te voy a mentir, no se puede. Se puede llegar, pero toma más horas y más meses. Si quieres ajustarlo, platicamos."

> Ser honesta con los números es parte de ser pro. Nunca prometas lo que no puedes cumplir.

Si no hay un sí todavía, está bien. Agendas el siguiente contacto y repites el proceso.

### ✍️ Escribe
Escribe las cuatro preguntas con tus palabras, como tú las dirías. Ensáyalas en voz alta.

### 💬 Cuéntame
¿Cuál de las cinco cosas de la postura te cuesta más?

## 10 · Clase 10 · Arrancar bien
*Habilidad 6 · La plática de arranque y cruzar la raya*

Mucha gente invierte energía en inscribir y luego deja a la nueva sola para que "se las arregle". La Pro no. La Pro pone expectativas claras, la ayuda a tener resultados rápidos y la acompaña hasta que vuela sola.

### La plática de arranque
Cada vez que entra alguien nuevo, agenda una plática de arranque. Siempre la misma, en cinco partes.

**1. Celebra su decisión.** "¡Felicidades! Estoy orgullosa de ti por tomar el control. A partir de hoy las cosas van a ser distintas." Cinco minutos que borran cualquier duda.

**2. Pon las expectativas.** Tres frases que lo cambian todo:
- "Si te va bien, va a ser gracias a ti. Y si no, también va a ser por ti. Yo te guío en cada paso, pero no lo puedo hacer por ti. Trabajo contigo, no para ti."
- "Mi trabajo es que dejes de necesitarme lo antes posible. ¿Te parece buena meta?"
- "Va a haber días buenos y malos. Voy a saber que estás en uno malo cuando dejes de contestar, de ir a las juntas o empiece a escuchar excusas. Cuando eso pase, y nos pasa a todas, ¿qué quieres que haga: te dejo en paz o te recuerdo por qué empezaste?"

Compáralo con lo que solemos decir: "tranquila, yo te ayudo con todo". Eso crea una nueva que espera a que tú hagas el trabajo y que te usa de excusa cuando no puedes.

**3. Revisa la lista de arranque.**
- Que use los productos y se enamore de ellos. Si hay muestras o testers, que tenga suficientes.
- Que tenga las herramientas: el video, el catálogo, su link.
- Que esté conectada: el grupo del equipo, la app, el calendario de juntas y eventos.
- Que entienda lo básico del plan de ganancias. No todo, solo los primeros niveles.
- Que sepa invitar. Un resumen de los 8 pasos le ahorra semanas de hablar de más.

**4. Arma el plan de su primera semana.** Es una carrera por los primeros resultados. Si llegan pronto, sigue. Si no, se apaga. ¿Cómo consigue su primera clienta? ¿Su primera socia? ¿Qué evento puede ir? ¿Qué necesita para su primera ganancia?

**5. Deja tareas con fecha.** Las nuevas aman la dirección. "Para el jueves, tu lista de 100 nombres. Me la mandas y la revisamos." De tarea en tarea, igual que de contacto en contacto.

### Cruzar la raya
Cuando alguien empieza hay una raya invisible. De un lado, es más fácil renunciar que seguir. Del otro, es más fácil seguir que renunciar. Tu trabajo es ayudarla a cruzarla. Ayudan:
- Su primera clienta.
- Su primera socia.
- Su primera ganancia.
- Ir a un evento grande.
- Hacer amigas en el equipo.
- Decirle al mundo que va en serio.
- Subir de nivel.
- Que la reconozcan por un logro.

Y la raya nunca desaparece del todo. Como líder, fíjate siempre de qué lado está cada una.

### ✍️ Escribe
Escribe tus tres frases de expectativas con tus palabras.

### ✅ Hoy
Si tienes una nueva en tu equipo, agenda su plática de arranque. Si no, ensáyala con tu mentora.

## 11 · Clase 11 · Llena el evento
*Habilidad 7 · Promover, no solo anunciar*

Las juntas hacen crecer el negocio. La tecnología ayuda, pero nada reemplaza estar cara a cara. Y el más poderoso de todos es el evento grande: ese al que viajas, te hospedas y pasas uno o dos días enfocada en tus sueños.

### Por qué los eventos importan tanto
- **Te llenan.** Alejarte de la rutina un fin de semana te ayuda a reenfocarte y regresar con fuerza.
- **Escuchas la frase que necesitabas.** A veces alguien dice algo justo en tu momento y te cambia para siempre. Casi todas las grandes decisiones de las líderes pasaron en un evento.
- **Prueba social.** Ves a cientos que tomaron la misma decisión que tú. Ves a otras que tenían tus mismos miedos y llegaron lejos. "Si ella pudo, yo también."
- **Presión positiva.** Ves los reconocimientos en el escenario y piensas "la próxima, subo yo". Y no quieres llegar al siguiente sin avances.
- **Comunidad.** Afuera hay gente que no entiende lo que haces. Ahí estás rodeada de gente que piensa como tú.

### Las que regresan
La lógica es simple: en cada evento, una parte de la gente ya no regresa. Las que siguen regresando, evento tras evento, son las que van creciendo. No es magia: entre evento y evento hay que trabajar las habilidades. Pero si tú sigues regresando, con el tiempo terminas entre las que más crecen, y un día en el escenario.

### Empieza por ti
Para crear una cultura de eventos, primero tú tienes que ser la más comprometida. No te pierdas los eventos grandes. Hazlo prioridad desde que se anuncian: ahorra un poco cada semana, comparte cuarto y coche, lleva comida, organiza quién cuida a los niños. **Sin endeudarte:** planear con tiempo es lo que lo hace posible.

### Anunciar o promover
La mayoría **anuncia**: "Les recuerdo que el evento es en marzo" y espera. La Pro **promueve**:
- Lo hace prioridad en su equipo y habla de él seguido.
- Cuenta historias de lo que pasó en el último evento.
- Pinta la imagen de lo que van a vivir.
- No descansa hasta que cada una tiene su lugar.
- Lleva la cuenta: cuántas fueron al anterior y cuántas van a este.

Cuando alguien dice "no puedo", no te quedes con la primera respuesta. Pregunta, escucha y busca soluciones juntas: ¿y si comparten cuarto? ¿y si apartan con tiempo? ¿quién te puede echar la mano con los niños? Muchas veces el "no puedo" era un "no sabía cómo". **Cuenta tu historia, no te compres la suya.** Y si después de platicarlo de verdad no se puede, se respeta.

Piensa que tu equipo cotiza en bolsa y su valor es cuántas personas llevas a cada evento. Empiezas tú sola, luego con dos, luego con cinco. Siempre un número más grande que la vez anterior.

### ✍️ Escribe
Escribe el próximo evento de tu equipo, la fecha y cuántas quieres llevar. Luego, tu plan para pagar tu lugar sin deudas.

### 💬 Cuéntame
¿Qué te pasó en algún evento que te cambió? Esa historia es tu mejor herramienta para promover el siguiente.

## 12 · Clase 12 · Esto toma tiempo
*Para largo · 1·3·5·7, cómo se aprende y tus cinco*

Si alguien abre una tienda, espera tardar años en recuperar lo que invirtió. Pero cuando alguien entra a un negocio en red, espera recuperar en un mes, ganar en el segundo y estar rica en el tercero. Y cuando no pasa, culpa al negocio. Todo lo que vale toma tiempo.

### Solo ganas lo que eres
A veces te llega un mes de suerte: estabas en el lugar correcto. Pero si no creces rápido como persona a ese nuevo nivel, tu ingreso regresa al nivel de quien eres hoy. Para ganar más, tienes que volverte más.

### El 1·3·5·7
Una guía general (no una promesa) de cómo se ve el camino con trabajo constante:
- **1 año** para volverte competente: sabes lo básico, cubres tus gastos y estás aprendiendo.
- **3 años** de trabajo constante de medio tiempo para que pueda volverse tu actividad principal.
- **5 años** para tener un ingreso alto y estable.
- **7 años** para ser experta.

Cada persona va a su ritmo y nadie te puede garantizar cifras. Pero piénsalo así: en siete años vas a tener siete años más de todos modos. Mejor que sean siete años volviéndote experta.

### Cómo se aprende esto
- **No hay experiencias buenas ni malas, solo experiencias para aprender.** Quita una presión enorme. Ya no buscas que todo salga perfecto, buscas tener muchas experiencias.
- **Copia a quien ya lo logró.** No reinventes nada. En tu equipo hay alguien que ya domina cada habilidad, y en este negocio a la gente le gusta compartir.
- **Estudia.** Audios y podcasts en el coche, diez páginas de un libro al día (un libro al mes), videos de capacitación, eventos.
- **Cuidado con las distracciones.** Hay mil técnicas nuevas cada semana. Primero domina las siete habilidades.
- **Actúa.** Casi todo se aprende haciendo. Es muy difícil verte bien y mejorar al mismo tiempo, así que elige mejorar.
- **Enseña.** Enseñar es la mejor forma de aprender. Aunque sea a una sola persona de tu equipo.

### Planea, hazlo, revisa
1. Elige una habilidad.
2. **Planea** cómo la vas a practicar.
3. **Hazlo.**
4. **Revisa** qué salió y qué cambiarías.
5. Haz un plan mejor y repite.

La mayoría solo hace, sin plan. Y casi nadie revisa. Este ciclo, repetido, te vuelve experta.

### Tus cinco
Te pareces a las cinco personas con las que más tiempo pasas: piensas, hablas y actúas como ellas. Tres cosas que puedes hacer: alejarte de lo que es tóxico, pasar menos tiempo con lo que te jala hacia abajo y buscar más a quienes te empujan a crecer. Un truco: cada cierto tiempo alguien de tus cinco cambia. Cuando pase, elige con intención quién ocupa ese lugar.

Y una cosa más que todas las líderes tienen en común: **trabajan mucho**. Disfrutan su estilo de vida, pero se lo trabajan. La libertad es posible, pero no es gratis.

### ✍️ Escribe
Elige una habilidad para esta semana y escribe tu plan: qué vas a hacer, cuántas veces y cuándo vas a revisar.

### ✅ Hoy
Escribe los nombres de tus cinco. ¿A quién quieres sumar?

## 13 · Clase 13 · Vale la pena
*Para largo · La carrera, la libertad y la persona en la que te conviertes*

Este negocio tiene altibajos y es muy emocional. Pero al final, por muchas razones, vale la pena.

### La carrera que construyes
Toda carrera tiene una barrera de entrada (lo que cuesta entrar) y un beneficio a largo plazo (lo que obtienes). Ser doctora exige años de estudio, dinero y contactos. En este negocio la barrera es muy baja y el beneficio puede ser muy alto. Pocas profesiones tienen esa proporción. La diferencia está en tratarlo como carrera y no como pasatiempo.

### La libertad
Libertad es poder elegir. Vivir la vida que tú quieres y no la que otros quieren para ti. Imagina: despertar cuando terminas de dormir, hacer un trabajo que te llena, con gente que te cae bien, sin tener que ceder siempre, con tiempo para los que quieres. Enfrentar tus miedos cuesta. Vivir a medias toda la vida cuesta más.

### Las vidas que tocas
Una cosa es cambiar tu vida y la de tu familia. Otra es ayudar a otra mujer a hacer lo mismo. Puedes darle esperanza a quien no la tiene y animarle un sueño. Es como tirar una piedra al agua: las ondas siguen creciendo aunque no las veas todas.

### La gente que conoces
Amigas en muchas ciudades, gente apasionada que se dedica a levantar a otras. Puede que este negocio te dé más amistades que cualquier otro trabajo que hayas tenido.

### Los lugares y las causas
Viajes de incentivo, la visita a otra ciudad para apoyar a tu equipo, tiempo para viajar por tu cuenta. Y la posibilidad de ayudar a las causas que te importan de tres formas: con tu dinero, con tu tiempo y con tu influencia. Esa última es la más poderosa: inspira a tu equipo a hacer algo bueno contigo.

### La persona en la que te conviertes
Al final, este negocio es una escuela de crecimiento personal. Aprendes a enfrentar tus miedos, a resolver problemas, a cuidar lo que entra en tu mente, a hacerte fuerte y a liderar.

> Lo mejor no es conseguir lo que quieres. Lo mejor es en quién te tienes que convertir para conseguirlo.

### 🪞 Para pensar
De todo lo que vale la pena (carrera, libertad, vidas que tocas, amistades, lugares, causas, la persona en la que te conviertes), ¿qué es lo que más te mueve a ti?

### ✍️ Escribe
Regresa a tu calificación de la clase 3. Califícate otra vez del 1 al 10 en cada habilidad. Elige la que más quieres subir este mes.

### 💬 Cuéntame
Escribe tu decisión final, con fecha: "Hoy, (fecha), decido ser profesional."

## 14 · Guion de invitación
*Herramienta · Los 8 pasos con frases para Farmasi*

Tenlo a la mano antes de cada llamada. No lo leas palabra por palabra: entiende la idea y dilo a tu manera.

### Los 8 pasos en una línea
Prisa → cumplido → invitación → el trato → que ella ponga el día → confirma → agenda la llamada → despídete.

### 1 · Ten prisa
- "Tengo mil cosas hoy, pero me urgía hablar contigo."
- "Voy de salida, pero necesitaba decirte algo rápido."
- "No es momento de contarte todo y ya me voy, pero…"

### 2 · Cumplido sincero
- "Siempre me has apoyado y te lo agradezco muchísimo."
- "Eres de las personas más organizadas que conozco."
- "Siempre te ves increíble, se nota que te cuidas."
- "Me atendiste súper bien. ¿A qué te dedicas además de esto?"

### 3 · La invitación
**De frente** (te conoce o sabes que busca algo):
- "¿Te acuerdas que me dijiste que querías un ingreso extra? ¿Era en serio? Creo que encontré algo para ti."
- "Cuando pensé en alguien a quien le podría ir muy bien con esto, pensé en ti."
- "¿Piensas hacer lo mismo que haces hoy el resto de tu vida?"

**Pide consejo** (familia, amigas cercanas):
- "Empecé un negocio y estoy nerviosa. ¿Me dejas practicar contigo?"
- "Tú sabes mucho de esto. ¿Me ayudas a ver si tomé una buena decisión?"
- "Empecé con una marca de maquillaje y skincare y quiero tu opinión honesta de los productos."

**¿A quién conoces?** (personas ocupadas o exitosas):
- "Seguro esto no es para ti, pero ¿conoces a alguien con ganas de tener un ingreso extra desde su casa?"
- "Estoy buscando mujeres con ganas de crecer. ¿Conoces a alguien así?"
- Si pide más información: "Claro, tiene sentido que quieras saber más antes de recomendar a alguien."

### 4 · El trato
- "Si te mando un video de 15 minutos, ¿lo ves?"
- "Si te llevo el catálogo, ¿lo revisas?"
- "Si te dejo una muestra, ¿la pruebas?"
- "Si te invito a un Zoom corto, ¿te conectas?"
- Si pide más: "Todo lo que preguntas viene ahí. Si te lo mando, ¿lo ves?"
- Si dice que no: "Gracias por tu tiempo." Y no mandas nada.

### 5 · Que ella ponga el día
- "¿Cuándo crees que lo puedas ver, seguro?" (y te callas)
- Si es vago: "No quiero quitarte tiempo. ¿Ponemos un día en que seguro ya lo viste?"

### 6 · Confirma
- "Entonces si te marco el (día siguiente), ya lo viste seguro, ¿verdad?"

### 7 · Agenda
- "¿A qué número y a qué hora te marco?"
- Anótalo en tu agenda en ese momento.

### 8 · Despídete
- "¡Perfecto, hablamos el viernes! Me voy corriendo, gracias."

### Cuando le marques
- No lo vio: "No te preocupes. ¿Cuándo lo puedes ver, seguro seguro?"
- Sí lo vio: "¿Qué fue lo que más te gustó?" → "Del 1 al 10, ¿dónde estás?" → "¿Qué te ayudaría a subir ese número?" → agenda el siguiente contacto.

## 15 · Respuestas a las dudas
*Herramienta · Te entiendo, me pasó, descubrí*

La fórmula para casi todo: **"Te entiendo. A mí me pasó igual. Y esto fue lo que descubrí."** Si no tienes historia propia, usa la de otra socia: "Tengo una amiga a la que le pasaba lo mismo…". Luego haz una pregunta.

### "No tengo dinero"
"Te entiendo, yo tampoco me sentía con dinero para empezar algo. Pero pensé: si hoy no me alcanza, ¿cómo va a cambiar si sigo haciendo lo mismo? Si de verdad sintieras que esto es una oportunidad para ti, ¿crees que encontrarías la forma?" Nunca la empujes a endeudarse: busquen juntas la opción de inicio que le quede.

### "No tengo tiempo"
"A mí me pasaba igual. Descubrí que se puede empezar con pocas horas a la semana, en los ratos que ya tengo. ¿Cuántas horas crees que sí podrías?"

### "No soy vendedora"
"Yo tampoco. Descubrí que no se trata de vender, sino de recomendar lo que ya uso y de invitar a que lo conozcan. El video y el catálogo hacen casi todo."

### "No conozco a nadie"
"Pensaba lo mismo hasta que hice mi lista y salieron más de cien nombres. Además, cada día conoces gente nueva. Te enseño a hacer la tuya."

### "Estoy muy grande / muy chica / no tengo experiencia"
"En este negocio no importa tu edad ni tu experiencia. El plan es igual para todas. Lo que importa es aprender las habilidades, y eso se aprende."

### "¿Es una pirámide?"
Si lo dice con emoción: "Parece que te pasó algo. ¿Qué pasó?" Escucha. Luego: "¿Crees que en ese momento le diste una oportunidad justa?"
Y explica con calma: "Las pirámides son ilegales y viven de inscribir gente sin producto real. Esto es venta directa: la ganancia viene de productos que clientas reales compran y usan. Yo nunca estaría en algo ilegal."

### "No me interesan esas cosas de multinivel"
"Sí, esto es venta directa. ¿Qué sabes de ella?" Y escucha. Con preguntas, no con discursos.

### "No quiero molestar a mis amigas"
"¿Qué te hace pensar que las molestarías? Si de verdad te encantara un producto, ¿se lo recomendarías? Te enseño a compartirlo sin que suene a venta."

### "¿Y tú cuánto ganas?"
- Si ya tienes resultados, compártelos con honestidad.
- Si apenas empiezas: "Apenas estoy arrancando y estoy muy emocionada con lo que viene."
- Si llevas tiempo a medio tiempo: "Lo hago a medio tiempo y voy creciendo. Me emociona porque sabía que si no hacía algo distinto, nada iba a cambiar."
- Ofrece conectarla con alguien que tenga más resultados para que platique con ella.

### Lo que nunca
- Nunca prometas ingresos ni digas cifras que no puedas sostener.
- Nunca hagas sentir tonta a la otra persona.
- Nunca discutas para ganar.

## 16 · La plática de arranque
*Herramienta · Lista para tus nuevas*

Úsala con cada persona nueva, en las primeras 48 horas. Toma unos 45 minutos.

### 1 · Celebra (5 min)
- "¡Felicidades por tu decisión! Estoy orgullosa de ti."
- Pregúntale por qué entró y escríbelo. Lo vas a necesitar en sus días malos.

### 2 · Expectativas (5 min)
- "Tu éxito depende de ti. Yo te guío, pero no lo hago por ti. Trabajo contigo, no para ti."
- "Mi meta es que dejes de necesitarme pronto. ¿Te parece?"
- "Cuando estés en un día malo, ¿quieres que te deje en paz o que te recuerde por qué empezaste?" Anota su respuesta.

### 3 · Lista de arranque (20 min)
- Tiene sus productos y los está usando.
- Tiene muestras o testers para compartir.
- Tiene el video de la oportunidad, el catálogo y su link.
- Está en el grupo del equipo y en la app.
- Conoce las fechas de las próximas juntas y del próximo evento grande.
- Entiende lo básico del plan de ganancias (los primeros niveles).
- Conoce los 8 pasos de la invitación (dale el guion).

### 4 · Plan de la primera semana (10 min)
- ¿Quién podría ser su primera clienta?
- ¿Quién podría ser su primera socia?
- ¿A qué junta o evento va a ir?
- ¿Qué necesita para tener su primera ganancia?

### 5 · Tareas con fecha (5 min)
- Lista de 100 nombres para: ______
- Tres invitaciones con los 8 pasos para: ______
- Próxima llamada contigo: ______

### Para cruzar la raya
Celebra en voz alta: su primera clienta, su primera socia, su primera ganancia, su primer evento, cuando sube de nivel. Cada logro la empuja al lado donde es más fácil seguir que renunciar.

## 17 · Tu semana pro
*Herramienta · Rutina y planea-hazlo-revisa*

Una semana sencilla que, repetida, te vuelve profesional. Ajusta los números a tus horas reales.

### Todos los días
- Agrega 2 nombres a tu lista viva.
- Haz al menos 1 invitación con los 8 pasos.
- Cumple todos los seguimientos agendados.
- 10 páginas de un libro o 20 minutos de un audio de crecimiento.
- Usa tus productos. Eres tu primera clienta.

### Cada semana
- Junta los contactos de cada prospecto: que vea, pruebe y platique en la misma semana.
- Ve a una junta de tu equipo (presencial o en línea).
- Cuenta tu historia al menos una vez.
- Si tienes nuevas, revisa sus tareas y celebra sus logros.
- Habla del próximo evento grande con tu equipo.

### Tu planea, hazlo, revisa
**Habilidad de la semana:** ______

**Planea:** ¿Qué voy a hacer, cuántas veces y cuándo?

**Hazlo:** Marca cada vez que lo practiques: ☐ ☐ ☐ ☐ ☐

**Revisa (domingo):**
- ¿Qué salió bien?
- ¿Qué cambiaría?
- ¿Cuál es mi plan mejorado para la próxima semana?

### Tus números de la semana
- Nombres nuevos en la lista: ___
- Invitaciones: ___
- Herramientas vistas (videos, catálogos, muestras): ___
- Seguimientos cumplidos: ___
- Clientas nuevas: ___
- Socias nuevas: ___

No hay semanas buenas ni malas. Hay semanas para aprender.
