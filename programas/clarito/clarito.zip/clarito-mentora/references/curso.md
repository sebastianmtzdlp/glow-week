# Clarito · contenido completo del curso

## 0 · Bienvenida a Clarito
*Empieza aquí · Cómo usar el curso*

Este curso es para que cuando hables de lo que vendes, tu clienta entienda en cinco segundos qué le ofreces, cómo le cambia el día y qué tiene que hacer para tenerlo.

### Por qué existe este curso
Casi todas en el equipo tenemos buen producto. Lo que nos falla muchas veces no es lo que vendemos, sino cómo lo contamos. Publicamos fotos bonitas, mandamos audios largos, ponemos en la bio una frase que suena linda pero no dice nada, y luego nos preguntamos por qué nadie pregunta.

La razón es sencilla: **la gente no compra lo mejor, compra lo que entiende más rápido**. Si tu mensaje cuesta trabajo, tu clienta se va con la que lo dijo más claro, aunque su producto sea peor que el tuyo.

> Si confundes, pierdes. Si lo dices clarito, te escuchan.

### La idea de todo el curso
Todas las películas que te han atrapado siguen casi el mismo camino. Una protagonista quiere algo, se topa con un problema, aparece alguien que la guía, le da un plan y la empuja a actuar. Eso la salva de un final triste y la lleva a un final feliz.

Ese camino ya está grabado en el cerebro de tu clienta. Cuando acomodas tu mensaje en ese orden, ella no tiene que esforzarse para entenderte. Y el cambio más grande de todos es este: **la protagonista es ella, no tú**. Tú eres la guía.

### Cómo está armado
- **Clase 1.** Por qué tu mensaje se pierde entre el ruido y la prueba de los cinco segundos.
- **Clases 2 a 8.** Las siete piezas de tu guion: qué quiere ella, su problema, tú como guía, el plan, la invitación, lo que está en juego y el final feliz.
- **Clase 9.** En quién se convierte tu clienta gracias a ti.
- **Clase 10.** Cómo usar tu guion en tu perfil, tus mensajes y con tu equipo.
- **Herramientas.** Tu guion en una hoja, la revisión de los cinco segundos y un banco de frases.

### Cómo sacarle provecho
1. Lee una clase por día o por semana, como te acomode. Son cortas.
2. Haz el ejercicio de cada clase en el cuaderno de abajo. Cada respuesta llena una parte de tu guion.
3. Al terminar la Clase 8 ya tienes tu guion completo. Pásalo a la hoja de Herramientas y úsalo en todo lo que publiques.

### 🪞 Mírate al espejo
Si una clienta nueva entra hoy a tu perfil, ¿podría decir en cinco segundos qué vendes y por qué le conviene?

### ✍️ Ejercicio
Escribe en una sola frase qué le ofreces a tu clienta. Sin pensarlo mucho. La vamos a mejorar a lo largo del curso y al final la vas a comparar.

### ✅ Tu tarea de la semana
Toma captura de tu perfil (bio, foto y las primeras publicaciones) y guárdala. Es tu "antes".

### 💬 Para compartir en el grupo
Comparte tu frase de hoy. Nadie la va a juzgar: es el punto de partida de todas.

## 1 · Ruido o música
*Clase 1 · Por qué tu mensaje se pierde*

Tu clienta no te ignora porque sea grosera. Te ignora porque su cerebro está diseñado para ahorrar energía.

### El cerebro tiene dos trabajos
Todo el día, sin darse cuenta, el cerebro de tu clienta busca dos cosas: lo que la ayude a estar mejor (verse bien, sentirse segura, ahorrar tiempo o dinero, quedar bien con su gente) y gastar la menor energía posible para entender las cosas.

Por eso comete dos errores quien vende:
1. **Habla de cosas que no ayudan a la clienta.** Cuántos años tiene la marca, dónde está la fábrica, cuántos premios ganó la empresa. Es como contar las sillas de un salón: nadie lo hace. Lo que la gente sí ubica son las salidas, porque eso le sirve.
2. **La hace pensar de más.** Un audio de tres minutos, una publicación con veinte productos, una bio con cinco emojis y tres frases. Entender eso cansa, y lo que cansa, se brinca.

### Ruido o música
El ruido y la música están hechos de lo mismo: sonido. La diferencia es que la música sigue un orden que el cerebro reconoce. Por eso se te queda una canción y no te acuerdas del ruido de la calle.

Tu mensaje funciona igual. Si dices muchas cosas sin orden, es ruido. Si lo acomodas como una historia, es música. Y para que suene a música hay que cortar: todo lo que no ayuda a la historia de tu clienta, sale.

> Cada cosa que publicas o es música para tu clienta o es ruido. No hay en medio.

### La prueba de los cinco segundos
Imagina que alguien que no te conoce ve tu perfil, tu estado de WhatsApp o tu publicación durante cinco segundos. Al terminar debería poder responder:
1. **¿Qué ofreces?**
2. **¿Cómo me mejora la vida?**
3. **¿Qué hago para tenerlo?**

Si no puede, no es que tu producto no sirva. Es que tu mensaje todavía no está claro.

### Un ejemplo
Antes: "✨ Belleza consciente ✨ Mamá, emprendedora, soñadora 💕 Farmasi lover".
Después: "Te ayudo a armar tu rutina de piel en 3 pasos, sin gastar de más. Escríbeme 'RUTINA' y te digo cuál es la tuya".

La primera suena bonita, pero obliga a adivinar. La segunda pasa la prueba en cinco segundos.

### 🪞 Mírate al espejo
¿Qué cosas publicas que a ti te importan pero a tu clienta no le cambian nada?

### ✍️ Ejercicio
1. Abre tu perfil y tu última publicación de venta.
2. Pídele a alguien que no conozca tu negocio que la vea cinco segundos.
3. Pregúntale las tres preguntas y anota lo que te conteste, tal cual.

### ✅ Tu tarea de la semana
Cambia una sola cosa de tu bio para que responda la primera pregunta: qué ofreces.

### 💬 Para compartir en el grupo
Comparte qué respondió la persona que hizo la prueba. Seguro te sorprendió algo.

## 2 · Tu clienta es la protagonista
*Clase 2 · Qué quiere ella*

La historia no se trata de ti ni de tu marca. Se trata de tu clienta. Y toda historia empieza cuando la protagonista quiere algo.

### La pregunta que engancha
En una película, a los pocos minutos ya sabes qué quiere la protagonista: ganar la competencia, recuperar a su familia, conseguir el trabajo. Desde ese momento te quedas viendo porque quieres saber si lo va a lograr.

Con tu clienta pasa igual. En cuanto le dices claramente algo que ella quiere, se abre una pregunta en su cabeza: **¿de verdad me puedes ayudar a tenerlo?** Esa pregunta es la que la hace seguir leyendo. Si no le dices qué quiere, no hay pregunta, y si no hay pregunta, no hay historia.

### Un solo deseo
El error más común es querer decirlo todo: "maquillaje, skincare, cuidado del cabello, perfumes, vitaminas para el cabello, y además te invito al negocio". Cuando ofreces veinte cosas, tu clienta no se queda con ninguna.

Elige **un deseo principal** para tu marca. Lo demás puede venir después, en publicaciones o campañas específicas, como historias secundarias de la misma película.

### Que sea algo que de verdad le importe
El deseo tiene que conectar con algo que la ayude a estar mejor en su vida real. Por ejemplo:
- **Ahorrar dinero:** "Tu maquillaje completo por menos de lo que gastas en un café a la semana".
- **Ahorrar tiempo:** "Lista en 5 minutos para la escuela de los niños".
- **Sentirse parte de algo:** "Un grupo de mujeres que se echan porras".
- **Verse y sentirse bien frente a otros:** "La piel de la que te van a preguntar qué te hiciste".
- **Tener sentido:** "Que lo que compras también ayude a otra mujer a crecer su negocio".

Frases como "belleza que inspira" o "brilla con tu luz" suenan bonitas pero son niebla. Tu clienta no sabe a dónde la llevas.

> Tu clienta es como alguien que pide aventón. Lo único que quiere saber es a dónde vas.

### Ejemplos de deseos claros
- Skincare: "Una rutina que sí vas a seguir".
- Maquillaje: "Verte arreglada en 5 minutos".
- Fragancias: "Un aroma que la gente asocie contigo".
- Para invitar al equipo: "Un negocio que puedes acomodar entre la escuela y la casa".

### 🪞 Mírate al espejo
Si le preguntas a una clienta a dónde la llevas tú, ¿qué te contestaría?

### ✍️ Ejercicio
1. Escribe diez cosas que tus clientas quieren y tú las puedes ayudar a conseguir.
2. Tacha las que suenan bonito pero no se entienden.
3. Encierra **una**. Esa es la primera pieza de tu guion: **Lo que ella quiere**.

### ✅ Tu tarea de la semana
Haz una publicación o historia que diga ese deseo en una frase y nada más.

### 💬 Para compartir en el grupo
Comparte el deseo que elegiste. Pídele al grupo que te diga si se entiende a la primera.

## 3 · La villana y los tres problemas
*Clase 3 · Lo que le estorba*

Cuando hablas del problema de tu clienta, se siente entendida. Y entre más claro lo nombras, más le interesa lo que ofreces.

### Toda historia necesita una villana
Sin alguien o algo que estorbe, no hay historia. Entre más clara la villana, más quieres que gane la protagonista.

La villana de tu clienta no tiene que ser una persona. Puede ser la falta de tiempo, los productos que prometen y no cumplen, el clóset lleno de cosas que no usa, las rutinas de diez pasos imposibles. Lo importante es que tenga cara, que se pueda señalar.

Una buena villana:
1. **Es la causa, no el sentimiento.** La frustración no es villana; es lo que la villana provoca. "Las rutinas complicadas" sí es villana.
2. **Se reconoce al instante.** Tu clienta la oye y dice "¡sí, eso!".
3. **Es una sola.** Tres villanas confunden.
4. **Es real.** Nada de inventar miedos para vender.

### Los tres niveles del problema
La villana le causa a tu clienta tres problemas a la vez:
- **Afuera:** lo que se ve. "Tengo la piel opaca", "no tengo maquillaje para el evento".
- **Adentro:** lo que siente. "Me da pena salir sin base", "me siento descuidada desde que nació el bebé", "me abruma no saber qué comprar".
- **Lo que no es justo:** la creencia de fondo. "Cuidarme no debería ser un lujo", "ninguna mamá debería sentir que no tiene ni cinco minutos para ella".

### El secreto de esta clase
Casi todas vendemos para el problema de afuera: "esta crema hidrata". Pero la gente compra para resolver el de adentro: dejar de sentirse descuidada, sentirse segura otra vez.

Cuando nombras lo que siente, tu clienta piensa: "ella sí me entiende". Y eso vale más que la mejor lista de ingredientes.

> Vendemos soluciones para lo de afuera. Ellas compran soluciones para lo de adentro.

### Un ejemplo completo
- **Villana:** las rutinas complicadas que nadie tiene tiempo de seguir.
- **Afuera:** "Mi piel se ve cansada".
- **Adentro:** "Siento que me dejé de cuidar".
- **No es justo:** "Cuidarte no debería requerir una hora que no tienes".

### 🪞 Mírate al espejo
Piensa en tu mejor clienta. ¿Qué sentía cuando te escribió la primera vez? No qué necesitaba, qué sentía.

### ✍️ Ejercicio
Llena estas cuatro piezas de tu guion:
1. **La villana:** ¿qué le estorba a tu clienta?
2. **Afuera:** ¿qué problema se ve?
3. **Adentro:** ¿cómo la hace sentir?
4. **No es justo:** ¿por qué está mal que tenga que pasar por eso?

### ✅ Tu tarea de la semana
Publica algo que nombre a la villana y el problema de adentro, sin vender todavía. Solo "te entiendo".

### 💬 Para compartir en el grupo
Comparte tu villana. A ver cuántas tenemos la misma.

## 4 · Tú eres la guía
*Clase 4 · Empatía y experiencia*

Tu clienta no está buscando a otra protagonista. Está buscando a alguien que la ayude a ganar.

### El error de querer ser la heroína
Cuando hablamos mucho de nosotras (mis logros, mi viaje, mi auto, mi rango, mi historia), creemos que inspiramos. Pero muchas veces la clienta siente que estamos compitiendo por su atención. Ella ya es la protagonista de su propia vida. Lo que necesita es una guía.

Piensa en las películas: la protagonista casi nunca es la más fuerte. Tiene dudas, no sabe si puede. La guía, en cambio, ya pasó por ahí. Tiene la experiencia. Pero la película no es sobre la guía. La guía solo aparece para ayudar.

> El día que te quite el sueño el éxito de tu clienta, y no el tuyo, tu negocio empieza a crecer.

### Las dos cosas que hacen a una guía
Para que tu clienta te reconozca como su guía, necesita ver dos cosas:

**1. Empatía: "te entiendo".**
Dile que sabes lo que siente. Frases que sirven:
- "Sé lo que es verte al espejo y no reconocerte."
- "Ninguna mamá debería sentir que cuidarse es un lujo."
- "A mí también me abrumaba no saber qué comprar."

La gente confía en quien la entiende. Y no va a saber que te importa hasta que se lo digas.

**2. Experiencia: "sé cómo ayudarte".**
Imagina que vas con una nutrióloga, le dices que quieres bajar de peso y te contesta "¡yo también!". Te sales del consultorio. Tu clienta necesita saber que sabes lo que haces, sin que presumas. Cuatro formas:
- **Testimonios:** dos o tres, cortitos, de clientas reales.
- **Números:** "Más de 200 rutinas armadas", "clientas desde hace 4 años".
- **Reconocimientos:** si te capacitaste o ganaste algo, menciónalo pequeñito.
- **Antes y después reales** del resultado que ellas buscan, con su permiso.

### Primera impresión
Cuando alguien te conoce, en el fondo se pregunta dos cosas: ¿puedo confiar en ella? y ¿sabe lo que hace? La empatía responde la primera. La experiencia, la segunda. Necesitas las dos.

### 🪞 Mírate al espejo
Revisa tus últimas diez publicaciones. ¿En cuántas la protagonista eres tú y en cuántas es tu clienta?

### ✍️ Ejercicio
1. Escribe tres frases de empatía para el problema de adentro de tu clienta (Clase 3).
2. Junta tus pruebas de experiencia: tres testimonios cortos, un número y lo que hayas aprendido.
3. Elige una frase de empatía y una prueba. Esa es la pieza **La guía** de tu guion.

### ✅ Tu tarea de la semana
Pídele a tres clientas un testimonio corto. Pregúntales: "¿Cómo estabas antes y cómo estás ahora?".

### 💬 Para compartir en el grupo
Comparte tu mejor frase de empatía.

## 5 · Dale un plan
*Clase 5 · Los pasos y tus promesas*

Tu clienta ya confía en ti. Pero comprar es un compromiso, y antes de comprometerse necesita ver el camino.

### Piedras en el río
Imagina a tu clienta parada a la orilla de un río. Del otro lado está lo que quiere. Pero escucha una cascada más abajo y piensa: ¿y si me caigo? ¿Y si no me funciona? ¿Y si hago el ridículo comprándolo?

Tu trabajo es poner piedras en el río. Cuando le dices "primero pisas aquí, luego aquí, y ya llegaste", el miedo baja y cruza.

### El plan de pasos
Explícale en tres pasos (máximo seis) cómo hacer negocio contigo o cómo usar lo que compra. Aunque te parezca obvio, para ella no lo es.

Antes de comprar:
1. Escríbeme "RUTINA".
2. Te hago tres preguntas sobre tu piel.
3. Te mando tu rutina con precio y te la llevo a tu casa.

Después de comprar:
1. Mañana: limpiador y sérum.
2. Noche: limpiador y crema.
3. A los 15 días me mandas foto y ajustamos.

Ponle nombre a tu plan: "Tu rutina en 3 pasos", "Plan de 15 días", "Arreglada en 5". Con nombre, se ve más valioso y se recuerda mejor.

> Si no le dices qué sigue, la confundes. Y una clienta confundida no compra.

### Tus promesas
El plan de pasos le quita la confusión. Tus promesas le quitan el miedo.

Escribe todo lo que le preocupa a tu clienta antes de comprarte y responde cada miedo con una promesa:
- "¿Y si no me queda el tono?" → "Te ayudo a elegirlo por videollamada."
- "¿Y si me insiste para entrar al negocio?" → "Si solo quieres comprar, solo compras. Nunca te voy a presionar."
- "¿Y si me deja de contestar después de vender?" → "Te doy seguimiento a los 15 días, siempre."

Tus promesas no tienen que ir en cada publicación. Pueden ir en tus historias destacadas, en tu mensaje de bienvenida o en una tarjeta dentro del pedido. Y solo promete lo que de verdad cumples.

### 🪞 Mírate al espejo
¿Qué le preguntan siempre las clientas antes de comprarte? Esas preguntas son los miedos que tu plan tiene que resolver.

### ✍️ Ejercicio
1. Escribe tu plan de tres pasos y ponle nombre.
2. Haz una lista de cinco miedos de tu clienta y responde cada uno con una promesa que sí cumplas.
3. Anota los pasos y el nombre en la pieza **El plan** de tu guion.

### ✅ Tu tarea de la semana
Arma una historia destacada con tu plan de tres pasos y tus promesas.

### 💬 Para compartir en el grupo
Comparte el nombre de tu plan.

## 6 · Invítala
*Clase 6 · El sí grande y el sí chiquito*

Las protagonistas no actúan solas. Alguien tiene que invitarlas. Y tu clienta no te lee la mente.

### Nadie actúa si no la invitan
En las películas, la protagonista nunca decide cambiar su vida un martes cualquiera porque sí. Algo la empuja. En la vida real pasa igual: la gente no se mueve si nadie la invita a moverse.

A muchas nos da pena pedir la venta. No queremos parecer la vendedora intensa. Pero casi nadie se pasa de insistente: la mayoría pedimos tan bajito que nadie nos oye. Y cuando no invitas con claridad, comunicas que no crees en tu producto.

> Si de verdad le cambia el día, ¿por qué te daría pena invitarla?

### Dos invitaciones
Tu clienta puede estar lista para comprar hoy, o puede no estarlo. Por eso necesitas dos invitaciones, siempre juntas.

**El sí grande (invitación directa).** Lleva a la compra:
- "Pídela aquí."
- "Escríbeme 'QUIERO' y te la aparto."
- "Agenda tu prueba de tono."

**El sí chiquito (invitación puente).** No pide dinero; le da algo de valor para que te conozca:
- Una guía gratis: "Los 5 errores al elegir tu base".
- Un mini diagnóstico: "Responde 3 preguntas y te digo tu tipo de piel".
- Una muestra o una prueba en vivo.
- Un video con testimonios de clientas.

Es como en el amor: el sí grande es "¿te casas conmigo?" y el sí chiquito es "¿salimos otra vez?". Si te dice que no al primero, no se acaba la relación. La invitas a salir de nuevo, le das valor, y cuando esté lista te va a decir que sí.

### Por qué funciona regalar
El sí chiquito hace tres cosas: te ubica como la que sabe del tema, genera ganas de corresponder (cuando das, la gente quiere devolver) y te convierte en su guía. La próxima vez que tenga ese problema, va a pensar en ti.

### Dónde poner tu invitación
- Al final de cada publicación de venta.
- Fija en tu perfil y en tu enlace.
- En tu mensaje de bienvenida de WhatsApp.
- Repetida: la gente no lee, escanea. Tiene que verla varias veces.

### 🪞 Mírate al espejo
En tus últimas cinco publicaciones, ¿cuántas terminan con una invitación clara?

### ✍️ Ejercicio
1. Escribe tu sí grande: una frase con un verbo claro.
2. Inventa tu sí chiquito: algo útil y gratis que puedas dar esta semana.
3. Anótalos en la pieza **La invitación** de tu guion.

### ✅ Tu tarea de la semana
Crea tu sí chiquito (una guía, un mini diagnóstico o un video) y ofrécelo en una publicación junto con tu sí grande.

### 💬 Para compartir en el grupo
Comparte tu idea de sí chiquito. Seguro a otra le da una idea.

## 7 · Lo que está en juego
*Clase 7 · Una pizca de chile*

Si no se gana ni se pierde nada, no hay historia. Y si no pasa nada por no comprarte, tu clienta no tiene por qué comprarte.

### Sin riesgo, no hay historia
Imagina una película donde la bomba era de juguete, o una de amor donde todo sale bien desde el principio. Te aburres. Lo que te tiene al filo del asiento es saber qué puede salir mal.

Tu clienta también se pregunta, en silencio: **¿y qué pasa si no lo compro?** Si tú no le respondes, ella decide que no pasa nada.

### Perder pesa más que ganar
A la gente le duele más perder algo que lo que le alegra ganar lo mismo. Perder 100 pesos se siente peor que encontrarte 100 pesos. Por eso, a veces, mostrar lo que se puede perder mueve más que mostrar lo que se puede ganar.

### Una pizca, no el frasco
Esto es como el chile en la comida. Sin nada, queda simple. Con una pizca, sabe rico. Con mucho, nadie se lo come. Si llenas tu mensaje de miedo, la gente se cierra. Si no pones nada, no le importa.

> Lo que está en juego es chile: una pizca le da sabor, el frasco entero lo arruina.

### Cómo decirlo sin asustar
Un camino en cuatro pasos:
1. **Muéstrale que le puede pasar.** "Casi todas usamos un tono de base que no es el nuestro."
2. **Dile que vale la pena evitarlo.** "Y eso hace que la piel se vea gris en las fotos."
3. **Dale la salida.** "Por eso hago pruebas de tono por videollamada."
4. **Invítala.** "Agenda la tuya aquí."

### Ejemplos de lo que tu clienta quiere evitar
- Gastar en productos que terminan en el cajón.
- Llegar al evento y no sentirse segura en las fotos.
- Seguir sintiendo que no tiene ni cinco minutos para ella.
- Comprar el tono equivocado otra vez.

Siempre real, siempre con cariño. Nada de inventar riesgos ni de prometer que un producto evita problemas de salud.

### 🪞 Mírate al espejo
¿Qué le pasa a tu clienta si sigue igual seis meses más?

### ✍️ Ejercicio
1. Haz una lista de todo lo que tu clienta pierde si no resuelve su problema.
2. Elige tres, los más reales y que menos asusten.
3. Anótalos en la pieza **Lo que está en juego** de tu guion.

### ✅ Tu tarea de la semana
Escribe una publicación con los cuatro pasos: le puede pasar, vale la pena evitarlo, la salida, la invitación.

### 💬 Para compartir en el grupo
Comparte tu frase de "lo que está en juego" y pide al grupo que te diga si se pasa de picante.

## 8 · El final feliz
*Clase 8 · A dónde la llevas*

Nunca des por hecho que tu clienta se imagina cómo le va a cambiar la vida. Díselo.

### La gente quiere que la lleven a algún lado
Una de las mejores ideas sobre liderazgo es esta: la gente quiere que la lleven a algún lado. Le pasa a tu familia, a tu equipo y a tu clienta. Si no le dices a dónde la llevas, se va con quien sí se lo dijo.

### Que sea concreto
"Sentirte increíble" es niebla. "Salir de casa en 5 minutos, con la piel lista y sin pensar qué ponerte" es una escena que tu clienta puede ver. Los finales felices de las buenas historias son específicos: pasa algo concreto a alguien concreto.

### Antes y después
Llena esta tabla para tu clienta:
- **Qué tiene:** antes, un cajón de productos que no usa; después, tres productos que sí usa.
- **Cómo se siente:** antes, abrumada; después, tranquila y segura.
- **Cómo es su día:** antes, sale corriendo sin arreglarse; después, cinco minutos y lista.
- **Cómo la ven:** antes, "¿estás cansada?"; después, "¿qué te hiciste?".

Esa tabla te da frases para un mes de contenido.

> Tu clienta no compra la crema. Compra el momento en que alguien le pregunta qué se hizo.

### Los tres finales que todas queremos
Las historias suelen terminar de una de tres formas, porque son tres cosas que todas deseamos:
1. **Ganar un lugar.** Que la reconozcan, que la vean distinto. Ejemplo: un nivel de "clienta consentida" con beneficios, o acceso antes que nadie a los lanzamientos.
2. **Sentirse completa.** Que algo de afuera le resuelva lo que le falta: menos estrés, menos trabajo, más tiempo.
3. **Aceptarse y crecer.** Llegar a su potencial o sentirse bien como es. Ejemplo: contenido con clientas reales, sin filtros, que dice "así como eres, te ves bien".

### Muéstralo
Las imágenes también cuentan la historia. En lugar de la foto del producto sobre la mesa, muestra a una clienta real (con permiso) contenta, usándolo. Una sonrisa auténtica vende el final feliz mejor que cualquier texto.

### 🪞 Mírate al espejo
¿Cuál de los tres finales le ofrece tu producto a tu clienta?

### ✍️ Ejercicio
1. Llena la tabla de antes y después con tus palabras.
2. Escribe en una frase el final feliz de tu clienta.
3. Anótalo en la pieza **El final feliz** de tu guion. Con esto, tu guion ya está completo.

### ✅ Tu tarea de la semana
Publica una foto o video de una clienta real disfrutando el resultado, con su permiso y su frase.

### 💬 Para compartir en el grupo
Comparte tu frase de final feliz.

## 9 · De quién a quién
*Clase 9 · En quién se convierte gracias a ti*

Debajo de todo lo que tu clienta compra hay un deseo más grande: convertirse en alguien un poquito mejor.

### Todas queremos transformarnos
Al principio de la historia, la protagonista tiene dudas y no se siente capaz. A lo largo del camino aprende, se atreve y, al final, es otra. Esa transformación es la razón por la que amamos las historias, porque es nuestra historia.

Tu clienta no solo quiere una piel más bonita. Quiere ser la mujer que se cuida, la que se ve arreglada sin esfuerzo, la que se da su lugar. Cuando tu marca la acompaña en ese cambio, deja de ser una vendedora más y se vuelve parte de su historia.

### ¿Cómo quiere que hablen de ella?
La mejor manera de encontrar esa identidad es preguntarte: **¿qué le gustaría a tu clienta que dijeran de ella sus amigas?** "Siempre se ve arreglada", "sabe de skincare", "se da tiempo para ella", "es la que siempre huele rico".

Esa frase te da el lenguaje para tu contenido. Ya no hablas solo del producto; hablas de la mujer en la que se está convirtiendo.

> No vendes productos. Acompañas a una mujer a convertirse en la que quiere ser.

### De ___ a ___
Escríbelo así:
- **De** abrumada con mil productos **a** la que tiene su rutina clarita.
- **De** "no tengo tiempo para mí" **a** la que se da cinco minutos todos los días.
- **De** insegura en las fotos **a** la que sale con confianza.
- Para tu equipo: **de** "no sé vender" **a** la que explica su producto con seguridad.

### La guía celebra el cambio
En las películas, cuando la protagonista por fin gana, aparece la guía y le dice: "Mira lo lejos que llegaste". Ese momento es importante porque ella sola no se da cuenta de cuánto cambió.

Tú puedes hacer eso con tus clientas y con tu equipo. Escríbeles para celebrar su avance, comparte (con permiso) su antes y después, y diles en voz alta que son otras. Una clienta que se siente vista se queda contigo para siempre.

### 🪞 Mírate al espejo
¿Quién eras tú antes de empezar con tu negocio, y quién eres ahora? ¿Alguien te lo ha dicho?

### ✍️ Ejercicio
1. Escribe cómo le gustaría a tu clienta que hablaran de ella.
2. Llena tu frase: **De** ___ **a** ___.
3. Anótala en la pieza **De quién a quién** de tu guion.

### ✅ Tu tarea de la semana
Escríbele a una clienta o a alguien de tu equipo para decirle, con detalle, cuánto ha cambiado.

### 💬 Para compartir en el grupo
Comparte tu "de ___ a ___".

## 10 · Úsalo en todos lados
*Clase 10 · Tu perfil, tus mensajes y tu equipo*

Un guion guardado en una libreta no vende. Lo que vende es usarlo en cada cosa que publicas y dices.

### Empieza por tu perfil
Tu perfil (Instagram, TikTok, Facebook o tu catálogo en línea) es lo primero que ve una clienta nueva. Es como una primera cita: no le cuentas tu vida entera, le dices lo justo para que quiera una segunda. Cinco cosas:

1. **Tu oferta, arriba y clara.** En la bio y en tu primera publicación fija: qué ofreces, a quién y qué le cambia. "Rutinas de piel en 3 pasos para mamás con poco tiempo."
2. **Tu invitación, visible y repetida.** Un solo botón o enlace principal, con tu sí grande. Tu sí chiquito, cerca, pero sin competir.
3. **Imágenes del final feliz.** Clientas reales contentas, no solo productos sobre la mesa.
4. **Tus opciones, en pedacitos.** Si vendes varias cosas, busca una frase que las una y separa lo demás en destacadas: "Piel", "Maquillaje", "Aromas", "Únete al equipo".
5. **Pocas palabras.** La gente no lee perfiles, los escanea. Si puedes decir algo en la mitad de palabras, hazlo.

> Si no viene de tu guion, es ruido.

### Tus mensajes
Usa tu guion para armar tus mensajes de WhatsApp en este orden:
1. Lo que ella quiere.
2. El problema de adentro (con empatía).
3. Tu plan en tres pasos.
4. Tu invitación.
5. El final feliz.

No tiene que ser largo. Cinco líneas bastan.

### Con tu equipo
Las clientas no son las únicas que se confunden cuando el mensaje no es claro. Los equipos también. Cuando no hay una historia que una a todas, cada quien jala para su lado.

Si eres líder, aplica el mismo guion al revés: **tu compañera es la protagonista y tú eres su guía**. ¿Qué quiere ella? ¿Qué le estorba? ¿Qué plan le das? ¿A dónde la llevas? Y cada una debería poder contar en una frase la historia de su clienta y cómo la ayuda. Cuando todo el equipo cuenta la misma historia clarita, la gente la repite.

### 🪞 Mírate al espejo
¿Tu equipo, o tu socia, contaría tu negocio con las mismas palabras que tú?

### ✍️ Ejercicio
1. Reescribe tu bio con tu guion: deseo, cómo le ayudas y tu invitación.
2. Reescribe tu mensaje de bienvenida de WhatsApp en cinco líneas.
3. Saca tu captura de "antes" de la Bienvenida y compárala.

### ✅ Tu tarea de la semana
Haz la prueba de los cinco segundos (Herramientas) a tu perfil nuevo con tres personas.

### 💬 Para compartir en el grupo
Comparte tu antes y después del perfil. ¡Celébrense!

## 11 · Tu guion en una hoja
*Herramientas · Las piezas de tu mensaje*

Todo tu mensaje cabe en una hoja. Llénala con lo que escribiste en cada clase y tenla a la mano cada vez que vayas a publicar.

### Las piezas
1. **Lo que ella quiere** (Clase 2): un solo deseo, claro.
2. **La villana** (Clase 3): lo que le estorba.
3. **Afuera** (Clase 3): el problema que se ve.
4. **Adentro** (Clase 3): cómo la hace sentir.
5. **No es justo** (Clase 3): por qué no debería pasar por eso.
6. **La guía** (Clase 4): tu frase de empatía y tu prueba de experiencia.
7. **El plan** (Clase 5): tres pasos con nombre, y tus promesas.
8. **La invitación** (Clase 6): tu sí grande y tu sí chiquito.
9. **Lo que está en juego** (Clase 7): tres cosas que quiere evitar.
10. **El final feliz** (Clase 8): a dónde la llevas.
11. **De quién a quién** (Clase 9): de ___ a ___.

### Un ejemplo lleno
1. Una rutina de piel que sí va a seguir.
2. Las rutinas complicadas.
3. Piel opaca y cansada.
4. Siente que se dejó de cuidar.
5. Cuidarse no debería requerir una hora que no tiene.
6. "Sé lo que es no tener ni cinco minutos." Más de 200 rutinas armadas.
7. "Tu rutina en 3 pasos": me escribes, te pregunto, te la llevo. Si no te gusta, te ayudo a cambiarla.
8. Sí grande: "Escríbeme RUTINA". Sí chiquito: "Responde 3 preguntas y te digo tu tipo de piel".
9. Gastar en productos que no usa, verse cansada en las fotos, seguir sin tiempo para ella.
10. Cinco minutos en la mañana y la piel lista.
11. De abrumada a la que tiene su rutina clarita.

### Cómo usarlo
- Haz un guion para tu marca en general y, si quieres, uno por línea de producto o por tipo de clienta.
- Antes de publicar, pregúntate: ¿esto sale de alguna pieza de mi guion? Si no, es ruido.

> Una hoja, siete piezas, todas tus publicaciones.

## 12 · La prueba de los cinco segundos
*Herramientas · Revisa antes de publicar*

Usa esta lista antes de publicar o cuando sientas que algo no está funcionando.

### La prueba
Enséñale tu perfil o tu publicación a alguien que no conozca tu negocio durante cinco segundos. Después pregúntale:
1. ¿Qué ofrezco?
2. ¿Cómo te mejora la vida?
3. ¿Qué tienes que hacer para tenerlo?

Si duda en alguna, esa es la parte que hay que aclarar.

### La revisión rápida
- ¿La protagonista es mi clienta, no yo?
- ¿Dice un solo deseo, claro?
- ¿Nombra lo que ella siente, no solo lo que se ve?
- ¿Muestro que la entiendo y que sé lo que hago, sin presumir?
- ¿Hay un plan sencillo de qué sigue?
- ¿Termina con una invitación clara?
- ¿Hay una pizca (solo una) de lo que está en juego?
- ¿Se ve el final feliz?
- ¿Usé la menor cantidad de palabras posible?
- ¿Quité todo lo que no sale de mi guion?

### Señales de ruido
- Frases bonitas que no dicen qué vendes.
- Más de un deseo en la misma publicación.
- Palabras técnicas que tu clienta no usa. Di "piel que se ve descansada", no el nombre del ingrediente.
- Audios o textos largos para algo que cabe en tres líneas.
- Ninguna invitación al final.

> Si tienes que explicarlo, todavía no está claro.

## 13 · Banco de frases
*Herramientas · Para cuando no sepas cómo empezar*

Frases para empezar cada pieza de tu mensaje. Úsalas como molde y cámbialas a tu voz.

### Lo que ella quiere
- "Para ti que quieres ___ sin ___."
- "Imagina ___ en solo ___."

### Empatía
- "Sé lo que es ___."
- "Ninguna mujer debería ___."
- "A mí también me pasaba que ___."

### Experiencia
- "Ya van ___ clientas que ___."
- "Esto me dijo ___ después de ___."

### El plan
- "Es así de fácil: 1) ___ 2) ___ 3) ___."
- "Mi promesa: ___."

### La invitación
- Sí grande: "Escríbeme ___ y te ___." / "Aparta el tuyo aquí."
- Sí chiquito: "¿Quieres mi guía gratis de ___?" / "Responde ___ y te digo ___."

### Lo que está en juego
- "Si sigues ___, vas a seguir ___."
- "No dejes que ___ te quite ___."

### Final feliz
- "Imagina que ___."
- "Así se siente cuando ___."
- "De ___ a ___."

### Para tu mensaje de WhatsApp (5 líneas)
1. "Hola, ___. ¿Te gustaría ___?"
2. "Sé que ___ (problema de adentro)."
3. "Lo hacemos en 3 pasos: ___."
4. "Escríbeme ___ y empezamos."
5. "Para que pronto ___ (final feliz)."

> Las mejores frases suenan a ti. Usa estas para arrancar, no para quedarte.
